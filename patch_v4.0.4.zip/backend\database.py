import base64
import hashlib
import secrets
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "postall.db"

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    return "pbkdf2$" + base64.urlsafe_b64encode(salt).decode() + "$" + hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 210000).hex()

def get_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db

def init_db(seed_courses: bool = False):
    db = get_db()
    journal_mode = db.execute("PRAGMA journal_mode=WAL").fetchone()
    if not journal_mode or str(journal_mode[0]).lower() != "wal":
        db.close()
        raise RuntimeError("SQLite WAL mode could not be enabled for the application database.")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS workspaces (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL, persona TEXT DEFAULT 'tech_academy', is_default BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, must_reset INTEGER DEFAULT 1, must_change_password BOOLEAN DEFAULT 0,
      email TEXT DEFAULT '', role TEXT DEFAULT 'admin', is_active BOOLEAN DEFAULT 1,
      last_login_at TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      mfa_secret TEXT DEFAULT NULL, mfa_enabled BOOLEAN DEFAULT 0, sso_provider TEXT DEFAULT 'local');
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS courses (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL,
      description TEXT DEFAULT '', status TEXT DEFAULT 'ACTIVE', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      syllabus_url TEXT DEFAULT '');
    CREATE TABLE IF NOT EXISTS course_syllabus_cache (course_id INTEGER PRIMARY KEY,
      source_url TEXT NOT NULL, topics_json TEXT NOT NULL,
      FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS topics (id INTEGER PRIMARY KEY, course_id INTEGER NOT NULL, title TEXT NOT NULL,
      status TEXT DEFAULT 'PENDING', details TEXT DEFAULT '', target_platforms TEXT DEFAULT '[]',
      content_format TEXT DEFAULT '', last_generated_at TEXT,
      FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS drafts (id INTEGER PRIMARY KEY, course_id INTEGER, topic_id INTEGER, prompt TEXT,
      body TEXT NOT NULL, asset_path TEXT, asset_type TEXT DEFAULT 'infographic', status TEXT DEFAULT 'DRAFT',
      target_platforms TEXT DEFAULT '[]', aspect_ratio TEXT DEFAULT '4:5',
      scheduled_at TEXT, approved_at TEXT, published_at TEXT, rejected_reason TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(course_id) REFERENCES courses(id), FOREIGN KEY(topic_id) REFERENCES topics(id));
    CREATE TABLE IF NOT EXISTS system_logs (id INTEGER PRIMARY KEY, timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
      level TEXT NOT NULL, module TEXT NOT NULL, message TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS api_usage (model TEXT PRIMARY KEY, request_count INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS publish_events (id INTEGER PRIMARY KEY, draft_id INTEGER, status TEXT,
      linkedin_url TEXT, error TEXT, occurred_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS post_archives (id INTEGER PRIMARY KEY, archive_month TEXT UNIQUE NOT NULL,
      archive_path TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS social_publications (
      id INTEGER PRIMARY KEY, draft_id INTEGER NOT NULL, platform TEXT NOT NULL,
      status TEXT NOT NULL, post_url TEXT, error TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(draft_id,platform), FOREIGN KEY(draft_id) REFERENCES drafts(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS action_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token TEXT UNIQUE NOT NULL,
      draft_id INTEGER NOT NULL,
      action_type TEXT NOT NULL,
      expires_at DATETIME NOT NULL,
      used_at DATETIME DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(draft_id) REFERENCES drafts(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category TEXT DEFAULT 'info',
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS trending_cache (
      category TEXT PRIMARY KEY,
      payload_json TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS trending_sources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category_id TEXT NOT NULL,
      category_label TEXT NOT NULL,
      feed_name TEXT NOT NULL,
      feed_url TEXT NOT NULL,
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS update_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      from_version TEXT NOT NULL,
      to_version TEXT NOT NULL,
      git_commit TEXT,
      applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      status TEXT DEFAULT 'SUCCESS',
      applied_by TEXT DEFAULT 'admin',
      details TEXT);
    CREATE TABLE IF NOT EXISTS post_analytics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      draft_id INTEGER NOT NULL,
      platform TEXT DEFAULT 'linkedin',
      post_urn TEXT DEFAULT '',
      post_url TEXT DEFAULT '',
      impressions INTEGER DEFAULT 0,
      clicks INTEGER DEFAULT 0,
      reactions INTEGER DEFAULT 0,
      comments INTEGER DEFAULT 0,
      reposts INTEGER DEFAULT 0,
      engagement_rate REAL DEFAULT 0.0,
      last_polled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(draft_id) REFERENCES drafts(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS siem_audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_id TEXT UNIQUE NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      actor TEXT NOT NULL,
      action TEXT NOT NULL,
      resource_type TEXT NOT NULL,
      resource_id TEXT DEFAULT '',
      status TEXT NOT NULL,
      ip_address TEXT DEFAULT '',
      user_agent TEXT DEFAULT '',
      details_json TEXT DEFAULT '{}',
      shipped_to_siem BOOLEAN DEFAULT 0);
    """)
    # Migration compatibility for the original UI/API.
    db.execute("CREATE VIEW IF NOT EXISTS modules AS SELECT t.id, c.name course_name, t.title topic, t.status FROM topics t JOIN courses c ON c.id=t.course_id")
    for statement in (
        "ALTER TABLE drafts ADD COLUMN notification_sent_at TEXT",
        "ALTER TABLE drafts ADD COLUMN publish_attempts INTEGER DEFAULT 0",
        "ALTER TABLE drafts ADD COLUMN target_platforms TEXT DEFAULT '[]'",
        "ALTER TABLE drafts ADD COLUMN aspect_ratio TEXT DEFAULT '4:5'",
        "ALTER TABLE users ADD COLUMN must_change_password BOOLEAN DEFAULT 0",
        "ALTER TABLE users ADD COLUMN email TEXT DEFAULT ''",
        "ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'admin'",
        "ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT 1",
        "ALTER TABLE users ADD COLUMN last_login_at TEXT DEFAULT ''",
    ):
        try: db.execute(statement)
        except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE drafts ADD COLUMN artifact_path TEXT")
    except sqlite3.OperationalError: pass
    for statement in (
        "ALTER TABLE courses ADD COLUMN syllabus_url TEXT DEFAULT ''",
        "ALTER TABLE topics ADD COLUMN details TEXT DEFAULT ''",
        "ALTER TABLE topics ADD COLUMN source TEXT DEFAULT ''",
        "ALTER TABLE topics ADD COLUMN target_platforms TEXT DEFAULT '[]'",
        "ALTER TABLE topics ADD COLUMN content_format TEXT DEFAULT ''",
        "ALTER TABLE topics ADD COLUMN last_generated_at TEXT",
        "ALTER TABLE api_usage ADD COLUMN prompt_tokens INTEGER DEFAULT 0",
        "ALTER TABLE api_usage ADD COLUMN output_tokens INTEGER DEFAULT 0",
        "ALTER TABLE api_usage ADD COLUMN total_tokens INTEGER DEFAULT 0",
    ):
        try: db.execute(statement)
        except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN custom_hashtags TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN workspace_persona TEXT DEFAULT 'tech_academy'")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN is_setup_complete BOOLEAN DEFAULT 0")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN telemetry_enabled BOOLEAN DEFAULT 1")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN enable_branding BOOLEAN DEFAULT 0")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN custom_brand_name TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN custom_brand_tagline TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN github_repo_url TEXT DEFAULT 'randumduck/Postall_V4-Releases'")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN github_repo TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN github_releases_repo TEXT DEFAULT 'randumduck/Postall_V4-Releases'")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN github_pat TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN update_channel TEXT DEFAULT 'stable'")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN auto_check_updates BOOLEAN DEFAULT 1")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN last_update_check DATETIME DEFAULT NULL")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN dlp_enabled BOOLEAN DEFAULT 1")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN brand_safety_enabled BOOLEAN DEFAULT 1")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN banned_keywords TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN competitor_names TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass

    # Phase 3 (P0) Identity & MFA Migrations
    try: db.execute("ALTER TABLE users ADD COLUMN mfa_secret TEXT DEFAULT NULL")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE users ADD COLUMN mfa_enabled BOOLEAN DEFAULT 0")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE users ADD COLUMN sso_provider TEXT DEFAULT 'local'")
    except sqlite3.OperationalError: pass

    try: db.execute("ALTER TABLE settings ADD COLUMN sso_enabled BOOLEAN DEFAULT 0")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN sso_client_id TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN sso_client_secret TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass
    try: db.execute("ALTER TABLE settings ADD COLUMN sso_metadata_url TEXT DEFAULT ''")
    except sqlite3.OperationalError: pass

    # Phase 4 (P0) Enterprise Storage Migrations
    for col in [
        "storage_backend TEXT DEFAULT 'local'",
        "s3_endpoint_url TEXT DEFAULT ''",
        "s3_bucket_name TEXT DEFAULT 'postall-assets'",
        "s3_region TEXT DEFAULT 'us-east-1'",
        "s3_access_key TEXT DEFAULT ''",
        "s3_secret_key TEXT DEFAULT ''",
    ]:
        try:
            db.execute(f"ALTER TABLE settings ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass

    # Phase 4 (P0) Resilient Distributed Task Queue & Locks
    db.execute("""
    CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        status TEXT DEFAULT 'PENDING',
        priority INTEGER DEFAULT 50,
        payload_json TEXT DEFAULT '{}',
        result_json TEXT DEFAULT '{}',
        error TEXT DEFAULT '',
        retry_count INTEGER DEFAULT 0,
        max_retries INTEGER DEFAULT 3,
        scheduled_for DATETIME DEFAULT CURRENT_TIMESTAMP,
        started_at DATETIME DEFAULT NULL,
        completed_at DATETIME DEFAULT NULL,
        locked_by TEXT DEFAULT NULL,
        lock_expires_at DATETIME DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)
    db.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status, scheduled_for)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_tasks_lock ON tasks(locked_by, lock_expires_at)")

    db.execute("""
    CREATE TABLE IF NOT EXISTS distributed_locks (
        lock_name TEXT PRIMARY KEY,
        locked_by TEXT NOT NULL,
        acquired_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL
    );
    """)

    # Local LLM Self-Learning In-Context Memory
    db.execute("""
    CREATE TABLE IF NOT EXISTS local_llm_memory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        context_key TEXT,
        learning_data TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)
    db.execute("CREATE INDEX IF NOT EXISTS idx_local_memory_key ON local_llm_memory(context_key);")


    # Enterprise SCIM 2.0 & Active State Migrations
    for col in [
        "is_active BOOLEAN DEFAULT 1",
        "email TEXT DEFAULT ''",
        "external_id TEXT DEFAULT ''",
    ]:
        try:
            db.execute(f"ALTER TABLE users ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass

    # Enterprise Maker-Checker & Dual-Authorization Migrations
    for col in [
        "approval_status TEXT DEFAULT 'NONE'",
        "author_id INTEGER DEFAULT NULL",
        "author_username TEXT DEFAULT ''",
        "approved_by INTEGER DEFAULT NULL",  # reviewer user_id for 4-eyes audit trail
    ]:
        try:
            db.execute(f"ALTER TABLE drafts ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass

    for col in [
        "scim_enabled BOOLEAN DEFAULT 0",
        "scim_token TEXT DEFAULT ''",
        "maker_checker_enabled BOOLEAN DEFAULT 0",
    ]:
        try:
            db.execute(f"ALTER TABLE settings ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass

    # Dual-Authorization Approvals Table (Maker-Checker 4-Eyes Compliance)
    db.execute("""
    CREATE TABLE IF NOT EXISTS approvals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        draft_id INTEGER NOT NULL,
        workspace_id INTEGER DEFAULT 1,
        requester_id INTEGER NOT NULL,
        requester_username TEXT NOT NULL,
        reviewer_id INTEGER DEFAULT NULL,
        reviewer_username TEXT DEFAULT NULL,
        status TEXT DEFAULT 'PENDING',
        notes TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME DEFAULT NULL,
        FOREIGN KEY(draft_id) REFERENCES drafts(id),
        FOREIGN KEY(requester_id) REFERENCES users(id)
    );
    """)
    db.execute("CREATE INDEX IF NOT EXISTS idx_approvals_draft ON approvals(draft_id)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_approvals_status ON approvals(status)")

    # Granular Workspace ABAC Memberships Table
    db.execute("""
    CREATE TABLE IF NOT EXISTS workspace_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workspace_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role TEXT NOT NULL DEFAULT 'editor',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(workspace_id, user_id),
        FOREIGN KEY(workspace_id) REFERENCES workspaces(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    db.execute("CREATE INDEX IF NOT EXISTS idx_ws_members ON workspace_members(workspace_id, user_id)")

    # Phase 2 (P1) Multi-Tenant Workspaces
    db.execute("""
    CREATE TABLE IF NOT EXISTS workspaces (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        persona TEXT DEFAULT 'tech_academy',
        is_default BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)

    try:
        ws_count = db.execute("SELECT COUNT(*) FROM workspaces").fetchone()[0]
        if ws_count == 0:
            db.execute("INSERT INTO workspaces (id, name, slug, persona, is_default) VALUES (1, 'Default Workspace', 'default', 'tech_academy', 1)")
    except Exception:
        pass

    for table in ["courses", "topics", "drafts", "settings", "system_logs", "post_analytics"]:
        try:
            db.execute(f"ALTER TABLE {table} ADD COLUMN workspace_id INTEGER DEFAULT 1 REFERENCES workspaces(id)")
        except sqlite3.OperationalError:
            try:
                db.execute(f"ALTER TABLE {table} ADD COLUMN workspace_id INTEGER DEFAULT 1")
            except sqlite3.OperationalError:
                pass
        try:
            db.execute(f"UPDATE {table} SET workspace_id = 1 WHERE workspace_id IS NULL")
        except sqlite3.OperationalError:
            pass

    db.execute("""INSERT OR IGNORE INTO settings(key,value) VALUES
      ('post_time','09:00'),('notification_time','08:00'),('timezone','Asia/Kolkata'),
      ('smtp_host',''),('smtp_port','587'),('smtp_sender',''),('smtp_receiver',''),
      ('enable_gemini_api','0'),('enable_local_llm','1'),('gemini_configured','0'),('dry_run_mode','0'),
      ('dlp_enabled','1'),('brand_safety_enabled','1'),
      ('banned_keywords',''),('competitor_names',''),
      ('sso_enabled','0'),('sso_client_id',''),('sso_client_secret',''),('sso_metadata_url',''),
      ('storage_backend','local'),('s3_endpoint_url',''),('s3_bucket_name','postall-assets'),('s3_region','us-east-1'),('s3_access_key',''),('s3_secret_key',''),
      ('gemini_api_key',''),('gemini_api_key_1',''),('gemini_api_key_2',''),
      ('ai_primary_model','gemini-flash-lite-latest'),('ai_temperature','0.7'),
      ('workspace_persona','tech_academy'),
      ('active_license_key',''),('last_known_timestamp','0.0'),('license_activated_at',''),('license_hwid_bound',''),
      ('ai_provider','local'),
      ('ai_provider_status','ready'),
      ('openai_api_key',''),('openai_base_url','https://api.openai.com/v1'),('openai_model','gpt-4o'),
      ('deepseek_api_key',''),('deepseek_base_url','https://api.deepseek.com/v1'),('deepseek_model','deepseek-chat'),
      ('mistral_api_key',''),('mistral_base_url','https://api.mistral.ai/v1'),('mistral_model','mistral-large-latest'),
      ('claude_api_key',''),('claude_model','claude-3-5-sonnet-20241022'),
      ('custom_ai_api_key',''),('custom_ai_base_url','http://localhost:11434/v1'),('custom_ai_model','llama3'),
      ('linkedin_access_token',''),('x_api_key',''),('x_api_secret',''),
      ('x_access_token',''),('x_access_token_secret',''),('x_user_access_token',''),
      ('custom_hashtags',''),
      ('server_base_url','http://172.19.74.165:8000'),
      ('slack_webhook_url',''),('teams_webhook_url',''),
      ('alert_on_draft_ready','1'),('alert_on_publish_success','1'),('alert_on_failure','1'),
      ('autopilot_enabled','0'),('autopilot_buffer_days','3'),
      ('ldap_host',''),('ldap_domain',''),('ldap_base_dn',''),('ldap_port','389'),('ldap_use_ssl','0')""")
    for k, v in [
        ('custom_hashtags', ''),
        ('workspace_persona', 'tech_academy'),
        ('ai_provider', 'local'),
        ('ai_provider_status', 'ready'),
        ('openai_api_key', ''),
        ('openai_base_url', 'https://api.openai.com/v1'),
        ('openai_model', 'gpt-4o'),
        ('deepseek_api_key', ''),
        ('deepseek_base_url', 'https://api.deepseek.com/v1'),
        ('deepseek_model', 'deepseek-chat'),
        ('mistral_api_key', ''),
        ('mistral_base_url', 'https://api.mistral.ai/v1'),
        ('mistral_model', 'mistral-large-latest'),
        ('claude_api_key', ''),
        ('claude_model', 'claude-3-5-sonnet-20241022'),
        ('custom_ai_api_key', ''),
        ('custom_ai_base_url', 'http://localhost:11434/v1'),
        ('custom_ai_model', 'llama3'),
        ('server_base_url', 'http://172.19.74.165:8000'),
        ('slack_webhook_url', ''),
        ('teams_webhook_url', ''),
        ('alert_on_draft_ready', '1'),
        ('alert_on_publish_success', '1'),
        ('alert_on_failure', '1'),
        ('autopilot_enabled', '0'),
        ('autopilot_buffer_days', '3'),
        ('ldap_host', ''),
        ('ldap_domain', ''),
        ('ldap_base_dn', ''),
        ('ldap_port', '389'),
        ('ldap_use_ssl', '0'),
        ('sso_enabled', '0'),
        ('sso_client_id', ''),
        ('sso_client_secret', ''),
        ('sso_metadata_url', ''),
        ('is_setup_complete', '0'),
        ('telemetry_enabled', '1'),
        ('enable_branding', '0'),
        ('custom_brand_name', ''),
        ('custom_brand_tagline', ''),
        ('github_repo_url', 'randumduck/Postall_V4-Releases'),
        ('github_repo', 'randumduck/Postall_V4-Releases'),
        ('github_releases_repo', 'randumduck/Postall_V4-Releases'),
        ('github_pat', ''),
        ('update_channel', 'stable'),
        ('auto_check_updates', '1'),
        ('last_update_check', ''),
    ]:
        try: db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
        except sqlite3.OperationalError: pass
    db.execute(
        "UPDATE settings SET value=? WHERE key IN ('github_repo_url','github_repo','github_releases_repo') AND value LIKE 'yourusername/%'",
        ('randumduck/Postall_V4-Releases',)
    )

    # If is_setup_complete is not yet recorded, check if this is an established instance with active drafts
    if not db.execute("SELECT 1 FROM settings WHERE key='is_setup_complete'").fetchone():
        has_existing_data = False
        try:
            if db.execute("SELECT COUNT(*) FROM drafts").fetchone()[0] > 0:
                has_existing_data = True
        except Exception:
            pass
        init_val = "1" if has_existing_data else "0"
        db.execute("INSERT INTO settings(key, value) VALUES ('is_setup_complete', ?)", (init_val,))

    timezone_migration=db.execute("SELECT value FROM settings WHERE key='timezone_default_migrated'").fetchone()
    if not timezone_migration:
        db.execute("UPDATE settings SET value='Asia/Kolkata' WHERE key='timezone' AND value='UTC'")
        db.execute("INSERT INTO settings(key,value) VALUES('timezone_default_migrated','1')")
    
    # Ensure existing users have a defined role and active status
    db.execute("UPDATE users SET role='admin' WHERE role IS NULL OR role=''")
    db.execute("UPDATE users SET is_active=1 WHERE is_active IS NULL")

    if not db.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
        db.execute("INSERT INTO users(username,password_hash,role,is_active,must_reset,must_change_password) VALUES ('admin',?,'admin',1,1,0)", (hash_password("admin"),))
    db.commit(); db.close()

def checkpoint_db():
    """Flushes SQLite WAL to main database file."""
    try:
        db = get_db()
        db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        db.close()
    except Exception:
        pass

def purge_all_tables(seed_courses: bool = False):
    """Purges all tables and re-seeds default admin and settings without re-inserting old courses."""
    db = get_db()
    db.execute("PRAGMA foreign_keys=OFF")
    tables = [
        "action_tokens", "notifications", "social_publications", "publish_events", "post_archives",
        "drafts", "topics", "course_syllabus_cache", "courses",
        "system_logs", "api_usage", "trending_cache", "trending_sources", "settings", "users"
    ]
    for tbl in tables:
        try:
            db.execute(f"DELETE FROM {tbl}")
        except sqlite3.OperationalError:
            pass
    try:
        db.execute("DELETE FROM sqlite_sequence")
    except sqlite3.OperationalError:
        pass
    db.execute("PRAGMA foreign_keys=ON")
    db.commit()
    db.close()
    checkpoint_db()
    init_db(seed_courses=seed_courses)
    # Ensure is_setup_complete is explicitly set to 0 on factory reset
    set_setup_completed(False)

def is_setup_completed() -> bool:
    """Returns True if the initial setup wizard has been successfully completed."""
    try:
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key='is_setup_complete'").fetchone()
        db.close()
        if row:
            val = str(row["value"]).strip().lower()
            return val in ("1", "true", "yes", "completed")
        return False
    except Exception:
        return False

def set_setup_completed(completed: bool = True, telemetry: bool = True):
    """Updates setup completion status and telemetry preference in SQLite settings."""
    try:
        db = get_db()
        val_setup = "1" if completed else "0"
        val_telemetry = "1" if telemetry else "0"
        db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('is_setup_complete', ?)", (val_setup,))
        db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('telemetry_enabled', ?)", (val_telemetry,))
        try:
            db.execute("UPDATE settings SET is_setup_complete = ?, telemetry_enabled = ?", (1 if completed else 0, 1 if telemetry else 0))
        except Exception:
            pass
        db.commit()
        db.close()
    except Exception as exc:
        print(f"Error setting setup status: {exc}")

def check_data_volume_persistence() -> dict:
    """
    Attempts to write and delete a temporary 1KB file in data/ to verify write permissions
    and volume persistence. Also checks if running in an unmounted Docker container.
    """
    test_file = DB_PATH.parent / ".volume_persistence_probe"
    is_docker = Path("/.dockerenv").is_file() or Path("/run/.containerenv").is_file()
    
    docker_mounted = True
    if is_docker:
        try:
            with open("/proc/mounts", "r") as f:
                mounts = f.read()
                docker_mounted = ("/app/data" in mounts) or ("Postall_V4/data" in mounts)
        except Exception:
            docker_mounted = False

    try:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = b"POSTALL_STORAGE_PROBE_" + b"0" * 1000
        test_file.write_bytes(payload)
        
        if not test_file.is_file() or test_file.stat().st_size < 1000:
            return {
                "persistent": False,
                "docker_detected": is_docker,
                "volume_mounted": False,
                "detail": "Failed write/readback verification on storage volume."
            }
            
        test_file.unlink(missing_ok=True)
        
        if is_docker and not docker_mounted:
            return {
                "persistent": False,
                "docker_detected": True,
                "volume_mounted": False,
                "detail": "Docker container detected without a persistent volume mounted at /app/data. Data will be lost upon container restart."
            }
            
        return {
            "persistent": True,
            "docker_detected": is_docker,
            "volume_mounted": True if not is_docker else docker_mounted,
            "detail": "Storage directory is persistent and verified writable (1024 bytes probe verified)."
        }
    except Exception as exc:
        try:
            if test_file.exists():
                test_file.unlink(missing_ok=True)
        except Exception:
            pass
        return {
            "persistent": False,
            "docker_detected": is_docker,
            "volume_mounted": False,
            "detail": f"Storage volume write failed: {exc}"
        }

def get_branding_settings() -> dict:
    """Returns the current white-label branding configuration."""
    try:
        db = get_db()
        rows = db.execute("SELECT key, value FROM settings WHERE key IN ('enable_branding', 'custom_brand_name', 'custom_brand_tagline')").fetchall()
        db.close()
        cfg = {r["key"]: r["value"] for r in rows}
        enable_branding = cfg.get("enable_branding") in ("1", "true", "True", True, 1)
        return {
            "enable_branding": enable_branding,
            "custom_brand_name": cfg.get("custom_brand_name", "").strip(),
            "custom_brand_tagline": cfg.get("custom_brand_tagline", "").strip()
        }
    except Exception:
        return {"enable_branding": False, "custom_brand_name": "", "custom_brand_tagline": ""}

def set_branding_settings(enable_branding: bool, custom_brand_name: str, custom_brand_tagline: str):
    """Updates white-label branding settings in SQLite."""
    db = get_db()
    db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('enable_branding', ?)", ("1" if enable_branding else "0",))
    db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('custom_brand_name', ?)", (custom_brand_name.strip(),))
    db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('custom_brand_tagline', ?)", (custom_brand_tagline.strip(),))
    db.commit()
    db.close()

def add_notification(category: str, title: str, message: str) -> int:
    """Inserts a system notification alert."""
    db = get_db()
    cursor = db.execute(
        "INSERT INTO notifications (category, title, message, is_read) VALUES (?, ?, ?, 0)",
        (category, title, message)
    )
    db.commit()
    nid = cursor.lastrowid
    db.close()
    return nid

def get_notifications(limit: int = 50, unread_only: bool = False):
    """Fetches system notifications ordered by most recent."""
    db = get_db()
    query = "SELECT id, category, title, message, is_read, created_at FROM notifications"
    if unread_only:
        query += " WHERE is_read = 0"
    query += " ORDER BY id DESC LIMIT ?"
    rows = [dict(r) for r in db.execute(query, (limit,)).fetchall()]
    db.close()
    return rows

def mark_all_notifications_read() -> int:
    """Marks all unread notifications as read."""
    db = get_db()
    cursor = db.execute("UPDATE notifications SET is_read = 1 WHERE is_read = 0")
    db.commit()
    cnt = cursor.rowcount
    db.close()
    return cnt

def get_unread_notifications_count() -> int:
    """Returns total count of unread notifications."""
    db = get_db()
    row = db.execute("SELECT COUNT(*) as cnt FROM notifications WHERE is_read = 0").fetchone()
    db.close()
    return int(row["cnt"]) if row else 0


# ==============================================================================
# ENTERPRISE USER MANAGEMENT & RBAC HELPERS
# ==============================================================================

def get_all_users() -> list:
    """Returns all system users excluding password hashes."""
    db = get_db()
    rows = db.execute(
        "SELECT id, username, email, role, is_active, must_reset, must_change_password, mfa_enabled, sso_provider, last_login_at, created_at FROM users ORDER BY id ASC"
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]

def get_user_by_id(user_id: int):
    """Retrieves a single user record by numeric ID."""
    db = get_db()
    row = db.execute(
        "SELECT id, username, email, role, is_active, must_reset, must_change_password, mfa_enabled, sso_provider, last_login_at, created_at FROM users WHERE id=?",
        (user_id,)
    ).fetchone()
    db.close()
    return dict(row) if row else None

def get_user_by_username(username: str, include_hash: bool = False):
    """Retrieves user by unique username string."""
    db = get_db()
    if include_hash:
        row = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    else:
        row = db.execute(
            "SELECT id, username, email, role, is_active, must_reset, must_change_password, mfa_enabled, sso_provider, last_login_at, created_at FROM users WHERE username=?",
            (username,)
        ).fetchone()
    db.close()
    return dict(row) if row else None

def create_user(username: str, password_hash: str, role: str = "editor", email: str = "", must_change_password: bool = False) -> int:
    """Inserts a new system user with designated role and email."""
    db = get_db()
    cursor = db.execute(
        "INSERT INTO users (username, password_hash, role, is_active, email, must_reset, must_change_password) VALUES (?, ?, ?, 1, ?, 0, ?)",
        (username.strip(), password_hash, role.strip().lower(), email.strip(), 1 if must_change_password else 0)
    )
    db.commit()
    uid = cursor.lastrowid
    db.close()
    return uid

def update_user(user_id: int, role: str = None, email: str = None, is_active: bool = None, password_hash: str = None, must_change_password: bool = None) -> bool:
    """Updates attributes for an existing user."""
    db = get_db()
    updates = []
    params = []
    if role is not None:
        updates.append("role = ?")
        params.append(role.strip().lower())
    if email is not None:
        updates.append("email = ?")
        params.append(email.strip())
    if is_active is not None:
        updates.append("is_active = ?")
        params.append(1 if is_active else 0)
    if password_hash is not None:
        updates.append("password_hash = ?")
        params.append(password_hash)
    if must_change_password is not None:
        updates.append("must_change_password = ?")
        params.append(1 if must_change_password else 0)

    if not updates:
        db.close()
        return True

    params.append(user_id)
    sql = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
    db.execute(sql, tuple(params))
    db.commit()
    db.close()
    return True

def delete_user(user_id: int) -> bool:
    """Deletes a user record by ID."""
    db = get_db()
    db.execute("DELETE FROM users WHERE id = ?", (user_id,))
    db.commit()
    db.close()
    return True

DEFAULT_TRENDING_SOURCES = [
    # Cybersecurity & CVEs
    ("cybersecurity", "Cybersecurity & CVEs", "The Hacker News", "https://feeds.feedburner.com/TheHackersNews"),
    ("cybersecurity", "Cybersecurity & CVEs", "Security Affairs", "https://securityaffairs.com/feed"),
    ("cybersecurity", "Cybersecurity & CVEs", "CISA Advisories", "https://www.cisa.gov/cybersecurity-advisories.xml"),
    # Tech & Cloud
    ("technology", "Tech & Cloud", "TechCrunch", "https://techcrunch.com/feed/"),
    ("technology", "Tech & Cloud", "Ars Technica", "https://feeds.arstechnica.com/arstechnica/index"),
    ("technology", "Tech & Cloud", "The Verge", "https://www.theverge.com/rss/index.xml"),
    # AI & ML
    ("ai_data", "AI & ML", "MIT Technology Review AI", "https://www.technologyreview.com/topic/artificial-intelligence/feed"),
    ("ai_data", "AI & ML", "VentureBeat AI", "https://venturebeat.com/category/ai/feed/"),
    # Business & ROI
    ("business_finance", "Business & ROI", "MarketWatch Top Stories", "https://feeds.content.dowjones.io/public/rss/mw_topstories"),
    ("business_finance", "Business & ROI", "Yahoo Finance", "https://finance.yahoo.com/news/rssindex"),
    # Fashion & Trends
    ("fashion_lifestyle", "Fashion & Trends", "Vogue Business", "https://www.vogue.com/feed/rss"),
    ("fashion_lifestyle", "Fashion & Trends", "Fashionista", "https://fashionista.com/.rss/excerpt/"),
]

def seed_default_trending_sources(db):
    """Pre-seeds default enterprise RSS feed sources if the trending_sources table is empty."""
    try:
        cur = db.execute("SELECT COUNT(*) as cnt FROM trending_sources")
        row = cur.fetchone()
        if row and row["cnt"] == 0:
            for cat_id, cat_lbl, fname, furl in DEFAULT_TRENDING_SOURCES:
                db.execute(
                    "INSERT INTO trending_sources (category_id, category_label, feed_name, feed_url, is_active) VALUES (?, ?, ?, ?, 1)",
                    (cat_id, cat_lbl, fname, furl)
                )
    except Exception:
        pass

def get_trending_sources(category_id: str = None) -> list:
    """Returns all trending RSS sources, optionally filtered by category_id."""
    db = get_db()
    if category_id:
        rows = db.execute(
            "SELECT * FROM trending_sources WHERE category_id = ? ORDER BY id ASC",
            (category_id,)
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM trending_sources ORDER BY category_id, id ASC").fetchall()
    db.close()
    return [dict(r) for r in rows]

def get_trending_categories_summary() -> list:
    """Returns distinct categories with active/total source counts."""
    db = get_db()
    rows = db.execute("""
        SELECT category_id, category_label,
               COUNT(*) as total_feeds,
               SUM(CASE WHEN is_active=1 THEN 1 ELSE 0 END) as active_feeds
        FROM trending_sources
        GROUP BY category_id, category_label
        ORDER BY MIN(id) ASC
    """).fetchall()
    db.close()
    icon_map = {
        "cybersecurity": "🛡️",
        "technology": "💻",
        "ai_data": "🤖",
        "business_finance": "📈",
        "fashion_lifestyle": "👗",
    }
    res = []
    for r in rows:
        cid = r["category_id"]
        res.append({
            "id": cid,
            "category_id": cid,
            "label": r["category_label"],
            "category_label": r["category_label"],
            "icon": icon_map.get(cid, "📡"),
            "total_feeds": r["total_feeds"],
            "active_feeds": r["active_feeds"],
            "feed_count": r["active_feeds"]
        })
    return res

def add_trending_source(category_id: str, category_label: str, feed_name: str, feed_url: str) -> int:
    """Adds a new trending RSS source and clears the category's cache."""
    db = get_db()
    cursor = db.execute(
        "INSERT INTO trending_sources (category_id, category_label, feed_name, feed_url, is_active) VALUES (?, ?, ?, ?, 1)",
        (category_id.strip().lower(), category_label.strip(), feed_name.strip(), feed_url.strip())
    )
    db.execute("DELETE FROM trending_cache WHERE category = ?", (category_id.strip().lower(),))
    db.commit()
    sid = cursor.lastrowid
    db.close()
    return sid

def delete_trending_source(source_id: int) -> bool:
    """Deletes a trending source by ID and clears the category's cache."""
    db = get_db()
    row = db.execute("SELECT category_id FROM trending_sources WHERE id = ?", (source_id,)).fetchone()
    if row:
        cat_id = row["category_id"]
        db.execute("DELETE FROM trending_cache WHERE category = ?", (cat_id,))
    db.execute("DELETE FROM trending_sources WHERE id = ?", (source_id,))
    db.commit()
    db.close()
    return True

def toggle_trending_source(source_id: int, is_active: bool) -> bool:
    """Toggles active state of a trending source and clears the category's cache."""
    db = get_db()
    row = db.execute("SELECT category_id FROM trending_sources WHERE id = ?", (source_id,)).fetchone()
    if row:
        cat_id = row["category_id"]
        db.execute("DELETE FROM trending_cache WHERE category = ?", (cat_id,))
    db.execute("UPDATE trending_sources SET is_active = ? WHERE id = ?", (1 if is_active else 0, source_id))
    db.commit()
    db.close()
    return True
