/**
 * Postall_V4 — Enterprise Setup Wizard Controller
 * Manages 5-step initialization, storage persistence probe, Ed25519 activation,
 * AI router baseline, and Golden Sand canvas particle simulation.
 */

let currentStep = 1;
const TOTAL_STEPS = 5;
let volumeCheckResult = { persistent: false };

// ==============================================================================
// 1. GOLDEN SAND PARTICLE MESH SIMULATION
// ==============================================================================
(function initParticleMesh() {
    const canvas = document.getElementById("meshCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener("resize", () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const NUM_PARTICLES = Math.min(65, Math.floor((width * height) / 22000));
    const CONNECT_DIST = 130;

    for (let i = 0; i < NUM_PARTICLES; i++) {
        particles.push({
            x: Math.random() * width,
            y: Math.random() * height,
            vx: (Math.random() - 0.5) * 0.45,
            vy: (Math.random() - 0.5) * 0.45,
            size: Math.random() * 1.8 + 0.8,
            alpha: Math.random() * 0.5 + 0.25
        });
    }

    function render() {
        ctx.clearRect(0, 0, width, height);

        // Draw connecting lines
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < CONNECT_DIST) {
                    const lineAlpha = (1 - dist / CONNECT_DIST) * 0.18;
                    ctx.strokeStyle = `rgba(212, 175, 55, ${lineAlpha})`;
                    ctx.lineWidth = 0.75;
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.stroke();
                }
            }
        }

        // Draw particle nodes
        for (const p of particles) {
            p.x += p.vx;
            p.y += p.vy;

            if (p.x < 0) p.x = width;
            if (p.x > width) p.x = 0;
            if (p.y < 0) p.y = height;
            if (p.y > height) p.y = 0;

            ctx.fillStyle = `rgba(245, 208, 97, ${p.alpha})`;
            ctx.shadowColor = "rgba(212, 175, 55, 0.4)";
            ctx.shadowBlur = 6;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }

        requestAnimationFrame(render);
    }
    render();
})();

// ==============================================================================
// 2. TOAST NOTIFICATIONS HELPER
// ==============================================================================
function showToast(message, type = "error") {
    const existing = document.querySelector(".toast-box");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.className = `toast-box ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transition = "opacity 0.3s ease";
        setTimeout(() => toast.remove(), 300);
    }, 4500);
}

// ==============================================================================
// 3. STEP 1: PRE-FLIGHT STORAGE & VOLUME CHECK
// ==============================================================================
async function executeVolumeCheck() {
    const loadingBox = document.getElementById("volume-probe-loading");
    const container = document.getElementById("volume-status-container");
    const nextBtn = document.getElementById("btn-wizard-next");

    try {
        const res = await fetch("/api/setup/check-volume");
        const data = await res.json();
        volumeCheckResult = data;

        if (loadingBox) loadingBox.style.display = "none";
        if (!container) return;

        container.style.display = "block";

        if (data.persistent) {
            container.innerHTML = `
                <div class="volume-status-box success">
                    <div class="volume-icon-box">
                        <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    </div>
                    <div class="volume-text">
                        <h4>Storage Persistence Verified</h4>
                        <p>${data.detail || "1024-byte probe write & readback succeeded. Data storage is persistent."}</p>
                        <div style="margin-top: 6px; font-family: var(--font-mono); font-size: 11px; color: #34d399;">
                            ✓ SQLite WAL and Ed25519 license files will safely persist.
                        </div>
                    </div>
                </div>
            `;
            if (nextBtn) nextBtn.disabled = false;
        } else {
            // Critical Red Danger Warning
            container.innerHTML = `
                <div class="volume-status-box danger">
                    <div class="volume-icon-box">
                        <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                    </div>
                    <div class="volume-text">
                        <h4>Docker Volume Not Mounted — High Risk Warning</h4>
                        <p>${data.detail || "The container is running without a persistent volume mount at /app/data. All settings, database posts, and licenses will be permanently lost when the container is recreated or stopped."}</p>
                        
                        <div style="margin-top: 8px; font-size: 11.5px; color: #fca5a5;">
                            To ensure persistent data across restarts, start your container with a host mount:
                        </div>
                        <div class="docker-command-snippet">docker run -d -p 8000:8000 -v $(pwd)/data:/app/data postall:v4</div>

                        <label class="ack-checkbox-wrap">
                            <input type="checkbox" id="ack-unmounted-volume" onchange="toggleAckVolume(this.checked)">
                            <span>I understand the risks of unmounted container storage and choose to proceed in ephemeral evaluation mode.</span>
                        </label>
                    </div>
                </div>
            `;
            if (nextBtn) nextBtn.disabled = true;
        }
    } catch (err) {
        if (loadingBox) loadingBox.style.display = "none";
        if (container) {
            container.style.display = "block";
            container.innerHTML = `
                <div class="volume-status-box danger">
                    <div class="volume-text">
                        <h4>Probe Communication Error</h4>
                        <p>${err.message}</p>
                    </div>
                </div>
            `;
        }
    }
}

function toggleAckVolume(isChecked) {
    const nextBtn = document.getElementById("btn-wizard-next");
    if (nextBtn) {
        nextBtn.disabled = !isChecked;
    }
}

// ==============================================================================
// 4. STEP 2: CREDENTIALS & LICENSE VALIDATION
// ==============================================================================
function togglePasswordVisibility(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const isPw = input.type === "password";
    input.type = isPw ? "text" : "password";
    btn.style.color = isPw ? "var(--gold-light)" : "var(--text-muted)";
}

function useDemoEvaluationKey() {
    const keyField = document.getElementById("setup-license-key");
    if (keyField) {
        keyField.value = "";
        keyField.placeholder = "Operating in 3-Day Demo Evaluation Mode (Ed25519 signature requirement deferred for 72 hours).";
        showToast("Demo Evaluation Mode selected (72-hour trial).", "success");
    }
}

function handleLicenseFileLoad(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        const text = e.target.result;
        const keyField = document.getElementById("setup-license-key");
        if (keyField) {
            keyField.value = text.trim();
            showToast(`Loaded license key from ${file.name}`, "success");
        }
    };
    reader.readAsText(file);
}

// ==============================================================================
// 5. STEP 3: PERSONA SELECTION
// ==============================================================================
function selectPersona(personaId, cardEl) {
    document.querySelectorAll(".persona-card").forEach(c => c.classList.remove("selected"));
    if (cardEl) cardEl.classList.add("selected");
    const hidden = document.getElementById("setup-selected-persona");
    if (hidden) hidden.value = personaId;
}

// ==============================================================================
// 6. STEP 4: AI PROVIDER & LDAP ENGINE
// ==============================================================================
function handleAiProviderChange(provider) {
    const customFields = document.getElementById("custom-ai-fields");
    const keyLabel = document.getElementById("setup-key-label");
    const keyInput = document.getElementById("setup-ai-api-key");
    const keyGroup = keyInput?.closest(".form-group");
    const baseUrlInput = document.getElementById("setup-ai-base-url");
    const modelInput = document.getElementById("setup-ai-model");

    const labelMap = {
        local: "Local Qwen Engine",
        gemini: "Gemini API Key",
        openai: "OpenAI API Key",
        deepseek: "DeepSeek API Key",
        mistral: "Mistral API Key",
        claude: "Anthropic Claude API Key",
        custom: "Provider API Key"
    };

    if (keyLabel) keyLabel.textContent = labelMap[provider] || "API Key";
    if (keyGroup) keyGroup.style.display = provider === "local" ? "none" : "";
    if (keyInput) {
        keyInput.disabled = provider === "local";
        keyInput.required = false;
    }

    if (provider === "custom") {
        if (customFields) customFields.style.display = "grid";
        if (baseUrlInput && !baseUrlInput.value) baseUrlInput.value = "http://localhost:11434/v1";
        if (modelInput && !modelInput.value) modelInput.value = "llama3";
    } else {
        if (customFields) customFields.style.display = "none";
    }
}

async function testSetupAiConnection() {
    const btn = document.getElementById("btn-test-ai");
    const statusText = document.getElementById("setup-ai-test-status");
    const provider = document.getElementById("setup-ai-provider").value;
    const apiKey = document.getElementById("setup-ai-api-key").value.trim();
    const baseUrl = document.getElementById("setup-ai-base-url")?.value.trim();
    const model = document.getElementById("setup-ai-model")?.value.trim();

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="animate-spin inline-block mr-1">⟳</span> Testing...`;
    }

    try {
        const res = await fetch("/api/setup/test-provider", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                provider,
                api_key: apiKey,
                base_url: baseUrl,
                model
            })
        });
        const data = await res.json();
        if (res.ok && data.status === "active") {
            statusText.style.color = "#34d399";
            statusText.textContent = `✓ ${data.message || "Provider connection verified successfully!"}`;
            showToast("AI Provider connection active!", "success");
        } else {
            statusText.style.color = "#f87171";
            statusText.textContent = `✗ ${data.message || "Connection test failed. Check key & network."}`;
            showToast(data.message || "Connection failed", "error");
        }
    } catch (err) {
        statusText.style.color = "#f87171";
        statusText.textContent = `✗ Error: ${err.message}`;
        showToast(err.message, "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = "Test Provider Connection";
        }
    }
}

function toggleLdapCheckbox() {
    const chk = document.getElementById("setup-enable-ldap");
    if (chk) chk.checked = !chk.checked;
}

// ==============================================================================
// 7. STEP 5: REVIEW SUMMARY & FINAL SUBMISSION
// ==============================================================================
function updateStep5Summary() {
    const storageEl = document.getElementById("summary-storage-val");
    if (storageEl) {
        storageEl.textContent = volumeCheckResult.persistent ? "Verified Persistent" : "Unmounted / Ephemeral";
        storageEl.style.color = volumeCheckResult.persistent ? "#34d399" : "#f87171";
    }

    const personaVal = document.getElementById("setup-selected-persona")?.value || "tech_academy";
    const personaNames = {
        tech_academy: "Tech Academy & Certifications",
        media_agency: "Media Company / Agency",
        b2b_enterprise: "B2B Enterprise Thought Leadership"
    };
    const personaEl = document.getElementById("summary-persona-val");
    if (personaEl) personaEl.textContent = personaNames[personaVal] || personaVal;

    const providerVal = document.getElementById("setup-ai-provider")?.value || "local";
    const providerNames = {
        local: "Postall_V4 AI (Qwen2.5-1.5B offline)",
        gemini: "Google Gemini (Native)",
        openai: "OpenAI GPT-4o",
        deepseek: "DeepSeek Reasoner",
        mistral: "Mistral AI",
        claude: "Anthropic Claude 3.5",
        custom: "Custom OpenAI-Compatible"
    };
    const aiEl = document.getElementById("summary-ai-val");
    if (aiEl) aiEl.textContent = providerNames[providerVal] || providerVal;
}

async function submitSetupComplete() {
    const submitBtn = document.getElementById("btn-wizard-submit");
    const errorBox = document.getElementById("setup-final-error");
    if (errorBox) errorBox.style.display = "none";

    const adminPassword = document.getElementById("setup-admin-password")?.value || "";
    const licenseKey = document.getElementById("setup-license-key")?.value || "";
    const workspacePersona = document.getElementById("setup-selected-persona")?.value || "tech_academy";
    const aiProvider = document.getElementById("setup-ai-provider")?.value || "local";
    const aiApiKey = document.getElementById("setup-ai-api-key")?.value || "";
    const aiBaseUrl = document.getElementById("setup-ai-base-url")?.value || null;
    const aiModel = document.getElementById("setup-ai-model")?.value || null;
    const enableLdap = Boolean(document.getElementById("setup-enable-ldap")?.checked);
    const telemetryEnabled = Boolean(document.getElementById("setup-telemetry-enabled")?.checked);

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="animate-spin inline-block mr-2">⚙</span> Initializing Postall_V4 Engine...`;
    }

    try {
        const payload = {
            admin_password: adminPassword,
            license_key: licenseKey,
            workspace_persona: workspacePersona,
            ai_provider: aiProvider,
            ai_api_key: aiApiKey,
            ai_base_url: aiBaseUrl,
            ai_model: aiModel,
            enable_ldap: enableLdap,
            telemetry_enabled: telemetryEnabled
        };

        const res = await fetch("/api/setup/complete", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (res.ok && data.status === "success") {
            showToast("Initialization complete! Redirecting to login...", "success");
            setTimeout(() => {
                window.location.href = data.redirect_url || "/login";
            }, 1200);
        } else {
            const msg = data.detail || data.message || "Initialization failed. Please verify inputs.";
            if (errorBox) {
                errorBox.style.display = "block";
                errorBox.textContent = `Initialization Error: ${msg}`;
            }
            showToast(msg, "error");
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = `<span>Initialize Postall_V4 Platform</span>`;
            }
        }
    } catch (err) {
        if (errorBox) {
            errorBox.style.display = "block";
            errorBox.textContent = `Network Exception: ${err.message}`;
        }
        showToast(err.message, "error");
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `<span>Initialize Postall_V4 Platform</span>`;
        }
    }
}

// ==============================================================================
// 8. STEP NAVIGATION CONTROLLER
// ==============================================================================
function validateStep(step) {
    if (step === 1) {
        if (!volumeCheckResult.persistent) {
            const ack = document.getElementById("ack-unmounted-volume")?.checked;
            if (!ack) {
                showToast("Please acknowledge unmounted storage risk to proceed.", "error");
                return false;
            }
        }
        return true;
    }

    if (step === 2) {
        const pw = document.getElementById("setup-admin-password")?.value || "";
        const confirmPw = document.getElementById("setup-confirm-password")?.value || "";

        if (pw.length < 8) {
            showToast("Master Administrator password must be at least 8 characters.", "error");
            document.getElementById("setup-admin-password")?.focus();
            return false;
        }

        if (pw !== confirmPw) {
            showToast("Administrator passwords do not match. Please re-type.", "error");
            document.getElementById("setup-confirm-password")?.focus();
            return false;
        }
        return true;
    }

    return true;
}

function updateTimelineUI() {
    const progressPercent = ((currentStep - 1) / (TOTAL_STEPS - 1)) * 100;
    const bar = document.getElementById("timeline-progress-bar");
    if (bar) bar.style.width = `${progressPercent}%`;

    for (let i = 1; i <= TOTAL_STEPS; i++) {
        const node = document.getElementById(`step-node-${i}`);
        if (!node) continue;
        node.classList.toggle("active", i === currentStep);
        node.classList.toggle("completed", i < currentStep);
    }

    document.querySelectorAll(".step-pane").forEach((pane, idx) => {
        pane.classList.toggle("active", idx + 1 === currentStep);
    });

    const prevBtn = document.getElementById("btn-wizard-prev");
    const nextBtn = document.getElementById("btn-wizard-next");
    const submitBtn = document.getElementById("btn-wizard-submit");

    if (prevBtn) prevBtn.style.display = currentStep > 1 ? "inline-flex" : "none";
    if (nextBtn) nextBtn.style.display = currentStep < TOTAL_STEPS ? "inline-flex" : "none";
    if (submitBtn) submitBtn.style.display = currentStep === TOTAL_STEPS ? "inline-flex" : "none";

    if (currentStep === 5) {
        updateStep5Summary();
    }
}

function navigateStep(direction) {
    if (direction > 0) {
        if (!validateStep(currentStep)) return;
    }

    const target = currentStep + direction;
    if (target >= 1 && target <= TOTAL_STEPS) {
        currentStep = target;
        updateTimelineUI();
    }
}

// ==============================================================================
// 9. INITIALIZATION
// ==============================================================================
document.addEventListener("DOMContentLoaded", () => {
    updateTimelineUI();
    executeVolumeCheck();
    handleAiProviderChange(document.getElementById("setup-ai-provider")?.value || "local");

    // Password match watcher
    const pwInput = document.getElementById("setup-admin-password");
    const confirmInput = document.getElementById("setup-confirm-password");
    const matchLabel = document.getElementById("pw-match-label");

    function checkMatch() {
        if (!confirmInput.value) {
            matchLabel.textContent = "";
            return;
        }
        if (pwInput.value === confirmInput.value) {
            matchLabel.style.color = "#34d399";
            matchLabel.textContent = "✓ Passwords match";
        } else {
            matchLabel.style.color = "#f87171";
            matchLabel.textContent = "✗ Passwords do not match";
        }
    }

    if (pwInput && confirmInput) {
        pwInput.addEventListener("input", checkMatch);
        confirmInput.addEventListener("input", checkMatch);
    }
});
