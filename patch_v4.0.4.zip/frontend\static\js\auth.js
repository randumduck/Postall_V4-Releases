/* Small authenticated fetch adapter used by every dashboard API call. */
(function () {
    const originalFetch = window.fetch.bind(window);
    window.fetch = function (input, options) {
        options = options || {};
        const headers = new Headers(options.headers || {});
        const token = localStorage.getItem("token") || localStorage.getItem("vanguard_token");
        if (token) headers.set("Authorization", "Bearer " + token);
        return originalFetch(input, Object.assign({}, options, {headers})).then(function (response) {
            if (response.status === 401) {
                localStorage.removeItem("token"); localStorage.removeItem("vanguard_token");
                if (!location.pathname.includes("login")) location.href = "/login";
            }
            return response;
        });
    };
})();
