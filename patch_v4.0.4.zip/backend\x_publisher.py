"""Publisher for X using an OAuth 2.0 user access token."""
import requests


def trim_post(body: str, limit: int = 270) -> str:
    text=" ".join(body.split())
    if sum(2 if ord(char)>127 else 1 for char in text) <= limit:
        return text
    trimmed=[]
    weight=0
    for char in text:
        cost=2 if ord(char)>127 else 1
        if weight+cost>limit-2:
            break
        trimmed.append(char)
        weight+=cost
    result="".join(trimmed).rsplit(" ",1)[0].rstrip(" ,;:-")
    return result+"…"


def publish_post(body: str, access_token: str) -> str:
    if not access_token:
        raise RuntimeError("X OAuth 2.0 user access token is not configured")
    try:
        response=requests.post(
            "https://api.x.com/2/tweets",
            headers={"Authorization":f"Bearer {access_token}","Content-Type":"application/json"},
            json={"text":trim_post(body)},
            timeout=30,
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"X API request failed ({type(exc).__name__})") from exc
    if response.status_code not in (200,201):
        raise RuntimeError(f"X API rejected the post (HTTP {response.status_code})")
    try:
        post_id=response.json()["data"]["id"]
    except (ValueError,KeyError,TypeError) as exc:
        raise RuntimeError("X API response did not contain a post ID") from exc
    return f"https://x.com/i/web/status/{post_id}"
