"""LinkedIn publisher compatibility module.
Delegates to backend.social_publisher using official REST APIs.
"""
from pathlib import Path
from typing import Optional
from .social_publisher import publish_draft, publish_to_linkedin

__all__ = ["publish_draft", "publish_to_linkedin"]
