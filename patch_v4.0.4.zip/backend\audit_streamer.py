"""
Postall_V4 - Enterprise SIEM & Audit Streamer (backend/audit_streamer.py)
Non-blocking asynchronous audit log shipper supporting RFC 5424 Syslog, CEF (Common Event Format),
and JSON streaming to Splunk, Datadog, Elastic, and corporate SIEM collectors.
Guarantees local persistence fallback in SQLite so no event is lost during network partitions.
"""

import os
import sys
import json
import time
import socket
import urllib.request
import urllib.error
import threading
import queue
import uuid
import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List

# Thread-safe queue for audit events
_audit_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue(maxsize=10000)
_worker_started = False
_worker_lock = threading.Lock()

# Metrics counters
_stats_lock = threading.Lock()
_total_events_logged = 0
_events_shipped_siem = 0
_events_persisted_db = 0
_last_shipped_timestamp: Optional[str] = None
_last_error: Optional[str] = None

# Severity to CEF mapping
SEVERITY_MAP = {
    "INFO": 1,
    "LOW": 3,
    "WARNING": 5,
    "MEDIUM": 6,
    "ERROR": 8,
    "HIGH": 8,
    "CRITICAL": 10
}


def _get_db_connection():
    """Lazily import and acquire database connection."""
    try:
        from backend.database import get_db
        return get_db()
    except Exception as e:
        print(f"[AUDIT_STREAMER] Failed to get database connection: {e}")
        return None


def _get_siem_config() -> Dict[str, Any]:
    """Retrieve active SIEM settings from environment or settings table."""
    config = {
        "enabled": os.getenv("SIEM_ENABLED", "false").lower() in ("true", "1", "yes"),
        "protocol": os.getenv("SIEM_PROTOCOL", "udp").lower(),  # udp, tcp, http
        "host": os.getenv("SIEM_HOST", "127.0.0.1"),
        "port": int(os.getenv("SIEM_PORT", "514")),
        "format": os.getenv("SIEM_FORMAT", "cef").lower(),  # cef, rfc5424, json
        "http_url": os.getenv("SIEM_HTTP_URL", ""),
        "http_token": os.getenv("SIEM_HTTP_TOKEN", ""),
        "app_name": "Postall_V4",
        "app_version": "4.0.1"
    }

    # Also check settings table in DB if available
    try:
        db = _get_db_connection()
        if db:
            rows = db.execute("SELECT key, value FROM settings WHERE key LIKE 'siem_%'").fetchall()
            for r in rows:
                k = r["key"].replace("siem_", "")
                v = r["value"]
                if k == "enabled":
                    config["enabled"] = str(v).lower() in ("true", "1", "yes")
                elif k == "port":
                    try:
                        config["port"] = int(v)
                    except ValueError:
                        pass
                elif k in config:
                    config[k] = v
            db.close()
    except Exception:
        pass

    return config


def format_cef(event: Dict[str, Any]) -> str:
    """
    Format event into ArcSight Common Event Format (CEF).
    Syntax: CEF:Version|Device Vendor|Device Product|Device Version|Device Event Class ID|Name|Severity|[Extension]
    """
    vendor = "PostAll"
    product = "Postall_V4"
    version = event.get("version", "4.0.1")
    event_class = event.get("action", "GENERIC_AUDIT")
    name = event.get("action", "Generic Audit Event")
    sev_str = event.get("severity", "INFO").upper()
    severity = SEVERITY_MAP.get(sev_str, 1)

    # Extensions
    actor = event.get("actor", "system")
    src = event.get("ip_address") or "127.0.0.1"
    res_type = event.get("resource_type", "")
    res_id = str(event.get("resource_id", ""))
    status = event.get("status", "SUCCESS")
    details = event.get("details", {})
    details_str = json.dumps(details) if isinstance(details, dict) else str(details)

    extension_parts = [
        f"src={src}",
        f"suser={actor}",
        f"act={event_class}",
        f"cs1={res_type}",
        f"cs1Label=ResourceType",
        f"cs2={res_id}",
        f"cs2Label=ResourceId",
        f"cs3={status}",
        f"cs3Label=Outcome",
        f"externalId={event.get('event_id', '')}",
        f"msg={details_str[:255]}"
    ]
    extensions = " ".join(extension_parts)

    return f"CEF:0|{vendor}|{product}|{version}|{event_class}|{name}|{severity}|{extensions}"


def format_rfc5424(event: Dict[str, Any]) -> str:
    """
    Format event into RFC 5424 Syslog standard.
    <PRI>VERSION TIMESTAMP HOSTNAME APP-NAME PROCID MSGID [STRUCTURED-DATA] MSG
    """
    # Facility: user-level (1), Severity: informational (6) -> PRI = 1*8 + 6 = 14
    pri = 14
    ts = event.get("timestamp", datetime.datetime.now(datetime.timezone.utc).isoformat())
    hostname = socket.gethostname() or "postall-node"
    app_name = "postall"
    proc_id = os.getpid()
    msg_id = event.get("event_id", str(uuid.uuid4())[:8])

    actor = event.get("actor", "system")
    action = event.get("action", "ACTION")
    status = event.get("status", "SUCCESS")
    res_type = event.get("resource_type", "")
    res_id = event.get("resource_id", "")

    sd = f'[audit@postall actor="{actor}" action="{action}" status="{status}" target="{res_type}:{res_id}"]'
    msg = json.dumps(event.get("details", {}))

    return f"<{pri}>1 {ts} {hostname} {app_name} {proc_id} {msg_id} {sd} {msg}"


def format_json(event: Dict[str, Any]) -> str:
    """Format event into standard structured JSON line."""
    return json.dumps(event)


def _send_udp(message: str, host: str, port: int) -> bool:
    """Ship message via UDP socket."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(2.0)
    try:
        sock.sendto(message.encode("utf-8"), (host, port))
        return True
    finally:
        sock.close()


def _send_tcp(message: str, host: str, port: int) -> bool:
    """Ship message via TCP socket."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(2.0)
    try:
        sock.connect((host, port))
        sock.sendall((message + "\n").encode("utf-8"))
        return True
    finally:
        sock.close()


def _send_http(message: str, url: str, token: str = "") -> bool:
    """Ship message via HTTPS POST request."""
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, data=message.encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=3.0) as resp:
        return resp.status in (200, 201, 202, 204)


def _worker_loop():
    """Background consumer daemon that processes queued audit events."""
    global _total_events_logged, _events_shipped_siem, _events_persisted_db
    global _last_shipped_timestamp, _last_error

    while True:
        try:
            event = _audit_queue.get()
            if event is None:
                break

            # 1. Always persist to local SQLite audit log
            db = _get_db_connection()
            if db:
                try:
                    db.execute("""
                        INSERT OR REPLACE INTO siem_audit_logs
                        (event_id, timestamp, actor, action, resource_type, resource_id, status, ip_address, user_agent, details_json, shipped_to_siem)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        event["event_id"],
                        event["timestamp"],
                        event["actor"],
                        event["action"],
                        event["resource_type"],
                        str(event.get("resource_id", "")),
                        event["status"],
                        event.get("ip_address", ""),
                        event.get("user_agent", ""),
                        json.dumps(event.get("details", {})),
                        0
                    ))
                    db.commit()
                    with _stats_lock:
                        _events_persisted_db += 1
                except Exception as db_err:
                    _last_error = f"DB insert error: {db_err}"
                finally:
                    db.close()

            # 2. Check if SIEM forwarding is enabled
            cfg = _get_siem_config()
            shipped = False
            if cfg["enabled"]:
                fmt = cfg["format"]
                if fmt == "cef":
                    payload = format_cef(event)
                elif fmt == "rfc5424":
                    payload = format_rfc5424(event)
                else:
                    payload = format_json(event)

                proto = cfg["protocol"]
                try:
                    if proto == "udp":
                        shipped = _send_udp(payload, cfg["host"], cfg["port"])
                    elif proto == "tcp":
                        shipped = _send_tcp(payload, cfg["host"], cfg["port"])
                    elif proto == "http" and cfg["http_url"]:
                        shipped = _send_http(format_json(event), cfg["http_url"], cfg["http_token"])

                    if shipped:
                        with _stats_lock:
                            _events_shipped_siem += 1
                            _last_shipped_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
                        
                        # Update shipped_to_siem flag in local DB
                        db_up = _get_db_connection()
                        if db_up:
                            try:
                                db_up.execute("UPDATE siem_audit_logs SET shipped_to_siem = 1 WHERE event_id = ?", (event["event_id"],))
                                db_up.commit()
                            finally:
                                db_up.close()
                except Exception as emit_err:
                    with _stats_lock:
                        _last_error = f"SIEM emit ({proto}): {emit_err}"

            _audit_queue.task_done()
        except Exception as loop_err:
            with _stats_lock:
                _last_error = f"Worker loop error: {loop_err}"
            time.sleep(0.1)


def ensure_worker_started():
    """Ensure the background log shipper worker thread is alive."""
    global _worker_started
    with _worker_lock:
        if not _worker_started:
            worker_thread = threading.Thread(target=_worker_loop, daemon=True, name="SIEM-Audit-Worker")
            worker_thread.start()
            _worker_started = True


def log_audit_event(
    actor: str,
    action: str,
    resource_type: str,
    resource_id: Optional[Any] = None,
    status: str = "SUCCESS",
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
    severity: str = "INFO"
) -> str:
    """
    Main non-blocking public interface to log an enterprise audit event.
    Returns the generated UUID4 event_id.
    """
    global _total_events_logged
    ensure_worker_started()

    event_id = str(uuid.uuid4())
    event = {
        "event_id": event_id,
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "actor": actor or "anonymous",
        "action": action.upper(),
        "resource_type": resource_type.lower(),
        "resource_id": str(resource_id) if resource_id is not None else "",
        "status": status.upper(),
        "severity": severity.upper(),
        "ip_address": ip_address or "127.0.0.1",
        "user_agent": user_agent or "PostAll-Agent",
        "details": details or {},
        "version": "4.0.1"
    }

    with _stats_lock:
        _total_events_logged += 1

    try:
        _audit_queue.put_nowait(event)
    except queue.Full:
        # Fallback synchronous write to database if queue is completely saturated
        db = _get_db_connection()
        if db:
            try:
                db.execute("""
                    INSERT OR REPLACE INTO siem_audit_logs
                    (event_id, timestamp, actor, action, resource_type, resource_id, status, ip_address, user_agent, details_json, shipped_to_siem)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                """, (
                    event["event_id"], event["timestamp"], event["actor"], event["action"],
                    event["resource_type"], event["resource_id"], event["status"],
                    event["ip_address"], event["user_agent"], json.dumps(event["details"])
                ))
                db.commit()
            finally:
                db.close()

    return event_id


def get_audit_events(limit: int = 50, offset: int = 0, action_filter: Optional[str] = None, actor_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    """Retrieve audit events from the local audit store."""
    db = _get_db_connection()
    if not db:
        return []
    try:
        query = "SELECT * FROM siem_audit_logs"
        params: List[Any] = []
        conditions = []
        if action_filter:
            conditions.append("action LIKE ?")
            params.append(f"%{action_filter}%")
        if actor_filter:
            conditions.append("actor LIKE ?")
            params.append(f"%{actor_filter}%")

        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY id DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        rows = db.execute(query, params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["details"] = json.loads(d.get("details_json", "{}"))
            except Exception:
                d["details"] = {}
            result.append(d)
        return result
    finally:
        db.close()


def get_siem_status() -> Dict[str, Any]:
    """Return live status of the SIEM audit streaming system."""
    ensure_worker_started()
    cfg = _get_siem_config()
    with _stats_lock:
        return {
            "siem_enabled": cfg["enabled"],
            "protocol": cfg["protocol"],
            "collector_endpoint": f"{cfg['host']}:{cfg['port']}" if cfg["protocol"] in ("udp", "tcp") else cfg["http_url"],
            "format": cfg["format"].upper(),
            "total_events_logged": _total_events_logged,
            "events_shipped_siem": _events_shipped_siem,
            "events_persisted_db": _events_persisted_db,
            "queue_pending_events": _audit_queue.qsize(),
            "last_shipped_at": _last_shipped_timestamp or "--",
            "last_error": _last_error,
            "supported_formats": ["CEF", "RFC5424", "JSON"]
        }


def test_siem_connection(host: Optional[str] = None, port: Optional[int] = None, protocol: Optional[str] = None) -> Dict[str, Any]:
    """Test collector connectivity with a synthetic test event."""
    cfg = _get_siem_config()
    target_host = host or cfg["host"]
    target_port = port or cfg["port"]
    target_proto = (protocol or cfg["protocol"]).lower()

    test_event = {
        "event_id": str(uuid.uuid4()),
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "actor": "admin_test",
        "action": "SIEM_HEARTBEAT_TEST",
        "resource_type": "siem_collector",
        "resource_id": f"{target_host}:{target_port}",
        "status": "SUCCESS",
        "severity": "LOW",
        "ip_address": "127.0.0.1",
        "user_agent": "PostAll-TestClient",
        "details": {"test": True, "ping": "pong"},
        "version": "4.0.1"
    }

    cef_msg = format_cef(test_event)

    try:
        if target_proto == "udp":
            _send_udp(cef_msg, target_host, target_port)
            return {"success": True, "status": "success", "message": f"UDP test packet dispatched to {target_host}:{target_port} (CEF format)", "format": "CEF"}
        elif target_proto == "tcp":
            _send_tcp(cef_msg, target_host, target_port)
            return {"success": True, "status": "success", "message": f"TCP test packet delivered to {target_host}:{target_port}", "format": "CEF"}
        elif target_proto == "http":
            _send_http(format_json(test_event), cfg.get("http_url", ""))
            return {"success": True, "status": "success", "message": f"HTTP test payload delivered to {cfg.get('http_url', '')}", "format": "JSON"}
        else:
            return {"success": False, "status": "error", "message": f"Unsupported protocol '{target_proto}'"}
    except Exception as e:
        return {"success": False, "status": "error", "message": f"Failed connecting to {target_host}:{target_port}: {str(e)}"}
