"""
Postall_V4 - Enterprise Over-The-Air (OTA) Update Engine
=========================================================
Handles checking GitHub releases (public releases repository without storing PAT),
downloading release payloads, SHA-256 verification, version manifest tracking,
automated pre-flight snapshotting, safe atomic extraction strictly preserving persistent
volumes (/data, /venv, .env, linkedin_session), update_history ledger audit logging,
rollback restoration, and graceful container reboots.
"""

import os
import sys
import shutil
import zipfile
import ssl
import httpx
import certifi
import asyncio
import signal
import logging
import threading
import time
import re
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List

logger = logging.getLogger("update_engine")
ROOT_DIR = Path(__file__).resolve().parent.parent
CURRENT_VERSION = "4.0.0"
VERSION_ORACLE_URL = "https://raw.githubusercontent.com/randumduck/Postall_V4-Releases/main/version.json"

# Critical paths that MUST NEVER be overwritten by OTA updates
PROTECTED_PREFIXES = (
    "data/",
    "data\\",
    "venv/",
    "venv\\",
    ".env",
    "linkedin_session/",
    "linkedin_session\\",
    "cisco-umbrella-root-ca.crt",
    "license.key"
)

PROTECTED_EXACT_NAMES = {
    ".env",
    "postall.db",
    "license.key",
    "data",
    "venv",
    "linkedin_session"
}

def _get_ssl_context() -> ssl.SSLContext:
    """Use certifi roots for GitHub traffic and append an optional operator CA."""
    context = ssl.create_default_context(cafile=certifi.where())
    custom_ca_bundle = os.getenv("POSTALL_CA_BUNDLE") or os.getenv("SSL_CERT_FILE")
    if custom_ca_bundle:
        context.load_verify_locations(cafile=custom_ca_bundle)
    return context


class VersionInfo(dict):
    """
    Hybrid version object: behaves as a dictionary (e.g. v['git_commit'], v['version'])
    and compares equally to version strings (e.g. v == '4.0.0' or str(v) == '4.0.0').
    """
    def __init__(self, version: str, git_commit: str = "", build_date: str = "", target_arch: str = "linux-x86_64", **kwargs):
        super().__init__(
            version=version,
            current_version=version,
            git_commit=git_commit,
            build_date=build_date,
            target_arch=target_arch,
            **kwargs
        )

    def __str__(self) -> str:
        return str(self.get("version", "4.0.0"))

    def __repr__(self) -> str:
        return repr(dict(self))

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, str):
            my_v = str(self.get("version", "")).lstrip("vV").strip()
            other_v = other.lstrip("vV").strip()
            return my_v == other_v
        return super().__eq__(other)


def get_version_manifest() -> Dict[str, Any]:
    """Reads version_manifest.json from the application root if present."""
    manifest_file = ROOT_DIR / "version_manifest.json"
    if manifest_file.exists():
        try:
            return json.loads(manifest_file.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.warning(f"Could not read version_manifest.json: {exc}")
    return {}


def get_current_version() -> VersionInfo:
    """Reads VERSION.txt and version_manifest.json and returns a VersionInfo instance."""
    manifest = get_version_manifest()
    ver_str = manifest.get("version", "4.0.0") if manifest else "4.0.0"
    version_file = ROOT_DIR / "VERSION.txt"
    try:
        if version_file.exists():
            content = version_file.read_text(encoding="utf-8").strip()
            if content:
                ver_str = content
    except Exception as exc:
        logger.warning(f"Could not read VERSION.txt: {exc}")

    git_commit = manifest.get("git_commit", "")
    build_date = manifest.get("build_date", "")
    target_arch = manifest.get("target_arch", "linux-x86_64")

    return VersionInfo(
        version=ver_str,
        git_commit=git_commit,
        build_date=build_date,
        target_arch=target_arch
    )


def clean_github_repo_slug(repo_input: str) -> str:
    """Extracts 'owner/repo' from user-supplied URLs or slug strings."""
    slug = (repo_input or "").strip()
    slug = re.sub(r"^https?://github\.com/", "", slug, flags=re.IGNORECASE)
    slug = re.sub(r"^github\.com/", "", slug, flags=re.IGNORECASE)
    slug = slug.strip("/").removesuffix(".git")
    return slug


def parse_semver(v_str: str) -> List[int]:
    """Helper to parse semantic versioning numbers from tag strings like 'v4.0.1' or '4.0.1-rc1'."""
    clean = re.sub(r'[^0-9.]', '', v_str.lstrip("vV").split("-")[0])
    parts = [int(x) for x in clean.split(".") if x.isdigit()]
    return parts or [0, 0, 0]


async def check_version_oracle() -> Dict[str, Any]:
    """Fetch the public version manifest and compare it with the running app version."""
    try:
        async with httpx.AsyncClient(
            timeout=10.0,
            follow_redirects=True,
            verify=_get_ssl_context(),
            trust_env=True,
        ) as client:
            response = await client.get(
                VERSION_ORACLE_URL,
                headers={"Accept": "application/json", "User-Agent": "Postall_V4-Version-Oracle/1.0"},
            )
            response.raise_for_status()
            manifest = response.json()

        if not isinstance(manifest, dict):
            raise ValueError("Version oracle response must be a JSON object.")
        latest_version = manifest.get("latest_version")
        if not isinstance(latest_version, str) or not latest_version.strip():
            raise ValueError("Version oracle response is missing latest_version.")
        if not re.fullmatch(r"v?\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?", latest_version.strip()):
            raise ValueError("Version oracle latest_version is not a valid semantic version.")

        changelog = manifest.get("changelog", [])
        instructions = manifest.get("update_instructions", "")
        if not isinstance(changelog, list) or not all(isinstance(item, str) for item in changelog):
            raise ValueError("Version oracle changelog must be an array of strings.")
        if not isinstance(instructions, str):
            raise ValueError("Version oracle update_instructions must be a string.")

        latest_version = latest_version.strip().lstrip("vV")
        current_parts = parse_semver(CURRENT_VERSION)
        latest_parts = parse_semver(latest_version)
        width = max(len(current_parts), len(latest_parts))
        current_parts.extend([0] * (width - len(current_parts)))
        latest_parts.extend([0] * (width - len(latest_parts)))
        return {
            "current_version": CURRENT_VERSION,
            "latest_version": latest_version,
            "update_available": latest_parts > current_parts,
            "changelog": changelog,
            "update_instructions": instructions.strip(),
        }
    except (httpx.HTTPError, OSError, ValueError, TypeError) as exc:
        logger.warning("Version oracle unavailable: %s", exc)
        return {
            "current_version": CURRENT_VERSION,
            "latest_version": CURRENT_VERSION,
            "update_available": False,
            "changelog": [],
            "update_instructions": "",
            "offline": True,
            "error": str(exc),
        }


async def check_github_releases(repo: str, pat: Optional[str] = None) -> Dict[str, Any]:
    """
    Queries public GitHub Releases API: GET https://api.github.com/repos/{repo}/releases/latest.
    Works for public repositories without storing or supplying GitHub PATs.
    Locates .zip asset and optional .sha256 checksum asset.
    Compares remote tag against local version.
    Returns:
      {"update_available": bool, "current": str, "latest": str, "notes": str,
       "download_url": str, "sha256_url": str, ...}
    """
    clean_repo = clean_github_repo_slug(repo)
    cur_info = get_current_version()
    current_ver = str(cur_info)

    if not clean_repo or "/" not in clean_repo:
        raise ValueError(f"Invalid GitHub repository '{repo}'. Format must be 'owner/repo'.")

    api_url = f"https://api.github.com/repos/{clean_repo}/releases/latest"
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Postall_V4-Enterprise-OTA/4.0"
    }
    if pat and pat.strip():
        headers["Authorization"] = f"Bearer {pat.strip()}"

    async with httpx.AsyncClient(
        timeout=20.0, follow_redirects=True, verify=_get_ssl_context(), trust_env=True
    ) as client:
        try:
            resp = await client.get(api_url, headers=headers)
        except httpx.RequestError as exc:
            logger.error(f"GitHub API connectivity error ({clean_repo}): {exc}")
            raise RuntimeError(f"Could not reach GitHub API: {exc}") from exc

        if resp.status_code == 404:
            raise RuntimeError(f"Repository or release not found at '{clean_repo}'. Verify repo name and ensure a release is published.")
        elif resp.status_code in (401, 403):
            err_msg = resp.json().get("message", "Authentication or rate limit error.") if resp.headers.get("content-type", "").startswith("application/json") else resp.text
            raise RuntimeError(f"GitHub API access denied ({resp.status_code}): {err_msg}")
        elif resp.status_code != 200:
            raise RuntimeError(f"GitHub API returned unexpected status {resp.status_code}: {resp.text[:200]}")

        data = resp.json()
        tag_name = data.get("tag_name", "").strip()
        release_name = data.get("name", "").strip() or tag_name
        body = data.get("body", "").strip() or "No release notes provided."
        published_at = data.get("published_at", "")

        download_url = ""
        sha256_url = ""
        asset_name = ""
        assets = data.get("assets", [])
        for asset in assets:
            name = asset.get("name", "")
            if name.lower().endswith(".zip"):
                download_url = asset.get("browser_download_url", "")
                asset_name = name
            elif name.lower().endswith(".sha256"):
                sha256_url = asset.get("browser_download_url", "")

        # Fallback to source zipball if no explicit zip asset attached
        if not download_url:
            download_url = data.get("zipball_url", "")
            asset_name = f"{tag_name}.zip"

        update_available = False
        if tag_name:
            try:
                update_available = parse_semver(tag_name) > parse_semver(current_ver)
            except Exception:
                update_available = tag_name.lstrip("vV").strip() != current_ver.lstrip("vV").strip()

        latest_ver_str = tag_name.lstrip("vV") or current_ver

        return {
            "update_available": update_available,
            "current": current_ver,
            "latest": latest_ver_str,
            "current_version": current_ver,
            "latest_version": latest_ver_str,
            "tag_name": tag_name,
            "release_name": release_name,
            "notes": body,
            "changelog": body,
            "body": body,
            "download_url": download_url,
            "browser_download_url": download_url,
            "sha256_url": sha256_url,
            "asset_name": asset_name,
            "published_at": published_at,
            "git_commit": cur_info.get("git_commit", "")
        }


# Compatibility alias
check_github_update = check_github_releases


def create_snapshot() -> str:
    """
    Archives current working application code into
    data/backups/snapshot_{current_version}_{timestamp}.zip before applying any update.
    Returns the snapshot file path.
    """
    current_ver = str(get_current_version())
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backups_dir = ROOT_DIR / "data" / "backups"
    backups_dir.mkdir(parents=True, exist_ok=True)

    snapshot_filename = f"snapshot_{current_ver}_{timestamp}.zip"
    snapshot_path = backups_dir / snapshot_filename

    include_dirs = ["backend", "frontend", "scripts"]
    include_files = ["VERSION.txt", "version_manifest.json", "requirements.txt", "deploy.sh", "Dockerfile", "README.md"]

    with zipfile.ZipFile(snapshot_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for d in include_dirs:
            dir_path = ROOT_DIR / d
            if dir_path.exists():
                for p in dir_path.rglob("*"):
                    if p.is_file():
                        rel = p.relative_to(ROOT_DIR)
                        norm_rel = str(rel).replace("\\", "/")
                        if "__pycache__" in norm_rel:
                            continue
                        zf.write(p, arcname=norm_rel)

        for f in include_files:
            file_path = ROOT_DIR / f
            if file_path.exists() and file_path.is_file():
                zf.write(file_path, arcname=f)

    logger.info(f"Pre-update snapshot created at: {snapshot_path}")
    return str(snapshot_path)


# Compatibility alias
create_pre_update_snapshot = create_snapshot


def list_snapshots() -> List[Dict[str, Any]]:
    """Returns a list of available pre-update snapshots stored in data/backups/."""
    backups_dir = ROOT_DIR / "data" / "backups"
    if not backups_dir.exists():
        return []

    snapshots = []
    for f in sorted(backups_dir.glob("*.zip"), key=os.path.getmtime, reverse=True):
        stat = f.stat()
        mtime = datetime.fromtimestamp(stat.st_mtime)
        snapshots.append({
            "filename": f.name,
            "path": str(f),
            "size_bytes": stat.st_size,
            "size_formatted": f"{stat.st_size / (1024 * 1024):.2f} MB",
            "created_at": mtime.isoformat(),
            "formatted_time": mtime.strftime("%Y-%m-%d %H:%M:%S")
        })
    return snapshots


def extract_update_payload(zip_path: str, target_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    Safely extracts the .zip payload into target_dir (defaults to ROOT_DIR).
    CRITICAL SAFETY GUARD: Explicitly skips any files targeting:
      - data/
      - venv/
      - .env
      - linkedin_session/
      - license.key or root certificates
    Also guards against Zip Slip (directory traversal) vulnerabilities.
    """
    dest_root = Path(target_dir).resolve() if target_dir else ROOT_DIR.resolve()
    zip_file_path = Path(zip_path).resolve()

    if not zip_file_path.exists():
        raise FileNotFoundError(f"Update payload not found at '{zip_path}'.")

    extracted_files = []
    skipped_files = []

    with zipfile.ZipFile(zip_file_path, "r") as zf:
        namelist = zf.namelist()
        if not namelist:
            raise ValueError("Update zip archive is empty.")

        # Detect top-level packaging prefix folder if present
        common_prefix = ""
        first_elements = [n.split("/")[0] for n in namelist if "/" in n]
        if first_elements:
            candidate_prefix = first_elements[0] + "/"
            if all(n.startswith(candidate_prefix) or n == first_elements[0] for n in namelist):
                has_app_root = any(
                    n.startswith(f"{candidate_prefix}backend/") or
                    n.startswith(f"{candidate_prefix}frontend/") or
                    n == f"{candidate_prefix}requirements.txt" or
                    n == f"{candidate_prefix}VERSION.txt" or
                    n == f"{candidate_prefix}version_manifest.json"
                    for n in namelist
                )
                if has_app_root:
                    common_prefix = candidate_prefix

        for member in zf.infolist():
            raw_name = member.filename
            if not raw_name or raw_name.endswith("/"):
                continue

            clean_rel = raw_name
            if common_prefix and clean_rel.startswith(common_prefix):
                clean_rel = clean_rel[len(common_prefix):]

            norm_rel = clean_rel.replace("\\", "/").strip("/")
            if not norm_rel:
                continue

            # Hard safety filter
            is_protected = False
            if norm_rel in PROTECTED_EXACT_NAMES:
                is_protected = True
            for prefix in PROTECTED_PREFIXES:
                if norm_rel.startswith(prefix.replace("\\", "/")):
                    is_protected = True
                    break

            if is_protected:
                logger.info(f"[OTA SAFETY] Skipping protected path in update payload: {norm_rel}")
                skipped_files.append(norm_rel)
                continue

            # Safe destination path resolution (Zip Slip protection)
            target_path = (dest_root / norm_rel).resolve()
            if not target_path.is_relative_to(dest_root):
                logger.warning(f"[OTA SAFETY] Zip Slip attempt detected for member '{raw_name}'. Skipping.")
                skipped_files.append(norm_rel)
                continue

            target_path.parent.mkdir(parents=True, exist_ok=True)

            with zf.open(member) as source_file, open(target_path, "wb") as dest_file:
                shutil.copyfileobj(source_file, dest_file)

            extracted_files.append(norm_rel)

    logger.info(f"OTA extraction completed: {len(extracted_files)} files written, {len(skipped_files)} protected/skipped.")
    return {
        "status": "success",
        "extracted_count": len(extracted_files),
        "skipped_count": len(skipped_files),
        "extracted_files": extracted_files[:30],
        "skipped_files": skipped_files
    }


def log_update_history(from_version: str, to_version: str, git_commit: str = "", status: str = "SUCCESS", applied_by: str = "admin", details: str = ""):
    """Inserts an immutable audit record into the update_history table."""
    try:
        from backend.database import get_db
        db = get_db()
        db.execute(
            """INSERT INTO update_history (from_version, to_version, git_commit, applied_at, status, applied_by, details)
               VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?)""",
            (from_version, to_version, git_commit, status, applied_by, details)
        )
        db.commit()
        db.close()
    except Exception as exc:
        logger.warning(f"Could not record update_history entry: {exc}")


def get_update_history(limit: int = 50) -> List[Dict[str, Any]]:
    """Retrieves recent update history entries from the database."""
    try:
        from backend.database import get_db
        db = get_db()
        rows = db.execute(
            """SELECT id, from_version, to_version, git_commit, applied_at, status, applied_by, details
               FROM update_history ORDER BY id DESC LIMIT ?""",
            (limit,)
        ).fetchall()
        db.close()
        return [dict(r) for r in rows]
    except Exception as exc:
        logger.warning(f"Could not query update_history: {exc}")
        return []


async def apply_update(download_url: str, expected_sha256: Optional[str] = None, user: str = "admin", pat: Optional[str] = None) -> Dict[str, Any]:
    """
    Downloads update package to /tmp/update.zip.
    Verifies SHA-256 hash if provided.
    Executes create_snapshot().
    Extracts compiled .so binaries and assets over /app.
    Records audit entry in update_history table.
    Cleans up temporary files.
    """
    if not download_url:
        raise ValueError("Download URL is required to apply update.")

    import tempfile
    try:
        tmp_dir = Path("/tmp")
        tmp_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        tmp_dir = Path(tempfile.gettempdir())

    target_zip = tmp_dir / "update.zip"

    headers = {"User-Agent": "Postall_V4-Enterprise-OTA/4.0"}
    if pat and pat.strip():
        headers["Authorization"] = f"Bearer {pat.strip()}"

    logger.info(f"Downloading update payload from {download_url}...")
    async with httpx.AsyncClient(
        timeout=120.0, follow_redirects=True, verify=_get_ssl_context(), trust_env=True
    ) as client:
        resp = await client.get(download_url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError(f"Failed to download update payload from GitHub (HTTP {resp.status_code})")
        content = resp.content

        # SHA-256 verification
        if expected_sha256 and expected_sha256.strip():
            calc_hash = hashlib.sha256(content).hexdigest().lower()
            clean_expected = expected_sha256.strip().split()[0].lower()
            if calc_hash != clean_expected:
                raise ValueError(f"SHA-256 checksum mismatch! Expected: {clean_expected}, Calculated: {calc_hash}")
            logger.info("SHA-256 checksum verified successfully.")

        target_zip.write_bytes(content)

    from_ver = str(get_current_version())
    snapshot_path = create_snapshot()

    try:
        res = extract_update_payload(str(target_zip))
    finally:
        if target_zip.exists():
            target_zip.unlink()

    to_ver_info = get_current_version()
    to_ver = str(to_ver_info)
    git_commit = to_ver_info.get("git_commit", "")

    # Audit logging
    log_update_history(
        from_version=from_ver,
        to_version=to_ver,
        git_commit=git_commit,
        status="SUCCESS",
        applied_by=user,
        details=f"Extracted {res.get('extracted_count', 0)} files. Snapshot: {snapshot_path}"
    )

    return {
        "status": "success",
        "message": f"Update to {to_ver} extracted successfully. Container reboot initiated.",
        "from_version": from_ver,
        "to_version": to_ver,
        "git_commit": git_commit,
        "snapshot_path": snapshot_path,
        "extracted_count": res.get("extracted_count", 0),
        "skipped_count": res.get("skipped_count", 0)
    }


# Compatibility alias
apply_ota_update = apply_update


def rollback_snapshot(snapshot_file: str, user: str = "admin") -> Dict[str, Any]:
    """
    Extracts a selected backup from data/backups/ back over ROOT_DIR,
    restoring previous operational state while strictly protecting data volumes.
    """
    backups_dir = (ROOT_DIR / "data" / "backups").resolve()
    target_path = Path(snapshot_file).resolve()

    if not target_path.exists():
        target_path = (backups_dir / Path(snapshot_file).name).resolve()

    if not target_path.exists():
        raise FileNotFoundError(f"Snapshot archive '{snapshot_file}' not found.")

    if not target_path.is_relative_to(backups_dir):
        raise PermissionError("Rollback snapshot must reside inside data/backups/ directory.")

    from_ver = str(get_current_version())
    res = extract_update_payload(str(target_path), target_dir=str(ROOT_DIR))
    to_ver_info = get_current_version()
    to_ver = str(to_ver_info)

    log_update_history(
        from_version=from_ver,
        to_version=to_ver,
        git_commit=to_ver_info.get("git_commit", ""),
        status="ROLLED_BACK",
        applied_by=user,
        details=f"Rolled back using snapshot '{target_path.name}'. {res['extracted_count']} files restored."
    )

    logger.info(f"Rollback completed using '{target_path.name}': {res['extracted_count']} files restored.")
    return {
        "status": "success",
        "message": f"Snapshot '{target_path.name}' restored successfully.",
        "from_version": from_ver,
        "to_version": to_ver,
        "restored_count": res["extracted_count"]
    }


def trigger_restart(delay_seconds: float = 1.0):
    """
    Schedules a delayed clean process exit (SIGTERM / sys.exit(0)).
    In Docker (with restart: unless-stopped), Docker will immediately restart
    the container with the newly extracted code.
    """
    def _shutdown_worker():
        time.sleep(delay_seconds)
        logger.info("Executing container reboot signal (SIGTERM / sys.exit)...")
        try:
            if hasattr(signal, "SIGTERM"):
                os.kill(os.getpid(), signal.SIGTERM)
            else:
                sys.exit(0)
        except Exception as exc:
            logger.warning(f"Process termination via SIGTERM raised ({exc}); falling back to sys.exit(0)")
            sys.exit(0)

    t = threading.Thread(target=_shutdown_worker, daemon=True)
    t.start()


# Compatibility aliases
trigger_graceful_restart = trigger_restart
trigger_container_restart = trigger_restart
