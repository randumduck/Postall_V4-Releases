"""Silent, fail-closed OTA patch checking and deployment."""

import asyncio
from contextlib import closing
import hashlib
import io
import logging
import os
import re
import shutil
import signal
import sqlite3
import ssl
import stat
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Optional
from urllib.parse import urlparse

import certifi
import httpx
from packaging.version import InvalidVersion, Version

logger = logging.getLogger("postall.ota_updater")
ORACLE_URL = "https://raw.githubusercontent.com/randumduck/Postall_V4-Releases/main/version.json"
APP_ROOT = Path(os.getenv("POSTALL_APP_ROOT", Path(__file__).resolve().parent.parent)).resolve()
DB_PATH = Path(os.getenv("DATABASE_PATH", APP_ROOT / "data" / "postall.db"))
CURRENT_VERSION = os.getenv("APP_VERSION", "4.0.0")
POLL_INTERVAL_SECONDS = 6 * 60 * 60
MAX_PATCH_BYTES = 256 * 1024 * 1024
MAX_EXPANDED_BYTES = 512 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 10_000
ALLOWED_DOWNLOAD_HOSTS = {
    "github.com",
    "objects.githubusercontent.com",
    "release-assets.githubusercontent.com",
    "raw.githubusercontent.com",
}
PROTECTED_NAMES = {".env", "license.key", "postall.db", "postall.db-wal", "postall.db-shm"}
PROTECTED_DIRS = {"data", "keys", "uploads", "assets", "posts", "linkedin_session"}

_last_status: dict[str, Any] = {
    "state": "checking",
    "current_version": CURRENT_VERSION,
    "latest_version": None,
    "oracle_reachable": None,
    "update_available": False,
    "patch_available": False,
    "changelog": [],
    "update_instructions": "",
    "offline": False,
    "last_checked_at": None,
}
_update_lock = asyncio.Lock()
_patch_apply_lock = asyncio.Lock()


def get_ssl_context() -> ssl.SSLContext:
    """Use certifi roots and optionally add an operator-provided enterprise CA."""
    context = ssl.create_default_context(cafile=certifi.where())
    custom_ca = os.getenv("POSTALL_CA_BUNDLE") or os.getenv("SSL_CERT_FILE")
    if custom_ca:
        context.load_verify_locations(cafile=custom_ca)
    return context


def init_audit_ledger() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(DB_PATH, timeout=10)) as connection:
        with connection:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS update_audit_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    applied_date TEXT NOT NULL,
                    from_version TEXT NOT NULL,
                    target_version TEXT NOT NULL,
                    status TEXT NOT NULL,
                    details TEXT NOT NULL DEFAULT ''
                )
            """)


def record_audit(from_version: str, target_version: str, status: str, details: str) -> None:
    init_audit_ledger()
    with closing(sqlite3.connect(DB_PATH, timeout=10)) as connection:
        with connection:
            connection.execute(
                """INSERT INTO update_audit_ledger
                   (applied_date, from_version, target_version, status, details)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    datetime.now(timezone.utc).isoformat(),
                    from_version,
                    target_version,
                    status,
                    details[:2000],
                ),
            )


def get_installed_version() -> str:
    """Return the last successfully installed version, or the image version."""
    try:
        init_audit_ledger()
        with closing(sqlite3.connect(DB_PATH, timeout=5)) as connection:
            row = connection.execute(
                """SELECT target_version FROM update_audit_ledger
                   WHERE status='SUCCESS' ORDER BY id DESC LIMIT 1"""
            ).fetchone()
        if row and row[0]:
            return str(row[0])
    except sqlite3.Error:
        logger.exception("Could not read the installed OTA version from the audit ledger.")
    return CURRENT_VERSION


def get_update_status() -> dict[str, Any]:
    """Return the latest cached check result without making a network request."""
    status = dict(_last_status)
    status["current_version"] = get_installed_version()
    return status


def _validated_version(value: Any) -> Version:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Version Oracle is missing latest_version.")
    try:
        return Version(value.strip().removeprefix("v").removeprefix("V"))
    except InvalidVersion as exc:
        raise ValueError(f"Invalid version from Version Oracle: {value!r}") from exc


def _validate_download_url(url: Any) -> str:
    if not isinstance(url, str):
        raise ValueError("Version Oracle patch_url must be an HTTPS URL.")
    parsed = urlparse(url)
    if (
        parsed.scheme != "https"
        or parsed.hostname not in ALLOWED_DOWNLOAD_HOSTS
        or parsed.username is not None
        or parsed.password is not None
        or not parsed.path.lower().endswith(".zip")
    ):
        raise ValueError("Patch URL must be an HTTPS ZIP hosted on an approved GitHub host.")
    return url


async def fetch_oracle_manifest() -> dict[str, Any]:
    context = get_ssl_context()
    async with httpx.AsyncClient(
        verify=context,
        timeout=15.0,
        follow_redirects=True,
        trust_env=True,
    ) as client:
        response = await client.get(
            ORACLE_URL,
            headers={"Accept": "application/json", "User-Agent": "Postall_V4-OTA/1.0"},
        )
        response.raise_for_status()
        if urlparse(str(response.url)).hostname not in ALLOWED_DOWNLOAD_HOSTS:
            raise ValueError("Version Oracle redirected to an unapproved host.")
        manifest = response.json()
    if not isinstance(manifest, dict):
        raise ValueError("Version Oracle response must be a JSON object.")
    _validated_version(manifest.get("latest_version"))
    changelog = manifest.get("changelog", [])
    if not isinstance(changelog, list) or not all(isinstance(item, str) for item in changelog):
        raise ValueError("Version Oracle changelog must be an array of strings.")
    instructions = manifest.get("update_instructions", "")
    if not isinstance(instructions, str):
        raise ValueError("Version Oracle update_instructions must be a string.")
    return manifest


def _is_protected(relative_path: PurePosixPath) -> bool:
    parts = {part.lower() for part in relative_path.parts}
    if any(part in PROTECTED_DIRS for part in parts):
        return True
    name = relative_path.name.lower()
    return (
        name in PROTECTED_NAMES
        or name.endswith((".db", ".db-wal", ".db-shm", ".sqlite", ".sqlite3"))
        or name.endswith(("-wal", "-shm"))
    )


def _validated_archive_members(archive: zipfile.ZipFile, staging: Path) -> list[tuple[zipfile.ZipInfo, PurePosixPath]]:
    members = archive.infolist()
    if not members or len(members) > MAX_ARCHIVE_MEMBERS:
        raise ValueError("Patch archive is empty or contains too many entries.")

    expanded_size = sum(member.file_size for member in members)
    if expanded_size > MAX_EXPANDED_BYTES:
        raise ValueError("Patch archive exceeds the maximum expanded size.")

    result: list[tuple[zipfile.ZipInfo, PurePosixPath]] = []
    seen: set[str] = set()
    staging_root = staging.resolve()
    for member in members:
        name = member.filename.replace("\\", "/")
        if not name or name.startswith("/") or "\x00" in name:
            raise ValueError(f"Invalid path in patch archive: {member.filename!r}")
        raw_parts = name.rstrip("/").split("/")
        path = PurePosixPath(name)
        if any(part in ("", ".", "..") or ":" in part for part in raw_parts):
            raise ValueError(f"Directory traversal path in patch archive: {member.filename!r}")
        if path.parts[0] not in {"backend", "frontend"}:
            raise ValueError(f"Patch may only contain backend/ or frontend/ files: {member.filename!r}")
        if _is_protected(path):
            raise ValueError(f"Patch contains a protected path: {member.filename!r}")
        normalized = path.as_posix().rstrip("/")
        if normalized in seen:
            raise ValueError(f"Duplicate path in patch archive: {member.filename!r}")
        seen.add(normalized)

        mode = member.external_attr >> 16
        if stat.S_ISLNK(mode):
            raise ValueError(f"Symbolic links are not permitted in patches: {member.filename!r}")
        if member.flag_bits & 0x1:
            raise ValueError("Encrypted ZIP members are not supported.")
        resolved = (staging_root / Path(*path.parts)).resolve()
        if not resolved.is_relative_to(staging_root):
            raise ValueError(f"Directory traversal path in patch archive: {member.filename!r}")
        result.append((member, path))

    corrupt_member = archive.testzip()
    if corrupt_member:
        raise ValueError(f"Patch archive failed CRC verification at {corrupt_member!r}.")
    return result


def _atomic_copy(source: Path, destination: Path) -> None:
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.ota-",
        dir=destination.parent,
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def _install_patch(zip_bytes: bytes, target_version: str) -> int:
    if len(zip_bytes) > MAX_PATCH_BYTES:
        raise ValueError("Patch download exceeds the maximum allowed size.")

    staging = Path(tempfile.mkdtemp(prefix="postall-ota-", dir=os.getenv("OTA_STAGING_DIR", "/tmp")))
    staged_files: list[tuple[Path, Path]] = []
    rollback_files: list[tuple[Path, Optional[Path]]] = []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
            members = _validated_archive_members(archive, staging)
            extracted_total = 0
            for member, relative_path in members:
                if member.is_dir():
                    continue
                staged_path = staging.joinpath(*relative_path.parts)
                staged_path.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member) as source, staged_path.open("wb") as destination:
                    while True:
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        extracted_total += len(chunk)
                        if extracted_total > MAX_EXPANDED_BYTES or extracted_total > MAX_PATCH_BYTES * 4:
                            raise ValueError("Patch archive exceeds the maximum expanded size.")
                        destination.write(chunk)
                staged_files.append((staged_path, APP_ROOT.joinpath(*relative_path.parts)))
            if not staged_files:
                raise ValueError("Patch archive contains no application files.")

        backup_root = staging / ".rollback"
        for source_path, target_path in staged_files:
            if not target_path.resolve().is_relative_to(APP_ROOT):
                raise ValueError(f"Patch target resolves outside the application root: {target_path}")
            target_path.parent.mkdir(parents=True, exist_ok=True)
            ancestor = target_path.parent
            while ancestor != APP_ROOT:
                if ancestor.is_symlink():
                    raise ValueError(f"Refusing to update through symlink directory: {ancestor}")
                ancestor = ancestor.parent
            if target_path.exists() and target_path.is_symlink():
                raise ValueError(f"Refusing to overwrite symlink target: {target_path}")
            backup_path: Optional[Path] = None
            if target_path.exists():
                backup_path = backup_root.joinpath(*target_path.relative_to(APP_ROOT).parts)
                backup_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target_path, backup_path)
            rollback_files.append((target_path, backup_path))
            _atomic_copy(source_path, target_path)

        return len(staged_files)
    except Exception:
        for target_path, backup_path in reversed(rollback_files):
            try:
                if backup_path is None:
                    target_path.unlink(missing_ok=True)
                else:
                    _atomic_copy(backup_path, target_path)
            except OSError:
                logger.exception("Failed to restore file during OTA rollback: %s", target_path)
        raise
    finally:
        shutil.rmtree(staging, ignore_errors=True)


async def _download_patch(url: str, expected_sha256: Optional[str]) -> bytes:
    context = get_ssl_context()
    async with httpx.AsyncClient(
        verify=context,
        timeout=httpx.Timeout(60.0, connect=15.0),
        follow_redirects=True,
        trust_env=True,
    ) as client:
        async with client.stream(
            "GET",
            url,
            headers={"Accept": "application/zip", "User-Agent": "Postall_V4-OTA/1.0"},
        ) as response:
            response.raise_for_status()
            if urlparse(str(response.url)).hostname not in ALLOWED_DOWNLOAD_HOSTS:
                raise ValueError("Patch download redirected to an unapproved host.")
            content_length = response.headers.get("content-length")
            if content_length and int(content_length) > MAX_PATCH_BYTES:
                raise ValueError("Patch download exceeds the maximum allowed size.")

            chunks = bytearray()
            digest = hashlib.sha256()
            async for chunk in response.aiter_bytes():
                chunks.extend(chunk)
                digest.update(chunk)
                if len(chunks) > MAX_PATCH_BYTES:
                    raise ValueError("Patch download exceeds the maximum allowed size.")

    if expected_sha256:
        clean_hash = expected_sha256.strip().split()[0].lower()
        if len(clean_hash) != 64 or digest.hexdigest() != clean_hash:
            raise ValueError("Patch SHA-256 checksum validation failed.")
    return bytes(chunks)


async def check_ota_update() -> dict[str, Any]:
    """Fetch the oracle and cache whether a newer patch is available."""
    global _last_status
    async with _update_lock:
        current = get_installed_version()
        checked_at = datetime.now(timezone.utc).isoformat()
        try:
            manifest = await fetch_oracle_manifest()
            latest = str(_validated_version(manifest["latest_version"]))
            newer = _validated_version(latest) > _validated_version(current)
            patch_url = manifest.get("patch_url")
            patch_sha256 = manifest.get("patch_sha256") or manifest.get("sha256")
            if patch_url:
                patch_url = _validate_download_url(patch_url)
            if patch_sha256 is not None and (
                not isinstance(patch_sha256, str)
                or not re.fullmatch(r"[0-9a-fA-F]{64}", patch_sha256.strip())
            ):
                raise ValueError("Version Oracle patch_sha256 must be a 64-character hexadecimal digest.")
            _last_status = {
                "state": "update_available" if newer else "up_to_date",
                "current_version": current,
                "latest_version": latest,
                "oracle_reachable": True,
                "update_available": newer,
                "patch_available": bool(newer and patch_url),
                "patch_url": patch_url if newer else None,
                "patch_sha256": patch_sha256 if newer else None,
                "changelog": manifest.get("changelog", []),
                "update_instructions": manifest.get("update_instructions", ""),
                "offline": False,
                "release_date": manifest.get("release_date"),
                "last_checked_at": checked_at,
            }
        except (httpx.HTTPError, OSError, ValueError, TypeError) as exc:
            logger.warning("OTA Version Oracle check failed: %s", exc)
            _last_status = {
                "state": "offline",
                "current_version": current,
                "latest_version": None,
                "oracle_reachable": False,
                "update_available": False,
                "patch_available": False,
                "changelog": [],
                "update_instructions": "",
                "offline": True,
                "last_checked_at": checked_at,
                "error": str(exc),
            }
        return dict(_last_status)


async def _apply_latest_patch_locked(status: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Download, validate, atomically install, audit and signal process restart."""
    status = status or await check_ota_update()
    current = status["current_version"]
    latest = status.get("latest_version") or current
    if not status.get("oracle_reachable"):
        return {"status": "error", "message": status.get("error", "Version Oracle is unreachable.")}
    if not status.get("update_available"):
        return {"status": "up_to_date", "current_version": current, "latest_version": latest}
    if _validated_version(latest) <= _validated_version(get_installed_version()):
        return {"status": "up_to_date", "current_version": get_installed_version(), "latest_version": latest}
    if not status.get("patch_available"):
        return {"status": "error", "message": "A newer release is listed, but no verified patch_url is available."}

    try:
        patch_bytes = await _download_patch(status["patch_url"], status.get("patch_sha256"))
        file_count = _install_patch(patch_bytes, latest)
        record_audit(current, latest, "SUCCESS", f"Installed {file_count} files from the verified OTA patch.")
        _last_status.update({"state": "applied", "current_version": latest, "patch_available": False})
        logger.info("OTA patch %s installed; requesting graceful container restart.", latest)
        os.kill(os.getpid(), signal.SIGTERM)
        return {"status": "applied", "from_version": current, "version": latest, "files_updated": file_count}
    except Exception as exc:
        try:
            record_audit(current, latest, "FAILED", str(exc))
        except sqlite3.Error:
            logger.exception("Could not record the failed OTA update in the audit ledger.")
        _last_status.update({"state": "failed", "error": str(exc)})
        logger.exception("OTA patch %s failed.", latest)
        raise


async def apply_latest_patch(status: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Serialize patch application so a user request cannot race the poller."""
    async with _patch_apply_lock:
        return await _apply_latest_patch_locked(status)


async def check_and_apply_ota_update() -> dict[str, Any]:
    status = await check_ota_update()
    if status.get("update_available") and status.get("patch_available"):
        return await apply_latest_patch(status)
    return status


async def periodic_ota_worker() -> None:
    """Poll on process startup and every six hours; cancellation is graceful."""
    while True:
        try:
            status = await check_and_apply_ota_update()
            logger.info("Scheduled OTA check completed: %s.", status.get("state", status.get("status")))
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Scheduled OTA poll failed; will retry on the next interval.")
        await asyncio.sleep(POLL_INTERVAL_SECONDS)


def list_update_audit_ledger(limit: int = 50) -> list[dict[str, Any]]:
    init_audit_ledger()
    with closing(sqlite3.connect(DB_PATH, timeout=10)) as connection:
        connection.row_factory = sqlite3.Row
        rows = connection.execute(
            "SELECT * FROM update_audit_ledger ORDER BY id DESC LIMIT ?",
            (max(1, min(limit, 200)),),
        ).fetchall()
    return [dict(row) for row in rows]
