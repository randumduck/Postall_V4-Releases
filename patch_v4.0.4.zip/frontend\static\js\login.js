/**
 * Postall_V4 - Enterprise Interactive Login Engine
 * Features:
 * - Native HTML5 Canvas "Golden Sand" Particle Mesh with Distance Interconnection
 * - Magnetic Mouse Gravitational Vectoring
 * - Local & LDAP Multi-Auth Switching
 * - Secure Forgot Password Dispatch & Force Reset Workflow
 */

(function () {
    'use strict';

    /* ==========================================================================
       GOLDEN SAND PARTICLE MESH CANVAS ENGINE
       ========================================================================== */
    const canvas = document.getElementById('mesh-canvas');
    const ctx = canvas?.getContext('2d');
    if (canvas && ctx) {
        let width = 0;
        let height = 0;
        const particles = [];
        const mouse = { x: 0, y: 0, active: false };
        const colors = [
            { r: 245, g: 158, b: 11, alpha: 0.7 },
            { r: 217, g: 119, b: 6, alpha: 0.5 }
        ];
        const particleCount = 125;
        const connectDistance = 110;
        const connectDistanceSquared = connectDistance * connectDistance;

        function resize() {
            width = Math.max(1, window.innerWidth);
            height = Math.max(1, window.innerHeight);
            const dpr = Math.max(1, window.devicePixelRatio || 1);
            canvas.width = Math.round(width * dpr);
            canvas.height = Math.round(height * dpr);
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            if (!particles.length) {
                for (let i = 0; i < particleCount; i++) {
                    particles.push({
                        x: Math.random() * width,
                        y: Math.random() * height,
                        vx: (Math.random() - 0.5) * 0.42,
                        vy: (Math.random() - 0.5) * 0.42,
                        radius: 1 + Math.random() * 1.3,
                        color: colors[Math.floor(Math.random() * colors.length)]
                    });
                }
            } else {
                particles.forEach(p => {
                    p.x = Math.min(p.x, width);
                    p.y = Math.min(p.y, height);
                });
            }
        }

        window.addEventListener('resize', resize, { passive: true });
        window.addEventListener('pointermove', event => {
            mouse.x = event.clientX;
            mouse.y = event.clientY;
            mouse.active = true;
        }, { passive: true });
        window.addEventListener('pointerout', event => {
            if (!event.relatedTarget) mouse.active = false;
        }, { passive: true });
        resize();

        function isDelaunayTriangle(i, j, k) {
            const a = particles[i], b = particles[j], c = particles[k];
            const determinant = 2 * (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y));
            if (Math.abs(determinant) < 0.01) return false;
            const aSquared = a.x * a.x + a.y * a.y;
            const bSquared = b.x * b.x + b.y * b.y;
            const cSquared = c.x * c.x + c.y * c.y;
            const centerX = (aSquared * (b.y - c.y) + bSquared * (c.y - a.y) + cSquared * (a.y - b.y)) / determinant;
            const centerY = (aSquared * (c.x - b.x) + bSquared * (a.x - c.x) + cSquared * (b.x - a.x)) / determinant;
            const radiusSquared = (centerX - a.x) ** 2 + (centerY - a.y) ** 2;
            return !particles.some((point, index) => {
                if (index === i || index === j || index === k) return false;
                return (point.x - centerX) ** 2 + (point.y - centerY) ** 2 < radiusSquared - 0.5;
            });
        }

        function renderMesh() {
            ctx.clearRect(0, 0, width, height);
            const neighbors = particles.map(() => []);

            for (let i = 0; i < particles.length; i++) {
                const p = particles[i];
                if (mouse.active) {
                    const dx = mouse.x - p.x;
                    const dy = mouse.y - p.y;
                    const distanceSquared = dx * dx + dy * dy;
                    if (distanceSquared < 180 * 180 && distanceSquared > 1) {
                        p.vx += (dx / Math.sqrt(distanceSquared)) * 0.0015;
                        p.vy += (dy / Math.sqrt(distanceSquared)) * 0.0015;
                    }
                }
                p.vx = Math.max(-0.55, Math.min(0.55, p.vx));
                p.vy = Math.max(-0.55, Math.min(0.55, p.vy));
                p.x += p.vx;
                p.y += p.vy;
                if (p.x < 0 || p.x > width) { p.x = Math.max(0, Math.min(width, p.x)); p.vx *= -1; }
                if (p.y < 0 || p.y > height) { p.y = Math.max(0, Math.min(height, p.y)); p.vy *= -1; }
            }

            for (let i = 0; i < particles.length; i++) {
                const a = particles[i];
                for (let j = i + 1; j < particles.length; j++) {
                    const b = particles[j];
                    const dx = a.x - b.x;
                    const dy = a.y - b.y;
                    const distanceSquared = dx * dx + dy * dy;
                    if (distanceSquared >= connectDistanceSquared) continue;
                    const distance = Math.sqrt(distanceSquared);
                    const alpha = 0.18 + (1 - distance / connectDistance) * 0.22;
                    neighbors[i].push(j);
                    ctx.beginPath();
                    ctx.moveTo(a.x, a.y);
                    ctx.lineTo(b.x, b.y);
                    const lineGradient = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
                    lineGradient.addColorStop(0, `rgba(245, 158, 11, ${alpha})`);
                    lineGradient.addColorStop(1, `rgba(217, 119, 6, ${alpha})`);
                    ctx.strokeStyle = lineGradient;
                    ctx.lineWidth = 0.7;
                    ctx.stroke();
                }
            }

            for (let i = 0; i < particles.length; i++) {
                const adjacent = neighbors[i];
                for (let a = 0; a < adjacent.length; a++) {
                    const j = adjacent[a];
                    for (let b = a + 1; b < adjacent.length; b++) {
                        const k = adjacent[b];
                        if (!neighbors[j].includes(k) || !isDelaunayTriangle(i, j, k)) continue;
                        const p1 = particles[i], p2 = particles[j], p3 = particles[k];
                        const gradient = ctx.createLinearGradient(p1.x, p1.y, p3.x, p3.y);
                        gradient.addColorStop(0, "rgba(217, 119, 6, 0.04)");
                        gradient.addColorStop(1, "rgba(245, 158, 11, 0.015)");
                        ctx.beginPath();
                        ctx.moveTo(p1.x, p1.y);
                        ctx.lineTo(p2.x, p2.y);
                        ctx.lineTo(p3.x, p3.y);
                        ctx.closePath();
                        ctx.fillStyle = gradient;
                        ctx.fill();
                    }
                }
            }

            for (const p of particles) {
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${p.color.r}, ${p.color.g}, ${p.color.b}, ${p.color.alpha})`;
                ctx.fill();
            }
            requestAnimationFrame(renderMesh);
        }

        requestAnimationFrame(renderMesh);
    }


    /* ==========================================================================
       AUTHENTICATION LOGIC & FORM WORKFLOWS
       ========================================================================== */

    // Check if user is already authenticated
    const existingToken = localStorage.getItem('token');
    if (existingToken) {
        window.location.replace('/dashboard');
        return;
    }

    // DOM Elements
    const tabLocal = document.getElementById('tabLocal');
    const tabLdap = document.getElementById('tabLdap');

    const viewLogin = document.getElementById('viewLogin');
    const viewForgotPassword = document.getElementById('viewForgotPassword');
    const viewForceReset = document.getElementById('viewForceReset');
    const viewMfaChallenge = document.getElementById('viewMfaChallenge');

    const loginForm = document.getElementById('loginForm');
    const forgotForm = document.getElementById('forgotForm');
    const resetForm = document.getElementById('resetForm');
    const mfaForm = document.getElementById('mfaForm');
    const mfaCodeInput = document.getElementById('mfaCodeInput');
    const mfaTempToken = document.getElementById('mfaTempToken');
    const mfaSubmitBtn = document.getElementById('mfaSubmitBtn');
    const cancelMfaBtn = document.getElementById('cancelMfaBtn');
    const btnSsoLogin = document.getElementById('btnSsoLogin');

    const usernameInput = document.getElementById('usernameInput');
    const passwordInput = document.getElementById('passwordInput');
    const usernameLabel = document.getElementById('usernameLabel');
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    const ldapHint = document.getElementById('ldapHint');
    const loginTitle = document.getElementById('loginTitle');
    const loginSubtitle = document.getElementById('loginSubtitle');
    const loginSubmitBtn = document.getElementById('loginSubmitBtn');
    const loginSubmitText = document.getElementById('loginSubmitText');
    const togglePwBtn = document.getElementById('togglePwBtn');

    const forgotInput = document.getElementById('forgotInput');
    const forgotSubmitBtn = document.getElementById('forgotSubmitBtn');
    const backToLoginBtn = document.getElementById('backToLoginBtn');

    const newPasswordInput = document.getElementById('newPasswordInput');
    const confirmPasswordInput = document.getElementById('confirmPasswordInput');
    const resetSubmitBtn = document.getElementById('resetSubmitBtn');

    const authAlert = document.getElementById('authAlert');
    const authAlertText = document.getElementById('authAlertText');
    const toastContainer = document.getElementById('toast-container');

    let currentAuthType = 'local'; // 'local' | 'ldap'
    let forceResetToken = null;

    // Switch between Views
    function switchView(targetView) {
        hideAlert();
        [viewLogin, viewForgotPassword, viewForceReset, viewMfaChallenge].forEach(v => {
            if (v) v.classList.remove('active-view');
        });
        if (targetView) {
            targetView.classList.add('active-view');
        }
    }

    // Alert Messages inside Auth Card
    function showAlert(type, message) {
        if (!authAlert || !authAlertText) return;
        authAlert.className = `auth-alert auth-alert-${type} visible`;
        authAlertText.textContent = message;
    }

    function hideAlert() {
        if (!authAlert) return;
        authAlert.className = 'auth-alert';
    }

    // Floating Toasts
    function showToast(type, message, duration = 4000) {
        if (!toastContainer) return;
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        let iconSvg = '';
        if (type === 'success') {
            iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
        } else if (type === 'error') {
            iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
        } else {
            iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#F5D061" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
        }

        toast.innerHTML = `${iconSvg}<span>${message}</span>`;
        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'toastFadeOut 0.3s forwards';
            setTimeout(() => {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 300);
        }, duration);
    }

    // Toggle Password Visibility
    if (togglePwBtn && passwordInput) {
        togglePwBtn.addEventListener('click', function () {
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            togglePwBtn.innerHTML = isPassword
                ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`
                : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`;
        });
    }

    // Tab Switching: Local vs LDAP
    if (tabLocal && tabLdap) {
        tabLocal.addEventListener('click', function () {
            if (currentAuthType === 'local') return;
            currentAuthType = 'local';
            tabLocal.classList.add('active');
            tabLocal.setAttribute('aria-selected', 'true');
            tabLdap.classList.remove('active');
            tabLdap.setAttribute('aria-selected', 'false');

            // UI Adjustments for Local
            usernameLabel.textContent = 'Operator ID';
            usernameInput.placeholder = 'admin';
            forgotPasswordLink.style.display = 'inline-block';
            ldapHint.style.display = 'none';
            loginTitle.textContent = 'Operator Verification';
            loginSubtitle.textContent = 'Authenticate to initialize secure orchestration console.';
            loginSubmitText.textContent = 'Initialize Session';
            hideAlert();
        });

        tabLdap.addEventListener('click', function () {
            if (currentAuthType === 'ldap') return;
            currentAuthType = 'ldap';
            tabLdap.classList.add('active');
            tabLdap.setAttribute('aria-selected', 'true');
            tabLocal.classList.remove('active');
            tabLocal.setAttribute('aria-selected', 'false');

            // UI Adjustments for LDAP (hide Forgot Password)
            usernameLabel.textContent = 'Directory Username';
            usernameInput.placeholder = 'username@domain.com or sAMAccountName';
            forgotPasswordLink.style.display = 'none';
            ldapHint.style.display = 'flex';
            loginTitle.textContent = 'Directory Sign-In';
            loginSubtitle.textContent = 'Authenticate via corporate LDAP or Active Directory credentials.';
            loginSubmitText.textContent = 'Authenticate via LDAP';
            hideAlert();
        });
    }

    // Forgot Password link click
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', function (e) {
            e.preventDefault();
            switchView(viewForgotPassword);
            if (forgotInput) {
                forgotInput.value = usernameInput.value.trim();
                forgotInput.focus();
            }
        });
    }

    // Back to Login button
    if (backToLoginBtn) {
        backToLoginBtn.addEventListener('click', function () {
            switchView(viewLogin);
        });
    }

    /* ==========================================================================
       1. LOGIN SUBMISSION HANDLER
       ========================================================================== */
    if (loginForm) {
        loginForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();

            if (!username || !password) {
                showAlert('error', 'Please provide both username and password.');
                return;
            }

            loginSubmitBtn.disabled = true;
            const originalText = loginSubmitText.textContent;
            loginSubmitText.textContent = 'Authenticating...';

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        username: username,
                        password: password,
                        auth_type: currentAuthType
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    // Check for Mandatory Password Reset
                    if (data.status === 'force_reset' || data.must_reset) {
                        forceResetToken = data.token || data.access_token;
                        sessionStorage.setItem('reset_token', forceResetToken);
                        switchView(viewForceReset);
                        showAlert('info', 'Temporary or default passkey detected. Please define a permanent password.');
                        showToast('info', 'Password update required to proceed.');
                        if (newPasswordInput) newPasswordInput.focus();
                        return;
                    }

                    // Successful Direct Login
                    const token = data.access_token || data.token;
                    if (token) {
                        localStorage.setItem('token', token);
                        showToast('success', 'Authentication verified. Launching console...');
                        setTimeout(() => {
                            window.location.replace('/dashboard');
                        }, 400);
                    } else {
                        throw new Error('Authentication token missing from response payload.');
                    }
                } else if (response.status === 403 && (data.detail === 'MFA_REQUIRED' || data.status === 'mfa_required')) {
                    // Two-Factor Authentication Challenge
                    if (mfaTempToken) mfaTempToken.value = data.temp_token || '';
                    switchView(viewMfaChallenge);
                    showAlert('info', 'Two-Factor Authentication required. Enter the 6-digit code from your authenticator app.');
                    if (mfaCodeInput) {
                        mfaCodeInput.value = '';
                        mfaCodeInput.focus();
                    }
                    return;
                } else {
                    const errorMsg = data.detail || (currentAuthType === 'ldap' 
                        ? 'LDAP authentication failed. Verify directory credentials.' 
                        : 'Invalid operator ID or passkey.');
                    showAlert('error', errorMsg);
                }
            } catch (err) {
                showAlert('error', err.message || 'Network failure connecting to core authentication service.');
            } finally {
                loginSubmitBtn.disabled = false;
                loginSubmitText.textContent = originalText;
            }
        });
    }

    /* ==========================================================================
       2. FORGOT PASSWORD HANDLER
       ========================================================================== */
    if (forgotForm) {
        forgotForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const target = forgotInput.value.trim();
            if (!target) {
                showAlert('error', 'Please enter your Operator ID or registered email.');
                return;
            }

            forgotSubmitBtn.disabled = true;
            forgotSubmitBtn.querySelector('span').textContent = 'Dispatching Passkey...';

            try {
                const response = await fetch('/api/auth/forgot-password', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username_or_email: target })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    showToast('success', 'Temporary password sent to email.');
                    if (data.dev_temp_pw) {
                        showAlert('success', `Temporary Passkey: ${data.dev_temp_pw}`);
                    } else {
                        showAlert('success', 'A temporary passkey has been dispatched to your email address.');
                    }

                    setTimeout(() => {
                        usernameInput.value = target;
                        passwordInput.value = data.dev_temp_pw || '';
                        switchView(viewLogin);
                        showAlert('info', 'Log in using your temporary passkey. You will then set a new password.');
                        passwordInput.focus();
                    }, data.dev_temp_pw ? 3500 : 2000);
                } else {
                    showAlert('error', data.detail || 'Unable to locate user account matching provided identifier.');
                }
            } catch (err) {
                showAlert('error', 'Network failure while dispatching password recovery request.');
            } finally {
                forgotSubmitBtn.disabled = false;
                forgotSubmitBtn.querySelector('span').textContent = 'Send Temporary Passkey';
            }
        });
    }

    /* ==========================================================================
       3. FORCE RESET PASSWORD HANDLER
       ========================================================================== */
    if (resetForm) {
        resetForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const newPw = newPasswordInput.value.trim();
            const confirmPw = confirmPasswordInput.value.trim();

            if (newPw.length < 8) {
                showAlert('error', 'New password must be at least 8 characters in length.');
                return;
            }

            if (newPw !== confirmPw) {
                showAlert('error', 'New password and confirmation do not match.');
                return;
            }

            const token = forceResetToken || sessionStorage.getItem('reset_token');
            if (!token) {
                showAlert('error', 'Session verification token lost. Please log in again.');
                setTimeout(() => switchView(viewLogin), 1500);
                return;
            }

            resetSubmitBtn.disabled = true;
            resetSubmitBtn.querySelector('span').textContent = 'Updating Passkey...';

            try {
                const response = await fetch('/api/auth/reset-password', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        new_password: newPw,
                        confirm_password: confirmPw
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    const freshToken = data.access_token || data.token || token;
                    localStorage.setItem('token', freshToken);
                    sessionStorage.removeItem('reset_token');

                    showToast('success', 'Passkey successfully updated! Launching console...');
                    showAlert('success', 'Credentials updated. Redirecting to Enterprise Dashboard...');
                    setTimeout(() => {
                        window.location.replace('/dashboard');
                    }, 600);
                } else {
                    showAlert('error', data.detail || 'Failed to update passkey. Please check password criteria.');
                }
            } catch (err) {
                showAlert('error', 'Network failure updating password credentials.');
            } finally {
                resetSubmitBtn.disabled = false;
                resetSubmitBtn.querySelector('span').textContent = 'Update Password & Launch';
            }
        });
    }

    /* ==========================================================================
       4. CORPORATE SSO (OIDC) HANDLER
       ========================================================================== */
    if (btnSsoLogin) {
        btnSsoLogin.addEventListener('click', function () {
            window.location.href = '/api/auth/sso/login';
        });
    }

    async function checkSsoReadiness() {
        try {
            const res = await fetch('/api/auth/sso/status');
            const data = await res.json();
            const ssoBox = document.getElementById('ssoContainer');
            if (ssoBox) {
                if (data.sso_enabled && data.client_configured) {
                    ssoBox.style.display = 'block';
                } else {
                    ssoBox.style.display = 'none';
                }
            }
        } catch (e) {
            // Keep container default state if network check fails
        }
    }
    checkSsoReadiness();

    /* ==========================================================================
       5. TWO-FACTOR AUTHENTICATION (TOTP MFA) HANDLER
       ========================================================================== */
    if (mfaForm) {
        mfaForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const code = mfaCodeInput ? mfaCodeInput.value.trim() : '';
            const tempToken = mfaTempToken ? mfaTempToken.value.trim() : '';

            if (!code || code.length !== 6) {
                showAlert('error', 'Please enter a valid 6-digit verification code.');
                return;
            }

            if (mfaSubmitBtn) {
                mfaSubmitBtn.disabled = true;
                const txtSpan = mfaSubmitBtn.querySelector('span');
                if (txtSpan) txtSpan.textContent = 'Verifying Code...';
            }

            try {
                const response = await fetch('/api/auth/mfa/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        code: code,
                        temp_token: tempToken
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    const token = data.access_token || data.token;
                    if (token) {
                        localStorage.setItem('token', token);
                        showToast('success', 'Two-Factor Authentication verified! Launching console...');
                        showAlert('success', 'Identity confirmed. Launching Command Center...');
                        setTimeout(() => {
                            window.location.replace('/dashboard');
                        }, 500);
                    } else {
                        throw new Error('Access token missing from MFA verification payload.');
                    }
                } else {
                    showAlert('error', data.detail || 'Invalid verification code. Please check your authenticator app.');
                }
            } catch (err) {
                showAlert('error', err.message || 'Verification failure connecting to authentication service.');
            } finally {
                if (mfaSubmitBtn) {
                    mfaSubmitBtn.disabled = false;
                    const txtSpan = mfaSubmitBtn.querySelector('span');
                    if (txtSpan) txtSpan.textContent = 'Verify Identity';
                }
            }
        });
    }

    if (cancelMfaBtn) {
        cancelMfaBtn.addEventListener('click', function () {
            if (mfaCodeInput) mfaCodeInput.value = '';
            if (mfaTempToken) mfaTempToken.value = '';
            switchView(viewLogin);
        });
    }

})();
