"""Postall_V4 Enterprise Storage Engine
Provides a unified, pluggable object storage abstraction supporting:
1. LocalStorageProvider: Zero-cloud, air-gapped local filesystem with path traversal protection.
2. S3StorageProvider: Enterprise S3-compatible object storage (AWS S3, MinIO, Cloudflare R2, Ceph)
   with auto-bucket creation, presigned URLs, streaming, and transparent fallback to local disk.
3. Secrets Vault Integration: S3 secret keys are automatically decrypted from the Fernet AES-256 vault.
"""
from __future__ import annotations

import io
import os
import time
import uuid
import sqlite3
import mimetypes
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Dict, Any, Union

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "postall.db"


class StorageProvider(ABC):
    """Abstract interface for enterprise media and artifact storage."""

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Name of the storage provider (e.g. 'local', 's3')."""
        pass

    @abstractmethod
    def save_file(self, key: str, data: bytes, content_type: Optional[str] = None) -> str:
        """Persist binary data under the given key/path. Returns canonical identifier or relative path."""
        pass

    @abstractmethod
    def get_file(self, key: str) -> Optional[bytes]:
        """Retrieve binary content for a given key/path."""
        pass

    @abstractmethod
    def file_exists(self, key: str) -> bool:
        """Check if an object exists."""
        pass

    @abstractmethod
    def delete_file(self, key: str) -> bool:
        """Delete an object by key."""
        pass

    @abstractmethod
    def get_url(self, key: str, expires_in: int = 3600) -> str:
        """Get an accessible URL or endpoint path for the resource."""
        pass

    @abstractmethod
    def health_check(self) -> Dict[str, Any]:
        """Perform a synthetic read/write/delete round-trip probe."""
        pass


class LocalStorageProvider(StorageProvider):
    """Production-hardened local filesystem storage provider with directory traversal defense."""

    def __init__(self, base_dir: Optional[Path] = None):
        self.base_dir = (base_dir or DATA_DIR).resolve()
        self.base_dir.mkdir(parents=True, exist_ok=True)

    @property
    def provider_name(self) -> str:
        return "local"

    def _resolve_path(self, key: str) -> Path:
        """Safely resolve path within base_dir or project ROOT, preventing directory traversal."""
        # Normalize key slashes
        clean_key = key.replace("\\", "/").lstrip("/")
        
        # If key is already an absolute path within ROOT, allow it
        candidate = Path(clean_key)
        if candidate.is_absolute():
            resolved = candidate.resolve()
            try:
                resolved.relative_to(ROOT.resolve())
                return resolved
            except ValueError:
                # Outside root; redirect into base_dir
                return (self.base_dir / resolved.name).resolve()

        # If key starts with data/ or frontend/, resolve against ROOT
        if clean_key.startswith("data/") or clean_key.startswith("data\\"):
            resolved = (ROOT / clean_key).resolve()
        else:
            resolved = (self.base_dir / clean_key).resolve()

        # Enforce directory boundary security
        try:
            resolved.relative_to(ROOT.resolve())
        except ValueError:
            raise PermissionError(f"Directory traversal detected: {key}")
        return resolved

    def save_file(self, key: str, data: bytes, content_type: Optional[str] = None) -> str:
        target = self._resolve_path(key)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        try:
            return str(target.relative_to(ROOT)).replace("\\", "/")
        except ValueError:
            return str(target).replace("\\", "/")

    def get_file(self, key: str) -> Optional[bytes]:
        try:
            target = self._resolve_path(key)
            if target.is_file():
                return target.read_bytes()
        except Exception:
            return None
        return None

    def file_exists(self, key: str) -> bool:
        try:
            target = self._resolve_path(key)
            return target.is_file()
        except Exception:
            return False

    def delete_file(self, key: str) -> bool:
        try:
            target = self._resolve_path(key)
            if target.is_file():
                target.unlink()
                return True
        except Exception:
            return False
        return False

    def get_url(self, key: str, expires_in: int = 3600) -> str:
        # Standard local asset URL
        clean = key.replace("\\", "/").lstrip("/")
        if clean.startswith("data/assets/"):
            return f"/api/assets/{Path(clean).name}"
        return f"/{clean}"

    def health_check(self) -> Dict[str, Any]:
        probe_key = f"storage_probe_{uuid.uuid4().hex[:8]}.tmp"
        probe_data = b"POSTALL_STORAGE_INTEGRITY_CHECK_" + os.urandom(256)
        start = time.perf_counter()
        try:
            self.save_file(probe_key, probe_data)
            readback = self.get_file(probe_key)
            if readback != probe_data:
                return {
                    "status": "degraded",
                    "provider": "local",
                    "error": "Data verification mismatch on storage readback",
                    "latency_ms": round((time.perf_counter() - start) * 1000, 2)
                }
            self.delete_file(probe_key)
            elapsed_ms = round((time.perf_counter() - start) * 1000, 2)
            return {
                "status": "healthy",
                "provider": "local",
                "path": str(self.base_dir),
                "latency_ms": elapsed_ms,
                "detail": f"Local storage verified operational ({elapsed_ms}ms round-trip)"
            }
        except Exception as exc:
            return {
                "status": "error",
                "provider": "local",
                "error": str(exc),
                "latency_ms": round((time.perf_counter() - start) * 1000, 2)
            }


class S3StorageProvider(StorageProvider):
    """High-availability enterprise S3 & MinIO object storage provider with local fallback."""

    def __init__(
        self,
        bucket_name: str,
        endpoint_url: Optional[str] = None,
        region_name: str = "us-east-1",
        access_key_id: Optional[str] = None,
        secret_access_key: Optional[str] = None,
        local_fallback_dir: Optional[Path] = None
    ):
        self.bucket_name = bucket_name.strip()
        self.endpoint_url = endpoint_url.strip() if endpoint_url and endpoint_url.strip() else None
        self.region_name = (region_name or "us-east-1").strip()
        self.access_key_id = access_key_id.strip() if access_key_id else None
        self.secret_access_key = secret_access_key.strip() if secret_access_key else None
        self.local_backup = LocalStorageProvider(local_fallback_dir)
        self._s3_client = None

    @property
    def provider_name(self) -> str:
        return "s3"

    def _get_client(self):
        """Lazy-initialize boto3 S3 client."""
        if self._s3_client is not None:
            return self._s3_client
        try:
            import boto3
            from botocore.config import Config
            config = Config(
                signature_version="s3v4",
                retries={"max_attempts": 3, "mode": "standard"},
                connect_timeout=5,
                read_timeout=15
            )
            client_kwargs = {
                "service_name": "s3",
                "region_name": self.region_name,
                "config": config
            }
            if self.endpoint_url:
                client_kwargs["endpoint_url"] = self.endpoint_url
            if self.access_key_id and self.secret_access_key:
                client_kwargs["aws_access_key_id"] = self.access_key_id
                client_kwargs["aws_secret_access_key"] = self.secret_access_key

            self._s3_client = boto3.client(**client_kwargs)
            return self._s3_client
        except Exception as exc:
            raise RuntimeError(f"Failed to initialize S3 client: {exc}") from exc

    def _ensure_bucket(self):
        """Ensure the target bucket exists, attempting creation if needed."""
        client = self._get_client()
        try:
            client.head_bucket(Bucket=self.bucket_name)
        except Exception:
            try:
                create_kwargs: Dict[str, Any] = {"Bucket": self.bucket_name}
                if self.region_name and self.region_name != "us-east-1":
                    create_kwargs["CreateBucketConfiguration"] = {"LocationConstraint": self.region_name}
                client.create_bucket(**create_kwargs)
            except Exception:
                pass  # Bucket may exist or creation is not permitted for current IAM role

    def save_file(self, key: str, data: bytes, content_type: Optional[str] = None) -> str:
        # Always mirror to local backup first for guaranteed zero-data-loss resiliency
        local_rel = self.local_backup.save_file(key, data, content_type)

        clean_key = key.replace("\\", "/").lstrip("/")
        if not content_type:
            content_type, _ = mimetypes.guess_type(clean_key)
            if not content_type:
                content_type = "application/octet-stream"

        try:
            client = self._get_client()
            client.put_object(
                Bucket=self.bucket_name,
                Key=clean_key,
                Body=data,
                ContentType=content_type
            )
            return f"s3://{self.bucket_name}/{clean_key}"
        except Exception:
            # Fall back to local path with zero downtime
            return local_rel

    def get_file(self, key: str) -> Optional[bytes]:
        clean_key = key.replace("\\", "/").lstrip("/")
        # Strip s3://bucket/ prefix if present
        if clean_key.startswith("s3://"):
            parts = clean_key[5:].split("/", 1)
            if len(parts) == 2:
                clean_key = parts[1]

        try:
            client = self._get_client()
            response = client.get_object(Bucket=self.bucket_name, Key=clean_key)
            return response["Body"].read()
        except Exception:
            # S3 miss or network issue -> fallback to local disk
            return self.local_backup.get_file(key)

    def file_exists(self, key: str) -> bool:
        clean_key = key.replace("\\", "/").lstrip("/")
        if clean_key.startswith("s3://"):
            parts = clean_key[5:].split("/", 1)
            if len(parts) == 2:
                clean_key = parts[1]
        try:
            client = self._get_client()
            client.head_object(Bucket=self.bucket_name, Key=clean_key)
            return True
        except Exception:
            return self.local_backup.file_exists(key)

    def delete_file(self, key: str) -> bool:
        clean_key = key.replace("\\", "/").lstrip("/")
        if clean_key.startswith("s3://"):
            parts = clean_key[5:].split("/", 1)
            if len(parts) == 2:
                clean_key = parts[1]
        deleted_s3 = False
        try:
            client = self._get_client()
            client.delete_object(Bucket=self.bucket_name, Key=clean_key)
            deleted_s3 = True
        except Exception:
            pass
        deleted_local = self.local_backup.delete_file(key)
        return deleted_s3 or deleted_local

    def get_url(self, key: str, expires_in: int = 3600) -> str:
        clean_key = key.replace("\\", "/").lstrip("/")
        if clean_key.startswith("s3://"):
            parts = clean_key[5:].split("/", 1)
            if len(parts) == 2:
                clean_key = parts[1]
        try:
            client = self._get_client()
            url = client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket_name, "Key": clean_key},
                ExpiresIn=expires_in
            )
            return url
        except Exception:
            return self.local_backup.get_url(key, expires_in)

    def health_check(self) -> Dict[str, Any]:
        probe_key = f"postall_probe_{uuid.uuid4().hex[:8]}.tmp"
        probe_data = b"POSTALL_S3_INTEGRITY_PROBE_" + os.urandom(128)
        start = time.perf_counter()
        try:
            client = self._get_client()
            self._ensure_bucket()
            client.put_object(
                Bucket=self.bucket_name,
                Key=probe_key,
                Body=probe_data,
                ContentType="application/octet-stream"
            )
            resp = client.get_object(Bucket=self.bucket_name, Key=probe_key)
            readback = resp["Body"].read()
            client.delete_object(Bucket=self.bucket_name, Key=probe_key)
            elapsed_ms = round((time.perf_counter() - start) * 1000, 2)
            if readback != probe_data:
                return {
                    "status": "degraded",
                    "provider": "s3",
                    "bucket": self.bucket_name,
                    "endpoint": self.endpoint_url or "AWS Standard",
                    "error": "Checksum/readback verification failed",
                    "latency_ms": elapsed_ms
                }
            return {
                "status": "healthy",
                "provider": "s3",
                "bucket": self.bucket_name,
                "endpoint": self.endpoint_url or "AWS Standard",
                "region": self.region_name,
                "latency_ms": elapsed_ms,
                "detail": f"S3 bucket read/write verified successfully ({elapsed_ms}ms)"
            }
        except Exception as exc:
            return {
                "status": "error",
                "provider": "s3",
                "bucket": self.bucket_name,
                "endpoint": self.endpoint_url or "AWS Standard",
                "error": str(exc),
                "latency_ms": round((time.perf_counter() - start) * 1000, 2)
            }


_GLOBAL_STORAGE_PROVIDER: Optional[StorageProvider] = None


def get_storage_provider(force_reload: bool = False) -> StorageProvider:
    """Retrieve the active enterprise StorageProvider based on database settings and environment."""
    global _GLOBAL_STORAGE_PROVIDER
    if _GLOBAL_STORAGE_PROVIDER is not None and not force_reload:
        return _GLOBAL_STORAGE_PROVIDER

    backend_type = os.getenv("STORAGE_BACKEND", "local").lower().strip()
    s3_endpoint = os.getenv("S3_ENDPOINT_URL", "")
    s3_bucket = os.getenv("S3_BUCKET_NAME", "postall-assets")
    s3_region = os.getenv("S3_REGION", "us-east-1")
    s3_access_key = os.getenv("S3_ACCESS_KEY", "")
    s3_secret_key = os.getenv("S3_SECRET_KEY", "")

    # Query settings from postall.db if available
    if DB_PATH.exists():
        try:
            conn = sqlite3.connect(DB_PATH)
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT key, value FROM settings WHERE key LIKE 's3_%' OR key='storage_backend'").fetchall()
            conn.close()
            settings_map = {r["key"]: r["value"] for r in rows if r["value"]}
            if "storage_backend" in settings_map:
                backend_type = settings_map["storage_backend"].lower().strip()
            if "s3_endpoint_url" in settings_map:
                s3_endpoint = settings_map["s3_endpoint_url"].strip()
            if "s3_bucket_name" in settings_map:
                s3_bucket = settings_map["s3_bucket_name"].strip()
            if "s3_region" in settings_map:
                s3_region = settings_map["s3_region"].strip()
            if "s3_access_key" in settings_map:
                s3_access_key = settings_map["s3_access_key"].strip()
            if "s3_secret_key" in settings_map:
                s3_secret_key = settings_map["s3_secret_key"].strip()
        except Exception:
            pass

    # Decrypt s3_secret_key from Vault if encrypted
    if s3_secret_key:
        try:
            from backend.vault import get_secret_vault
            vault = get_secret_vault()
            # If value starts with enc: or vault lookup is available
            s3_secret_key = vault.get_secret("s3_secret_key") or s3_secret_key
        except Exception:
            pass

    if backend_type == "s3" and s3_bucket:
        try:
            _GLOBAL_STORAGE_PROVIDER = S3StorageProvider(
                bucket_name=s3_bucket,
                endpoint_url=s3_endpoint or None,
                region_name=s3_region or "us-east-1",
                access_key_id=s3_access_key or None,
                secret_access_key=s3_secret_key or None
            )
            return _GLOBAL_STORAGE_PROVIDER
        except Exception:
            # Fall back to local if S3 initialization fails
            _GLOBAL_STORAGE_PROVIDER = LocalStorageProvider()
            return _GLOBAL_STORAGE_PROVIDER

    _GLOBAL_STORAGE_PROVIDER = LocalStorageProvider()
    return _GLOBAL_STORAGE_PROVIDER
