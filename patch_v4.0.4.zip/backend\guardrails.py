"""
Postall_V4 - Enterprise AI Governance & Guardrails Engine
(backend/guardrails.py)
Phase 2 (P1) Master Guardrails:
1. Pre-Flight Data Loss Prevention (DLP): Scans prompts before external LLM dispatch
   and redacts PII, credentials, internal IP addresses, credit cards, and SSNs.
2. Post-Flight Brand Safety & Competitive Filtering: Inspects generated post bodies
   against administrator-defined banned PR keywords and competitor names.
"""

import re
import logging
from typing import List, Dict, Any, Tuple, Optional

logger = logging.getLogger("guardrails")

# ==============================================================================
# 1. DLP / PII SCRUBBING REGEX PATTERNS
# ==============================================================================

# Standard API Keys / Secrets:
# - OpenAI / Anthropic: sk-...
# - Google: AIzaSy...
# - GitHub: ghp_... / github_pat_...
# - Slack: xoxb-... / xoxp-...
# - Generic 32-64 char hex string tokens
RE_SECRET_PATTERNS = [
    re.compile(r"\b(?:sk-[a-zA-Z0-9_\-]{20,})\b"),
    re.compile(r"\b(?:AIza[0-9A-Za-z\-_]{30,40})\b"),
    re.compile(r"\b(?:ghp_[a-zA-Z0-9]{36}|github_pat_[a-zA-Z0-9_]{50,})\b"),
    re.compile(r"\b(?:xox[baprs]-[0-9]{10,}-[a-zA-Z0-9_\-]+)\b"),
    re.compile(r"\b(?:Bearer\s+[a-zA-Z0-9_\.\-]{25,})\b", re.IGNORECASE),
    re.compile(r"\b[0-9a-fA-F]{32,64}\b"),  # 32 to 64 character hex tokens
]

# Credit Card Numbers:
# - 16-digit (Visa, Mastercard, Discover): 4 groups of 4 digits, dashed or spaced
# - 15-digit (American Express): 34xx or 37xx
RE_CREDIT_CARDS = [
    re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"),
    re.compile(r"\b3[47]\d{2}[-\s]?\d{6}[-\s]?\d{5}\b"),
]

# Social Security Numbers (SSN):
# - Format: 123-45-6789 or 123 45 6789
RE_SSN = re.compile(r"\b\d{3}[-\s]\d{2}[-\s]\d{4}\b")

# IP Addresses:
# - IPv4: 4 octets between 0 and 255 (e.g. 192.168.1.1, 10.0.0.1, 172.16.0.1)
# - Note: does NOT match 3-octet version numbers like 4.0.1
RE_IPV4 = re.compile(r"\b(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\b")

# - IPv6: Standard full or collapsed hex colons
RE_IPV6 = re.compile(r"\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{1,4}\b|\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b|\bfe80::[0-9a-fA-F:]+\b", re.IGNORECASE)


def redact_pii(text: str) -> str:
    """
    Pre-Flight DLP Engine:
    Identifies and redacts sensitive information before prompts leave the server:
      - API keys / Tokens / Secrets -> <REDACTED_SECRET>
      - Credit Card numbers -> <REDACTED_CC>
      - Social Security Numbers -> <REDACTED_SSN>
      - IPv4 / IPv6 addresses -> <REDACTED_IP>

    Returns the scrubbed text.
    """
    if not text or not isinstance(text, str):
        return text or ""

    scrubbed = text

    # 1. Redact Secrets & API Keys
    for pattern in RE_SECRET_PATTERNS:
        scrubbed = pattern.sub("<REDACTED_SECRET>", scrubbed)

    # 2. Redact Credit Card Numbers
    for pattern in RE_CREDIT_CARDS:
        scrubbed = pattern.sub("<REDACTED_CC>", scrubbed)

    # 3. Redact Social Security Numbers (SSN)
    scrubbed = RE_SSN.sub("<REDACTED_SSN>", scrubbed)

    # 4. Redact IPv4 Addresses
    scrubbed = RE_IPV4.sub("<REDACTED_IP>", scrubbed)

    # 5. Redact IPv6 Addresses
    scrubbed = RE_IPV6.sub("<REDACTED_IP>", scrubbed)

    return scrubbed


# ==============================================================================
# 2. POST-FLIGHT BRAND SAFETY & COMPETITOR VALIDATION
# ==============================================================================

def check_brand_safety(text: str, banned_keywords: str, competitor_names: str) -> List[str]:
    """
    Post-Flight Brand Safety Engine:
    Scans generated post content against administrator-configured banned keywords
    and competitor brand names.

    Args:
        text: The AI-generated post body
        banned_keywords: Comma-separated or newline-separated prohibited terms
        competitor_names: Comma-separated or newline-separated competitor names

    Returns:
        List of unique matched violation terms (lowercase). Empty list if clean.
    """
    if not text or not isinstance(text, str):
        return []

    # Parse and normalize terms
    raw_terms: List[str] = []
    if banned_keywords:
        raw_terms.extend(re.split(r"[,;\n]+", str(banned_keywords)))
    if competitor_names:
        raw_terms.extend(re.split(r"[,;\n]+", str(competitor_names)))

    # Deduplicate and clean
    cleaned_terms = set()
    for t in raw_terms:
        item = t.strip().lower()
        if item and len(item) >= 2:  # Ignore 1-character artifacts
            cleaned_terms.add(item)

    if not cleaned_terms:
        return []

    violations = []
    text_lower = text.lower()

    for term in sorted(cleaned_terms):
        # Use regex boundary matching so 'cat' doesn't flag 'category'
        # If term contains non-alphanumeric (like 'c++' or 'brand-x'), use escaped boundary
        escaped = re.escape(term)
        pattern = rf"(?:\b|_){escaped}(?:\b|_)"
        
        try:
            if re.search(pattern, text_lower):
                violations.append(term)
            elif term in text_lower and not term.isalnum():
                # For terms with symbols or punctuation
                violations.append(term)
        except Exception as exc:
            logger.warning("Error matching brand safety term '%s': %s", term, exc)
            if term in text_lower:
                violations.append(term)

    return sorted(list(set(violations)))


def sanitize_violation_header(body: str) -> str:
    """
    Strips the `[⚠️ BRAND SAFETY VIOLATION DETECTED: ...] \n\n` warning prefix
    if present, returning clean content for re-evaluation during user edit.
    """
    if not body:
        return ""
    return re.sub(r"^\[⚠️\s*BRAND SAFETY VIOLATION DETECTED:[^\]]+\]\s*\n*", "", body, flags=re.IGNORECASE).strip()
