"""
Postall_V4 - Unified Multi-LLM Provider Engine
Routes prompt execution across Google Gemini, OpenAI, DeepSeek, Mistral, Anthropic Claude,
and Local Qwen LLM using async httpx and resilient fallbacks.
"""

import asyncio
import json
import logging
import os
import re
import time
from typing import Optional, Dict, Any, Callable, Tuple
import httpx

logger = logging.getLogger("ai_router")

# Standard provider default configurations
PROVIDER_DEFAULTS = {
    "gemini": {
        "name": "Google Gemini",
        "base_url": "https://generativelanguage.googleapis.com/v1beta",
        "default_model": "gemini-flash-lite-latest",
        "type": "gemini"
    },
    "openai": {
        "name": "OpenAI",
        "base_url": "https://api.openai.com/v1",
        "default_model": "gpt-4o",
        "type": "openai_compatible"
    },
    "deepseek": {
        "name": "DeepSeek",
        "base_url": "https://api.deepseek.com/v1",
        "default_model": "deepseek-chat",
        "type": "openai_compatible"
    },
    "mistral": {
        "name": "Mistral AI",
        "base_url": "https://api.mistral.ai/v1",
        "default_model": "mistral-large-latest",
        "type": "openai_compatible"
    },
    "claude": {
        "name": "Anthropic Claude",
        "base_url": "https://api.anthropic.com/v1",
        "default_model": "claude-3-5-sonnet-20241022",
        "type": "anthropic"
    },
    "custom": {
        "name": "Custom OpenAI-Compatible",
        "base_url": "http://localhost:11434/v1",
        "default_model": "llama3",
        "type": "openai_compatible"
    },
    "local": {
        "name": "Local Qwen LLM (Offline)",
        "base_url": "local",
        "default_model": "Qwen2.5-Coder-0.5B-GGUF",
        "type": "local"
    }
}

# Local LLM forward reference hook (set by backend/main.py on startup)
_local_llm_runner: Optional[Callable] = None

def register_local_llm_runner(runner: Callable):
    """Allows backend/main.py to inject the local Qwen LLM execution function."""
    global _local_llm_runner
    _local_llm_runner = runner

def get_settings_dict() -> Dict[str, str]:
    """Helper to fetch all key-value settings from the SQLite database."""
    try:
        from backend.database import get_db
        db = get_db()
        rows = db.execute("SELECT key, value FROM settings").fetchall()
        db.close()
        settings = {r["key"]: r["value"] for r in rows}
        from backend.vault import SENSITIVE_SECRET_KEYS, get_secret
        for key in SENSITIVE_SECRET_KEYS:
            if settings.get(key):
                settings[key] = get_secret(key)
        return settings
    except Exception as exc:
        logger.warning("Could not read settings from DB: %s", exc)
        return {}

def record_usage_metric(model_name: str, prompt_tokens: int, output_tokens: int):
    """Updates api_usage table in the SQLite database."""
    try:
        from backend.database import get_db
        db = get_db()
        db.execute(
            """INSERT INTO api_usage(model, request_count, prompt_tokens, output_tokens, total_tokens)
               VALUES (?, 1, ?, ?, ?)
               ON CONFLICT(model) DO UPDATE SET
                 request_count = request_count + 1,
                 prompt_tokens = prompt_tokens + excluded.prompt_tokens,
                 output_tokens = output_tokens + excluded.output_tokens,
                 total_tokens = total_tokens + excluded.total_tokens""",
            (model_name, prompt_tokens, output_tokens, prompt_tokens + output_tokens)
        )
        db.commit()
        db.close()
    except Exception as exc:
        logger.debug("Failed recording AI usage metric: %s", exc)

async def _call_gemini_rest(
    api_key: str,
    model: str,
    prompt: str,
    system_prompt: str = "",
    temperature: float = 0.7
) -> Tuple[str, int, int]:
    """Calls Gemini via official REST endpoint using httpx."""
    clean_model = model.strip() if model else "gemini-flash-lite-latest"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{clean_model}:generateContent?key={api_key}"
    
    contents = []
    if system_prompt:
        contents.append({"role": "user", "parts": [{"text": f"SYSTEM INSTRUCTION: {system_prompt}"}]})
        contents.append({"role": "model", "parts": [{"text": "Understood. I will strictly adhere to these instructions."}]})
    contents.append({"role": "user", "parts": [{"text": prompt}]})

    payload = {
        "contents": contents,
        "generationConfig": {
            "temperature": float(temperature)
        }
    }

    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.post(url, json=payload)
        if resp.status_code != 200:
            err_msg = resp.text[:300]
            raise RuntimeError(f"Gemini API returned HTTP {resp.status_code}: {err_msg}")
        
        data = resp.json()
        candidates = data.get("candidates", [])
        if not candidates:
            raise RuntimeError("Gemini API returned 0 candidates")
        
        parts = candidates[0].get("content", {}).get("parts", [])
        text = "".join([p.get("text", "") for p in parts]).strip()
        
        usage = data.get("usageMetadata", {})
        prompt_tokens = usage.get("promptTokenCount", 0)
        output_tokens = usage.get("candidatesTokenCount", 0)
        return text, prompt_tokens, output_tokens

async def _call_openai_compatible(
    base_url: str,
    api_key: str,
    model: str,
    prompt: str,
    system_prompt: str = "",
    temperature: float = 0.7
) -> Tuple[str, int, int]:
    """Calls any standard OpenAI-compatible completions endpoint (OpenAI, DeepSeek, Mistral, Groq, vLLM, Ollama)."""
    clean_base = (base_url or "").rstrip("/")
    if not clean_base.endswith("/chat/completions"):
        if not clean_base.endswith("/v1"):
            clean_base = f"{clean_base}/v1"
        url = f"{clean_base}/chat/completions"
    else:
        url = clean_base

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}" if api_key else ""
    }

    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    payload = {
        "model": model,
        "messages": messages,
        "temperature": float(temperature)
    }

    async with httpx.AsyncClient(timeout=75.0) as client:
        resp = await client.post(url, json=payload, headers=headers)
        if resp.status_code != 200:
            err_msg = resp.text[:300]
            raise RuntimeError(f"OpenAI-compatible API ({url}) returned HTTP {resp.status_code}: {err_msg}")
        
        data = resp.json()
        choices = data.get("choices", [])
        if not choices:
            raise RuntimeError(f"OpenAI-compatible API returned empty choices array from {url}")
        
        text = choices[0].get("message", {}).get("content", "").strip()
        usage = data.get("usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        output_tokens = usage.get("completion_tokens", 0)
        return text, prompt_tokens, output_tokens

async def _call_anthropic_claude(
    api_key: str,
    model: str,
    prompt: str,
    system_prompt: str = "",
    temperature: float = 0.7
) -> Tuple[str, int, int]:
    """Calls Anthropic Claude Messages API using httpx."""
    url = "https://api.anthropic.com/v1/messages"
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01"
    }

    payload = {
        "model": model or "claude-3-5-sonnet-20241022",
        "max_tokens": 4096,
        "temperature": float(temperature),
        "messages": [{"role": "user", "content": prompt}]
    }
    if system_prompt:
        payload["system"] = system_prompt

    async with httpx.AsyncClient(timeout=75.0) as client:
        resp = await client.post(url, json=payload, headers=headers)
        if resp.status_code != 200:
            err_msg = resp.text[:300]
            raise RuntimeError(f"Anthropic API returned HTTP {resp.status_code}: {err_msg}")
        
        data = resp.json()
        content_items = data.get("content", [])
        text = "".join([c.get("text", "") for c in content_items if c.get("type") == "text"]).strip()
        
        usage = data.get("usage", {})
        prompt_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)
        return text, prompt_tokens, output_tokens

async def test_provider_connection(
    provider: str,
    api_key: str,
    base_url: Optional[str] = None,
    model: Optional[str] = None
) -> Dict[str, Any]:
    """
    Validates credentials and network reachability for any supported provider.
    Returns status, latency in milliseconds, and a sample ping response.
    """
    prov = (provider or "gemini").lower().strip()
    t_start = time.perf_counter()
    test_prompt = "Reply with exactly: 'OK'"
    test_system = "Be brief."

    try:
        if prov == "gemini":
            key = api_key or os.getenv("GEMINI_API_KEY", "")
            target_model = model or PROVIDER_DEFAULTS["gemini"]["default_model"]
            try:
                text, p_tok, o_tok = await _call_gemini_rest(key, target_model, test_prompt, test_system)
            except Exception as exc:
                if not re.search(r"(?:HTTP\s*)?404|NOT_FOUND", str(exc), re.IGNORECASE):
                    raise
                target_model = "gemini-1.5-pro" if target_model != "gemini-1.5-pro" else "gemini-flash-lite-latest"
                logger.warning("Gemini model was not found during provider test; retrying with %s.", target_model)
                text, p_tok, o_tok = await _call_gemini_rest(key, target_model, test_prompt, test_system)
        
        elif prov in ("openai", "deepseek", "mistral", "custom"):
            defaults = PROVIDER_DEFAULTS.get(prov, PROVIDER_DEFAULTS["custom"])
            target_url = base_url or defaults["base_url"]
            target_model = model or defaults["default_model"]
            text, p_tok, o_tok = await _call_openai_compatible(target_url, api_key, target_model, test_prompt, test_system)
        
        elif prov == "claude":
            target_model = model or "claude-3-5-sonnet-20241022"
            text, p_tok, o_tok = await _call_anthropic_claude(api_key, target_model, test_prompt, test_system)
        
        elif prov == "local":
            if not _local_llm_runner:
                raise RuntimeError("Local LLM runner is not loaded or offline")
            text = await _local_llm_runner(test_prompt, max_tokens=10)
            p_tok, o_tok = 0, 0
        else:
            raise ValueError(f"Unknown provider '{provider}'")

        latency_ms = int((time.perf_counter() - t_start) * 1000)
        return {
            "status": "success",
            "provider": prov,
            "model": target_model if prov != "local" else "local",
            "latency_ms": latency_ms,
            "sample_response": text[:100],
            "message": f"Successfully connected to {prov.upper()} in {latency_ms}ms"
        }
    except Exception as exc:
        latency_ms = int((time.perf_counter() - t_start) * 1000)
        return {
            "status": "error",
            "provider": prov,
            "latency_ms": latency_ms,
            "message": f"Connection failed: {str(exc)}"
        }

async def generate_text(
    prompt: str,
    system_prompt: str = "",
    model_override: Optional[str] = None,
    on_event: Optional[Callable[[str], None]] = None,
    on_usage: Optional[Callable[[Dict[str, Any]], None]] = None
) -> str:
    """
    Unified entry point for AI text generation.
    Reads provider settings, selects target engine, and manages fallbacks.
    """
    settings = get_settings_dict()
    provider = (settings.get("ai_provider") or "gemini").lower().strip()
    temperature = float(settings.get("ai_temperature") or 0.7)

    # Pre-Flight Data Loss Prevention (DLP / PII Scrubbing)
    dlp_enabled = str(settings.get("dlp_enabled", "1")).lower() in {"1", "true", "yes", "on"}
    if dlp_enabled:
        from backend.guardrails import redact_pii
        orig_prompt = prompt
        prompt = redact_pii(prompt)
        if system_prompt:
            system_prompt = redact_pii(system_prompt)
        if prompt != orig_prompt:
            logger.info("[DLP GUARDRAIL] Pre-flight PII/credential redaction applied to outgoing prompt.")
            if on_event:
                on_event("Pre-flight DLP Guardrail: Redacted sensitive credentials/PII from outgoing LLM payload.")

    # 1. Primary Attempt
    errors = []
    try:
        if on_event:
            on_event(f"Routing generation request to active provider: {provider.upper()}")
        
        text, p_tok, o_tok = await _dispatch_provider_call(provider, prompt, system_prompt, model_override, temperature, settings)
        
        target_model = model_override or _get_model_for_provider(provider, settings)
        record_usage_metric(target_model, p_tok, o_tok)
        
        if on_usage:
            on_usage({
                "model": target_model,
                "engine": provider,
                "prompt_tokens": p_tok,
                "output_tokens": o_tok,
                "total_tokens": p_tok + o_tok
            })
        if on_event:
            on_event(f"Successfully generated response using {provider.upper()} ({target_model}).")
        
        return text

    except Exception as exc:
        err_msg = f"{provider.upper()}: {type(exc).__name__}: {str(exc)}"
        errors.append(err_msg)
        logger.warning("[AI ROUTER] Primary provider %s failed: %s", provider, exc)
        if on_event:
            on_event(f"Primary provider ({provider.upper()}) encountered an error. Initiating fallback hierarchy...")

    # 2. Secondary Cloud Fallback (If Primary was not Gemini, fallback to Gemini; otherwise fallback to OpenAI if configured)
    fallback_provider = "gemini" if provider != "gemini" else "openai"
    try:
        # Check if fallback has a configured key
        has_fallback_key = False
        if fallback_provider == "gemini":
            has_fallback_key = bool(settings.get("gemini_api_key") or settings.get("gemini_api_key_1") or os.getenv("GEMINI_API_KEY"))
        elif fallback_provider == "openai":
            has_fallback_key = bool(settings.get("openai_api_key"))

        if has_fallback_key:
            if on_event:
                on_event(f"Attempting cloud fallback to {fallback_provider.upper()}...")
            text, p_tok, o_tok = await _dispatch_provider_call(fallback_provider, prompt, system_prompt, None, temperature, settings)
            fb_model = _get_model_for_provider(fallback_provider, settings)
            record_usage_metric(fb_model, p_tok, o_tok)
            if on_usage:
                on_usage({"model": fb_model, "engine": fallback_provider, "prompt_tokens": p_tok, "output_tokens": o_tok, "total_tokens": p_tok + o_tok})
            if on_event:
                on_event(f"Cloud fallback to {fallback_provider.upper()} succeeded.")
            return text
    except Exception as exc:
        err_msg = f"{fallback_provider.upper()} Fallback: {type(exc).__name__}: {str(exc)}"
        errors.append(err_msg)
        logger.warning("[AI ROUTER] Cloud fallback %s failed: %s", fallback_provider, exc)

    # 3. Universal Offline Fallback: Local Qwen LLM
    enable_local = str(settings.get("enable_local_llm", "1")).lower() not in {"0", "false", "off", "no"}
    if enable_local and _local_llm_runner:
        try:
            if on_event:
                on_event("Attempting offline fallback via local Qwen LLM...")
            text = await _local_llm_runner(f"{system_prompt}\n\n{prompt}" if system_prompt else prompt, max_tokens=500)
            record_usage_metric("Qwen2.5-Coder-0.5B-GGUF", 0, 0)
            if on_event:
                on_event("Offline local Qwen LLM fallback completed task.")
            return text
        except Exception as exc:
            errors.append(f"Local Qwen LLM: {type(exc).__name__}: {str(exc)}")

    # All avenues exhausted
    joined_errs = " | ".join(errors)
    raise RuntimeError(f"All configured AI engines failed to generate response: {joined_errs}")

def _get_model_for_provider(provider: str, settings: Dict[str, str]) -> str:
    """Returns the configured or default model name for a provider."""
    p = provider.lower()
    if p == "gemini":
        return settings.get("ai_primary_model") or settings.get("gemini_model") or "gemini-flash-lite-latest"
    elif p == "openai":
        return settings.get("openai_model") or "gpt-4o"
    elif p == "deepseek":
        return settings.get("deepseek_model") or "deepseek-chat"
    elif p == "mistral":
        return settings.get("mistral_model") or "mistral-large-latest"
    elif p == "claude":
        return settings.get("claude_model") or "claude-3-5-sonnet-20241022"
    elif p == "custom":
        return settings.get("custom_ai_model") or "custom-model"
    return "default-model"

async def _dispatch_provider_call(
    provider: str,
    prompt: str,
    system_prompt: str,
    model_override: Optional[str],
    temperature: float,
    settings: Dict[str, str]
) -> Tuple[str, int, int]:
    """Helper dispatching the HTTP call according to provider type."""
    p = provider.lower()

    if p == "gemini":
        # Supports multi-key rotation
        keys = [
            settings.get("gemini_api_key", ""),
            settings.get("gemini_api_key_1", ""),
            settings.get("gemini_api_key_2", ""),
            os.getenv("GEMINI_API_KEY", "")
        ]
        active_keys = [k.strip() for k in keys if k and k.strip()]
        if not active_keys:
            raise RuntimeError("Gemini selected but no Gemini API keys are configured.")
        
        target_model = model_override or _get_model_for_provider("gemini", settings)
        configured_fallbacks = settings.get("gemini_fallback_models") or os.getenv("GEMINI_FALLBACK_MODELS", "")
        fallback_models = [model.strip() for model in configured_fallbacks.split(",") if model.strip()]
        fallback_models.extend(("gemini-flash-lite-latest", "gemini-1.5-pro"))
        models = list(dict.fromkeys((target_model, *fallback_models)))

        for model in models:
            last_exc = None
            for key in active_keys:
                try:
                    return await _call_gemini_rest(key, model, prompt, system_prompt, temperature)
                except Exception as exc:
                    last_exc = exc
            if last_exc and re.search(r"(?:HTTP\s*)?404|NOT_FOUND", str(last_exc), re.IGNORECASE):
                logger.warning("Gemini model %s was not found; trying the next configured fallback.", model)
                continue
            if last_exc:
                raise last_exc
        raise RuntimeError("All configured Gemini models and keys failed.")

    elif p in ("openai", "deepseek", "mistral", "custom"):
        defaults = PROVIDER_DEFAULTS.get(p, PROVIDER_DEFAULTS["custom"])
        key = settings.get(f"{p}_api_key", "")
        base_url = settings.get(f"{p}_base_url") or defaults["base_url"]
        target_model = model_override or _get_model_for_provider(p, settings)
        return await _call_openai_compatible(base_url, key, target_model, prompt, system_prompt, temperature)

    elif p == "claude":
        key = settings.get("claude_api_key", "")
        if not key:
            raise RuntimeError("Anthropic Claude selected but claude_api_key is empty.")
        target_model = model_override or _get_model_for_provider("claude", settings)
        return await _call_anthropic_claude(key, target_model, prompt, system_prompt, temperature)

    elif p == "local":
        if not _local_llm_runner:
            raise RuntimeError("Local LLM runner is not loaded.")
        combined = f"{system_prompt}\n\n{prompt}" if system_prompt else prompt
        text = await _local_llm_runner(combined, max_tokens=500)
        return text, 0, 0

    else:
        raise ValueError(f"Unsupported AI provider '{provider}'")
