const titles = {
    overview: "Command Center",
    modules: "Content Pipelines",
    pipelines: "Content Pipelines",
    ondemand: "On-Demand Publishing",
    promo: "Campaign Promotions",
    trending: "Trending Radar",
    approval: "Editorial Approvals",
    license: "License & Compliance",
    notifications: "Notification Center",
    users: "Identity & Access Management",
    howto: "Documentation & Runbooks",
    integrations: "Platform Health & Telemetry",
    health: "Platform Health & Telemetry",
    logs: "Security & Audit Logs",
    settings: "System Configuration",
    updates: "System Lifecycle & Updates"
};

const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
function markdownInline(value) {
    return esc(value)
        .replace(/`([^`]+)`/g, "<code class=\"rounded bg-slate-800 px-1 text-sky-300\">$1</code>")
        .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
        .replace(/__([^_]+)__/g, "<strong>$1</strong>")
        .replace(/(^|[^*])\*([^*]+)\*/g, "$1<em>$2</em>");
}
function renderMarkdown(value) {
    const blocks=[], lines=String(value ?? "").replace(/\r/g,"").split("\n");
    let paragraph=[], list=[];
    const flushParagraph=()=>{ if (paragraph.length) { blocks.push(`<p>${paragraph.map(markdownInline).join("<br>")}</p>`); paragraph=[]; } };
    const flushList=()=>{ if (list.length) { blocks.push(`<ul>${list.map(item=>`<li>${markdownInline(item)}</li>`).join("")}</ul>`); list=[]; } };
    for (const line of lines) {
        const heading=line.match(/^\s{0,3}(#{1,3})\s+(.+)$/);
        const item=line.match(/^\s*[-*+]\s+(.+)$/);
        if (heading) { flushParagraph(); flushList(); const level=heading[1].length; blocks.push(`<h${level+1}>${markdownInline(heading[2])}</h${level+1}>`); }
        else if (item) { flushParagraph(); list.push(item[1]); }
        else if (!line.trim()) { flushParagraph(); flushList(); }
        else { flushList(); paragraph.push(line); }
    }
    flushParagraph(); flushList();
    return blocks.join("");
}
function applyTheme() {
    const savedTheme = localStorage.getItem("postall_v4_theme");
    const theme = ["midnight", "ocean", "forest", "sunset", "rose", "light"].includes(savedTheme) ? savedTheme : "midnight";
    const dark = theme !== "light";
    document.documentElement.dataset.theme = theme;
    document.documentElement.classList.toggle("dark", dark);
    document.getElementById("icon-sun")?.classList.toggle("hidden", !dark);
    document.getElementById("icon-moon")?.classList.toggle("hidden", dark);
    const selector = document.getElementById("theme-selector");
    if (selector) selector.value = theme;
}
function toggleTheme() {
    const current = localStorage.getItem("postall_v4_theme") || "midnight";
    localStorage.setItem("postall_v4_theme", current === "light" ? "midnight" : "light");
    applyTheme();
}
function changeTheme(theme) {
    localStorage.setItem("postall_v4_theme", theme || "midnight");
    applyTheme();
}
function applySidebarState() {
    const collapsed = localStorage.getItem("postall_v4_sidebar_collapsed") === "true";
    document.body.classList.toggle("sidebar-collapsed", collapsed);
    const toggle = document.getElementById("sidebar-toggle");
    if (toggle) {
        toggle.setAttribute("aria-label", collapsed ? "Expand sidebar" : "Collapse sidebar");
        toggle.title = collapsed ? "Expand sidebar" : "Collapse sidebar";
    }
}

window.verifyChannel = testSocialConnection;

async function refreshInstagramToken() {
    const button = document.getElementById("refresh-instagram-btn");
    const original = button?.textContent || "Refresh Token";
    if (button) { button.disabled = true; button.textContent = "Refreshing…"; }
    try {
        const result = await api("/api/social/refresh-token/instagram", { method: "POST" });
        showToast(result.message, "success");
        window.dispatchEvent(new Event("postall:settings-updated"));
    } catch (error) {
        showToast(error.message, "error");
    } finally {
        if (button) { button.disabled = false; button.textContent = original; }
    }
}
function toggleSidebar(forceState) {
    if (window.innerWidth < 1024) {
        const isOpen = typeof forceState === "boolean" ? forceState : !document.body.classList.contains("mobile-sidebar-open");
        document.body.classList.toggle("mobile-sidebar-open", isOpen);
        const backdrop = document.getElementById("sidebar-backdrop");
        if (backdrop) backdrop.classList.toggle("hidden", !isOpen);
    } else {
        const shouldCollapse = typeof forceState === "boolean" ? !forceState : !document.body.classList.contains("sidebar-collapsed");
        localStorage.setItem("postall_v4_sidebar_collapsed", String(shouldCollapse));
        applySidebarState();
    }
}

function showToast(message, type = "info") {
    const toast = document.createElement("div");
    toast.className = `fixed top-5 right-5 z-50 max-w-xl rounded-lg border px-4 py-3 text-sm shadow-xl ${type === "error" ? "border-red-400 bg-red-950 text-red-100" : "border-blue-400 bg-slate-900 text-white"}`;
    toast.setAttribute("role",type==="error"?"alert":"status");
    toast.setAttribute("aria-live",type==="error"?"assertive":"polite");
    toast.textContent = message; document.body.appendChild(toast); setTimeout(() => toast.remove(), type==="error"?9000:4500);
}
function getActiveWorkspaceId() {
    return localStorage.getItem("active_workspace_id") || localStorage.getItem("activeWorkspaceId") || "1";
}
function persistActiveWorkspaceId(id) {
    const workspaceId = String(id);
    localStorage.setItem("active_workspace_id", workspaceId);
    localStorage.setItem("activeWorkspaceId", workspaceId);
    document.cookie = `active_workspace_id=${encodeURIComponent(workspaceId)}; Path=/; SameSite=Lax`;
}
async function api(url, options = {}) {
    const token = localStorage.getItem("token") || sessionStorage.getItem("token") || localStorage.getItem("vanguard_token");
    const headers = Object.assign({}, options.headers || {});
    if (token && !headers["Authorization"] && !headers["authorization"]) {
        headers["Authorization"] = `Bearer ${token}`;
    }
    const activeWs = getActiveWorkspaceId();
    if (!Object.keys(headers).some(key => key.toLowerCase() === "x-workspace-id")) {
        headers["X-Workspace-Id"] = activeWs;
    }
    document.cookie = `active_workspace_id=${encodeURIComponent(activeWs)}; Path=/; SameSite=Lax`;
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
        if (response.status === 402) {
            triggerLicenseActivationModal();
            throw new Error("System Locked: Valid License Required (HTTP 402)");
        }
        const text = await response.text();
        let detail = `${url} failed (HTTP ${response.status})`;
        try {
            const payload=JSON.parse(text);
            detail=payload.message || payload.detail || detail;
        } catch {
            if (text && !/^\s*</.test(text) && text.length < 300) detail=text;
        }
        throw new Error(detail);
    }
    return response.json();
}

function triggerLicenseActivationModal() {
    const modal = document.getElementById("license-activation-modal");
    if (modal) {
        modal.classList.remove("hidden");
        document.body.style.overflow = "hidden";
    }
}

async function submitLicenseActivation(event) {
    if (event) event.preventDefault();
    const keyInput = document.getElementById("activation-key-input");
    const statusBox = document.getElementById("activation-status-message");
    const btn = document.getElementById("activation-submit-btn");
    if (!keyInput) return;

    const licenseKey = keyInput.value.trim();
    if (!licenseKey) {
        if (statusBox) {
            statusBox.className = "text-xs p-3 rounded-lg border border-red-500/40 bg-red-950/60 text-red-200 font-mono block";
            statusBox.textContent = "Please paste a valid Base64 license key string.";
        }
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<svg class="w-4 h-4 animate-spin inline mr-2" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Activating Cryptographic Key...`;
    }

    try {
        const res = await fetch("/api/license/activate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ license_key: licenseKey })
        });
        const data = await res.json();
        if (res.ok && data.status === "success") {
            if (statusBox) {
                statusBox.className = "text-xs p-3 rounded-lg border border-emerald-500/40 bg-emerald-950/60 text-emerald-200 font-mono block";
                statusBox.textContent = `License Verified! Client: ${data.license.client} (${data.license.type}). Reloading engine...`;
            }
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            if (statusBox) {
                statusBox.className = "text-xs p-3 rounded-lg border border-red-500/40 bg-red-950/60 text-red-200 font-mono block";
                statusBox.textContent = data.detail || "Cryptographic verification failed.";
            }
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = `<span>Activate Postall_V4 Engine</span>`;
            }
        }
    } catch (err) {
        if (statusBox) {
            statusBox.className = "text-xs p-3 rounded-lg border border-red-500/40 bg-red-950/60 text-red-200 font-mono block";
            statusBox.textContent = `Connection error: ${err.message}`;
        }
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<span>Activate Postall_V4 Engine</span>`;
        }
    }
}

let currentLicenseState = null;

async function fetchLicenseStatus() {
    try {
        const res = await fetch("/api/license");
        const data = await res.json();
        currentLicenseState = data;
        const valid = Boolean(data.valid);
        const payload = data.payload || {};
        const machineId = data.machine_id || "--";
        const isDemo = Boolean(payload.is_demo);
        const daysLeft = payload.days_remaining !== undefined ? payload.days_remaining : "--";
        const hoursLeft = payload.hours_remaining !== undefined ? payload.hours_remaining : "--";
        const clientName = payload.client || payload.client_name || (valid ? "Enterprise Client" : "Unlicensed Instance");
        const licType = payload.type || payload.license_type || (valid ? "Production" : "Unlicensed");
        const expiryIso = payload.expires_at_iso || (payload.expires_at ? new Date(payload.expires_at * 1000).toLocaleString() : "--");
        const licId = payload.license_id || (isDemo ? "POSTALL-DEMO-3DAYS" : "--");

        // 1. Sidebar Nav Pill (#nav-license-pill)
        const navPill = document.getElementById("nav-license-pill");
        if (navPill) {
            if (!valid) {
                navPill.className = "bg-red-100 dark:bg-red-500/20 text-red-600 dark:text-red-400 py-0.5 px-2 rounded font-mono text-[10px] font-bold border border-red-500/30";
                navPill.textContent = "Locked";
            } else if (isDemo) {
                navPill.className = "bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 py-0.5 px-2 rounded font-mono text-[10px] font-bold border border-amber-500/30";
                navPill.textContent = `Demo (${daysLeft}d)`;
            } else {
                navPill.className = "bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 py-0.5 px-2 rounded font-mono text-[10px] font-bold border border-emerald-500/30";
                navPill.textContent = "Active";
            }
        }

        // 2. Command Center Overview Block (#cc-license-block)
        const ccBlock = document.getElementById("cc-license-block");
        if (ccBlock) {
            const ccBadge = document.getElementById("cc-license-badge");
            const ccBadgeText = document.getElementById("cc-license-badge-text");
            const ccTypeBadge = document.getElementById("cc-license-type-badge");
            const ccClient = document.getElementById("cc-license-client");
            const ccHwid = document.getElementById("cc-license-hwid");
            const ccRemaining = document.getElementById("cc-license-remaining");
            const ccBtnLabel = document.getElementById("cc-btn-license-label");
            const ccIcon = document.getElementById("cc-license-icon");

            if (ccHwid) ccHwid.innerHTML = `Hardware HWID: <code class="text-slate-700 dark:text-slate-300 font-mono font-bold">${esc(machineId)}</code>`;
            if (ccClient) ccClient.innerHTML = `Client: <strong class="text-slate-800 dark:text-slate-200">${esc(clientName)}</strong>`;
            if (ccTypeBadge) ccTypeBadge.textContent = licType;

            if (!valid) {
                if (ccBadge) {
                    ccBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/10 text-red-500 border border-red-500/30 font-mono";
                    if (ccBadgeText) ccBadgeText.textContent = "LOCKED / EXPIRED";
                }
                if (ccRemaining) {
                    ccRemaining.className = "text-red-500 font-bold";
                    ccRemaining.textContent = "Trial Expired (0 Days Remaining - Key Required)";
                }
                if (ccBtnLabel) ccBtnLabel.textContent = "Activate Key";
                if (ccIcon) ccIcon.className = "w-12 h-12 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-500 shadow-lg shadow-red-500/20 flex-shrink-0";
            } else if (isDemo) {
                if (ccBadge) {
                    ccBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-500 border border-amber-500/30 font-mono";
                    if (ccBadgeText) ccBadgeText.textContent = "DEMO EVALUATION (3-DAY TRIAL)";
                }
                if (ccRemaining) {
                    ccRemaining.className = "text-amber-500 font-bold";
                    ccRemaining.textContent = `${daysLeft} Days Remaining (${hoursLeft}h left before system lock)`;
                }
                if (ccBtnLabel) ccBtnLabel.textContent = "Activate Key";
                if (ccIcon) ccIcon.className = "w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-lg shadow-amber-500/20 flex-shrink-0";
            } else {
                if (ccBadge) {
                    ccBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 font-mono";
                    if (ccBadgeText) ccBadgeText.textContent = "ACTIVE & LICENSED";
                }
                if (ccRemaining) {
                    ccRemaining.className = "text-emerald-500 font-bold";
                    ccRemaining.textContent = `${daysLeft} Days Remaining (Active Production)`;
                }
                if (ccBtnLabel) ccBtnLabel.textContent = "Update Key";
                if (ccIcon) ccIcon.className = "w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500 shadow-lg shadow-emerald-500/20 flex-shrink-0";
            }
        }

        // 3. Update Dedicated License Tab Elements (#tab-license)
        const licBannerBadge = document.getElementById("lic-banner-status-badge");
        const licBannerText = document.getElementById("lic-banner-status-text");
        const licBannerDesc = document.getElementById("lic-banner-desc");
        const licBannerIcon = document.getElementById("lic-banner-icon");
        const licCardTier = document.getElementById("lic-card-tier-pill");
        const licCardClient = document.getElementById("lic-card-client");
        const licCardId = document.getElementById("lic-card-id");
        const licCardCountdown = document.getElementById("lic-card-countdown");
        const licCardExpiry = document.getElementById("lic-card-expiry");
        const licCardHwid = document.getElementById("lic-card-hwid");

        if (licCardClient) licCardClient.textContent = clientName;
        if (licCardId) licCardId.textContent = licId;
        if (licCardExpiry) licCardExpiry.textContent = expiryIso;
        if (licCardHwid) licCardHwid.textContent = machineId;
        if (licCardTier) licCardTier.textContent = licType;

        if (licBannerBadge) {
            if (!valid) {
                licBannerBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold font-mono bg-red-500/10 text-red-500 border border-red-500/30";
                if (licBannerText) licBannerText.textContent = "SYSTEM LOCKED: UNLICENSED";
                if (licBannerDesc) licBannerDesc.textContent = data.error || "The 3-day demo period has expired or the digital license signature is invalid. All post creation and autoloop functions are locked.";
                if (licBannerIcon) licBannerIcon.className = "w-12 h-12 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-500 shadow-lg shadow-red-500/20 flex-shrink-0";
                if (licCardCountdown) {
                    licCardCountdown.className = "font-bold font-mono text-xs text-red-500";
                    licCardCountdown.textContent = "0 Days (Locked Out)";
                }
            } else if (isDemo) {
                licBannerBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold font-mono bg-amber-500/10 text-amber-500 border border-amber-500/30";
                if (licBannerText) licBannerText.textContent = "DEMO EVALUATION MODE";
                if (licBannerDesc) licBannerDesc.textContent = `Running in temporary 3-day demo mode (${hoursLeft} hours remaining). The system will lock itself out automatically after 3 days unless activated with an Ed25519 key.`;
                if (licBannerIcon) licBannerIcon.className = "w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-lg shadow-amber-500/20 flex-shrink-0";
                if (licCardCountdown) {
                    licCardCountdown.className = "font-bold font-mono text-xs text-amber-500";
                    licCardCountdown.textContent = `${daysLeft} Days (${hoursLeft}h left)`;
                }
            } else {
                licBannerBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold font-mono bg-emerald-500/10 text-emerald-500 border border-emerald-500/30";
                if (licBannerText) licBannerText.textContent = "ACTIVE & LICENSED";
                if (licBannerDesc) licBannerDesc.textContent = `Authentic Ed25519 digital signature verified. Autopilot scheduler and all enterprise distribution features are fully enabled.`;
                if (licBannerIcon) licBannerIcon.className = "w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500 shadow-lg shadow-emerald-500/20 flex-shrink-0";
                if (licCardCountdown) {
                    licCardCountdown.className = "font-bold font-mono text-xs text-emerald-500";
                    licCardCountdown.textContent = `${daysLeft} Days Remaining`;
                }
            }
        }
    } catch (err) {
        console.error("fetchLicenseStatus error:", err);
    }
}

function copyHwidToClipboard() {
    const hwidEl = document.getElementById("lic-card-hwid");
    const labelEl = document.getElementById("lic-copy-hwid-text");
    if (!hwidEl) return;
    const text = hwidEl.textContent.trim();
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
            if (labelEl) {
                labelEl.textContent = "Copied!";
                setTimeout(() => { labelEl.textContent = "Copy HWID"; }, 2000);
            }
            showToast("Hardware HWID copied to clipboard");
        }).catch(() => {
            showToast(`HWID: ${text}`);
        });
    } else {
        showToast(`HWID: ${text}`);
    }
}

async function submitLicenseFromPane(event) {
    if (event) event.preventDefault();
    const keyInput = document.getElementById("pane-license-input");
    const statusBox = document.getElementById("pane-license-status");
    const btn = document.getElementById("pane-license-btn");
    if (!keyInput) return;

    const licenseKey = keyInput.value.trim();
    if (!licenseKey) {
        if (statusBox) {
            statusBox.className = "text-xs p-3.5 rounded-xl border border-red-500/40 bg-red-950/60 text-red-200 font-mono block";
            statusBox.textContent = "Please enter or paste a valid Base64 license key.";
        }
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<svg class="w-4 h-4 animate-spin inline mr-2" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Validating Ed25519 Signature...`;
    }

    try {
        const res = await fetch("/api/license/activate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ license_key: licenseKey })
        });
        const data = await res.json();
        if (res.ok && data.status === "success") {
            if (statusBox) {
                statusBox.className = "text-xs p-3.5 rounded-xl border border-emerald-500/40 bg-emerald-950/60 text-emerald-200 font-mono block";
                statusBox.textContent = `License Verified! Client: ${data.license.client} (${data.license.type}). Reloading application...`;
            }
            showToast("License key successfully activated!", "success");
            setTimeout(() => {
                window.location.reload();
            }, 1200);
        } else {
            if (statusBox) {
                statusBox.className = "text-xs p-3.5 rounded-xl border border-red-500/40 bg-red-950/60 text-red-200 font-mono block";
                statusBox.textContent = data.detail || "Cryptographic verification failed: Tampered or invalid signature.";
            }
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = `<span>Verify &amp; Activate License</span>`;
            }
        }
    } catch (err) {
        if (statusBox) {
            statusBox.className = "text-xs p-3.5 rounded-xl border border-red-500/40 bg-red-950/60 text-red-200 font-mono block";
            statusBox.textContent = `Connection error: ${err.message}`;
        }
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<span>Verify &amp; Activate License</span>`;
        }
    }
}

function handleLicenseFileUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const nameLabel = document.getElementById("pane-license-file-name");
    if (nameLabel) nameLabel.textContent = `Loaded file: ${file.name} (${file.size} bytes)`;
    const reader = new FileReader();
    reader.onload = function(e) {
        const content = e.target.result;
        const input = document.getElementById("pane-license-input");
        if (input) {
            input.value = content.trim();
            showToast(`Loaded license key from ${file.name}`);
        }
    };
    reader.readAsText(file);
}

async function fetchNotifications() {
    const listEl = document.getElementById("notifications-list");
    const badgeSidebar = document.getElementById("nav-notifications-badge");
    const dotSidebar = document.getElementById("nav-notifications-dot");
    const badgeHeader = document.getElementById("notifications-header-badge");

    try {
        const res = await api("/api/notifications");
        const notifs = res.notifications || [];
        const unreadCount = Number(res.unread_count || 0);

        if (badgeSidebar) {
            badgeSidebar.textContent = unreadCount;
            badgeSidebar.classList.toggle("hidden", unreadCount === 0);
        }
        if (dotSidebar) {
            dotSidebar.classList.toggle("hidden", unreadCount === 0);
        }
        if (badgeHeader) {
            badgeHeader.textContent = `${unreadCount} unread`;
            badgeHeader.className = unreadCount > 0 
                ? "px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-rose-500/10 text-rose-500 border border-rose-500/20"
                : "px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-slate-500/10 text-slate-400 border border-slate-500/20";
        }

        if (!listEl) return;

        if (notifs.length === 0) {
            listEl.innerHTML = `
                <div class="py-16 text-center">
                    <div class="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mx-auto mb-3">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path></svg>
                    </div>
                    <p class="text-xs font-bold text-slate-700 dark:text-slate-300">All Clear</p>
                    <p class="text-[11px] text-slate-400 mt-1">No system alerts or active notifications.</p>
                </div>
            `;
            return;
        }

        listEl.innerHTML = notifs.map(n => {
            const isUnread = !n.is_read;
            const cat = (n.category || "info").toLowerCase();
            let catColor = "blue";
            let catIcon = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>`;
            if (cat === "warning") {
                catColor = "amber";
                catIcon = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>`;
            } else if (cat === "critical" || cat === "error") {
                catColor = "rose";
                catIcon = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>`;
            }

            return `
                <div class="relative p-4 sm:p-5 rounded-xl bg-slate-50 dark:bg-[#070b16] border ${isUnread ? 'border-l-4 border-l-rose-500 border-slate-300 dark:border-gray-800 shadow-[0_0_15px_rgba(244,63,94,0.08)]' : 'border-slate-200 dark:border-gray-800/60 opacity-80'} transition-all hover:border-slate-400 dark:hover:border-gray-700">
                    <div class="flex items-start justify-between gap-4">
                        <div class="flex items-start gap-3 min-w-0">
                            <div class="w-8 h-8 rounded-lg bg-${catColor}-500/10 border border-${catColor}-500/20 text-${catColor}-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">${catIcon}</svg>
                            </div>
                            <div class="min-w-0">
                                <div class="flex items-center gap-2 flex-wrap">
                                    <h4 class="text-xs sm:text-sm font-bold text-slate-800 dark:text-white leading-snug">${esc(n.title)}</h4>
                                    <span class="px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold bg-${catColor}-500/10 text-${catColor}-500 border border-${catColor}-500/20">${esc(cat)}</span>
                                    ${isUnread ? '<span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>' : ''}
                                </div>
                                <p class="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed break-words">${esc(n.message)}</p>
                            </div>
                        </div>
                        <div class="text-[10px] font-mono text-slate-400 dark:text-slate-500 flex-shrink-0 text-right">
                            ${esc(n.created_at || "")}
                        </div>
                    </div>
                </div>
            `;
        }).join("");
    } catch (err) {
        if (listEl) {
            listEl.innerHTML = `<div class="p-8 text-center text-xs text-red-400">${esc(err.message)}</div>`;
        }
    }
}

async function markAllNotificationsRead() {
    try {
        await api("/api/notifications/read-all", { method: "POST" });
        showToast("All notifications marked as read.");
        await fetchNotifications();
    } catch (err) {
        showToast(`Failed marking notifications as read: ${err.message}`, "error");
    }
}

// ========================================================
// ENTERPRISE RBAC & USER PROFILE STATE
// ========================================================
window.currentUser = null;
window.currentPermissions = {
    can_manage_users: false,
    can_edit_settings: false,
    can_approve_drafts: false,
    can_generate_posts: false,
    can_manage_modules: false,
    can_factory_purge: false,
    is_view_only: false
};

async function fetchCurrentUserProfile() {
    try {
        const data = await api("/api/auth/me");
        window.currentUser = data.user || {
            id: data.id,
            username: data.username,
            email: data.email,
            role: data.role,
            is_active: data.is_active
        };
        window.currentPermissions = data.permissions || {};
        
        // 1. Update Sidebar user avatar & name
        const user = window.currentUser;
        const nameEl = document.getElementById("sidebar-user-name");
        const avatarEl = document.getElementById("sidebar-user-avatar");
        const badgeEl = document.getElementById("sidebar-user-role-badge");

        if (nameEl) nameEl.textContent = user.username || "Operator";
        if (avatarEl) {
            const initials = (user.username || "OP").substring(0, 2).toUpperCase();
            avatarEl.textContent = initials;
        }
        if (badgeEl) {
            const role = (user.role || "admin").toLowerCase();
            if (role === "admin") {
                badgeEl.className = "text-[9px] font-mono font-bold tracking-wider inline-flex items-center gap-1 text-amber-400";
                badgeEl.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span> ADMIN`;
            } else if (role === "editor") {
                badgeEl.className = "text-[9px] font-mono font-bold tracking-wider inline-flex items-center gap-1 text-cyan-400";
                badgeEl.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-cyan-400"></span> EDITOR`;
            } else {
                badgeEl.className = "text-[9px] font-mono font-bold tracking-wider inline-flex items-center gap-1 text-emerald-400";
                badgeEl.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> VIEWER`;
            }
        }

        // 2. Hide administrative sidebar links and governance sections for non-admins (Fix 2)
        const role = (user.role || "").toLowerCase();
        window.currentUserRole = role;
        const isAdmin = role === "admin";

        const secGov = document.getElementById("section-governance");
        if (secGov) secGov.style.display = isAdmin ? "" : "none";

        const navUsers = document.getElementById("nav-users");
        const navSettings = document.getElementById("nav-settings");
        const navLicense = document.getElementById("nav-license");
        if (navUsers) navUsers.style.display = isAdmin ? "" : "none";
        if (navSettings) navSettings.style.display = isAdmin ? "" : "none";
        if (navLicense) navLicense.style.display = isAdmin ? "" : "none";

        // 3. Hide License action buttons on Command Center for non-admins (Fix 2)
        const ccLicenseActions = document.getElementById("cc-license-actions");
        if (ccLicenseActions) ccLicenseActions.style.display = isAdmin ? "" : "none";
        const btnCcConsole = document.getElementById("cc-btn-license-console");
        const btnCcUpdate = document.getElementById("cc-btn-license-update");
        if (btnCcConsole) btnCcConsole.style.display = isAdmin ? "" : "none";
        if (btnCcUpdate) btnCcUpdate.style.display = isAdmin ? "" : "none";

        if (!isAdmin) {
            const activeNav = document.querySelector("aside button.nav-active");
            if (activeNav && ["nav-users", "nav-settings", "nav-license"].includes(activeNav.id)) {
                switchTab("overview");
            }
        }

        // 4. Enforce view-only observer locks across interactive tools
        applyRbacUiLocks();
    } catch(err) {
        console.warn("Could not load current user profile:", err.message);
    }
}

function applyRbacUiLocks() {
    const isViewer = Boolean(window.currentPermissions?.is_view_only);
    if (!isViewer) return;

    // Command Center Autopilot buttons
    const btnToggleAuto = document.getElementById("btn-toggle-autopilot");
    const btnForceAuto = document.getElementById("btn-force-autopilot");
    if (btnToggleAuto) { btnToggleAuto.disabled = true; btnToggleAuto.classList.add("opacity-50", "cursor-not-allowed"); btnToggleAuto.title = "View-only access"; }
    if (btnForceAuto) { btnForceAuto.disabled = true; btnForceAuto.classList.add("opacity-50", "cursor-not-allowed"); btnForceAuto.title = "View-only access"; }

    // Course Modules syllabus import
    const btnImport = document.getElementById("btn-import-syllabus");
    const btnAddModule = document.getElementById("btn-add-module");
    if (btnImport) { btnImport.disabled = true; btnImport.classList.add("opacity-50", "cursor-not-allowed"); }
    if (btnAddModule) { btnAddModule.disabled = true; btnAddModule.classList.add("opacity-50", "cursor-not-allowed"); }

    // On-Demand generation button
    const ondemandBtn = document.getElementById("ondemand-submit");
    if (ondemandBtn) { ondemandBtn.disabled = true; ondemandBtn.classList.add("opacity-50", "cursor-not-allowed"); ondemandBtn.textContent = "Generation Gated (Viewer Role)"; }

    // Promo generation button
    const promoBtn = document.getElementById("promo-submit-btn");
    if (promoBtn) { promoBtn.disabled = true; promoBtn.classList.add("opacity-50", "cursor-not-allowed"); promoBtn.textContent = "Campaign Gated (Viewer Role)"; }
}

// ========================================================
// USER MANAGEMENT & RBAC CONSOLE
// ========================================================
let allUsersList = [];

async function fetchUsers() {
    try {
        const res = await api("/api/users");
        allUsersList = res.users || [];

        // Update top metric counters
        const total = allUsersList.length;
        const admins = allUsersList.filter(u => u.role === "admin").length;
        const editors = allUsersList.filter(u => u.role === "editor").length;
        const viewers = allUsersList.filter(u => u.role === "viewer").length;

        const elTotal = document.getElementById("stat-users-total");
        const elAdmins = document.getElementById("stat-users-admins");
        const elEditors = document.getElementById("stat-users-editors");
        const elViewers = document.getElementById("stat-users-viewers");
        const elBadge = document.getElementById("users-count-badge");

        if (elTotal) elTotal.textContent = total;
        if (elAdmins) elAdmins.textContent = admins;
        if (elEditors) elEditors.textContent = editors;
        if (elViewers) elViewers.textContent = viewers;
        if (elBadge) elBadge.textContent = `${total} account${total === 1 ? '' : 's'}`;

        renderUsersTable(allUsersList);
    } catch(err) {
        showToast(`Could not load users: ${err.message}`, "error");
        const tbody = document.getElementById("users-table-body");
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="6" class="py-10 text-center text-rose-400">Failed loading operators: ${esc(err.message)}</td></tr>`;
        }
    }
}

function renderUsersTable(users) {
    const tbody = document.getElementById("users-table-body");
    if (!tbody) return;

    if (!users || users.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="py-10 text-center text-slate-400 italic">No matching operators found.</td></tr>`;
        return;
    }

    tbody.innerHTML = users.map(u => {
        const initials = (u.username || "U").substring(0, 2).toUpperCase();
        const role = (u.role || "viewer").toLowerCase();
        const roleBadge = role === "admin" 
            ? `<span class="px-2 py-0.5 rounded font-mono text-[10px] font-bold role-pill-admin role-badge-tooltip cursor-help" title="ADMIN: Full platform governance, API key rotation, license activation, system resets, and user provisioning.">ADMIN</span>`
            : role === "editor"
            ? `<span class="px-2 py-0.5 rounded font-mono text-[10px] font-bold role-pill-editor role-badge-tooltip cursor-help" title="EDITOR: Content generation, syllabus extraction, promo campaigns, and draft approval queue review. (Blocked from settings and licenses).">EDITOR</span>`
            : `<span class="px-2 py-0.5 rounded font-mono text-[10px] font-bold role-pill-viewer role-badge-tooltip cursor-help" title="VIEWER: Read-only access to Command Center metrics, audit logs, and draft previews. (Blocked from modifying content).">VIEWER</span>`;

        const statusBadge = u.is_active
            ? `<span class="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-semibold"><span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>Active</span>`
            : `<span class="inline-flex items-center gap-1.5 text-xs text-rose-400 font-semibold"><span class="w-1.5 h-1.5 rounded-full bg-rose-400"></span>Disabled</span>`;

        const lastLogin = u.last_login_at 
            ? `<span class="text-slate-300 font-mono text-[11px]">${esc(u.last_login_at.replace("T", " ").substring(0, 16))}</span>`
            : `<span class="text-slate-500 italic text-[11px]">Never</span>`;

        const createdAt = u.created_at
            ? `<span class="text-slate-400 font-mono text-[11px]">${esc(u.created_at.substring(0, 10))}</span>`
            : `<span class="text-slate-500">--</span>`;

        const mfaBadge = u.mfa_enabled 
            ? `<span class="px-1.5 py-0.5 rounded font-mono text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">MFA ON</span>` 
            : `<span class="px-1.5 py-0.5 rounded font-mono text-[9px] text-slate-500 bg-slate-500/10 border border-slate-500/20">MFA OFF</span>`;

        const isSelf = window.currentUser && window.currentUser.id === u.id;

        return `
            <tr class="hover:bg-slate-100/50 dark:hover:bg-[#0d1324]/50 transition-colors">
                <td class="px-4 py-2.5">
                    <div class="flex items-center gap-2.5">
                        <div class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-700 dark:text-slate-200 flex-shrink-0">
                            ${esc(initials)}
                        </div>
                        <div class="min-w-0">
                            <div class="font-bold text-slate-800 dark:text-white flex items-center gap-1.5 truncate">
                                <span>${esc(u.username)}</span>
                                ${isSelf ? '<span class="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">You</span>' : ''}
                            </div>
                            <div class="text-[11px] text-slate-400 truncate">${esc(u.email || "No email assigned")}</div>
                        </div>
                    </div>
                </td>
                <td class="px-4 py-2.5">${roleBadge}</td>
                <td class="px-4 py-2.5">
                    <div>${statusBadge}</div>
                    <div class="mt-1">${mfaBadge}</div>
                </td>
                <td class="px-4 py-2.5">${lastLogin}</td>
                <td class="px-4 py-2.5">${createdAt}</td>
                <td class="px-4 py-2.5 text-right">
                    <div class="flex items-center justify-end gap-1.5">
                        <button onclick="openEditUserModal(${u.id})" title="Edit Role &amp; Email" class="p-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                        </button>
                        ${u.mfa_enabled ? `
                            <button onclick="adminResetMfa(${u.id}, '${esc(u.username)}')" title="Reset / Clear MFA (Locked Out)" class="p-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 transition-colors">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                            </button>
                        ` : ''}
                        ${!isSelf ? `
                            <button onclick="toggleUserStatus(${u.id}, ${!u.is_active})" title="${u.is_active ? 'Deactivate Account' : 'Activate Account'}" class="p-1 rounded ${u.is_active ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-500' : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400'} transition-colors">
                                ${u.is_active 
                                    ? `<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>`
                                    : `<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`
                                }
                            </button>
                            <button onclick="deleteUserAccount(${u.id}, '${esc(u.username)}')" title="Delete Account" class="p-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 transition-colors">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

async function adminResetMfa(userId, username) {
    if (!confirm(`Are you sure you want to reset and clear Multi-Factor Authentication for '${username}'? The user will be able to log in with passkey alone until they re-enroll.`)) return;
    try {
        const res = await api(`/api/users/${userId}/reset-mfa`, { method: "POST" });
        showToast(res.message || `MFA cleared for ${username}`, "info");
        await fetchUsers();
    } catch (e) {
        showToast(`Failed to reset MFA: ${e.message}`, "error");
    }
}

function filterUsersTable() {
    const search = (document.getElementById("users-search-input")?.value || "").toLowerCase().trim();
    const role = (document.getElementById("users-role-filter")?.value || "all").toLowerCase();

    let filtered = allUsersList.slice();
    if (role !== "all") {
        filtered = filtered.filter(u => (u.role || "").toLowerCase() === role);
    }
    if (search) {
        filtered = filtered.filter(u => 
            (u.username || "").toLowerCase().includes(search) || 
            (u.email || "").toLowerCase().includes(search)
        );
    }
    renderUsersTable(filtered);
}

function togglePermissionsMatrixModal(show) {
    const modal = document.getElementById("permissions-matrix-modal");
    if (modal) modal.classList.toggle("hidden", !show);
}

function openAddUserModal() {
    document.getElementById("user-modal-id").value = "";
    document.getElementById("user-modal-title").textContent = "Add New Operator";
    const uInput = document.getElementById("user-modal-username");
    uInput.value = "";
    uInput.disabled = false;
    document.getElementById("user-modal-username-hint").textContent = "Unique system login username (3-32 characters).";
    document.getElementById("user-modal-email").value = "";
    document.getElementById("user-modal-role").value = "editor";
    const pInput = document.getElementById("user-modal-password");
    pInput.value = "";
    pInput.placeholder = "Enter temporary password";
    pInput.required = true;
    document.getElementById("user-modal-password-required").style.display = "";
    document.getElementById("user-modal-password-hint").textContent = "Temporary password for initial login.";
    document.getElementById("user-modal-status-group").classList.add("hidden");
    document.getElementById("user-editor-modal").classList.remove("hidden");
}

function openEditUserModal(userId) {
    const user = allUsersList.find(u => u.id === userId);
    if (!user) return showToast("Operator not found", "error");

    document.getElementById("user-modal-id").value = user.id;
    document.getElementById("user-modal-title").textContent = `Edit Operator: ${user.username}`;
    const uInput = document.getElementById("user-modal-username");
    uInput.value = user.username;
    uInput.disabled = true;
    document.getElementById("user-modal-username-hint").textContent = "Username is fixed.";
    document.getElementById("user-modal-email").value = user.email || "";
    document.getElementById("user-modal-role").value = user.role || "viewer";
    const pInput = document.getElementById("user-modal-password");
    pInput.value = "";
    pInput.placeholder = "Leave blank to keep existing password";
    pInput.required = false;
    document.getElementById("user-modal-password-required").style.display = "none";
    document.getElementById("user-modal-password-hint").textContent = "Only enter a new password if resetting credentials.";
    
    const isSelf = window.currentUser && window.currentUser.id === user.id;
    const statusGroup = document.getElementById("user-modal-status-group");
    const activeCb = document.getElementById("user-modal-is-active");
    if (statusGroup && activeCb) {
        statusGroup.classList.remove("hidden");
        activeCb.checked = Boolean(user.is_active);
        activeCb.disabled = isSelf; // prevent disabling oneself
    }

    document.getElementById("user-editor-modal").classList.remove("hidden");
}

function closeUserModal() {
    document.getElementById("user-editor-modal").classList.add("hidden");
}

async function submitUserForm(event) {
    event.preventDefault();
    const id = document.getElementById("user-modal-id").value;
    const email = document.getElementById("user-modal-email").value.trim();
    const role = document.getElementById("user-modal-role").value;
    const password = document.getElementById("user-modal-password").value;
    const btn = document.getElementById("user-modal-submit-btn");

    if (btn) { btn.disabled = true; btn.textContent = "Saving..."; }

    try {
        if (!id) {
            // Create user
            const username = document.getElementById("user-modal-username").value.trim();
            if (!username) throw new Error("Username is required");
            if (!password) throw new Error("Password is required");

            await api("/api/users", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, email, role, password })
            });
            showToast(`Operator "${username}" created successfully`, "success");
        } else {
            // Update user
            const payload = { email, role };
            if (password && password.trim()) payload.password = password.trim();
            const activeCb = document.getElementById("user-modal-is-active");
            if (activeCb) payload.is_active = activeCb.checked;

            await api(`/api/users/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });
            showToast("Operator updated successfully", "success");
        }
        closeUserModal();
        await fetchUsers();
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = "Save Operator"; }
    }
}

async function toggleUserStatus(userId, newActiveStatus) {
    const user = allUsersList.find(u => u.id === userId);
    const actionLabel = newActiveStatus ? "activate" : "deactivate";
    if (!confirm(`Are you sure you want to ${actionLabel} operator "${user?.username || userId}"?`)) return;

    try {
        await api(`/api/users/${userId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ is_active: newActiveStatus })
        });
        showToast(`Operator ${newActiveStatus ? "activated" : "deactivated"}`, "success");
        await fetchUsers();
    } catch(err) {
        showToast(err.message, "error");
    }
}

async function deleteUserAccount(userId, username) {
    if (!confirm(`Are you sure you want to PERMANENTLY delete operator "${username}"? This cannot be undone.`)) return;

    try {
        await api(`/api/users/${userId}`, { method: "DELETE" });
        showToast(`Operator "${username}" deleted`, "success");
        await fetchUsers();
    } catch(err) {
        showToast(err.message, "error");
    }
}

function switchTab(id) {
    if (window.innerWidth < 1024) {
        toggleSidebar(false);
    }

    const userRole = (window.currentUser?.role || window.currentUserRole || "").toLowerCase();
    if (["users", "settings", "license", "updates"].includes(id)) {
        if (userRole && userRole !== "admin") {
            showToast("Access Denied: Administrative privileges required", "error");
            return switchTab("overview");
        }
    }

    if (id === "users") {
        if (window.currentPermissions && !window.currentPermissions.can_manage_users) {
            showToast("Access Denied: Administrator role required for User Management", "error");
            return switchTab("overview");
        }
        fetchUsers();
    }
    if (id === "howto") { initKbSearch(); }
    if (id === "settings") {
        if (window.currentPermissions && !window.currentPermissions.can_edit_settings) {
            showToast("Access Denied: Administrator role required for System Settings", "error");
            return switchTab("overview");
        }
        fetchSettings();
    }

    document.querySelectorAll(".tab-content").forEach(e => e.classList.add("hidden"));

    document.getElementById("tab-" + id)?.classList.remove("hidden");
    if (id === "integrations" || id === "health") {
        document.getElementById("tab-health")?.classList.remove("hidden");
    }
    if (id === "pipelines" || id === "modules") {
        document.getElementById("tab-modules")?.classList.remove("hidden");
    }
    document.querySelectorAll("aside button[id^='nav-']").forEach(button => {
        const active = button.id === `nav-${id}` || ((id === "health" || id === "integrations") && (button.id === "nav-integrations" || button.id === "nav-health")) || (id === "pipelines" && button.id === "nav-modules");
        button.classList.toggle("nav-active", active);
        button.classList.toggle("nav-inactive", !active);
        if (active) button.setAttribute("aria-current", "page");
        else button.removeAttribute("aria-current");
    });
    document.getElementById("header-title").textContent = titles[id] || titles.overview;
    if (id === "overview") { fetchMetrics(); fetchPipeline(); fetchModelUsage(); fetchCommandStatus(); fetchAutopilotStatus(); fetchLicenseStatus(); fetchSocialAnalytics(); fetchContentKpis(); initKbSearch(); initSettingsNavigation(); fetchContentKpis(); }
    if (id === "license") fetchLicenseStatus();
    if (id === "updates") { fetchUpdateStatus(); fetchUpdateSnapshots(); }
    if (id === "modules" || id === "pipelines") fetchCourses();
    if (id === "ondemand") fetchOnDemandHistory();
    if (id === "approval") fetchDrafts("current");
    if (id === "notifications") fetchNotifications();
    if (id === "integrations" || id === "health") fetchIntegrations();
    if (id === "logs") fetchLogs();
    if (id === "trending") {
        if (typeof loadTrendingCategories === "function") loadTrendingCategories();
        fetchTrendingArticles();
    }
}

function terminateSession() { 
    try { localStorage.clear(); sessionStorage.clear(); } catch(e) {}
    location.href = "/login"; 
}
function formatUptime(seconds) {
    const minutes = Math.floor(Number(seconds || 0) / 60), days = Math.floor(minutes / 1440);
    const hours = Math.floor((minutes % 1440) / 60); return days ? `${days}d ${hours}h` : `${hours}h ${minutes % 60}m`;
}
async function fetchMetrics() {
    try { const m = await api("/api/system/metrics");
        document.getElementById("metric-cpu").textContent = `${Number(m.cpu_percent || 0).toFixed(1)}%`;
        document.getElementById("metric-ram-percent").textContent = `${Number(m.memory_percent || 0).toFixed(1)}%`;
        document.getElementById("metric-ram-detail").textContent = `${Number(m.memory_used_gb || 0).toFixed(1)} GB / ${Number(m.memory_total_gb || 0).toFixed(1)} GB`;
        document.getElementById("metric-disk-percent").textContent = `${Number(m.disk_percent || 0).toFixed(1)}%`;
        document.getElementById("metric-disk-detail").textContent = `${Number(m.disk_used_gb || 0).toFixed(1)} GB / ${Number(m.disk_total_gb || 0).toFixed(1)} GB`;
        document.getElementById("metric-uptime").textContent = formatUptime(m.uptime_seconds);
    } catch (e) { showToast(`Metrics unavailable: ${e.message}`, "error"); }
}
async function fetchPipeline() {
    const table = document.getElementById("queue-table"); if (!table) return;
    try { const posts = await api("/api/posts?view=upcoming");
        table.innerHTML = posts.slice(0, 20).map(p => `<tr class="border-b border-gray-800/40"><td class="py-3 px-5">#${p.id}</td><td class="py-3 px-5">${esc(p.prompt)}</td><td class="py-3 px-5 text-blue-400">${esc(p.status)}<br><small>${esc(p.scheduled_at_display || p.scheduled_at || "")}</small></td></tr>`).join("") ||
            `<tr>
                <td colspan="3" class="py-12 text-center">
                    <div class="flex flex-col items-center justify-center space-y-3">
                        <div class="w-10 h-10 rounded-full bg-slate-800/60 border border-slate-700/60 flex items-center justify-center text-slate-400 text-lg">⏳</div>
                        <div class="text-xs font-semibold text-slate-300">No upcoming posts queued</div>
                        <p class="text-[11px] text-slate-500 max-w-sm">The automated queue is currently clear. Spin up on-demand content or import campaign documents to schedule posts.</p>
                        <div class="flex items-center gap-2 pt-1">
                            <button type="button" onclick="switchTab('ondemand')" class="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow transition">
                                + Generate On-Demand Post
                            </button>
                            <button type="button" onclick="switchTab('modules')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
                                📥 Import Campaign Document
                            </button>
                        </div>
                    </div>
                </td>
            </tr>`;
    } catch (e) { table.innerHTML = `<tr><td colspan="3" class="py-10 text-center text-red-400">${esc(e.message)}</td></tr>`; }
}
async function fetchModelUsage() { const el = document.getElementById("ai-models-container"); if (!el) return; try {
    const rows = await api("/api/models/usage"); el.innerHTML = rows.map(x => `<div class="flex justify-between p-3"><span>${esc(x.model)}</span><span>${x.request_count} reqs · ${Number(x.total_tokens || 0).toLocaleString()} tokens</span></div>`).join("") || "No AI requests yet.";
} catch { el.textContent = "AI telemetry unavailable."; } }
async function fetchCommandStatus() {
    const gemini = document.getElementById("status-gemini"), smtp = document.getElementById("status-smtp");
    const local = document.getElementById("status-local-ai");
    if (!gemini || !smtp) return;
    try {
        const status = await api("/api/settings");
        const isGeminiOk = String(status.gemini_key_configured) === "true" || status.gemini_key_configured === true;
        const isSmtpOk = String(status.smtp_configured) === "true" || status.smtp_configured === true;
        for (const [element, configured] of [[gemini, isGeminiOk], [smtp, isSmtpOk]]) {
            element.classList.remove("text-slate-500", "text-emerald-400", "text-amber-400");
            if (configured) {
                element.textContent = "Configured";
                element.classList.add("text-emerald-400");
            } else {
                element.textContent = "Not configured";
                element.classList.add("text-amber-400");
            }
        }
        if (local) {
            const state=status.local_llm_status || "Standby";
            const isOnline = state === "Online";
            const localEnabled = String(status.enable_local_llm) === "1" || status.enable_local_llm === true;
            const usingLocal = localEnabled && status.ai_provider === "local";
            local.textContent = usingLocal ? "Local AI Engine Active" : `Postall_V4 AI Engine: ${isOnline ? "Active" : state}`;
            local.classList.remove("text-slate-500", "text-emerald-400", "text-amber-400");
            local.classList.add(usingLocal || isOnline ? "text-emerald-400" : state === "Disabled" ? "text-slate-500" : "text-amber-400");
        }
    } catch (error) {
        gemini.textContent = "Unavailable";
        smtp.textContent = "Unavailable";
        if (local) local.textContent="Postall_V4 AI Engine: Unavailable";
        gemini.className = "text-red-400";
        smtp.className = "text-red-400";
        showToast(`Service status unavailable: ${error.message}`, "error");
    }
}
let currentCoursesList = [];

function renderTopicStatusBadge(status) {
    const s = String(status || '').toUpperCase();
    if (s === 'PUBLISHED') {
        return `<span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/30"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>PUBLISHED</span>`;
    }
    if (s === 'QUEUED' || s === 'SCHEDULED') {
        return `<span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/30"><span class="w-1.5 h-1.5 rounded-full bg-blue-400"></span>SCHEDULED</span>`;
    }
    if (s === 'DRAFTED' || s === 'DRAFT' || s === 'APPROVED') {
        return `<span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30"><span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>DRAFTED</span>`;
    }
    return `<span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-500/10 text-slate-400 border border-slate-500/30"><span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>UNPOSTED</span>`;
}

function renderTopicChannelBadges(targetPlatforms) {
    let platforms = targetPlatforms;
    if (typeof platforms === "string") {
        try { platforms = JSON.parse(platforms); } catch { platforms = []; }
    }
    if (!Array.isArray(platforms)) return "";
    const labels = { linkedin: "LI", x: "X", twitter: "X", instagram: "IG", youtube: "YT" };
    return platforms.map(platform => labels[String(platform).toLowerCase()])
        .filter(Boolean)
        .map(label => `<span class="topic-channel-badge">${label}</span>`).join("");
}

async function fetchRoutingHealth() {
    const grid = document.getElementById("routing-health-grid");
    if (!grid) return;
    const channels = [
        ["linkedin", "LinkedIn", "REST API · ugcPosts / v2", "in"],
        ["twitter", "Twitter / X", "REST API v2", "𝕏"],
        ["instagram", "Instagram", "Graph API · v19.0+", "IG"],
        ["youtube", "YouTube", "Data API v3 · Shorts / Community staging", "YT"],
    ];
    try {
        const health = await api("/api/routing/health");
        grid.innerHTML = channels.map(([key, label, description, glyph]) => {
            const channel = health[key] || {};
            const active = channel.status === "ACTIVE";
            const badgeClass = active
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                : "bg-slate-500/10 text-slate-400 border-slate-500/30";
            const dotClass = active ? "bg-emerald-400 animate-pulse" : "bg-slate-500";
            const settingsAction = active ? "" : `<button type="button" onclick="openSocialSettings()" class="text-[10px] font-semibold text-blue-400 hover:text-blue-300">Configure in System Settings →</button>`;
            return `<article class="flex items-start justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-700/50 dark:bg-slate-800/30">
                <div class="flex min-w-0 items-center gap-3">
                    <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded bg-slate-800 text-xs font-bold text-white">${glyph}</span>
                    <span class="min-w-0"><span class="block text-sm font-semibold text-slate-800 dark:text-white">${label}</span><span class="block text-[10px] text-slate-500 dark:text-gray-400">${description}</span>${settingsAction}</span>
                </div>
                <span class="inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2 py-1 text-[9px] font-bold ${badgeClass}"><span class="h-1.5 w-1.5 rounded-full ${dotClass}"></span>${active ? "ACTIVE" : "UNCONFIGURED"}</span>
            </article>`;
        }).join("");
    } catch (error) {
        grid.innerHTML = `<p class="col-span-full text-xs text-rose-400">Routing health unavailable: ${esc(error.message)}</p>`;
    }
}

function openSocialSettings() {
    switchTab("settings");
    document.querySelector('[data-settings-target="sec-social"]')?.click();
}

window.addEventListener("postall:settings-updated", fetchRoutingHealth);

async function fetchAutopilotStatus() {
    try {
        const data = await api("/api/autopilot/status");
        const modeBadge = document.getElementById("autopilot-mode-badge");
        const bufferBadge = document.getElementById("autopilot-buffer-badge");
        const nextSchedule = document.getElementById("autopilot-next-schedule");
        const toggleBtn = document.getElementById("btn-toggle-autopilot");
        const toggleIcon = document.getElementById("autopilot-toggle-icon");
        const toggleLabel = document.getElementById("autopilot-toggle-label");

        if (modeBadge) {
            if (data.enabled) {
                modeBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/30";
                modeBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>AUTOPILOT: ACTIVE`;
            } else {
                modeBadge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-500 border border-amber-500/30";
                modeBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-amber-500"></span>AUTOPILOT: PAUSED`;
            }
        }

        if (bufferBadge) {
            const queued = Number(data.queued_days || 0);
            const target = Number(data.buffer_days || 3);
            const badgeColor = queued >= target ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30" : "bg-blue-500/10 text-blue-400 border-blue-500/30";
            bufferBadge.className = `px-2.5 py-0.5 rounded-full text-xs font-semibold border ${badgeColor}`;
            bufferBadge.textContent = `${queued} / ${target} Days Queued`;
        }

        if (nextSchedule) {
            if (data.next_scheduled_post) {
                const p = data.next_scheduled_post;
                const display = p.scheduled_at_display || `${p.scheduled_at} (${p.course_name || p.course || ""} &bull; ${p.topic_name || p.topic || ""})`;
                nextSchedule.innerHTML = `<span class="text-blue-400 font-semibold">Next Scheduled Post:</span> ${esc(display)}`;
            } else if (data.unposted_topics_count > 0) {
                nextSchedule.innerHTML = `<span class="text-slate-400">Next Slot:</span> Configured daily at ${esc(data.post_time || "09:00")} <span class="text-blue-400 font-medium">(${data.unposted_topics_count} unposted topics ready to queue)</span>`;
            } else {
                nextSchedule.innerHTML = `<span class="text-amber-400">All syllabus topics across active courses have been scheduled or published.</span>`;
            }
        }

        if (toggleBtn && toggleIcon && toggleLabel) {
            if (data.enabled) {
                toggleIcon.textContent = "⏸";
                toggleLabel.textContent = "Pause Autopilot";
                toggleBtn.title = "Pause autonomous daily generation and posting";
            } else {
                toggleIcon.textContent = "▶";
                toggleLabel.textContent = "Activate Autopilot";
                toggleBtn.title = "Activate autonomous daily generation and posting";
            }
        }
    } catch(err) {
        console.warn("Autopilot status fetch failed:", err);
    }
}

async function toggleAutopilot() {
    try {
        const res = await api("/api/autopilot/toggle", { method: "POST" });
        showToast(res.message || "Autopilot status toggled", "success");
        await fetchAutopilotStatus();
    } catch(err) {
        showToast(err.message, "error");
    }
}

async function runAutopilotNow() {
    const btn = document.getElementById("btn-run-autopilot-now");
    const origHtml = btn ? btn.innerHTML : "";
    if (btn) {
        btn.disabled = true;
        btn.classList.add("opacity-60", "cursor-not-allowed");
        btn.innerHTML = `<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg> Generating...`;
    }
    showToast("Running Autopilot buffer check and generating next post...", "info");
    try {
        const res = await api("/api/autopilot/run-now", { method: "POST" });
        showToast(res.message || "Autopilot run completed", "success");
        await Promise.all([fetchAutopilotStatus(), fetchPipeline(), fetchCourses()]);
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.classList.remove("opacity-60", "cursor-not-allowed");
            btn.innerHTML = origHtml;
        }
    }
}

async function fetchCourses() {
    const table = document.getElementById("modules-tbody"); if (!table) return;
    let courses;
    try { courses = await api("/api/courses"); } catch (e) { table.innerHTML = `<tr><td colspan="4" class="p-6 text-center text-red-400">Courses unavailable: ${esc(e.message)}</td></tr>`; throw e; }
    currentCoursesList = courses || [];
    table.innerHTML = courses.map((course, index) => `
        <tr class="border-b border-slate-200 dark:border-gray-800">
            <td class="p-3 text-center">${index + 1}</td>
            <td class="p-3 font-bold">
                <button id="course-toggle-${course.id}" class="inline-flex items-center gap-2 text-left" aria-expanded="false" onclick="toggleCourseTopics(${course.id})">
                    <span id="course-chevron-${course.id}" aria-hidden="true">▸</span>${esc(course.name)}
                </button>
                ${course.syllabus_url ? `<a class="block ml-6 mt-1 text-[10px] font-normal text-blue-400 hover:underline truncate max-w-xl" href="${esc(course.syllabus_url)}" target="_blank" rel="noopener noreferrer">Official syllabus source</a>` : ""}
            </td>
            <td class="p-3 text-center">${course.topics.length} topics</td>
            <td class="p-3 text-right space-x-2 sm:space-x-3">
                <button class="text-emerald-500 hover:text-emerald-400 font-semibold" title="Add single topic manually" onclick="promptAddTopic(${course.id}, '${esc(course.name).replace(/'/g, "\\'")}')">+ Topic</button>
                <button class="text-blue-500 hover:underline" onclick="populateCourse(${course.id}, this, false)">Populate AI syllabus</button>
                <button class="text-amber-500 hover:underline" onclick="populateCourse(${course.id}, this, true)">Regenerate / Append</button>
                <button class="btn-import-topic text-purple-500 hover:text-purple-400" title="Import campaign document" data-course-id="${course.id}" data-course-name="${esc(course.name).replace(/'/g, "\\'")}">Import</button>
                <button class="text-emerald-500 hover:text-emerald-400" title="Export syllabus as ODF document" aria-label="Export ${esc(course.name)} syllabus" onclick="exportCourseSyllabus(${course.id}, '${esc(course.name).replace(/'/g, "\\'")}')">
                    <svg class="inline w-3.5 h-3.5 align-text-bottom" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v12m0 0l-4-4m4 4l4-4M5 17v3h14v-3"></path></svg> Export ODF
                </button>
                <button class="text-red-400 hover:underline" onclick="deleteCourse(${course.id}, '${esc(course.name).replace(/'/g, "\\'")}')">Delete</button>
            </td>
        </tr>
        <tr id="course-topics-${course.id}" class="hidden">
            <td colspan="4" class="p-0">
                <div class="divide-y divide-slate-200 dark:divide-gray-800 bg-slate-50 dark:bg-[#0b1120]">
                    ${course.topics.map(topic => `<div class="grid grid-cols-[2rem_minmax(0,1fr)_8rem_14rem] items-center gap-3 px-5 py-3 text-sm">
                        <input type="checkbox" class="topic-select justify-self-center" value="${topic.id}" aria-label="Select ${esc(topic.title)}">
                        <span class="min-w-0">
                            <span class="block truncate">↳ ${esc(topic.title)}</span>
                            ${topic.details ? `<span class="block mt-0.5 text-xs text-slate-500 whitespace-normal">${esc(topic.details)}</span>` : ""}
                            ${topic.source ? `<span class="inline-block mt-0.5 text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-mono">${esc(topic.source)}</span>` : ""}
                            <span class="block">${renderTopicChannelBadges(topic.target_platforms)}</span>
                        </span>
                        <div>${renderTopicStatusBadge(topic.display_status || topic.status)}</div>
                        <span class="space-x-3 text-right">
                            <button class="text-blue-500" onclick="generateTopic(${topic.id})">Generate preview</button>
                            <button class="text-red-400" onclick="deleteTopic(${topic.id})">Delete</button>
                        </span>
                    </div>`).join("") || `<p class="p-4 pl-14 text-xs text-slate-500">No topics yet. <button onclick="promptAddTopic(${course.id}, '${esc(course.name).replace(/'/g, "\\'")}')" class="text-blue-400 underline font-semibold">Add a topic</button>, <button onclick="openImportSyllabusModal(${course.id})" class="text-purple-400 underline font-semibold">import syllabus</button>, or populate via AI.</p>`}
                </div>
            </td>
        </tr>`).join("") || "<tr><td colspan='4' class='p-6 text-center text-slate-500'>No courses. Add a course to begin.</td></tr>";
    const selectAll = document.getElementById("select-all-topics");
    if (selectAll) selectAll.checked = false;
}
function toggleCourseTopics(courseId) {
    const row = document.getElementById(`course-topics-${courseId}`);
    const button = document.getElementById(`course-toggle-${courseId}`);
    const chevron = document.getElementById(`course-chevron-${courseId}`);
    if (!row || !button || !chevron) return;
    const expanded = row.classList.toggle("hidden") === false;
    button.setAttribute("aria-expanded", String(expanded));
    chevron.textContent = expanded ? "▾" : "▸";
}
function selectAllTopics(selected) {
    document.querySelectorAll("#tab-modules .topic-select").forEach(input => { input.checked = selected; });
}
async function populateCourse(id, button, regenerate = false) {
    const originalContent = button?.innerHTML;
    if (button) {
        button.disabled = true;
        button.innerHTML = '<span class="inline-flex items-center gap-1"><span class="animate-spin">⟳</span> Generating…</span>';
    }
    try {
        showToast(regenerate ? "Regenerating syllabus and appending new objectives…" : "Discovering syllabus and populating topics...", "info");
        const r = await api(`/api/courses/${id}/populate${regenerate ? "?regenerate=true" : ""}`, { method:"POST" });
        if (r.warning) {
            showToast(r.warning, "warning");
        } else {
            showToast(r.cached ? "Using saved syllabus; no Gemini query made" : `${r.topics_added} new topics appended; existing and published topics were preserved.`, "success");
        }
        await fetchCourses();
    } catch(e) {
        showToast(e.message, "error");
    } finally {
        if (button) {
            button.disabled = false;
            button.innerHTML = originalContent;
        }
    }
}
async function promptAddTopic(courseId, courseName) {
    const title = prompt(`Enter topic title for ${courseName || 'course'}:`);
    if (!title || !title.trim()) return;
    const details = prompt(`(Optional) Enter topic description or details:`) || "";
    try {
        await api("/api/topics", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ course_id: courseId, title: title.trim(), details: details.trim() })
        });
        showToast("Topic added successfully", "success");
        fetchCourses();
    } catch(e) {
        showToast(e.message, "error");
    }
}
function openImportSyllabusModal(courseId = null) {
    const modal = document.getElementById("import-syllabus-modal");
    const select = document.getElementById("import-course-select");
    if (!modal || !select) return;
    if (currentCoursesList && currentCoursesList.length > 0) {
        select.innerHTML = currentCoursesList.map(c =>
            `<option value="${c.id}" ${courseId && Number(courseId) === Number(c.id) ? "selected" : ""}>${esc(c.name)} (${c.topics ? c.topics.length : 0} topics)</option>`
        ).join("");
    } else {
        select.innerHTML = `<option value="">No courses available - add a course first</option>`;
    }
    const textElem = document.getElementById("import-topics-text");
    if (textElem) textElem.value = "";
    modal.classList.remove("hidden");
}
function closeImportSyllabusModal() {
    const modal = document.getElementById("import-syllabus-modal");
    if (modal) modal.classList.add("hidden");
}
async function submitImportSyllabus(event) {
    event.preventDefault();
    const select = document.getElementById("import-course-select");
    const textarea = document.getElementById("import-topics-text");
    const submitBtn = document.getElementById("import-submit-btn");
    const courseId = select ? select.value : null;
    const content = textarea ? textarea.value.trim() : "";
    if (!courseId) return showToast("Select a course first", "error");
    if (!content) return showToast("Please paste or type topics to import", "error");
    if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = "Importing..."; }
    try {
        const res = await api(`/api/courses/${courseId}/import-topics`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ content })
        });
        showToast(res.message || `${res.topics_added || 0} topics imported successfully`, "success");
        closeImportSyllabusModal();
        fetchCourses();
    } catch(e) {
        showToast(e.message, "error");
    } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = "Import Topics"; }
    }
}
async function deleteCourse(id, name) { if (!confirm(`Delete ${name} and its topics?`)) return; try { await api(`/api/courses/${id}`, { method:"DELETE" }); showToast("Course deleted"); fetchCourses(); } catch(e) { showToast(e.message, "error"); } }
async function deleteTopic(id) { if (!confirm("Delete this topic and any generated drafts?")) return; try { await api(`/api/topics/${id}`, {method:"DELETE"}); showToast("Topic deleted"); fetchCourses(); } catch(e) { showToast(e.message,"error"); } }
async function deleteSelectedTopics() {
    const ids=[...document.querySelectorAll(".topic-select:checked")].map(x=>Number(x.value));
    if (!ids.length) return showToast("Select at least one topic","error");
    if (!confirm(`Delete ${ids.length} selected topic(s) and generated drafts?`)) return;
    try { await api("/api/topics/bulk-delete",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(ids)}); showToast(`${ids.length} topic(s) deleted`); fetchCourses(); } catch(e) { showToast(e.message,"error"); }
}
async function generateTopic(id) { try { const d = await api(`/api/modules/generate/${id}`, { method:"POST" }); showToast(`Draft #${d.id} ready for preview`); switchTab("approval"); } catch(e) { showToast(e.message, "error"); } }
async function addModulePrompt() {
    const name = prompt("Course or certification name");
    if (!name) return;
    try {
        await api("/api/courses", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name}) });
        fetchCourses();
    } catch(e) { showToast(e.message, "error"); }
}
async function exportCourseSyllabus(id, name) {
    try {
        const response = await fetch(`/api/courses/${id}/export`);
        if (!response.ok) {
            const payload = await response.json().catch(() => ({}));
            throw new Error(payload.detail || `Export failed (${response.status})`);
        }
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `${String(name).replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase()}-syllabus.odt`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
        showToast("ODF syllabus downloaded");
    } catch(error) {
        showToast(error.message, "error");
    }
}

function getDraftBadge(status) {
    const s = String(status || "").toUpperCase();
    switch (s) {
        case "FLAGGED_VIOLATION": return "bg-red-900/50 text-red-400 border border-red-500 font-black animate-pulse";
        case "DRAFT": return "bg-amber-500/10 text-amber-500 dark:text-amber-400 border border-amber-500/30";
        case "APPROVED": return "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30";
        case "SCHEDULED": return "bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/30";
        case "PUBLISHED": return "bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/30";
        case "REJECTED": return "bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30";
        default: return "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-300 dark:border-slate-700";
    }
}

function toggleDraft(id) {
    const card = document.getElementById(`draft-card-${id}`);
    if (!card) return;
    const isCollapsed = card.classList.toggle("collapsed");
    const label = card.querySelector(".draft-toggle-text");
    if (label) label.textContent = isCollapsed ? "Expand ▾" : "Collapse ▴";
}

function expandAllDrafts() {
    document.querySelectorAll(".draft-card").forEach(card => {
        card.classList.remove("collapsed");
        const label = card.querySelector(".draft-toggle-text");
        if (label) label.textContent = "Collapse ▴";
    });
}

function collapseAllDrafts() {
    document.querySelectorAll(".draft-card").forEach(card => {
        card.classList.add("collapsed");
        const label = card.querySelector(".draft-toggle-text");
        if (label) label.textContent = "Expand ▾";
    });
}

async function postNow(id) {
    if (!confirm(`Publish draft #${id} immediately?`)) return;
    try {
        const res = await api(`/api/drafts/${id}/post-now`, { method: "POST" });
        if (res && res.status === "dry_run") {
            showToast(res.message || "Dry run complete - no API call made", "info");
        } else {
            showToast(res && res.message ? res.message : "Posted successfully to LinkedIn", "success");
        }
        fetchDrafts("current");
        fetchApprovalCount();
    } catch(e) {
        showToast(e.message, "error");
    }
}

function updateApprovalBadge(count) {
    const badge = document.getElementById("nav-approval-badge");
    if (!badge) return;
    const num = Number(count) || 0;
    if (num <= 0) {
        badge.style.display = "none";
        badge.classList.add("hidden");
        badge.textContent = "";
    } else {
        badge.textContent = String(num);
        badge.style.display = "inline-flex";
        badge.classList.remove("hidden");
        badge.className = "inline-flex min-w-[20px] h-5 px-1.5 text-xs font-bold rounded-full items-center justify-center bg-blue-600/30 text-blue-400 border border-blue-500/40 font-mono sidebar-approval-badge";
    }
}

async function fetchApprovalCount() {
    try {
        const drafts = await api("/api/posts?view=current");
        if (Array.isArray(drafts)) {
            const pendingCount = drafts.filter(d => (d.status || "").toUpperCase() === "DRAFT").length;
            updateApprovalBadge(pendingCount);
        } else {
            updateApprovalBadge(0);
        }
    } catch (e) {
        updateApprovalBadge(0);
    }
}

async function fetchDrafts(view = "current") {
    const root = document.querySelector("#tab-approval"); if (!root) return;
    try {
        const drafts = await api(`/api/posts?view=${encodeURIComponent(view)}`);
        if (view === "current" && Array.isArray(drafts)) {
            const pendingCount = drafts.filter(d => ["DRAFT", "FLAGGED_VIOLATION"].includes((d.status || "").toUpperCase())).length;
            updateApprovalBadge(pendingCount);
        }
        // Ensure most recently created post appears on top
        drafts.sort((a, b) => (Number(b.id) || 0) - (Number(a.id) || 0));
        window.allDraftsCache = Object.fromEntries(drafts.map(d => [d.id, d]));

        root.innerHTML = `<div class="p-3 sm:p-6 space-y-4 max-w-7xl 2xl:max-w-[1680px] mx-auto">
            <!-- Top Controls Bar -->
            <div class="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#0d1324] p-3 sm:p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm">
                <div class="flex flex-wrap items-center gap-2">
                    <span class="font-bold text-xs uppercase tracking-wider text-slate-500 dark:text-gray-400 mr-1 sm:mr-2">Workflow</span>
                    ${["current","upcoming","past"].map(v => `<button onclick="fetchDrafts('${v}')" class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${v===view?"bg-blue-600 text-white shadow-md":"bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}">${v[0].toUpperCase()+v.slice(1)}</button>`).join("")}
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-500 font-mono hidden sm:inline mr-2">${drafts.length} ${drafts.length === 1 ? 'post' : 'posts'}</span>
                    <button onclick="expandAllDrafts()" class="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 transition-colors">Expand All</button>
                    <button onclick="collapseAllDrafts()" class="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 transition-colors">Collapse All</button>
                </div>
            </div>

            <!-- Retractable Draft Cards List -->
            <div class="space-y-3.5">
            ${drafts.map((d, index) => {
                const isCollapsed = index > 0; // Most recent draft expanded, older drafts retracted to title only
                return `<article class="draft-card rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#0f172a] shadow-sm overflow-hidden ${isCollapsed ? 'collapsed' : ''}" id="draft-card-${d.id}">
                    <!-- Clickable Header: Always visible -->
                    <div class="draft-header p-3.5 sm:p-4 flex flex-wrap items-center justify-between gap-3 cursor-pointer select-none hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors" onclick="toggleDraft(${d.id})">
                        <div class="flex items-center gap-2.5 sm:gap-3.5 min-w-0 flex-1">
                            <span class="draft-chevron text-slate-400 font-mono text-xs select-none">▼</span>
                            <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold font-mono tracking-wider ${getDraftBadge(d.status)}">#${d.id} · ${esc(d.status)}</span>
                            <div class="min-w-0 truncate">
                                <span class="text-sm sm:text-base font-semibold text-slate-900 dark:text-white truncate block">
                                    ${esc(d.topic_name || d.prompt || "On-demand post")}
                                </span>
                                ${d.course_name ? `<span class="text-xs text-blue-600 dark:text-blue-400 font-mono">Module: ${esc(d.course_name)}</span>` : ""}
                            </div>
                        </div>
                        <div class="flex items-center gap-3 flex-shrink-0">
                            <span class="text-xs text-slate-500 font-mono hidden md:inline-block">${esc(d.scheduled_at_display || d.scheduled_at || d.created_at || "")}</span>
                            <button type="button" class="text-xs px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium hover:bg-blue-500 hover:text-white transition-colors" onclick="event.stopPropagation(); toggleDraft(${d.id})">
                                <span class="draft-toggle-text">${isCollapsed ? 'Expand ▾' : 'Collapse ▴'}</span>
                            </button>
                        </div>
                    </div>

                    <!-- Retractable Draft Body -->
                    <div class="draft-body border-t border-slate-200 dark:border-slate-800/80 p-4 sm:p-6 space-y-5 bg-slate-50/50 dark:bg-[#090e1a]/40" id="draft-body-${d.id}">
                        ${d.status === "FLAGGED_VIOLATION" ? `
                        <div class="p-4 rounded-xl border border-red-500/50 bg-red-950/40 text-red-200 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div class="flex items-start gap-3">
                                <span class="text-2xl flex-shrink-0 animate-bounce">⚠️</span>
                                <div>
                                    <h4 class="text-xs sm:text-sm font-bold text-red-100 flex items-center gap-2">
                                        <span>Brand Safety Guardrail Triggered</span>
                                        <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-500/20 text-red-300 border border-red-500/40 uppercase">Locked</span>
                                    </h4>
                                    <p class="text-[11px] text-red-300 mt-1 leading-relaxed">
                                        This draft contains administrator-prohibited PR terms or competitor references. Publishing, scheduling, and approvals are strictly prohibited until the violations are resolved.
                                    </p>
                                </div>
                            </div>
                            <button type="button" onclick="openDraftEditModal(${d.id})" class="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold shadow-md transition-all flex items-center gap-1.5 flex-shrink-0 self-start sm:self-auto">
                                <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                <span>Edit &amp; Clear Violations</span>
                            </button>
                        </div>` : ""}

                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
                            <!-- LinkedIn Post Preview -->
                            <section class="min-w-0 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 p-4 sm:p-5 flex flex-col shadow-inner">
                                <div class="flex justify-between items-center mb-3 pb-2 border-b border-slate-200 dark:border-slate-800">
                                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                                        <svg class="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                                        LinkedIn Post Preview
                                    </h3>
                                    <button onclick="navigator.clipboard?.writeText(document.getElementById('post-copy-${d.id}')?.innerText || '').then(()=>showToast('Post copied to clipboard!'))" class="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors">Copy</button>
                                </div>
                                <div class="post-markdown space-y-3 text-sm leading-relaxed text-slate-800 dark:text-slate-200 overflow-y-auto max-h-[500px] pr-2 custom-scrollbar" id="post-copy-${d.id}">
                                    ${renderMarkdown(d.body)}
                                </div>
                            </section>

                            <!-- Infographic Preview -->
                            <section class="min-w-0 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 p-4 sm:p-5 flex flex-col shadow-inner">
                                <div class="flex justify-between items-center mb-3 pb-2 border-b border-slate-200 dark:border-slate-800">
                                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">Infographic Preview</h3>
                                    <a class="draft-asset-link hidden text-xs text-sky-500 dark:text-sky-400 hover:underline flex items-center gap-1 font-semibold" href="#" onclick="openDraftAsset(${d.id});return false">
                                        <span>View Fullscreen</span>
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                    </a>
                                </div>
                                <div class="draft-asset-frame flex min-h-64 flex-1 items-center justify-center overflow-hidden rounded-lg bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-gray-800/80 p-2">
                                    <span class="draft-asset-placeholder p-8 text-center text-xs sm:text-sm text-slate-500">Generating Infographic...</span>
                                    <img class="draft-asset hidden max-h-[480px] w-full object-contain rounded" data-draft-id="${d.id}" alt="Generated infographic preview">
                                </div>
                            </section>
                        </div>

                        <!-- Actions Toolbar -->
                        <div class="flex flex-wrap items-center gap-2.5 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs sm:text-sm">
                            <button onclick="sendDraftEmail(${d.id})" class="px-3.5 py-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 dark:text-amber-400 border border-amber-500/30 font-semibold transition-colors flex items-center gap-1.5">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                                Send Email
                            </button>
                            <button onclick="openDraftEditModal(${d.id})" class="px-3.5 py-2 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30 font-semibold transition-colors flex items-center gap-1.5">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                Edit Post
                            </button>
                            ${d.status==="DRAFT" ? `
                            ${(() => {
                                const mcEnabled = window._makerCheckerEnabled === true;
                                const currentUserId = window.currentUser && window.currentUser.id;
                                const authorId = d.author_id;
                                const isSelfAuthored = mcEnabled && currentUserId && authorId && String(currentUserId) === String(authorId);
                                if (isSelfAuthored) {
                                    return `
                                    <div class="flex flex-col gap-1">
                                        <button disabled class="px-3.5 py-2 rounded-lg bg-slate-500/10 text-slate-400 border border-slate-500/30 font-semibold cursor-not-allowed flex items-center gap-1.5 opacity-70">
                                            🔒 Peer Approval Required
                                        </button>
                                        <span class="text-[10px] text-amber-500 font-mono px-1">Self-authored draft. Awaiting independent reviewer.</span>
                                    </div>`;
                                } else {
                                    return `<button onclick="approveDraft(${d.id})" class="px-3.5 py-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 font-semibold transition-colors flex items-center gap-1.5">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                        Approve
                                    </button>`;
                                }
                            })()} 
                            <button onclick="rejectDraft(${d.id})" class="px-3.5 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 border border-red-500/30 font-semibold transition-colors flex items-center gap-1.5">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                                Reject
                            </button>` : ""}

                            ${["DRAFT","APPROVED"].includes(d.status) ? `
                            <button onclick="scheduleDraft(${d.id})" class="px-3.5 py-2 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30 font-semibold transition-colors flex items-center gap-1.5">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                Schedule
                            </button>` : ""}
                            ${d.status==="APPROVED" ? `
                            <button onclick="rejectDraft(${d.id})" class="px-3.5 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 border border-red-500/30 font-semibold transition-colors">
                                Reject
                            </button>` : ""}
                            ${["DRAFT","APPROVED"].includes(d.status) ? `
                            <button onclick="postNow(${d.id})" class="px-3.5 py-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-600 dark:text-purple-400 border border-purple-500/30 font-semibold transition-colors flex items-center gap-1.5">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                                Post Now
                            </button>` : ""}
                        </div>
                    </div>
                </article>`;
            }).join("") || `<p class="p-8 text-center text-slate-500 bg-white dark:bg-[#0f172a] rounded-xl border border-slate-200 dark:border-gray-800">No ${view} posts recorded.</p>`}
            </div>
        </div>`;

        await Promise.all([...root.querySelectorAll(".draft-asset")].map(async image => {
            try {
                const response=await fetch(`/api/drafts/${image.dataset.draftId}/asset`);
                if(!response.ok) throw new Error(`Image response ${response.status}`);
                const imageUrl=URL.createObjectURL(await response.blob());
                image.onload=()=>{ image.classList.remove("hidden"); image.closest(".draft-asset-frame").querySelector(".draft-asset-placeholder").classList.add("hidden"); image.closest("section").querySelector(".draft-asset-link").classList.remove("hidden"); URL.revokeObjectURL(imageUrl); };
                image.onerror=()=>{ image.removeAttribute("src"); URL.revokeObjectURL(imageUrl); };
                image.src=imageUrl;
            } catch { /* Keep the accessible generating placeholder visible when no image is ready. */ }
        }));
    } catch(e) { root.innerHTML = `<div class="p-6 text-red-400">${esc(e.message)}</div>`; }
}

async function openDraftAsset(id) {
    const tab=window.open("about:blank","_blank");
    if (!tab) return showToast("Allow pop-ups to open the infographic in a new tab.","error");
    tab.opener=null;
    try {
        const response=await fetch(`/api/drafts/${id}/asset`);
        if(!response.ok) throw new Error(`Infographic unavailable (${response.status})`);
        const url=URL.createObjectURL(await response.blob());
        tab.location.href=url;
    } catch(error) { tab.close(); showToast(error.message,"error"); }
}
async function approveDraft(id) { try { await api(`/api/drafts/${id}/approve`, {method:"POST"}); showToast("Approved"); fetchDrafts("current"); fetchApprovalCount(); } catch(e) { showToast(e.message,"error"); } }
async function rejectDraft(id) { try { await api(`/api/drafts/${id}/reject`, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({reason:prompt("Reason") || ""})}); showToast("Rejected"); fetchDrafts("current"); fetchApprovalCount(); } catch(e) { showToast(e.message,"error"); } }
async function scheduleDraft(id) { const value = prompt("Future date/time in configured timezone (YYYY-MM-DDTHH:MM; an ISO-8601 offset is also accepted)"); if (!value) return; try { await api(`/api/drafts/${id}/schedule`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({scheduled_at:value})}); showToast("Scheduled (one post per day in the configured timezone)"); fetchDrafts("upcoming"); fetchPipeline(); fetchApprovalCount(); } catch(e) { showToast(e.message,"error"); } }

function openDraftEditModal(did) {
    const d = (window.allDraftsCache && window.allDraftsCache[did]) || null;
    const modal = document.getElementById("modal-edit-draft");
    if (!modal) return;
    
    const idEl = document.getElementById("edit-draft-id");
    if (idEl) idEl.value = did;
    const badge = document.getElementById("edit-draft-badge");
    if (badge) badge.textContent = `#${did} · ${d ? d.status : ''}`;
    
    let body = d ? (d.body || "") : "";
    body = body.replace(/^\[⚠️️?\s*BRAND SAFETY VIOLATION DETECTED:[^\]]+\]\s*\n\n/i, "");
    
    const textarea = document.getElementById("edit-draft-body");
    if (textarea) {
        textarea.value = body;
        textarea.oninput = updateDraftCharCount;
    }
    updateDraftCharCount();
    
    const warnBox = document.getElementById("edit-draft-warning-box");
    const warnText = document.getElementById("edit-draft-warning-text");
    if (d && d.status === "FLAGGED_VIOLATION") {
        if (warnBox) warnBox.classList.remove("hidden");
        const match = (d.body || "").match(/Contains terms:\s*([^\]]+)\]/i);
        if (warnText) {
            warnText.textContent = match ? `Contains flagged terms: "${match[1]}". Please edit out prohibited terms or competitor names to clear violation.` : "Contains prohibited terms or competitor mentions. Please edit the text to clear the violation.";
        }
    } else {
        if (warnBox) warnBox.classList.add("hidden");
    }
    
    modal.classList.remove("hidden");
}

function closeDraftEditModal() {
    const modal = document.getElementById("modal-edit-draft");
    if (modal) modal.classList.add("hidden");
}

function updateDraftCharCount() {
    const textarea = document.getElementById("edit-draft-body");
    const countEl = document.getElementById("edit-draft-char-count");
    if (textarea && countEl) {
        countEl.textContent = `${textarea.value.length} characters`;
    }
}

async function submitDraftEdit() {
    const did = document.getElementById("edit-draft-id")?.value;
    const body = document.getElementById("edit-draft-body")?.value;
    const btn = document.getElementById("btn-save-draft-edit");
    const origText = btn ? btn.innerHTML : "Save";
    if (btn) { btn.disabled = true; btn.innerHTML = "Validating..."; }
    
    try {
        const res = await api(`/api/drafts/${did}/edit`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ body })
        });
        
        if (res.is_violation) {
            showToast(`⚠️ Guardrails Alert: Still contains prohibited terms: ${res.violations.join(', ')}`, "warning");
            const warnBox = document.getElementById("edit-draft-warning-box");
            const warnText = document.getElementById("edit-draft-warning-text");
            if (warnBox) warnBox.classList.remove("hidden");
            if (warnText) warnText.textContent = `Still contains terms: "${res.violations.join(', ')}". Please remove them.`;
        } else {
            showToast("Draft updated! Brand safety violations cleared.", "success");
            closeDraftEditModal();
        }
        await fetchDrafts();
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = origText; }
    }
}

async function fetchOnDemandHistory() {
    const table = document.getElementById("ondemand-history-table"); if (!table) return;
    try {
        const [rows, settings] = await Promise.all([api("/api/ondemand/history"), api("/api/settings")]);
        // Sort descending so newest on-demand posts are on top
        rows.sort((a, b) => (Number(b.id) || 0) - (Number(a.id) || 0));
        table.innerHTML = rows.map(d => {
            const published = Object.fromEntries((d.social_publications || []).map(x => [x.platform, x]));
            const linkedInDone = published.linkedin?.status === "PUBLISHED";
            const xDone = published.x?.status === "PUBLISHED";
            const linkedInBusy = published.linkedin?.status === "PUBLISHING";
            const xBusy = published.x?.status === "PUBLISHING";
            const canPost = (settings.linkedin_session_configured === "true" && !linkedInDone && !linkedInBusy) ||
                (settings.x_configured === "true" && !xDone && !xBusy);
            const postLinks = (d.social_publications || []).filter(x => x.status === "PUBLISHED" && x.post_url)
                .map(x => `<a class="text-emerald-500 hover:underline" href="${esc(x.post_url)}" target="_blank" rel="noopener noreferrer">${esc(x.platform)} live</a>`).join(" · ");
            const postStates = (d.social_publications || []).map(x => `<span class="${x.status === "PUBLISHED" ? "text-emerald-500" : "text-red-400"}" title="${esc(x.error || "")}">${esc(x.platform)}: ${esc(x.status)}</span>`).join(" · ");
            return `<tr class="border-b border-slate-200 dark:border-gray-800/60 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                <td class="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">${esc(d.created_at)}</td>
                <td class="py-3 px-4">
                    <div class="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                        <span class="text-blue-500 font-mono text-xs">#${d.id}</span>
                        <span>${esc(d.topic_name || d.prompt || "On-demand post")}</span>
                    </div>
                    <div class="text-[10px] text-slate-400 font-mono uppercase mt-0.5">${esc(d.asset_type || "infographic")}</div>
                    ${postStates ? `<div class="mt-1 flex flex-wrap gap-1.5 text-[10px]">${postStates}</div>` : ""}
                    ${postLinks ? `<div class="mt-1 flex flex-wrap gap-1.5 text-[10px]">${postLinks}</div>` : ""}
                </td>
                <td class="py-3 px-3 whitespace-nowrap">
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono tracking-wider ${getDraftBadge(d.status)}">${esc(d.status)}</span>
                </td>
                <td class="py-3 px-4">
                    <div class="max-w-[150px] sm:max-w-[200px] truncate text-[11px] font-mono text-slate-500" title="${esc(d.artifact_path || d.asset_path || "")}">
                        ${esc(d.artifact_path || d.asset_path || "—")}
                    </div>
                </td>
                <td class="py-3 px-4 text-right whitespace-nowrap">
                    <div class="flex flex-col items-end gap-1.5">
                        <button onclick="sendDraftEmail(${d.id})" class="text-amber-500 hover:text-amber-400 font-semibold text-xs flex items-center gap-1 transition-colors">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                            Send email
                        </button>
                        <div class="flex items-center gap-2 text-[10px] text-slate-400">
                            <label class="flex items-center gap-1 cursor-pointer ${settings.linkedin_session_configured === "true" ? "" : "opacity-40"}">
                                <input type="checkbox" class="publish-platform-${d.id} rounded" value="linkedin" ${linkedInDone || linkedInBusy || settings.linkedin_session_configured !== "true" ? "disabled" : ""}>
                                <span>LinkedIn</span>
                            </label>
                            <label class="flex items-center gap-1 cursor-pointer ${settings.x_configured === "true" ? "" : "opacity-40"}">
                                <input type="checkbox" class="publish-platform-${d.id} rounded" value="x" ${xDone || xBusy || settings.x_configured !== "true" ? "disabled" : ""}>
                                <span>X</span>
                            </label>
                        </div>
                        <button onclick="publishHistoryDraft(${d.id})" class="rounded-lg bg-blue-600 hover:bg-blue-500 px-2.5 py-1 text-white text-xs font-semibold shadow-sm transition-colors disabled:opacity-40 disabled:cursor-not-allowed" ${canPost ? "" : "disabled"}>
                            Post selected
                        </button>
                    </div>
                </td>
            </tr>`;
        }).join("") || "<tr><td colspan='5' class='py-10 text-center text-slate-500'>No generated posts.</td></tr>";
    } catch(e) { showToast(e.message,"error"); }
}

async function publishHistoryDraft(id) {
    const platforms=[...document.querySelectorAll(`.publish-platform-${id}:checked`)].map(input=>input.value);
    if (!platforms.length) return showToast("Select at least one configured platform","error");
    try {
        const response=await api(`/api/drafts/${id}/publish`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({platforms})});
        const summary=response.results.map(result=>`${result.platform}: ${result.status}${result.error ? ` (${result.error})` : ""}`).join(" · ");
        const isDryRun = response.results.every(result => result.status === "dry_run" || result.status === "DRY_RUN");
        const hasFailed = response.results.some(result => result.status === "FAILED");
        showToast(summary, hasFailed ? "error" : (isDryRun ? "info" : "success"));
        fetchOnDemandHistory();
    } catch(e) { showToast(e.message,"error"); }
}
async function fetchLogs() { try { const rows = await api("/api/logs"), table = document.getElementById("logs-table"); if (table) table.innerHTML = rows.map(x => `<tr><td class="p-2">${esc(x.timestamp)}</td><td class="p-2">${esc(x.level)}</td><td class="p-2">${esc(x.module)}: ${esc(x.message)}</td></tr>`).join(""); } catch(e) { showToast(e.message,"error"); } }
function toggleSettingsAccordion(id) {
    const card = document.getElementById(id);
    if (!card) return;
    card.classList.toggle("collapsed");
}

async function saveSettingsSection(sectionFormId) {
    const form = document.getElementById(sectionFormId);
    if (!form) return;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Convert booleans / checkboxes if present in this section
    if (form.elements.enable_gemini_api !== undefined) {
        data.enable_gemini_api = form.elements.enable_gemini_api.checked;
    }
    if (form.elements.enable_local_llm !== undefined) {
        data.enable_local_llm = form.elements.enable_local_llm.checked;
    }
    if (form.elements.dry_run_mode !== undefined) {
        data.dry_run_mode = form.elements.dry_run_mode.checked ? "1" : "0";
    }
    if (form.elements.alert_on_draft_ready !== undefined) {
        data.alert_on_draft_ready = form.elements.alert_on_draft_ready.checked ? "1" : "0";
    }
    if (form.elements.alert_on_publish_success !== undefined) {
        data.alert_on_publish_success = form.elements.alert_on_publish_success.checked ? "1" : "0";
    }
    if (form.elements.alert_on_failure !== undefined) {
        data.alert_on_failure = form.elements.alert_on_failure.checked ? "1" : "0";
    }
    if (form.elements.enable_branding !== undefined) {
        data.enable_branding = form.elements.enable_branding.checked;
    }
    if (form.elements.dlp_enabled !== undefined) {
        data.dlp_enabled = form.elements.dlp_enabled.checked ? "1" : "0";
    }
    if (form.elements.brand_safety_enabled !== undefined) {
        data.brand_safety_enabled = form.elements.brand_safety_enabled.checked ? "1" : "0";
    }
    if (form.elements.sso_enabled !== undefined) {
        data.sso_enabled = form.elements.sso_enabled.checked ? "1" : "0";
    }
    if (form.elements.maker_checker_enabled !== undefined) {
        data.maker_checker_enabled = form.elements.maker_checker_enabled.checked ? "1" : "0";
    }
    if (form.elements.scim_enabled !== undefined) {
        data.scim_enabled = form.elements.scim_enabled.checked ? "1" : "0";
    }

    for (const k of [
        "gemini_api_key", "gemini_api_key_1", "gemini_api_key_2", "gemini_key",
        "openai_api_key", "deepseek_api_key", "mistral_api_key", "claude_api_key", "custom_ai_api_key",
        "smtp_app_password", "linkedin_access_token",
        "x_api_key", "x_api_secret", "x_access_token", "x_access_token_secret", "x_user_access_token",
        "sso_client_secret", "linkedin_client_secret", "x_bearer_token", "instagram_app_secret",
        "instagram_access_token", "youtube_client_secret", "youtube_refresh_token"
    ]) {
        if (data[k] !== undefined && (!data[k] || !data[k].trim())) {
            delete data[k];
        }
    }

    const btn = form.querySelector("button[type='submit']");
    const origText = btn ? btn.textContent : "Save";
    if (btn) { btn.disabled = true; btn.textContent = "Saving..."; }

    try {
        const socialSettingsForm = ["form-linkedin", "form-x", "form-instagram", "form-youtube"].includes(sectionFormId);
        await api(socialSettingsForm ? "/api/settings/social" : "/api/settings", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });
        showToast("Settings section saved successfully", "success");
        window.dispatchEvent(new Event("postall:settings-updated"));
        await fetchSettings();
        if (typeof fetchAutopilotStatus === "function") fetchAutopilotStatus();
        if (typeof fetchPipeline === "function") fetchPipeline();
        if (typeof fetchDrafts === "function") fetchDrafts("current");
        if (typeof fetchOnDemandHistory === "function") fetchOnDemandHistory();
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = origText; }
    }
}

async function testWebhooks() {
    const btn = document.getElementById("webhook-test-btn");
    const origText = btn ? btn.textContent : "Send Test Webhook";
    if (btn) { btn.disabled = true; btn.textContent = "Sending Test..."; }

    const form = document.getElementById("form-alerts");
    const slackUrl = form ? (form.elements.slack_webhook_url ? form.elements.slack_webhook_url.value.trim() : "") : "";
    const teamsUrl = form ? (form.elements.teams_webhook_url ? form.elements.teams_webhook_url.value.trim() : "") : "";

    try {
        const res = await api("/api/settings/test-webhooks", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                slack_webhook_url: slackUrl,
                teams_webhook_url: teamsUrl
            })
        });
        const r = res.results || {};
        let msgs = [];
        if (r.slack && r.slack.status !== "not_configured") {
            msgs.push(`Slack: ${r.slack.message}`);
        }
        if (r.teams && r.teams.status !== "not_configured") {
            msgs.push(`Teams: ${r.teams.message}`);
        }
        if (msgs.length > 0) {
            showToast(msgs.join(" | "), "info");
        } else {
            showToast("No webhook URLs configured to test.", "warning");
        }
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = origText; }
    }
}


async function testGeminiKeys() {
    const btn = document.getElementById("test-gemini-keys-btn");
    const container = document.getElementById("gemini-keys-test-results");
    if (btn) { btn.disabled = true; btn.textContent = "Testing Keys..."; }
    if (container) {
        container.innerHTML = `<div class="p-2 rounded bg-indigo-500/10 text-xs text-indigo-400 border border-indigo-500/20 flex items-center gap-2">
            <svg class="animate-spin h-3.5 w-3.5 text-indigo-400" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
            <span>Verifying key quotas against Google Generative Language API...</span>
        </div>`;
    }
    try {
        const res = await api("/api/settings/test-gemini-keys", { method: "POST" });
        const results = res.results || {};
        if (container) {
            const slots = [
                { id: "primary", name: "Primary Key" },
                { id: "secondary", name: "Secondary Key (Fallback 1)" },
                { id: "tertiary", name: "Tertiary Key (Fallback 2)" }
            ];
            container.innerHTML = slots.map(slot => {
                const info = results[slot.id] || { status: "unknown", message: "No response" };
                let badgeClass = "bg-slate-700 text-slate-300";
                if (info.status === "active") badgeClass = "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30";
                else if (info.status === "exhausted") badgeClass = "bg-amber-500/10 text-amber-400 border border-amber-500/30";
                else if (info.status === "invalid" || info.status === "error") badgeClass = "bg-rose-500/10 text-rose-400 border border-rose-500/30";
                else if (info.status === "not_configured") badgeClass = "bg-slate-800 text-slate-400 border border-slate-700";
                return `<div class="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-xs">
                    <span class="font-medium text-slate-300">${slot.name}</span>
                    <span class="px-2 py-0.5 rounded text-[11px] font-mono ${badgeClass}">${esc(info.message || info.status)}</span>
                </div>`;
            }).join("");
        }
        showToast("Gemini key status updated", "success");
    } catch(err) {
        showToast(err.message, "error");
        if (container) container.innerHTML = `<span class="text-xs text-rose-400">${esc(err.message)}</span>`;
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = "Test Gemini Keys"; }
    }
}

function updatePersonaPreview(val) {
    const badge = document.getElementById("persona-badge-preview");
    const desc = document.getElementById("persona-description-preview");
    if (!badge || !desc) return;
    if (val === "media_agency") {
        badge.textContent = "HIGH-GROWTH MEDIA";
        desc.textContent = "High-converting hooks, conversational storytelling, industry trends, counter-intuitive insights, and high-CTR visual banners.";
    } else if (val === "b2b_enterprise") {
        badge.textContent = "ENTERPRISE STRATEGY";
        desc.textContent = "Business ROI, compliance, enterprise resilience, Total Cost of Ownership (TCO), and architectural versus comparisons.";
    } else if (val === "custom") {
        badge.textContent = "NEUTRAL EXPERT";
        desc.textContent = "Balanced, professional, and clear technical communication without strong stylistic bias.";
    } else {
        badge.textContent = "EDUCATION & CERTIFICATION";
        desc.textContent = "Technical cheat sheets, certification exam objectives, architecture deep dives, CLI command syntax, and production runbooks.";
    }
}

function updateProviderFields(provider) {
    const blocks = ["gemini", "openai", "deepseek", "mistral", "claude", "custom", "local"];
    blocks.forEach(p => {
        const el = document.getElementById(`provider-block-${p}`);
        if (el) {
            if (p === provider) {
                el.classList.remove("hidden");
            } else {
                el.classList.add("hidden");
            }
        }
    });
}

async function testActiveProvider() {
    const btn = document.getElementById("test-provider-btn");
    const container = document.getElementById("provider-test-results");
    const providerSelect = document.getElementById("ai_provider_select");
    const provider = providerSelect ? providerSelect.value : "gemini";

    let apiKey = "";
    let baseUrl = "";
    let model = "";

    const getVal = (name) => {
        const inp = document.querySelector(`input[name="${name}"]`);
        return inp ? inp.value.trim() : "";
    };

    if (provider === "gemini") {
        apiKey = getVal("gemini_api_key");
        model = document.getElementById("ai_primary_model_select")?.value || "";
    } else if (provider === "openai") {
        apiKey = getVal("openai_api_key");
        baseUrl = getVal("openai_base_url");
        model = getVal("openai_model");
    } else if (provider === "deepseek") {
        apiKey = getVal("deepseek_api_key");
        baseUrl = getVal("deepseek_base_url");
        model = getVal("deepseek_model");
    } else if (provider === "mistral") {
        apiKey = getVal("mistral_api_key");
        baseUrl = getVal("mistral_base_url");
        model = getVal("mistral_model");
    } else if (provider === "claude") {
        apiKey = getVal("claude_api_key");
        model = getVal("claude_model");
    } else if (provider === "custom") {
        apiKey = getVal("custom_ai_api_key");
        baseUrl = getVal("custom_ai_base_url");
        model = getVal("custom_ai_model");
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<svg class="animate-spin h-3.5 w-3.5 text-white inline-block mr-1" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg> Testing ${esc(provider.toUpperCase())}...`;
    }
    if (container) {
        container.innerHTML = `<div class="p-2.5 rounded-lg bg-indigo-500/10 text-xs text-indigo-400 border border-indigo-500/20 flex items-center gap-2">
            <svg class="animate-spin h-3.5 w-3.5 text-indigo-400" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
            <span>Pinging ${esc(provider.toUpperCase())} API endpoint and measuring latency...</span>
        </div>`;
    }

    try {
        const payload = {
            provider: provider,
            api_key: apiKey || null,
            base_url: baseUrl || null,
            model: model || null
        };
        const res = await api("/api/ai/test-provider", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (container) {
            const isOk = res.status === "active" || res.status === "success";
            const badgeClass = isOk ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30" : "bg-rose-500/10 text-rose-400 border border-rose-500/30";
            const latencyStr = res.latency_ms !== undefined ? ` (${res.latency_ms} ms)` : "";
            const sample = res.sample_response || res.ping_response || "";
            container.innerHTML = `<div class="p-3 rounded-lg bg-slate-900/80 border border-slate-800 space-y-1 text-xs">
                <div class="flex items-center justify-between">
                    <span class="font-bold text-slate-200 uppercase tracking-wider">${esc(res.provider || provider)} Verification</span>
                    <span class="px-2 py-0.5 rounded text-[11px] font-mono ${badgeClass}">${esc(res.status ? res.status.toUpperCase() : "RESULT")}${esc(latencyStr)}</span>
                </div>
                <p class="text-slate-400 text-[11px]">${esc(res.message || "Connection test completed.")}</p>
                ${sample ? `<div class="mt-1 p-2 rounded bg-slate-950 font-mono text-[10px] text-slate-400 overflow-x-auto">Sample: ${esc(sample)}</div>` : ""}
            </div>`;
        }
        if (res.status === "active" || res.status === "success") {
            showToast(`${provider.toUpperCase()} provider connected successfully!`, "success");
        } else {
            showToast(res.message || `${provider.toUpperCase()} verification failed`, "error");
        }
    } catch (err) {
        if (container) {
            container.innerHTML = `<div class="p-2.5 rounded-lg bg-rose-500/10 text-xs text-rose-400 border border-rose-500/20">
                <strong>Error:</strong> ${esc(err.message)}
            </div>`;
        }
        showToast(err.message, "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg><span>Test Provider Connection</span>`;
        }
    }
}

function toggleHowToItem(id) {
    const body = document.getElementById(`${id}-body`);
    const chevron = document.getElementById(`${id}-chevron`);
    if (!body) return;
    const isHidden = body.classList.contains("hidden");
    if (isHidden) {
        body.classList.remove("hidden");
        if (chevron) chevron.classList.add("rotate-180");
    } else {
        body.classList.add("hidden");
        if (chevron) chevron.classList.remove("rotate-180");
    }
}

function toggleAllHowToCards() {
    const btn = document.getElementById("howto-toggle-all-btn");
    const cards = ["howto-1", "howto-2", "howto-3", "howto-4", "howto-5", "howto-6"];
    const anyHidden = cards.some(id => {
        const b = document.getElementById(`${id}-body`);
        return b && b.classList.contains("hidden");
    });

    cards.forEach(id => {
        const body = document.getElementById(`${id}-body`);
        const chevron = document.getElementById(`${id}-chevron`);
        if (body) {
            if (anyHidden) {
                body.classList.remove("hidden");
                if (chevron) chevron.classList.add("rotate-180");
            } else {
                body.classList.add("hidden");
                if (chevron) chevron.classList.remove("rotate-180");
            }
        }
    });

    if (btn) {
        btn.textContent = anyHidden ? "Collapse All Guides" : "Expand All Guides";
    }
}

async function downloadDbBackup() {
    try {
        const token = localStorage.getItem("token") || sessionStorage.getItem("token");
        const res = await fetch("/api/settings/backup-db", {
            headers: token ? { "Authorization": `Bearer ${token}` } : {}
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ detail: "Backup failed" }));
            throw new Error(err.detail || "Database backup failed");
        }
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        const now = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        a.download = `postall_backup_${now}.db`;
        document.body.appendChild(a);
        a.click();
        window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
        a.remove();
        showToast("Database backup downloaded successfully", "success");
    } catch(err) {
        showToast(err.message, "error");
    }
}

async function downloadFullBackup() {
    const btn = document.getElementById("download-backup-btn");
    const origText = btn ? btn.innerHTML : "Download ZIP Archive";
    if (btn) { btn.disabled = true; btn.innerHTML = "<span>Packaging ZIP Archive...</span>"; }
    try {
        showToast("Packaging complete SQLite database and post assets...", "info");
        const token = localStorage.getItem("token") || sessionStorage.getItem("token") || localStorage.getItem("vanguard_token");
        const res = await fetch("/api/maintenance/backup", {
            headers: token ? { "Authorization": `Bearer ${token}` } : {}
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ detail: "Backup archive generation failed" }));
            throw new Error(err.detail || "Backup failed");
        }
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        const now = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        a.download = `postall_full_backup_${now}.zip`;
        document.body.appendChild(a);
        a.click();
        window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
        a.remove();
        showToast("Full backup archive downloaded successfully!", "success");
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = origText; }
    }
}

async function submitRestoreBackup(event) {
    event.preventDefault();
    const fileInput = document.getElementById("restore-zip-file");
    if (!fileInput || !fileInput.files.length) {
        return showToast("Please select a valid ZIP backup archive (.zip)", "error");
    }
    const file = fileInput.files[0];
    if (!file.name.toLowerCase().endsWith(".zip")) {
        return showToast("Only .zip backup archives are accepted.", "error");
    }
    const confirmed = confirm(
        "CRITICAL WARNING:\n\nRestoring will OVERWRITE the active SQLite database (postall.db) and replace post assets.\n\nAre you sure you want to proceed?"
    );
    if (!confirmed) return;

    const btn = document.getElementById("restore-upload-btn");
    const origText = btn ? btn.innerHTML : "Upload &amp; Restore";
    if (btn) { btn.disabled = true; btn.innerHTML = "<span>Restoring &amp; Re-initializing...</span>"; }

    const formData = new FormData();
    formData.append("file", file);

    try {
        const token = localStorage.getItem("token") || sessionStorage.getItem("token") || localStorage.getItem("vanguard_token");
        const res = await fetch("/api/maintenance/restore", {
            method: "POST",
            headers: token ? { "Authorization": `Bearer ${token}` } : {},
            body: formData
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ detail: "Full restore failed" }));
            throw new Error(err.detail || "Restore failed");
        }
        const data = await res.json();
        showToast(data.message || "Database and post assets restored successfully! Reloading in 3s...", "success");
        setTimeout(() => location.reload(), 3000);
    } catch(err) {
        showToast(err.message, "error");
        if (btn) { btn.disabled = false; btn.innerHTML = origText; }
    }
}

async function requestPurgeOtp() {
    const btn = document.getElementById("request-purge-otp-btn");
    const origText = btn ? btn.innerHTML : "Send 6-Digit OTP";
    if (btn) { btn.disabled = true; btn.innerHTML = "<span>Sending OTP...</span>"; }

    try {
        const res = await api("/api/maintenance/request-purge", { method: "POST" });
        if (res.dev_otp) {
            showToast(`OTP Code: ${res.dev_otp} (SMTP offline)`, "info");
            const otpInput = document.getElementById("purge-otp");
            if (otpInput) {
                otpInput.value = res.dev_otp;
                otpInput.focus();
            }
            alert(`Factory Reset OTP Code:\n\n${res.dev_otp}\n\n(SMTP is not configured, code auto-filled for verification)`);
        } else {
            showToast(res.message || "6-digit OTP dispatched to admin email.", "info");
            const otpInput = document.getElementById("purge-otp");
            if (otpInput) otpInput.focus();
        }
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = origText; }
    }
}

async function submitExecutePurge(event) {
    event.preventDefault();
    const password = document.getElementById("purge-password")?.value || "";
    const otp = document.getElementById("purge-otp")?.value?.trim() || "";
    const confirmText = document.getElementById("purge-confirm-text")?.value?.trim() || "";

    if (!password && !otp && confirmText.toUpperCase() !== "CONFIRM-RESET") {
        return alert("Security Authorization Required:\n\nPlease enter either:\n1. Your Admin Password\n2. The 6-digit email OTP\n3. Or type CONFIRM-RESET in the confirmation box.");
    }

    const confirmed = confirm(
        "⚠️ FINAL WARNING - FACTORY RESET ⚠️\n\n" +
        "This will PERMANENTLY ERASE all database records:\n" +
        "• All Courses, Topics, and Syllabi\n" +
        "• All Drafts and Scheduled Queue Posts\n" +
        "• All Social Publications and Logs\n" +
        "• All Post Artifacts and Generated Graphics\n\n" +
        "Default administrator credentials will be restored (admin / admin).\n\n" +
        "Click OK to permanently wipe and reset the system."
    );
    if (!confirmed) return;

    const btn = document.getElementById("execute-purge-btn");
    const origText = btn ? btn.innerHTML : "Purge All &amp; Factory Reset";
    if (btn) { btn.disabled = true; btn.innerHTML = "<span>Wiping Database &amp; Assets...</span>"; }

    try {
        const res = await api("/api/maintenance/execute-purge", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ password, otp, confirm_text: confirmText })
        });
        alert(res.message || "Factory reset complete! All data has been purged. Redirecting to login...");
        terminateSession();
    } catch(err) {
        alert("Factory Reset Aborted:\n\n" + err.message);
        if (btn) { btn.disabled = false; btn.innerHTML = origText; }
    }
}

let promoBannerObjectUrl = null;

async function submitPromoAd(event) {
    if (event) event.preventDefault();
    const objective = document.getElementById("promo-objective")?.value || "";
    const campaignName = document.getElementById("promo-campaign-name")?.value.trim() || "";
    const brand = document.getElementById("promo-brand")?.value.trim() || "";
    const audience = document.getElementById("promo-audience")?.value.trim() || "";
    const dates = document.getElementById("promo-dates")?.value.trim() || "";
    const context = document.getElementById("promo-context")?.value.trim() || "";
    const callToAction = document.getElementById("promo-cta")?.value || "Learn more";
    const logoInput = document.getElementById("promo-logo");
    const logoFile = (logoInput && logoInput.files.length) ? logoInput.files[0] : null;

    if (!objective || !campaignName || !brand || !audience || !context) {
        return showToast("Please fill in all required campaign fields.", "error");
    }
    if (logoFile && logoFile.size > 2 * 1024 * 1024) return showToast("Campaign logo must be smaller than 2 MB.", "error");

    const submitBtn = document.getElementById("btn-launch-promo") || document.getElementById("promo-submit-btn") || document.querySelector("#tab-promo button[type='submit']");
    const statusBadge = document.getElementById("promo-status-badge");

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span>Synthesizing Copy & Graphic...</span>`;
    }
    if (statusBadge) {
        statusBadge.textContent = "SYNTHESIZING (0 TOKENS)...";
        statusBadge.className = "px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30";
    }
    if (promoBannerObjectUrl) URL.revokeObjectURL(promoBannerObjectUrl);
    promoBannerObjectUrl = null;
    document.getElementById("promo-preview-img")?.removeAttribute("src");
    const promoDownload = document.getElementById("promo-download-link");
    if (promoDownload) promoDownload.href = "#";

    try {
        const logoDataUrl = logoFile ? await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onerror = () => reject(new Error("Could not read the selected campaign logo."));
            reader.onload = () => resolve(String(reader.result || ""));
            reader.readAsDataURL(logoFile);
        }) : null;
        const res = await api("/api/campaigns/generate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                campaign_name: campaignName,
                campaign_type: objective,
                brand_name: brand,
                target_audience: audience,
                key_dates: dates,
                context,
                call_to_action: callToAction,
                logo_data_url: logoDataUrl
            })
        });
        if (res.status === "success" || res.draft_id) {
            showToast("Multi-channel campaign package generated and saved.", "success");
            if (statusBadge) {
                statusBadge.textContent = `DRAFT #${res.draft_id} READY`;
                statusBadge.className = "px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30";
            }
            // Unhide preview container
            const emptyPlaceholder = document.getElementById("promo-empty-state");
            const previewCard = document.getElementById("promo-preview-content");
            if (emptyPlaceholder) emptyPlaceholder.classList.add("hidden");
            if (previewCard) {
                previewCard.classList.remove("hidden");
                const titleElem = document.getElementById("promo-preview-title");
                if (titleElem) titleElem.textContent = campaignName || brand || "Promotional Campaign";
                const copyElem = document.getElementById("promo-preview-copy");
                if (copyElem) copyElem.textContent = res.linkedin_post || res.post_body || res.body || "";
                const xThread = document.getElementById("promo-x-thread");
                if (xThread) xThread.textContent = (res.x_thread || []).map((post, index) => `${index + 1}/3 · ${post}`).join("\n\n");
                const instagramSlides = document.getElementById("promo-instagram-slides");
                if (instagramSlides) instagramSlides.textContent = (res.instagram_slides || []).map((slide, index) => `SLIDE ${index + 1}\n${slide}`).join("\n\n");
                const youtubeScript = document.getElementById("promo-youtube-script");
                if (youtubeScript) youtubeScript.textContent = `${res.youtube_shorts_hook || ""}\n\n${res.youtube_shorts_script || ""}`.trim();
                const youtubeCommunity = document.getElementById("promo-youtube-community");
                if (youtubeCommunity) youtubeCommunity.textContent = res.youtube_community_post || "";
                const hashtags = document.getElementById("promo-hashtags");
                if (hashtags) hashtags.textContent = (res.hashtags || []).join(" ");
                const imgElem = document.getElementById("promo-preview-img");
                if (imgElem) {
                    const token = localStorage.getItem("token") || sessionStorage.getItem("token") || localStorage.getItem("vanguard_token") || "";
                    try {
                        const response = await fetch(res.banner_url, {
                            headers: {
                                "Authorization": token ? `Bearer ${token}` : "",
                                "X-Workspace-Id": getActiveWorkspaceId()
                            }
                        });
                        if (!response.ok) throw new Error(`HTTP ${response.status}`);
                        if (promoBannerObjectUrl) URL.revokeObjectURL(promoBannerObjectUrl);
                        promoBannerObjectUrl = URL.createObjectURL(await response.blob());
                        imgElem.src = promoBannerObjectUrl;
                    } catch (previewError) {
                        showToast(`Campaign package saved, but banner preview failed: ${previewError.message}`, "warning");
                    }
                }
                const dlLink = document.getElementById("promo-download-link");
                if (dlLink && promoBannerObjectUrl) {
                    dlLink.href = promoBannerObjectUrl;
                }
            }
        } else {
            showToast(res.message || "Failed to generate promo", "error");
        }
    } catch (err) {
        console.error("Promo error:", err);
        showToast("Promo generation error: " + err.message, "error");
        if (statusBadge) {
            statusBadge.textContent = "FAILED";
            statusBadge.className = "px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30";
        }
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `<span>⚡ Generate Multi-Channel Campaign</span>`;
        }
    }
}

async function clearSyllabusCache() {
    if (!confirm("Are you sure you want to clear the course syllabus cache? This will cause future post generations to perform fresh web searches.")) return;
    try {
        const res = await api("/api/settings/clear-cache", { method: "POST" });
        showToast(res.message || "Syllabus cache cleared", "success");
    } catch(err) {
        showToast(err.message, "error");
    }
}

async function pruneAuditLogs() {
    const daysSelect = document.getElementById("prune-days-select");
    const days = parseInt(daysSelect ? daysSelect.value : "30", 10) || 30;
    if (!confirm(`Are you sure you want to permanently delete system logs older than ${days} days?`)) return;
    try {
        const res = await api("/api/settings/prune-logs", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ days })
        });
        showToast(res.message || "Audit logs pruned", "success");
        if (typeof fetchLogs === "function") fetchLogs();
    } catch(err) {
        showToast(err.message, "error");
    }
}

async function changeAdminPassword(event) {
    event.preventDefault();
    const curr = document.getElementById("admin-curr-password")?.value || "";
    const newP = document.getElementById("admin-new-password")?.value || "";
    const confP = document.getElementById("admin-conf-password")?.value || "";

    if (!curr) return showToast("Current password is required", "error");
    if (!newP || newP.length < 8) return showToast("New password must be at least 8 characters", "error");
    if (newP !== confP) return showToast("New passwords do not match", "error");

    const btn = document.getElementById("change-password-btn");
    if (btn) { btn.disabled = true; btn.textContent = "Updating..."; }

    try {
        await api("/api/auth/password", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ current_password: curr, new_password: newP })
        });
        showToast("Admin password changed successfully", "success");
        document.getElementById("admin-password-form").reset();
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = "Update Password"; }
    }
}

async function updateSettings(event) {
    event.preventDefault();
    const form=event.target,data=Object.fromEntries(new FormData(form).entries());
    if (form.elements.enable_gemini_api !== undefined) data.enable_gemini_api=form.elements.enable_gemini_api.checked;
    if (form.elements.enable_local_llm !== undefined) data.enable_local_llm=form.elements.enable_local_llm.checked;
    if (form.elements.dry_run_mode !== undefined) data.dry_run_mode=form.elements.dry_run_mode.checked ? "1" : "0";
    if (form.elements.alert_on_draft_ready !== undefined) data.alert_on_draft_ready = form.elements.alert_on_draft_ready.checked ? "1" : "0";
    if (form.elements.alert_on_publish_success !== undefined) data.alert_on_publish_success = form.elements.alert_on_publish_success.checked ? "1" : "0";
    if (form.elements.alert_on_failure !== undefined) data.alert_on_failure = form.elements.alert_on_failure.checked ? "1" : "0";
    
    // Do not transmit empty secret strings (keeps saved secrets in DB intact)
    for (const k of ["gemini_api_key", "gemini_api_key_1", "gemini_api_key_2", "gemini_key", "smtp_app_password", "linkedin_access_token", "x_api_key", "x_api_secret", "x_access_token", "x_access_token_secret", "x_user_access_token"]) {
        if (!data[k] || !data[k].trim()) delete data[k];
    }
    
    try {
        await api("/api/settings",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
        showToast("Settings saved successfully", "success");
        window.dispatchEvent(new Event("postall:settings-updated"));
        fetchSettings();
        fetchOnDemandHistory();
    } catch(error) { showToast(error.message,"error"); }
}

let currentSettingsTab = localStorage.getItem("postall_v4_settings_tab") || "scheduling";

function switchSettingsCategory(catId) {
    currentSettingsTab = catId;
    localStorage.setItem("postall_v4_settings_tab", catId);
    fetchSettings();
}


// =====================================================================
// Postall_V4 CONTENT OPERATIONS KPIS & KNOWLEDGE BASE SEARCH
// =====================================================================
async function fetchContentKpis() {
    try {
        // 1. Drafts Pending Approval
        try {
            const drafts = await api("/api/posts?view=current");
            const pendingCount = (drafts || []).filter(d => 
                d.status === "READY_FOR_APPROVAL" || d.status === "DRAFT" || d.status === "PENDING"
            ).length;
            const el = document.getElementById("cc-kpi-pending-drafts");
            if (el) el.textContent = pendingCount;
        } catch {
            const el = document.getElementById("cc-kpi-pending-drafts");
            if (el) el.textContent = "0";
        }

        // 2. Posts Scheduled
        try {
            const upcoming = await api("/api/posts?view=upcoming");
            const el = document.getElementById("cc-kpi-scheduled-posts");
            if (el) el.textContent = (upcoming || []).length;
        } catch {
            const el = document.getElementById("cc-kpi-scheduled-posts");
            if (el) el.textContent = "0";
        }

        // 3. Active Workspace
        try {
            const el = document.getElementById("cc-kpi-workspace");
            const elSub = document.getElementById("cc-kpi-workspace-sub");
            const currentWs = window.currentWorkspace?.name || localStorage.getItem("postall_v4_active_workspace_name") || "Default Workspace";
            if (el) el.textContent = currentWs;
            if (elSub) elSub.textContent = `ID #${window.currentWorkspace?.id || 1} · Role: ${window.currentUser?.role || "Admin"}`;
        } catch {
            const el = document.getElementById("cc-kpi-workspace");
            if (el) el.textContent = "Default Partition";
        }

        // 4. Next Publish Departure
        try {
            const settings = await api("/api/settings");
            const el = document.getElementById("cc-kpi-next-publish");
            const elSub = document.getElementById("cc-kpi-next-publish-sub");
            if (el && settings.post_time) {
                const tz = settings.timezone ? settings.timezone.split("/").pop().replace("_", " ") : "IST";
                el.textContent = `${settings.post_time} ${tz}`;
            }
            if (elSub && settings.cadence_mode) {
                elSub.textContent = `Cadence: ${settings.cadence_mode.toUpperCase()}`;
            }
        } catch {}
    } catch (e) {
        console.warn("Content KPIs load error:", e);
    }
}

window.navigateToSetting = function(tabId, settingsTarget) {
    switchTab(tabId);
    if (settingsTarget) {
        setTimeout(() => {
            const btn = document.querySelector(`[data-settings-target="${settingsTarget}"]`);
            if (btn) btn.click();
        }, 50);
    }
};

function initKbSearch() {
    const input = document.getElementById("kb-search-input");
    const nav = document.getElementById("kb-navigation");
    const cards = [...document.querySelectorAll(".kb-article-card")];
    if (!cards.length || !nav) return;

    if (!nav.dataset.initialized) {
        nav.replaceChildren();
        cards.forEach((card, index) => {
            const pageId = `runbook-${index + 1}`;
            card.dataset.docPage = pageId;
            const button = document.createElement("button");
            button.type = "button";
            button.className = "doc-nav-btn";
            button.dataset.docPage = pageId;
            button.textContent = card.querySelector("h3")?.textContent?.trim() || `Runbook ${index + 1}`;
            button.addEventListener("click", () => window.switchDocPage(pageId));
            nav.appendChild(button);
        });
        nav.dataset.initialized = "true";
    }

    const applySearch = () => {
        const query = (input?.value || "").toLowerCase().trim();
        const buttons = [...nav.querySelectorAll(".doc-nav-btn")];
        const matches = [];
        buttons.forEach(button => {
            const card = cards.find(item => item.dataset.docPage === button.dataset.docPage);
            const matchesQuery = !query || (card?.textContent || "").toLowerCase().includes(query);
            button.classList.toggle("hidden", !matchesQuery);
            if (matchesQuery) matches.push(button.dataset.docPage);
        });

        const counter = document.getElementById("kb-results-counter");
        if (counter) counter.textContent = query ? `${matches.length} of ${cards.length} Runbooks` : `${cards.length} Runbooks Indexed`;

        const noResults = document.getElementById("kb-no-results");
        if (noResults) noResults.classList.toggle("hidden", matches.length > 0);
        const activeCard = cards.find(card => card.dataset.docPage === activeKbPage);
        const currentPageVisible = matches.includes(activeKbPage) && activeCard && !activeCard.classList.contains("hidden");
        if (matches.length && !currentPageVisible) window.switchDocPage(matches[0]);
        if (!matches.length) cards.forEach(card => card.classList.add("hidden"));
    };

    if (input && !input._kbSearchBound) {
        input._kbSearchBound = true;
        input.addEventListener("input", applySearch);
    }
    applySearch();
    if (!activeKbPage) window.switchDocPage(cards[0].dataset.docPage);
}

let activeKbPage = null;
window.switchDocPage = function(pageId) {
    const cards = [...document.querySelectorAll(".kb-article-card")];
    const target = cards.find(card => card.dataset.docPage === pageId);
    if (!target) return;

    activeKbPage = pageId;
    cards.forEach(card => {
        const active = card === target;
        card.classList.toggle("hidden", !active);
        card.classList.remove("doc-page-enter");
        if (active) {
            void card.offsetWidth;
            card.classList.add("doc-page-enter");
        }
    });
    document.querySelectorAll("#kb-navigation .doc-nav-btn").forEach(button => {
        const active = button.dataset.docPage === pageId;
        button.classList.toggle("active", active);
        button.setAttribute("aria-current", active ? "page" : "false");
    });
    const noResults = document.getElementById("kb-no-results");
    if (noResults) noResults.classList.add("hidden");
};

function rebalanceCommandCenterHealth() {
    const grid = document.getElementById("command-center-health-grid");
    if (!grid) return;
    const telemetry = [...grid.querySelectorAll("section")].find(section =>
        section.querySelector("h2")?.textContent.includes("Social Engagement & Closed-Loop Telemetry")
    );
    if (telemetry && telemetry.parentElement !== grid) {
        telemetry.classList.add("lg:col-span-12");
        grid.appendChild(telemetry);
    }
}

function initSettingsNavigation() {
    const navBtns = document.querySelectorAll(".settings-nav-btn");
    const viewport = document.getElementById("settings-viewport");
    if (!navBtns.length || !viewport) return;

    navBtns.forEach(btn => {
        btn.onclick = () => {
            const targetId = btn.dataset.settingsTarget;
            if (!targetId) return;

            navBtns.forEach(b => {
                b.classList.remove("active", "text-slate-300", "bg-slate-800");
                b.classList.add("text-slate-400");
            });
            btn.classList.add("active", "text-slate-300", "bg-slate-800");
            btn.classList.remove("text-slate-400");

            viewport.querySelectorAll(".settings-panel").forEach(p => p.classList.add("hidden"));
            const target = document.getElementById(targetId);
            if (target) {
                target.classList.remove("hidden");
            }
            localStorage.setItem("postall_v4_settings_target", targetId);
        };
    });

    const saved = localStorage.getItem("postall_v4_settings_target") || "sec-scheduling";
    const targetBtn = document.querySelector(`.settings-nav-btn[data-settings-target="${saved}"]`) || navBtns[0];
    if (targetBtn) {
        navBtns.forEach(b => {
            b.classList.remove("active", "text-slate-300", "bg-slate-800");
            b.classList.add("text-slate-400");
        });
        targetBtn.classList.add("active", "text-slate-300", "bg-slate-800");
        targetBtn.classList.remove("text-slate-400");

        viewport.querySelectorAll(".settings-panel").forEach(p => p.classList.add("hidden"));
        const target = document.getElementById(targetBtn.dataset.settingsTarget);
        if (target) target.classList.remove("hidden");
    }
}


async function fetchSettings() {
    try {
        const settings = await api("/api/settings");
        // Expose maker-checker state globally so approval queue renders correctly
        window._makerCheckerEnabled = (settings.maker_checker_enabled === "1" || settings.maker_checker_enabled === true);

        // Initialize sub-navigation routing
        initSettingsNavigation();

        // Populate all forms inside #settings-viewport
        const formIds = [
            "form-scheduling",
            "form-ai",
            "form-identity",
            "form-linkedin",
            "form-x",
            "form-instagram",
            "form-youtube",
            "form-smtp",
            "form-alerts",
            "form-guardrails",
            "form-branding",
            "form-storage"
        ];

        formIds.forEach(fid => {
            const form = document.getElementById(fid);
            if (!form) return;
            for (const [key, val] of Object.entries(settings)) {
                const el = form.elements[key];
                if (!el) continue;
                if (el.type === "checkbox") {
                    el.checked = (val === "1" || val === 1 || val === true || val === "true");
                } else if (el.type !== "file" && el.type !== "password") {
                    if (val !== undefined && val !== null) {
                        el.value = val;
                    }
                } else if (el.type === "password") {
                    const configured = {
                        linkedin_access_token: settings.has_linkedin_access_token,
                        linkedin_client_secret: settings.has_linkedin_client_secret,
                        x_api_key: settings.has_x_api_key,
                        x_api_secret: settings.has_x_api_secret,
                        x_access_token: settings.has_x_access_token,
                        x_access_token_secret: settings.has_x_access_token_secret,
                        x_bearer_token: settings.has_x_user_access_token,
                        instagram_access_token: settings.has_instagram_access_token,
                        instagram_app_secret: settings.has_instagram_app_secret,
                        youtube_client_secret: settings.has_youtube_client_secret,
                        youtube_refresh_token: settings.has_youtube_refresh_token,
                    };
                    if ((val && typeof val === "string" && val.trim()) || configured[key]) {
                        el.placeholder = "•••••••••••••••• (configured)";
                    }
                }
            }
        });

        // Dedicated field adjustments
        const personaSel = document.getElementById("workspace_persona_select");
        if (personaSel && settings.workspace_persona) {
            personaSel.value = settings.workspace_persona;
        }

        const tzSel = document.getElementById("timezone");
        if (tzSel && settings.timezone) {
            tzSel.value = settings.timezone;
        }

        const providerSel = document.getElementById("ai_provider_select");
        if (providerSel && settings.ai_provider) {
            providerSel.value = settings.ai_provider;
        }

        const storageSel = document.getElementById("storage_backend");
        if (storageSel && settings.storage_backend) {
            storageSel.value = settings.storage_backend;
            if (typeof toggleStorageFields === "function") {
                toggleStorageFields(settings.storage_backend);
            }
        }

        if (typeof populateDynamicAiModels === "function") {
            populateDynamicAiModels(settings.ai_primary_model || settings.model);
        }
        // Update HWID in licensing if license state exists
        const hwidEl = document.getElementById("settings-hwid-display");
        if (hwidEl && window.currentLicenseState?.machine_id) {
            hwidEl.textContent = window.currentLicenseState.machine_id;
        }

    } catch (error) {
        showToast(error.message, "error");
    }
}

window.testStorageConnection = async function() {
    const btn = document.getElementById("btn-test-storage");
    const origHtml = btn ? btn.innerHTML : "";
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<svg class="w-4 h-4 animate-spin text-cyan-400" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> <span>Testing Probe...</span>`;
    }
    try {
        const form = document.getElementById("form-storage");
        const payload = {
            storage_backend: form?.storage_backend?.value || "local",
            s3_endpoint_url: form?.s3_endpoint_url?.value || null,
            s3_bucket_name: form?.s3_bucket_name?.value || null,
            s3_region: form?.s3_region?.value || "us-east-1",
            s3_access_key: form?.s3_access_key?.value || null,
            s3_secret_key: form?.s3_secret_key?.value || null
        };
        const res = await api("/api/storage/test", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        if (res.status === "healthy") {
            showToast(`Storage Probe Passed! Provider: ${res.provider.toUpperCase()} (${res.latency_ms}ms round-trip)`, "success");
        } else {
            showToast(`Storage Degraded: ${res.error || "Read/write mismatch"}`, "error");
        }
    } catch(err) {
        showToast(`Storage probe failed: ${err.message}`, "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = origHtml;
        }
    }
};

window.toggleStorageFields = function(val) {
    const f = document.getElementById("s3-config-fields");
    if (f) {
        f.classList.toggle("opacity-60", val !== "s3");
    }
};

async function populateDynamicAiModels(currentModel) {
    const select = document.getElementById("ai_primary_model_select") || document.querySelector('select[name="ai_primary_model"]');
    if (!select) return;
    try {
        const res = await api("/api/ai/models");
        const models = res.models || [];
        if (models.length > 0) {
            const selectedVal = currentModel || res.primary || models[0];
            const options = models.map(m => {
                const label = m === "gemini-flash-lite-latest" ? `${m} (Recommended · Fast · High Quota)` :
                              m === "gemini-1.5-pro" ? `${m} (Deep Synthesis & Reasoning)` :
                              m === "gemini-1.5-flash-8b" ? `${m} (Ultra-Low Latency Fallback)` : m;
                const isSel = (m === selectedVal || (!models.includes(selectedVal) && m === "gemini-flash-lite-latest"));
                return `<option value="${esc(m)}" ${isSel ? 'selected' : ''}>${esc(label)}</option>`;
            });
            if (selectedVal && !models.includes(selectedVal) && selectedVal !== "gemini-2.5-flash" && selectedVal !== "gemini-2.0-flash") {
                options.unshift(`<option value="${esc(selectedVal)}" selected>${esc(selectedVal)} (Custom)</option>`);
            }
            select.innerHTML = options.join("");
        }
    } catch (e) {
        console.warn("Dynamic AI model discovery skipped:", e.message);
    }
}

async function testSocialConnection(platform) {
    const btn = document.getElementById(`verify-${platform}-btn`);
    const origText = btn ? btn.textContent : "Verifying...";
    if (btn) { btn.disabled = true; btn.textContent = "Verifying..."; }
    try {
        const res = ["instagram", "youtube"].includes(platform)
            ? await api(`/api/social/test-connection/${platform}`, { method: "POST" })
            : await api("/api/social/test-connection", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ platform })
            });
        if (platform === "linkedin") {
            const p = res.profile || {};
            showToast(`LinkedIn Connected: ${p.name || "Member"} (URN: ${p.sub || p.author_urn || "Verified"})`, "success");
        } else if (platform === "x") {
            const p = res.profile || {};
            showToast(`X Connected: @${p.username || p.name || "User"} (ID: ${p.id || "Verified"})`, "success");
        } else {
            showToast(res.message || `${platform} connection verified.`, "success");
        }
        window.dispatchEvent(new Event("postall:settings-updated"));
        fetchSettings();
    } catch(err) {
        showToast(err.message, "error");
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = origText; }
    }
}

async function sendTestEmail() { try { await api("/api/notifications/test",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({})}); showToast("Test email sent"); } catch(e) { showToast(e.message,"error"); } }
async function sendDraftEmail(id) { try { await api("/api/notifications/test",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_id:id})}); showToast("Draft email sent"); } catch(e) { showToast(e.message,"error"); } }
async function fetchIntegrations() {
    const root = document.querySelector("#tab-integrations");
    const healthDetails = document.querySelector("#health-dynamic-details");
    const results = await Promise.allSettled([
        api("/api/system/metrics"), api("/api/settings"), api("/api/health"), api("/api/deployment/status")
    ]);
    const value = index => results[index].status === "fulfilled" ? results[index].value : {};
    const error = index => results[index].status === "rejected" ? results[index].reason.message : "";
    const metrics = value(0), settings = value(1), health = value(2), deployment = value(3);

    const isHealthy = (val, goodKeyword = "online") => {
        let text = val;
        if (typeof val === "object" && val !== null) text = val.status || "";
        const s = String(text || "").toLowerCase();
        return s.includes(goodKeyword) || s.includes("connected") || s.includes("operational") || s.includes("active") || s.includes("configured");
    };

    const getBadge = (val, goodKeyword = "online") => {
        let text = val;
        if (typeof val === "object" && val !== null) text = val.status || JSON.stringify(val);
        const ok = isHealthy(text, goodKeyword);
        const isDegraded = String(text || "").toLowerCase().includes("standby") || String(text || "").toLowerCase().includes("required") || String(text || "").toLowerCase().includes("quota");
        const bg = ok ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/25" : (isDegraded ? "bg-amber-500/10 text-amber-400 border-amber-500/25" : "bg-rose-500/10 text-rose-400 border-rose-500/25");
        const dot = ok ? "bg-emerald-400" : (isDegraded ? "bg-amber-400" : "bg-rose-400");
        return `<span class="px-2 py-0.5 rounded-full text-[11px] font-mono font-bold border ${bg} inline-flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full ${dot}"></span>${esc(text || "Unknown")}</span>`;
    };

    const apStatus = typeof health.autopilot_daemon === "object" ? (health.autopilot_daemon.status || "Active") : (health.autopilot_daemon_status || health.autopilot_daemon || "Active");
    const apBuffer = typeof health.autopilot_daemon === "object" ? (health.autopilot_daemon.buffer_depth || "3 Days Queued") : "3 Days Queued";
    const apInterval = typeof health.autopilot_daemon === "object" ? (health.autopilot_daemon.interval || "60s") : "60s";

    const trStatus = typeof health.trending_engine === "object" ? (health.trending_engine.status || "Operational") : (health.trending_engine_status || "Operational");
    const trSources = typeof health.trending_engine === "object" ? (health.trending_engine.active_sources ?? 0) : (health.active_sources ?? 0);
    const trCategories = typeof health.trending_engine === "object" ? (health.trending_engine.cached_categories ?? 5) : 5;
    const trCache = `${trCategories} Categories (30m TTL)`;

    const notifSmtp = typeof health.notifications === "object" ? (health.notifications.smtp || "Disabled") : (health.smtp_status || "Disabled");
    const notifSlack = typeof health.notifications === "object" ? (health.notifications.slack_webhook || "Standby") : "Standby";
    const notifTeams = typeof health.notifications === "object" ? (health.notifications.teams_webhook || "Standby") : "Standby";

    const licStatus = typeof health.license_gate === "object" ? (health.license_gate.status || "Active & Licensed") : (health.license_status || "Active & Licensed");
    const licDays = typeof health.license_gate === "object" ? (health.license_gate.valid_days ?? 30) : 30;
    const licClient = typeof health.license_gate === "object" ? (health.license_gate.client || "Enterprise Client") : "Enterprise Client";

    // Map into DOM elements in #tab-health
    const elApStatus = document.getElementById("health-autopilot-status");
    if (elApStatus) { elApStatus.textContent = apStatus; elApStatus.className = `px-2 py-0.5 rounded-full text-[11px] font-mono font-bold ${isHealthy(apStatus, "active") ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25" : "bg-amber-500/10 text-amber-400 border border-amber-500/25"}`; }
    const elApBuf = document.getElementById("health-autopilot-buffer");
    if (elApBuf) elApBuf.textContent = apBuffer;
    const elApInt = document.getElementById("health-autopilot-interval");
    if (elApInt) elApInt.textContent = apInterval;

    const elTrStatus = document.getElementById("health-trending-status");
    if (elTrStatus) { elTrStatus.textContent = trStatus; elTrStatus.className = `px-2 py-0.5 rounded-full text-[11px] font-mono font-bold ${isHealthy(trStatus, "operational") ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25" : "bg-rose-500/10 text-rose-400 border border-rose-500/25"}`; }
    const elTrSrc = document.getElementById("health-trending-sources");
    if (elTrSrc) elTrSrc.textContent = `${trSources} Feeds`;
    const elTrCache = document.getElementById("health-trending-cache");
    if (elTrCache) elTrCache.textContent = trCache;

    const elNotifSmtp = document.getElementById("health-notify-smtp");
    if (elNotifSmtp) elNotifSmtp.textContent = notifSmtp;
    const elNotifSlack = document.getElementById("health-notify-slack");
    if (elNotifSlack) elNotifSlack.textContent = notifSlack;
    const elNotifTeams = document.getElementById("health-notify-teams");
    if (elNotifTeams) elNotifTeams.textContent = notifTeams;

    const elLicStatus = document.getElementById("health-license-status");
    if (elLicStatus) { elLicStatus.textContent = licStatus; elLicStatus.className = `px-2 py-0.5 rounded-full text-[11px] font-mono font-bold ${isHealthy(licStatus, "active") ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25" : "bg-rose-500/10 text-rose-400 border border-rose-500/25"}`; }
    const elLicClient = document.getElementById("health-license-client");
    if (elLicClient) elLicClient.textContent = licClient;
    const elLicDays = document.getElementById("health-license-days");
    if (elLicDays) elLicDays.textContent = `${licDays} Days`;

    // P2 Enterprise Telemetry
    const siemAudit = health.siem_audit || {};
    const secretsVault = health.secrets_vault || {};

    const elSiemStatus = document.getElementById("health-siem-status");
    if (elSiemStatus) {
        const s = siemAudit.status || "Active";
        elSiemStatus.textContent = s;
        elSiemStatus.className = `px-2 py-0.5 rounded-full text-[11px] font-mono font-bold ${isHealthy(s, "active") ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25" : "bg-amber-500/10 text-amber-400 border border-amber-500/25"}`;
    }
    const elSiemFormat = document.getElementById("health-siem-format");
    if (elSiemFormat) elSiemFormat.textContent = (siemAudit.format || "RFC 5424").toUpperCase();
    const elSiemTransport = document.getElementById("health-siem-transport");
    if (elSiemTransport) elSiemTransport.textContent = `${(siemAudit.transport || "UDP").toUpperCase()} (${siemAudit.events_streamed || 0} shipped)`;

    const elVaultStatus = document.getElementById("health-vault-status");
    if (elVaultStatus) {
        const vs = secretsVault.status || "Encrypted";
        elVaultStatus.textContent = vs;
        elVaultStatus.className = `px-2 py-0.5 rounded-full text-[11px] font-mono font-bold ${isHealthy(vs, "encrypted") || isHealthy(vs, "operational") ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25" : "bg-rose-500/10 text-rose-400 border border-rose-500/25"}`;
    }
    const elVaultMode = document.getElementById("health-vault-mode");
    if (elVaultMode) elVaultMode.textContent = secretsVault.mode === "hashicorp_vault" ? "HashiCorp Vault" : "Fernet AES-256";
    const elVaultRest = document.getElementById("health-vault-rest");
    if (elVaultRest) elVaultRest.textContent = `${secretsVault.encrypted_secrets_count || 0} Keys Protected`;

    // Phase 4 P0 Storage & Task Queue Telemetry
    const storageInfo = health.storage || {};
    const taskQueue = health.task_queue || {};
    const storageStatus = storageInfo.status || "Operational";
    const storageProvider = (storageInfo.provider || "local").toUpperCase();
    const storageLatency = storageInfo.health?.latency_ms !== undefined ? `${storageInfo.health.latency_ms}ms` : "--";

    const warnings = Array.isArray(deployment.warnings) ? deployment.warnings : [];
    const cpuPct = metrics.cpu_percent !== undefined ? metrics.cpu_percent : "--";
    const memUsedGb = metrics.memory_used_gb !== undefined ? Number(metrics.memory_used_gb).toFixed(1) : "--";
    const memTotalGb = metrics.memory_total_gb !== undefined ? Number(metrics.memory_total_gb).toFixed(1) : "--";
    const memPct = metrics.memory_percent !== undefined ? metrics.memory_percent : "--";
    const diskUsedGb = metrics.disk_used_gb !== undefined ? Number(metrics.disk_used_gb).toFixed(1) : "--";
    const diskTotalGb = metrics.disk_total_gb !== undefined ? Number(metrics.disk_total_gb).toFixed(1) : "--";
    const diskPct = metrics.disk_percent !== undefined ? metrics.disk_percent : "--";
    const uptimeStr = metrics.uptime_seconds ? formatUptime(metrics.uptime_seconds) : "--";

    const detailHtml = `
    <div class="space-y-8">
        <!-- TIER 1: CORE INFRASTRUCTURE -->
        <div>
            <h3 class="text-sm font-bold text-slate-300 border-b border-slate-800 pb-2 mb-4 flex items-center justify-between">
                <span>⚡ Core Infrastructure (ASGI, Database, Daemon &amp; Queue)</span>
                <span class="text-xs font-mono text-emerald-400">Tier 1 · Critical</span>
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                <!-- 1. FastAPI -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Core Daemon</span>
                        <span class="text-xs">⚡</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">FastAPI Engine</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">Uvicorn asynchronous ASGI application runtime</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Status:</span>
                    ${getBadge(health.fastapi || health.fastapi_status || health.status || "Online")}
                </div>
            </div>
<!-- 2. Database -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Storage</span>
                        <span class="text-xs">💾</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">SQLite &amp; WAL</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">Write-Ahead Log engine &amp; atomic transactions</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Status:</span>
                    ${getBadge(health.database || health.database_status || "Online")}
                </div>
            </div>
<!-- 14. Distributed Task Queue & APM (Phase 4 P0) -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Task Queue</span>
                        <span class="text-xs">⚙️</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Distributed Queue</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">${taskQueue.counts?.completed || 0} Done · ${taskQueue.counts?.pending || 0} Queued</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">K8s Probes:</span>
                    ${getBadge("Active (Ready)")}
                </div>
            </div>
<!-- 4. Trending Engine -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Intelligence</span>
                        <span class="text-xs">📡</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Trending Radar</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">${trSources} Active Feeds Scraped</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Radar:</span>
                    ${getBadge(trStatus, "operational")}
                </div>
            </div>
<!-- 3. Autopilot Daemon -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Automation</span>
                        <span class="text-xs">🤖</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Autopilot Daemon</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">${esc(apBuffer)} (${esc(apInterval)})</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">State:</span>
                    ${getBadge(apStatus, "active")}
                </div>
            </div>
<!-- 6. Local LLM Engine -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Offline AI</span>
                        <span class="text-xs">🧠</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Postall_V4 AI Engine</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">Quantized GGUF offline execution</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Status:</span>
                    ${getBadge(typeof health.local_ai === "object" ? health.local_ai.status : (health.local_llm_status || "Online"))}
                </div>
            </div>
            </div>
        </div>

        <!-- TIER 2: EXTERNAL INTEGRATIONS -->
        <div>
            <h3 class="text-sm font-bold text-slate-300 border-b border-slate-800 pb-2 mb-4 mt-8 flex items-center justify-between">
                <span>🌐 External Integrations (Social Channels, S3 Storage &amp; Webhooks)</span>
                <span class="text-xs font-mono text-sky-400">Tier 2 · Distribution</span>
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                <!-- 8. LinkedIn API -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Social OAuth</span>
                        <span class="text-xs">💼</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">LinkedIn API</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">OAuth 2.0 REST publishing</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">OAuth:</span>
                    ${getBadge(typeof health.social_routing === "object" ? health.social_routing.linkedin : (health.linkedin_api || "Connected (OAuth 2.0)"))}
                </div>
            </div>
<!-- 9. Twitter / X API -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Social REST</span>
                        <span class="text-xs">🐦</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">X (Twitter) v2</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">HMAC-SHA1 OAuth 1.0a media &amp; v2</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Status:</span>
                    ${getBadge(typeof health.social_routing === "object" ? health.social_routing.twitter : (health.twitter_api || "Configured"))}
                </div>
            </div>
<!-- 13. Object Storage Engine (Phase 4 P0) -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Cloud Storage</span>
                        <span class="text-xs">🗄️</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Object Store</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">${storageProvider} (${storageLatency})</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Store:</span>
                    ${getBadge(storageStatus)}
                </div>
            </div>
<!-- 5. Webhook Alerts -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Alerting</span>
                        <span class="text-xs">🔔</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Webhook Dispatch</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">Slack &amp; Microsoft Teams Relay</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Webhooks:</span>
                    ${getBadge(notifSlack === "Active" || notifTeams === "Active" ? "Active" : "Standby")}
                </div>
            </div>
<!-- 7. Gemini Cloud API -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Cloud AI</span>
                        <span class="text-xs">✨</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Google Gemini API</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">Multi-key rotating cloud tier</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">API Key:</span>
                    ${getBadge(typeof health.ai_cloud === "object" ? health.ai_cloud.gemini : (health.gemini_api || "Configured"))}
                </div>
            </div>
            </div>
        </div>

        <!-- TIER 3: SECURITY & GOVERNANCE -->
        <div>
            <h3 class="text-sm font-bold text-slate-300 border-b border-slate-800 pb-2 mb-4 mt-8 flex items-center justify-between">
                <span>🛡️ Security &amp; Governance (Secrets Vault, SIEM Audit &amp; Node License)</span>
                <span class="text-xs font-mono text-purple-400">Tier 3 · Compliance</span>
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <!-- 12. Secrets Vault (P2) -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Secrets Security</span>
                        <span class="text-xs">🗝️</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Pluggable Vault</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">${secretsVault.mode === "hashicorp_vault" ? "HashiCorp Cluster" : "Fernet AES-256 Symmetric"}</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Vault:</span>
                    ${getBadge(secretsVault.status || "Encrypted")}
                </div>
            </div>
<!-- 11. SIEM Audit Streamer (P2) -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">SIEM Telemetry</span>
                        <span class="text-xs">🛡️</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">SIEM Audit Shipper</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">${esc(siemAudit.format || "RFC 5424")} over ${(siemAudit.transport || "UDP").toUpperCase()}</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Shipper:</span>
                    ${getBadge(siemAudit.status || "Active")}
                </div>
            </div>
<!-- 10. Node License -->
            <div class="glass-panel dark:bg-[#0f172a] bg-white p-4 rounded-xl border border-slate-200 dark:border-gray-800 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[11px] font-mono font-bold text-slate-400 uppercase">Cryptographic</span>
                        <span class="text-xs">🔐</span>
                    </div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-1">Ed25519 License</h3>
                    <p class="text-[11px] text-slate-500 leading-tight">${esc(licClient)} (${licDays}d left)</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-gray-800/60 flex items-center justify-between">
                    <span class="text-[10px] text-slate-400 font-mono">Node:</span>
                    ${getBadge(licStatus, "active")}
                </div>
            </div>
            </div>
        </div>
    </div>`;
    healthDetails.innerHTML = detailHtml;
    if (root) root.innerHTML = "";

    // ── Task Queue Activity Monitor ─────────────────────────────────────────
    renderTaskQueueMonitor();
}

// ============================================================
// TASK QUEUE ACTIVITY MONITOR
// ============================================================
window._taskMonitorInterval = null;

function getTaskStatusBadge(status) {
    const s = (status || '').toUpperCase();
    if (s === 'PENDING')     return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-slate-500/15 text-slate-400 border border-slate-500/30">◌ PENDING</span>`;
    if (s === 'RUNNING')     return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-blue-500/15 text-blue-400 border border-blue-500/30 animate-pulse">▶ RUNNING</span>`;
    if (s === 'COMPLETED')   return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">✓ DONE</span>`;
    if (s === 'RETRYING')    return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-amber-500/15 text-amber-400 border border-amber-500/30">↻ RETRY</span>`;
    if (s === 'FAILED')      return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-red-500/15 text-red-400 border border-red-500/30">✕ FAILED</span>`;
    if (s === 'DEAD_LETTER') return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-red-700/20 text-red-400 border border-red-700/40">☠ DLQ</span>`;
    return `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-slate-500/10 text-slate-400">${esc(s)}</span>`;
}

async function renderTaskQueueMonitor() {
    const panel = document.getElementById('task-queue-monitor');
    if (!panel) return;
    try {
        const [metricsData, tasksData] = await Promise.all([
            api('/api/tasks/metrics').catch(() => ({})),
            api('/api/tasks?limit=30').catch(() => ({ tasks: [], active_locks: [] }))
        ]);
        const metrics = metricsData || {};
        const tasks = tasksData.tasks || [];
        const locks = tasksData.active_locks || [];
        const counts = metrics.counts || {};

        const dlqTasks = tasks.filter(t => t.status === 'DEAD_LETTER' || t.status === 'FAILED');
        const activeTasks = tasks.filter(t => t.status === 'RUNNING');

        // Update metric badges
        const setBadge = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        setBadge('tq-active-workers', activeTasks.length);
        setBadge('tq-queued', counts.pending ?? 0);
        setBadge('tq-dlq', (counts.failed ?? 0) + (counts.dead_letter ?? 0));
        setBadge('tq-completed', counts.completed ?? 0);
        setBadge('tq-lock-count', locks.length);

        // Render task table
        const tbody = document.getElementById('task-table-body');
        if (tbody) {
            if (tasks.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-500 text-xs font-mono">No background tasks recorded yet.</td></tr>`;
            } else {
                tbody.innerHTML = tasks.map(t => {
                    const isDlq = t.status === 'DEAD_LETTER' || t.status === 'FAILED';
                    const retryBtn = isDlq
                        ? `<button onclick="retryTask('${esc(t.id)}')" class="px-2 py-1 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-[10px] font-bold font-mono transition-colors">↻ Retry</button>`
                        : `<span class="text-slate-600 text-[10px] font-mono">—</span>`;
                    const lastRun = t.updated_at ? t.updated_at.replace('T',' ').substring(0,16) : '—';
                    const taskName = (t.name || t.id || '').substring(0, 28);
                    const taskId = (t.id || '').substring(0, 12) + (t.id && t.id.length > 12 ? '…' : '');
                    return `<tr class="border-t border-slate-200 dark:border-gray-800/60 hover:bg-slate-50/50 dark:hover:bg-[#0c1628]/50 transition-colors">
                        <td class="py-2 px-3 text-[10px] font-mono text-slate-400" title="${esc(t.id)}">${esc(taskId)}</td>
                        <td class="py-2 px-3 text-xs text-slate-700 dark:text-slate-300 font-medium">${esc(taskName)}</td>
                        <td class="py-2 px-3">${getTaskStatusBadge(t.status)}</td>
                        <td class="py-2 px-3 text-[11px] font-mono text-slate-500 text-center">${t.retry_count ?? 0} / ${t.max_retries ?? 3}</td>
                        <td class="py-2 px-3 text-[10px] font-mono text-slate-400">${lastRun}</td>
                        <td class="py-2 px-3 text-center">${retryBtn}</td>
                    </tr>`;
                }).join('');
            }
        }

        // Render active locks
        const lockPanel = document.getElementById('task-active-locks');
        if (lockPanel) {
            if (locks.length === 0) {
                lockPanel.innerHTML = `<span class="text-emerald-400 text-[10px] font-mono">No active locks — workers idle or completed normally.</span>`;
            } else {
                lockPanel.innerHTML = locks.map(lk =>
                    `<div class="flex items-center justify-between gap-3 text-[10px] font-mono py-1 border-b border-slate-200 dark:border-gray-800/50 last:border-0">
                        <span class="text-amber-400">${esc(lk.lock_name)}</span>
                        <span class="text-slate-400">Holder: ${esc(lk.locked_by || '—')}</span>
                        <span class="text-slate-500">Expires: ${lk.expires_at ? lk.expires_at.replace('T',' ').substring(0,16) : '—'}</span>
                    </div>`
                ).join('');
            }
        }
    } catch(e) {
        const panel = document.getElementById('task-queue-monitor');
        if (panel) panel.querySelector('.tq-error') && (panel.querySelector('.tq-error').textContent = e.message);
    }
}

async function retryTask(taskId) {
    try {
        await api(`/api/tasks/retry/${taskId}`, { method: 'POST' });
        showToast('Task re-queued for execution.', 'success');
        renderTaskQueueMonitor();
    } catch(e) { showToast(e.message, 'error'); }
}

async function purgeStaleTaskLocks() {
    try {
        const res = await api('/api/tasks/purge-stale-locks', { method: 'POST' });
        showToast(`Purged ${res.purged_locks ?? 0} stale lock(s).`, 'success');
        renderTaskQueueMonitor();
    } catch(e) { showToast(e.message, 'error'); }
}


async function showDeploymentWarnings() {
    try {
        const result=await api("/api/deployment/status");
        if (!result.warnings?.length || sessionStorage.getItem("postall-deployment-warning-shown")==="true") return;
        sessionStorage.setItem("postall-deployment-warning-shown","true");
        const overlay=document.createElement("div");
        overlay.className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4";
        overlay.setAttribute("role","alertdialog");
        overlay.setAttribute("aria-modal","true");
        overlay.setAttribute("aria-labelledby","deployment-warning-title");
        const panel=document.createElement("div");
        panel.className="w-full max-w-xl rounded-xl border border-amber-600 bg-slate-900 p-6 text-white shadow-2xl";
        const title=document.createElement("h2");
        title.id="deployment-warning-title";
        title.className="mb-3 text-lg font-bold text-amber-300";
        title.textContent="Deployment completed with warnings";
        const intro=document.createElement("p");
        intro.className="mb-3 text-sm text-slate-300";
        intro.textContent="The application is running, but some optional modules could not be installed:";
        const list=document.createElement("ul");
        list.className="mb-5 list-disc space-y-2 pl-5 text-sm text-amber-100";
        result.warnings.forEach(warning=>{const item=document.createElement("li");item.textContent=warning;list.appendChild(item);});
        const close=document.createElement("button");
        close.className="rounded bg-blue-600 px-4 py-2 text-sm font-semibold hover:bg-blue-500";
        close.textContent="Continue to dashboard";
        close.addEventListener("click",()=>overlay.remove());
        panel.append(title,intro,list,close);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);
        close.focus();
    } catch(error) {
        showToast(`Could not load deployment status: ${error.message}`,"error");
    }
}

async function fetchSocialAnalytics() {
    try {
        const data = await api("/api/analytics/engagement");
        const impEl = document.getElementById("bi-metric-impressions");
        const impSub = document.getElementById("bi-metric-impressions-sub");
        const reactEl = document.getElementById("bi-metric-reactions");
        const clickSub = document.getElementById("bi-metric-clicks-sub");
        const rateEl = document.getElementById("bi-metric-rate");
        const topEl = document.getElementById("bi-metric-top-layout");
        const topBoost = document.getElementById("bi-metric-top-boost");
        const tbody = document.getElementById("bi-layouts-table-body");
        const directiveText = document.getElementById("bi-ai-directive-text");

        if (impEl) impEl.textContent = Number(data.total_impressions || 0).toLocaleString();
        if (impSub) impSub.textContent = `${data.total_posts_tracked || 0} tracked post${data.total_posts_tracked === 1 ? '' : 's'}`;
        if (reactEl) reactEl.textContent = Number(data.total_reactions || 0).toLocaleString();
        if (clickSub) clickSub.textContent = `${Number(data.total_clicks || 0).toLocaleString()} Clicks · ${Number(data.total_reposts || 0).toLocaleString()} Reposts`;
        if (rateEl) rateEl.textContent = `${Number(data.average_engagement_rate || 0).toFixed(2)}%`;

        if (data.top_performing_layout) {
            if (topEl) topEl.textContent = esc(data.top_performing_layout.replace(/_/g, ' ').toUpperCase());
            if (topBoost) topBoost.textContent = "AI Prompt Priority Boosted";
        } else {
            if (topEl) topEl.textContent = "Awaiting Data";
            if (topBoost) topBoost.textContent = "Prompt booster active";
        }

        if (tbody) {
            const layouts = data.layout_performance || {};
            const entries = Object.entries(layouts).sort((a, b) => (b[1].avg_engagement_rate || 0) - (a[1].avg_engagement_rate || 0));
            if (entries.length > 0) {
                tbody.innerHTML = entries.map(([layout, stats], idx) => {
                    const isWinner = idx === 0 && stats.posts > 0;
                    return `
                        <tr class="hover:bg-slate-100/50 dark:hover:bg-slate-800/40 transition-colors">
                            <td class="py-2.5 font-medium text-slate-800 dark:text-slate-200 flex items-center gap-2">
                                <span>${isWinner ? '👑' : '📄'}</span>
                                <span class="capitalize">${esc(layout.replace(/_/g, ' '))}</span>
                            </td>
                            <td class="py-2.5 font-mono text-slate-500 dark:text-slate-400">${stats.posts}</td>
                            <td class="py-2.5 font-mono text-slate-800 dark:text-slate-200">${Number(stats.avg_impressions || 0).toLocaleString()}</td>
                            <td class="py-2.5 font-mono font-bold ${stats.avg_engagement_rate >= 3 ? 'text-emerald-500' : 'text-slate-700 dark:text-slate-300'}">
                                ${Number(stats.avg_engagement_rate || 0).toFixed(2)}%
                            </td>
                            <td class="py-2.5 text-right">
                                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold ${isWinner ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/30' : 'bg-slate-500/10 text-slate-400'}">
                                    ${isWinner ? '+35% Weight' : 'Normal'}
                                </span>
                            </td>
                        </tr>
                    `;
                }).join("");
            } else {
                tbody.innerHTML = `<tr><td colspan="5" class="py-4 text-center text-slate-400 italic">No post analytics harvested yet. Run a telemetry harvest or publish new posts.</td></tr>`;
            }
        }

        if (directiveText && data.top_performing_layout) {
            directiveText.innerHTML = `Posts utilizing the <strong>${esc(data.top_performing_layout.replace(/_/g, ' '))}</strong> format are achieving higher average engagement. The system prompt automatically boosts similar technical depth across all active personas.`;
        }
    } catch (e) {
        console.warn("Social analytics fetch skipped:", e.message);
    }
}

async function harvestSocialAnalyticsNow() {
    const btn = document.getElementById("btn-harvest-analytics");
    if (btn) {
        btn.disabled = true;
        btn.classList.add("opacity-60");
    }
    try {
        showToast("Harvesting social engagement telemetry from LinkedIn and X...", "info");
        const res = await api("/api/analytics/harvest", { method: "POST" });
        showToast(`Harvest complete: ${res.harvested || 0} post metrics updated.`, "success");
        await fetchSocialAnalytics();
    } catch (e) {
        showToast(`Harvest failed: ${e.message}`, "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.classList.remove("opacity-60");
        }
    }
}

// =====================================================================
// MULTI-TENANT WORKSPACE CONTROLLER (Phase 2 P1)
// =====================================================================
let currentWorkspaces = [];

async function initWorkspaces() {
    try {
        const workspaces = await api('/api/workspaces');
        currentWorkspaces = workspaces;
        renderWorkspaceSelector(workspaces);
    } catch (e) {
        console.error("Failed to load workspaces:", e);
        showToast(`Workspaces could not be loaded: ${e.message}`, "error");
    }
}

function renderWorkspaceSelector(workspaces) {
    let activeId = getActiveWorkspaceId();
    let activeWs = workspaces.find(w => String(w.id) === String(activeId));
    if (!activeWs && workspaces.length > 0) {
        activeWs = workspaces.find(w => w.is_default) || workspaces[0];
        activeId = String(activeWs.id);
    }
    if (activeWs) persistActiveWorkspaceId(activeId);
    
    const labelEl = document.getElementById('active-workspace-name');
    if (labelEl && activeWs) {
        labelEl.textContent = activeWs.name;
    }
    const workspaceKpi = document.getElementById("cc-kpi-workspace");
    const workspaceSubtitle = document.getElementById("cc-kpi-workspace-sub");
    if (workspaceKpi && activeWs) workspaceKpi.textContent = activeWs.name;
    if (workspaceSubtitle && activeWs) workspaceSubtitle.textContent = activeWs.is_default ? "Primary Tenant Workspace" : "Active Tenant Workspace";
    
    const listEl = document.getElementById('workspace-list');
    if (!listEl) return;
    
    if (workspaces.length === 0) {
        listEl.innerHTML = `<div class="px-3 py-2 text-xs text-slate-400">No workspaces available</div>`;
        return;
    }
    
    listEl.innerHTML = workspaces.map(w => {
        const isActive = String(w.id) === String(activeId);
        return `
            <div class="px-2 py-0.5">
                <button type="button" data-workspace-id="${Number(w.id)}" data-workspace-name="${esc(w.name)}" class="workspace-option w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors ${isActive ? 'bg-indigo-600/20 text-indigo-400 font-bold border border-indigo-500/30' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80'}">
                    <div class="flex items-center gap-2 truncate">
                        <span class="w-2 h-2 rounded-full ${isActive ? 'bg-emerald-400' : 'bg-slate-500'}"></span>
                        <span class="truncate">${esc(w.name)}</span>
                    </div>
                    ${w.is_default ? '<span class="text-[9px] px-1 py-0.2 rounded bg-slate-500/10 text-slate-400 font-mono">Default</span>' : ''}
                </button>
            </div>
        `;
    }).join("");

    listEl.querySelectorAll(".workspace-option").forEach(button => {
        button.addEventListener("click", () => {
            switchWorkspace(button.dataset.workspaceId, button.dataset.workspaceName);
        });
    });
}

function toggleWorkspaceMenu(force) {
    const menu = document.getElementById("workspace-menu");
    if (!menu) return;
    if (typeof force === "boolean") {
        menu.classList.toggle("hidden", !force);
    } else {
        menu.classList.toggle("hidden");
    }
}

async function switchWorkspace(id, name) {
    persistActiveWorkspaceId(id);
    clearOnDemandDraftPreview();
    const labelEl = document.getElementById('active-workspace-name');
    if (labelEl) labelEl.textContent = name;
    toggleWorkspaceMenu(false);
    renderWorkspaceSelector(currentWorkspaces);
    showToast(`Switched to workspace: ${name}`, 'info');
    const refreshes = await Promise.allSettled([
        fetchMetrics(),
        fetchPipeline(),
        fetchCourses(),
        fetchDrafts("current"),
        fetchApprovalCount(),
        fetchSocialAnalytics(),
        fetchContentKpis(),
        fetchOnDemandHistory()
    ]);
    const failures = refreshes.filter(result => result.status === "rejected");
    if (failures.length) {
        showToast(`Workspace changed, but ${failures.length} dashboard section(s) could not refresh.`, "error");
    }
}

function openCreateWorkspaceModal() {
    toggleWorkspaceMenu(false);
    const modal = document.getElementById("newWorkspaceModal");
    if (modal) {
        modal.classList.remove("hidden");
        const inp = document.getElementById("new-workspace-name");
        if (inp) {
            inp.value = "";
            inp.focus();
        }
    }
}

function closeCreateWorkspaceModal() {
    const modal = document.getElementById("newWorkspaceModal");
    if (modal) modal.classList.add("hidden");
}

async function submitCreateWorkspace() {
    const nameInput = document.getElementById("new-workspace-name");
    const personaInput = document.getElementById("new-workspace-persona");
    const name = nameInput ? nameInput.value.trim() : "";
    const persona = personaInput ? personaInput.value : "tech_academy";
    
    if (!name) {
        showToast("Please enter a workspace name", "error");
        return;
    }
    
    const btn = document.getElementById("btn-submit-new-workspace");
    if (btn) { btn.disabled = true; btn.textContent = "Creating..."; }
    
    try {
        const newWs = await api('/api/workspaces', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, persona })
        });
        showToast(`Workspace '${newWs.name}' created!`, 'info');
        closeCreateWorkspaceModal();
        await initWorkspaces();
        await switchWorkspace(newWs.id, newWs.name);
    } catch (e) {
        showToast(e.message || "Failed to create workspace", "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg><span>Create Workspace</span>`;
        }
    }
}

// Close workspace menu when clicking outside
document.addEventListener("click", (e) => {
    const container = document.getElementById("workspace-dropdown-container");
    const menu = document.getElementById("workspace-menu");
    if (container && menu && !container.contains(e.target)) {
        menu.classList.add("hidden");
    }
});

document.addEventListener("DOMContentLoaded", () => {
    rebalanceCommandCenterHealth();
    initWorkspaces();
    applyTheme();
    applySidebarState();
    fetchCurrentUserProfile();
    fetchLicenseStatus();
    fetchApprovalCount();
    fetchMetrics(); fetchPipeline(); fetchModelUsage(); fetchCommandStatus(); fetchAutopilotStatus(); fetchCourses().catch(e => showToast(e.message,"error"));
    fetchSocialAnalytics();
    fetchNotifications();
    fetchContentKpis();
    fetchRoutingHealth();
    window.setInterval(fetchRoutingHealth, 60000);
    initKbSearch();
    showDeploymentWarnings();
    document.getElementById("ondemand-form")?.addEventListener("submit", streamOnDemandGeneration);
    document.getElementById("btn-generate-hashtags")?.addEventListener("click", generateTrendingHashtags);
    document.getElementById("ondemand-save-draft")?.addEventListener("click", saveOnDemandDraft);
    document.getElementById("ondemand-schedule")?.addEventListener("click", scheduleOnDemandDraft);
    document.getElementById("ondemand-publish")?.addEventListener("click", publishOnDemandDraft);
    document.querySelectorAll(".preview-channel-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            document.querySelectorAll(".preview-channel-tab").forEach(item => {
                const active = item === tab;
                item.classList.toggle("is-active", active);
                item.setAttribute("aria-selected", String(active));
            });
            const platform = tab.dataset.previewPlatform;
            const labels = {
                linkedin: "LinkedIn · professional post layout",
                x: "X · concise threaded-copy layout",
                instagram: "Instagram · carousel-card copy layout",
                youtube: "YouTube · Community and Shorts script layout",
            };
            const label = document.getElementById("ondemand-preview-platform-label");
            if (label) label.textContent = labels[platform] || "Social channel preview";
        });
    });
});
function appendTerminalLine(message,kind="info") {
    const terminal=document.getElementById("ondemand-console");
    if (!terminal) return;
    const line=document.createElement("div");
    line.className=kind==="error"?"text-red-400":kind==="usage"?"text-cyan-400":kind==="complete"?"text-emerald-400":"text-slate-600 dark:text-gray-300";
    line.textContent=`[${new Date().toLocaleTimeString()}] ${message}`;
    terminal.appendChild(line); terminal.scrollTop=terminal.scrollHeight;
}
let activeOnDemandDraftId = null;
let onDemandAssetObjectUrl = null;

function clearOnDemandDraftPreview() {
    activeOnDemandDraftId = null;
    if (onDemandAssetObjectUrl) {
        URL.revokeObjectURL(onDemandAssetObjectUrl);
        onDemandAssetObjectUrl = null;
    }
    const copy = document.getElementById("ondemand-preview-copy");
    const scheduleAt = document.getElementById("ondemand-schedule-at");
    const assetPreview = document.getElementById("ondemand-asset-preview");
    const layoutBadge = document.getElementById("ondemand-layout-badge");
    if (copy) { copy.value = ""; copy.disabled = true; }
    if (scheduleAt) { scheduleAt.value = ""; scheduleAt.disabled = true; }
    if (assetPreview) { assetPreview.removeAttribute("src"); assetPreview.classList.add("hidden"); }
    if (layoutBadge) layoutBadge.textContent = "CairoSVG layout · awaiting draft";
    for (const id of ["ondemand-save-draft", "ondemand-schedule", "ondemand-publish"]) {
        const button = document.getElementById(id);
        if (button) button.disabled = true;
    }
}

function selectedOnDemandPlatforms() {
    return [...document.querySelectorAll("input[name='target_platform']:checked")].map(input => input.value);
}

function generateTrendingHashtags() {
    const prompt = document.getElementById("ondemand-prompt")?.value || "";
    const audience = document.getElementById("ondemand-audience")?.value || "";
    const tone = document.getElementById("ondemand-tone")?.value || "";
    const words = `${prompt} ${audience} ${tone}`.match(/[A-Za-z][A-Za-z0-9]*/g) || [];
    const ignored = new Set(["with", "from", "that", "this", "into", "about", "your", "post", "and", "the", "for"]);
    const tags = [...new Set(words
        .map(word => word.toLowerCase())
        .filter(word => word.length > 3 && !ignored.has(word))
        .map(word => `#${word.charAt(0).toUpperCase()}${word.slice(1)}`))].slice(0, 4);
    tags.push("#DigitalMarketing", "#ThoughtLeadership");
    const output = document.getElementById("ondemand-hashtags");
    if (output) output.value = [...new Set(tags)].slice(0, 6).join(" ");
}

async function showOnDemandDraft(draft) {
    if (!draft?.id) return;
    activeOnDemandDraftId = Number(draft.id);
    const copy = document.getElementById("ondemand-preview-copy");
    const scheduleAt = document.getElementById("ondemand-schedule-at");
    const layoutBadge = document.getElementById("ondemand-layout-badge");
    const assetPreview = document.getElementById("ondemand-asset-preview");
    if (copy) {
        copy.value = draft.body || "";
        copy.disabled = false;
    }
    if (scheduleAt) scheduleAt.disabled = false;
    if (layoutBadge) layoutBadge.textContent = `CairoSVG layout · ${draft.aspect_ratio || "4:5"} asset ready`;
    for (const id of ["ondemand-save-draft", "ondemand-schedule", "ondemand-publish"]) {
        const button = document.getElementById(id);
        if (button) button.disabled = false;
    }
    if (assetPreview) {
        if (onDemandAssetObjectUrl) URL.revokeObjectURL(onDemandAssetObjectUrl);
        assetPreview.classList.add("hidden");
        try {
            const token = localStorage.getItem("token") || sessionStorage.getItem("token") || localStorage.getItem("vanguard_token") || "";
            const response = await fetch(`/api/drafts/${activeOnDemandDraftId}/asset`, {
                headers: {
                    "Authorization": token ? `Bearer ${token}` : "",
                    "X-Workspace-Id": getActiveWorkspaceId()
                }
            });
            if (!response.ok) throw new Error(`Visual preview unavailable (HTTP ${response.status})`);
            onDemandAssetObjectUrl = URL.createObjectURL(await response.blob());
            assetPreview.src = onDemandAssetObjectUrl;
            assetPreview.classList.remove("hidden");
        } catch (error) {
            showToast(error.message, "warning");
        }
    }
}

async function saveOnDemandDraft() {
    if (!activeOnDemandDraftId) return showToast("Generate a campaign draft first.", "error");
    const body = document.getElementById("ondemand-preview-copy")?.value || "";
    try {
        const result = await api(`/api/drafts/${activeOnDemandDraftId}/edit`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ body })
        });
        showToast(result.is_violation ? "Draft saved but flagged by brand-safety checks." : "Campaign draft saved.", result.is_violation ? "warning" : "success");
        await fetchOnDemandHistory();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function scheduleOnDemandDraft() {
    if (!activeOnDemandDraftId) return showToast("Generate a campaign draft first.", "error");
    const scheduleAt = document.getElementById("ondemand-schedule-at")?.value;
    if (!scheduleAt) return showToast("Choose a future date and time before scheduling.", "error");
    try {
        await api(`/api/drafts/${activeOnDemandDraftId}/edit`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ body: document.getElementById("ondemand-preview-copy")?.value || "" })
        });
        await api(`/api/drafts/${activeOnDemandDraftId}/schedule`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ scheduled_at: scheduleAt })
        });
        showToast("Campaign draft scheduled for the Autopilot queue.", "success");
        await fetchOnDemandHistory();
        await fetchApprovalCount();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function publishOnDemandDraft() {
    if (!activeOnDemandDraftId) return showToast("Generate a campaign draft first.", "error");
    const platforms = selectedOnDemandPlatforms().filter(platform => ["linkedin", "x", "instagram"].includes(platform));
    if (!platforms.length) return showToast("Select LinkedIn, X, or Instagram for direct publishing. YouTube copy remains staged until a video asset is attached.", "error");
    try {
        await api(`/api/drafts/${activeOnDemandDraftId}/edit`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ body: document.getElementById("ondemand-preview-copy")?.value || "" })
        });
        const result = await api(`/api/drafts/${activeOnDemandDraftId}/publish`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ platforms })
        });
        const published = (result.results || []).filter(item => item.status === "PUBLISHED" || item.status === "dry_run").length;
        showToast(`${published} destination(s) accepted the campaign.`, "success");
        await fetchOnDemandHistory();
        await fetchApprovalCount();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function streamOnDemandGeneration(event) {
    event.preventDefault();
    const promptText=document.getElementById("ondemand-prompt").value.trim();
    const format=document.querySelector("input[name='media_format']:checked")?.value==="video"?"video":"infographic";
    const aspectRatio=document.getElementById("ondemand-aspect-ratio")?.value || "4:5";
    const campaignName=document.getElementById("ondemand-campaign-name")?.value.trim() || "";
    if (!promptText) return;
    const button=document.getElementById("ondemand-submit"), terminal=document.getElementById("ondemand-console");
    const state=document.getElementById("ondemand-generation-status"), usage=document.getElementById("ondemand-token-usage");
    const originalButtonContent=button.innerHTML;
    const platforms=selectedOnDemandPlatforms();
    if (!platforms.length) return showToast("Select at least one target destination.", "error");
    button.disabled=true; button.innerHTML='<span class="inline-flex items-center gap-2"><span class="animate-spin">⟳</span> Generating campaign…</span>'; state.textContent="RUNNING"; usage.textContent="Tokens used: waiting for provider usage";
    terminal.replaceChildren(); appendTerminalLine(`postall@engine:~$ generate ${promptText}`,"info");
    try {
        const activeWs = getActiveWorkspaceId();
        const token = localStorage.getItem("token") || sessionStorage.getItem("token") || localStorage.getItem("vanguard_token") || "";
        const response=await fetch("/api/generate/on-demand/stream",{
            method:"POST",
            headers:{
                "Content-Type":"application/json",
                "X-Workspace-Id": activeWs,
                "Authorization": token ? `Bearer ${token}` : ""
            },
            body:JSON.stringify({
                prompt:promptText,
                format,
                platforms,
                tone:document.getElementById("ondemand-tone")?.value || "",
                target_audience:document.getElementById("ondemand-audience")?.value.trim() || "",
                call_to_action:document.getElementById("ondemand-cta")?.value || "",
                hashtags:document.getElementById("ondemand-hashtags")?.value.trim() || "",
                aspect_ratio:aspectRatio,
                campaign_name:campaignName
            })
        });
        if (!response.ok) {
            const payload=await response.json().catch(()=>({}));
            throw new Error(payload.detail || `Generation failed (${response.status})`);
        }
        if (!response.body) throw new Error("Streaming is not supported by this browser.");
        const reader=response.body.getReader(), decoder=new TextDecoder();
        let buffer="", completed=false;
        while (true) {
            const {value,done}=await reader.read();
            if (done) break;
            buffer+=decoder.decode(value,{stream:true});
            const events=buffer.split("\n\n"); buffer=events.pop() || "";
            for (const raw of events) {
                const dataLine=raw.split("\n").find(line=>line.startsWith("data: "));
                if (!dataLine) continue;
                const data=JSON.parse(dataLine.slice(6));
                appendTerminalLine(data.message,data.type);
                if (data.type==="usage") usage.textContent=data.usage_reported ? `Tokens used: ${Number(data.total_tokens||0).toLocaleString()} (${Number(data.prompt_tokens||0).toLocaleString()} prompt / ${Number(data.output_tokens||0).toLocaleString()} output)` : "Provider did not report token usage";
                if (data.type==="error") throw new Error(data.message);
                if (data.type==="complete") {
                    completed=true;
                    await showOnDemandDraft(data.draft);
                    if (usage.textContent.includes("waiting")) usage.textContent="No cloud token usage (local engine or usage not reported)";
                }
            }
        }
        if (!completed) throw new Error("Generation stream ended before a completion event.");
        state.textContent="COMPLETE"; showToast("Draft and infographic generated"); fetchOnDemandHistory(); fetchModelUsage(); fetchApprovalCount();
    } catch(error) {
        state.textContent="FAILED"; if (usage.textContent.includes("waiting")) usage.textContent="Token usage unavailable"; appendTerminalLine(error.message,"error"); showToast(error.message,"error");
    } finally {
        button.disabled=false; button.innerHTML=originalButtonContent;
    }
}
// Legacy polling removed. Handled by masterPulse().

/* ==============================================================================
   TRENDING RADAR ENGINE & RSS SYNTHESIS CONTROLLER
   ============================================================================== */
let currentTrendingCategory = "cybersecurity";
let trendingArticlesCache = {};
let availableTrendingCategories = [];

async function loadTrendingCategories() {
    const pillsContainer = document.getElementById("trending-category-pills");
    if (!pillsContainer) return;
    try {
        const res = await api("/api/trending/categories");
        if (res && res.categories && res.categories.length > 0) {
            availableTrendingCategories = res.categories;
            if (!availableTrendingCategories.some(c => c.id === currentTrendingCategory)) {
                currentTrendingCategory = availableTrendingCategories[0].id;
            }
            pillsContainer.innerHTML = availableTrendingCategories.map(cat => {
                const isActive = cat.id === currentTrendingCategory;
                const icon = cat.icon || "📰";
                const countBadge = (cat.feed_count !== undefined) 
                    ? `<span class="text-[10px] font-mono px-1.5 py-0.2 bg-black/20 dark:bg-white/10 rounded-full opacity-75">${cat.feed_count}</span>` 
                    : "";
                return `
                    <button type="button" onclick="selectTrendingCategory('${cat.id}')" data-category="${cat.id}" class="trending-cat-pill ${isActive ? 'active' : ''} px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap">
                        <span>${icon}</span>
                        <span>${esc(cat.label)}</span>
                        ${countBadge}
                    </button>
                `;
            }).join("");
        }
    } catch (e) {
        console.warn("Failed to load dynamic trending categories:", e);
    }
}

async function fetchTrendingArticles(category, forceRefresh = false) {
    const cat = category || currentTrendingCategory || "cybersecurity";
    currentTrendingCategory = cat;

    // Update active pill indicator
    document.querySelectorAll(".trending-cat-pill").forEach(p => {
        const isActive = p.getAttribute("data-category") === cat;
        p.classList.toggle("active", isActive);
    });

    const container = document.getElementById("trending-feed-container");
    if (!container) return;

    if (!forceRefresh && trendingArticlesCache[cat] && trendingArticlesCache[cat].length > 0) {
        renderTrendingGrid(trendingArticlesCache[cat]);
        return;
    }

    container.innerHTML = `
        <div class="col-span-full py-16 flex flex-col items-center justify-center text-center">
            <div class="w-10 h-10 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mb-3"></div>
            <p class="text-xs font-mono text-amber-400">Scanning real-time RSS intelligence feeds...</p>
            <p class="text-[11px] text-slate-500 mt-1">Connecting to dynamic feeds and parsing updates</p>
        </div>
    `;

    const icon = document.getElementById("trending-refresh-icon");
    if (icon) icon.classList.add("animate-spin");

    try {
        const res = await api(`/api/trending/articles?category=${encodeURIComponent(cat)}`);
        const articles = res.articles || [];
        trendingArticlesCache[cat] = articles;
        renderTrendingGrid(articles);
    } catch (err) {
        container.innerHTML = `
            <div class="col-span-full py-12 px-6 rounded-xl border border-rose-500/30 bg-rose-500/5 text-center">
                <p class="text-sm font-bold text-rose-400 mb-1">Failed to fetch trending articles</p>
                <p class="text-xs text-slate-400">${esc(err.message || "Network error fetching feed")}</p>
                <button onclick="fetchTrendingArticles('${cat}', true)" class="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs transition-colors">
                    Try Again
                </button>
            </div>
        `;
    } finally {
        if (icon) icon.classList.remove("animate-spin");
    }
}

function selectTrendingCategory(catId) {
    currentTrendingCategory = catId;
    document.querySelectorAll(".trending-cat-pill").forEach(p => {
        p.classList.toggle("active", p.getAttribute("data-category") === catId);
    });
    fetchTrendingArticles(catId, false);
}

function refreshTrendingFeed(force = true) {
    if (force && currentTrendingCategory) {
        delete trendingArticlesCache[currentTrendingCategory];
    }
    loadTrendingCategories();
    fetchTrendingArticles(currentTrendingCategory, true);
}

function renderTrendingGrid(articles) {
    const container = document.getElementById("trending-feed-container");
    if (!container) return;

    if (!articles || articles.length === 0) {
        container.innerHTML = `
            <div class="col-span-full py-16 text-center rounded-xl border border-slate-800 bg-[#0f172a]/60">
                <svg class="w-10 h-10 mx-auto text-slate-600 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><circle cx="12" cy="12" r="10" stroke-width="2"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" fill="currentColor"/></svg>
                <h4 class="text-sm font-bold text-slate-400">No active stories available in this category right now.</h4>
                <p class="text-xs text-slate-500 mt-1">Please try refreshing or select another industry category above.</p>
            </div>
        `;
        return;
    }

    const catBadgeMap = {
        cybersecurity: { label: "Cybersecurity", bg: "bg-rose-500/10 text-rose-400 border-rose-500/20" },
        technology: { label: "Technology", bg: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
        ai_data: { label: "AI & ML", bg: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
        business_finance: { label: "Business", bg: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
        fashion_lifestyle: { label: "Fashion", bg: "bg-pink-500/10 text-pink-400 border-pink-500/20" }
    };
    const catInfo = catBadgeMap[currentTrendingCategory] || { label: currentTrendingCategory.replace(/_/g, ' ').toUpperCase(), bg: "bg-amber-500/10 text-amber-400 border-amber-500/20" };

    container.innerHTML = articles.map(art => {
        const titleSafe = esc(art.title || "Untitled");
        const summarySafe = esc(art.summary || "No summary provided.");
        const sourceSafe = esc(art.source || "Feed Source");
        const publishedSafe = esc(art.published || "Recently");
        const linkSafe = esc(art.link || "#");

        const safeDataTitle = encodeURIComponent(art.title || "");
        const safeDataSummary = encodeURIComponent(art.summary || "");
        const safeDataSource = encodeURIComponent(art.source || "");

        return `
            <div class="trending-card p-5 group flex flex-col justify-between">
                <div>
                    <!-- Card Header: Category & Relative Date -->
                    <div class="flex items-center justify-between gap-2 mb-3">
                        <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${catInfo.bg}">
                            ${catInfo.label}
                        </span>
                        <div class="flex items-center gap-1.5 text-[10px] font-mono text-slate-500">
                            <svg class="w-3 h-3 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><circle cx="12" cy="12" r="10" stroke-width="2"/><path stroke-width="2" d="M12 6v6l4 2"/></svg>
                            <span>${publishedSafe}</span>
                        </div>
                    </div>

                    <!-- Source -->
                    <div class="text-[11px] font-semibold text-amber-500/90 mb-1.5 flex items-center gap-1.5">
                        <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                        <span>${sourceSafe}</span>
                    </div>

                    <!-- Headline -->
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white group-hover:text-amber-400 transition-colors mb-2 leading-snug line-clamp-2">
                        <a href="${linkSafe}" target="_blank" rel="noopener noreferrer" class="hover:underline" title="${titleSafe}">
                            ${titleSafe}
                        </a>
                    </h3>

                    <!-- Excerpt -->
                    <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4 trending-line-clamp-2">
                        ${summarySafe}
                    </p>
                </div>

                <!-- Footer Action Buttons -->
                <div class="pt-3 border-t border-slate-200/60 dark:border-gray-800/60 flex items-center justify-between gap-3">
                    <a href="${linkSafe}" target="_blank" rel="noopener noreferrer" class="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 transition-colors">
                        <span>Source ↗</span>
                    </a>
                    <button type="button" onclick="synthesizePostFromTrending('${safeDataTitle}', '${safeDataSummary}', '${safeDataSource}')" class="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs shadow transition-all flex items-center gap-1.5 flex-shrink-0 active:scale-95">
                        <span>⚡ Synthesize Post</span>
                    </button>
                </div>
            </div>
        `;
    }).join("");
}

function synthesizePostFromTrending(encTitle, encSummary, encSource) {
    const title = decodeURIComponent(encTitle || "");
    const summary = decodeURIComponent(encSummary || "");
    const source = decodeURIComponent(encSource || "");

    // 1. Switch active dashboard tab to ondemand
    switchTab("ondemand");

    // 2. Pre-fill On Demand topic input field
    const generatedPrompt = `Write an engaging, insightful LinkedIn breakdown on: "${title}". Core context: ${summary}. Discuss the practical impact and takeaways for industry professionals.`;

    const promptInput = document.getElementById("prompt-input") || document.getElementById("ondemand-prompt");
    if (promptInput) {
        promptInput.value = generatedPrompt;
        promptInput.focus();
        promptInput.dispatchEvent(new Event("input", { bubbles: true }));
    }

    // 3. Flash non-blocking toast
    showToast("Trending topic loaded into Content Studio", "success");
}

/* ==============================================================================
   TRENDING SOURCES & RSS FEED CONFIGURATION MODAL CONTROLLERS
   ============================================================================== */

function openManageTrendingFeedsModal() {
    const modal = document.getElementById("modal-manage-trending-feeds");
    if (!modal) return;
    modal.classList.remove("hidden");
    loadTrendingSourcesTable();
}

function closeManageTrendingFeedsModal() {
    const modal = document.getElementById("modal-manage-trending-feeds");
    if (modal) modal.classList.add("hidden");
}

async function loadTrendingSourcesTable() {
    const tbody = document.getElementById("trending-sources-tbody");
    const countBadge = document.getElementById("trending-sources-count");
    if (!tbody) return;
    tbody.innerHTML = `<tr><td colspan="5" class="py-6 text-center text-slate-400 italic">Loading configured feeds...</td></tr>`;
    try {
        const res = await api("/api/trending/sources");
        const sources = res.sources || [];
        if (countBadge) countBadge.textContent = `${sources.length} active/configured feeds`;
        if (sources.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="py-8 text-center text-slate-400 italic">No RSS feeds configured yet. Add your first feed above.</td></tr>`;
            return;
        }
        tbody.innerHTML = sources.map(s => {
            const isActive = !!s.is_active;
            const toggleBadge = isActive
                ? `<button type="button" onclick="toggleTrendingSourceAction(${s.id}, false)" class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20">Active</button>`
                : `<button type="button" onclick="toggleTrendingSourceAction(${s.id}, true)" class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-500/10 text-slate-400 border border-slate-500/30 hover:bg-slate-500/20">Paused</button>`;
            const feedUrlDisplay = esc(s.feed_url.length > 40 ? s.feed_url.substring(0, 37) + "..." : s.feed_url);
            return `
                <tr class="hover:bg-slate-500/5 transition-colors">
                    <td class="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">
                        <span class="px-2 py-0.5 rounded text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20">${esc(s.category_label || s.category_id)}</span>
                    </td>
                    <td class="py-2.5 px-3 font-medium">${esc(s.feed_name)}</td>
                    <td class="py-2.5 px-3 text-slate-400 font-mono text-[10px]">
                        <a href="${esc(s.feed_url)}" target="_blank" rel="noopener noreferrer" class="hover:text-amber-400 hover:underline" title="${esc(s.feed_url)}">${feedUrlDisplay} ↗</a>
                    </td>
                    <td class="py-2.5 px-3 text-center">${toggleBadge}</td>
                    <td class="py-2.5 px-3 text-right">
                        <button type="button" onclick="deleteTrendingSourceAction(${s.id})" class="text-rose-500 hover:text-rose-400 text-xs px-2 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 transition-colors">Delete</button>
                    </td>
                </tr>
            `;
        }).join("");
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="5" class="py-6 text-center text-rose-400">Error loading feeds: ${esc(e.message)}</td></tr>`;
    }
}

async function submitAddTrendingSource(e) {
    e.preventDefault();
    const catLabel = (document.getElementById("new-feed-cat-label")?.value || "").trim();
    const catId = (document.getElementById("new-feed-cat-id")?.value || "").trim().toLowerCase();
    const feedName = (document.getElementById("new-feed-name")?.value || "").trim();
    const feedUrl = (document.getElementById("new-feed-url")?.value || "").trim();

    if (!catLabel || !catId || !feedName || !feedUrl) {
        showToast("Please fill in all category and feed fields", "error");
        return;
    }

    const btn = document.getElementById("btn-save-trending-feed");
    if (btn) { btn.disabled = true; btn.textContent = "Saving..."; }

    try {
        const res = await api("/api/trending/sources", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                category_id: catId,
                category_label: catLabel,
                feed_name: feedName,
                feed_url: feedUrl
            })
        });
        showToast(res.message || "Feed added successfully", "success");
        document.getElementById("form-add-trending-source")?.reset();
        await loadTrendingSourcesTable();
        await loadTrendingCategories();
    } catch (err) {
        showToast(err.message || "Failed to add feed", "error");
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = "<span>Save Feed Source</span>"; }
    }
}

async function deleteTrendingSourceAction(sourceId) {
    if (!confirm("Are you sure you want to remove this RSS feed source?")) return;
    try {
        await api(`/api/trending/sources/${sourceId}`, { method: "DELETE" });
        showToast("RSS feed source deleted", "success");
        await loadTrendingSourcesTable();
        await loadTrendingCategories();
    } catch (e) {
        showToast(e.message || "Failed to delete source", "error");
    }
}

async function toggleTrendingSourceAction(sourceId, newActiveState) {
    try {
        await api(`/api/trending/sources/${sourceId}/toggle`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ is_active: !!newActiveState })
        });
        showToast(`Feed source ${newActiveState ? 'activated' : 'paused'}`, "success");
        await loadTrendingSourcesTable();
        await loadTrendingCategories();
    } catch (e) {
        showToast(e.message || "Failed to toggle source", "error");
    }
}

/* ==============================================================================
   UNIVERSAL CAMPAIGN DOCUMENT INGESTION CONTROLLERS (STEP 4)
   ============================================================================== */

let selectedCampaignFile = null;

function openImportDocumentModal(trackNameOrId = '') {
    const modal = document.getElementById("modal-import-campaign-document");
    if (!modal) return;
    
    selectedCampaignFile = null;
    const fileInput = document.getElementById("import-doc-file-input");
    if (fileInput) fileInput.value = "";
    
    const dropzoneLabel = document.getElementById("dropzone-label");
    const dropzoneSub = document.getElementById("dropzone-sub");
    if (dropzoneLabel) dropzoneLabel.textContent = "Click or Drag & Drop Document Here";
    if (dropzoneSub) dropzoneSub.textContent = "Supports PDF, DOCX, XLSX, CSV, and Plain Text (up to 25MB)";
    
    const trackInput = document.getElementById("import-doc-track-name");
    if (trackInput) {
        if (typeof trackNameOrId === "number" || (!isNaN(trackNameOrId) && trackNameOrId !== '')) {
            const courseObj = (window.currentCoursesList || []).find(c => Number(c.id) === Number(trackNameOrId));
            trackInput.value = courseObj ? courseObj.name : "";
        } else {
            trackInput.value = trackNameOrId || "";
        }
    }
    
    const manualText = document.getElementById("import-doc-manual-text");
    if (manualText) manualText.value = "";
    
    const progressContainer = document.getElementById("import-doc-progress");
    if (progressContainer) progressContainer.classList.add("hidden");
    
    const submitBtn = document.getElementById("btn-submit-doc-import");
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `<span>Ingest & Extract Topics</span>`;
    }
    
    modal.classList.remove("hidden");
    initDocumentDropzone();
}

function closeImportDocumentModal() {
    const modal = document.getElementById("modal-import-campaign-document");
    if (modal) modal.classList.add("hidden");
}

function handleDocumentFileSelected(files) {
    if (!files || !files[0]) return;
    selectedCampaignFile = files[0];
    
    const dropzoneLabel = document.getElementById("dropzone-label");
    const dropzoneSub = document.getElementById("dropzone-sub");
    if (dropzoneLabel) dropzoneLabel.textContent = `📄 ${selectedCampaignFile.name}`;
    if (dropzoneSub) dropzoneSub.textContent = `${(selectedCampaignFile.size / 1024).toFixed(1)} KB — Document ready for AI ingestion`;
    
    const trackInput = document.getElementById("import-doc-track-name");
    if (trackInput && !trackInput.value.trim()) {
        const baseName = selectedCampaignFile.name
            .replace(/\.[^/.]+$/, "")
            .replace(/[_-]+/g, " ")
            .trim();
        trackInput.value = baseName.replace(/\b\w/g, l => l.toUpperCase());
    }
}

function initDocumentDropzone() {
    const dropzone = document.getElementById("doc-dropzone");
    if (!dropzone || dropzone._hasListeners) return;
    dropzone._hasListeners = true;
    
    ['dragenter', 'dragover'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.add("border-indigo-500", "bg-indigo-500/10");
        }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.remove("border-indigo-500", "bg-indigo-500/10");
        }, false);
    });
    
    dropzone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        if (dt && dt.files && dt.files.length > 0) {
            handleDocumentFileSelected(dt.files);
        }
    }, false);
}

async function submitImportCampaignDocument(event) {
    event.preventDefault();
    const trackInput = document.getElementById("import-doc-track-name");
    const manualText = document.getElementById("import-doc-manual-text");
    const submitBtn = document.getElementById("btn-submit-doc-import");
    const progressContainer = document.getElementById("import-doc-progress");
    const progressBar = document.getElementById("import-progress-bar");
    const progressMsg = document.getElementById("import-progress-msg");
    
    let file = selectedCampaignFile;
    const manualVal = manualText ? manualText.value.trim() : "";
    const trackName = trackInput ? trackInput.value.trim() : "";
    
    if (!file && manualVal) {
        const filename = (trackName ? trackName.replace(/[^a-z0-9]+/gi, "_") : "Campaign_Topics") + ".txt";
        file = new File([manualVal], filename, { type: "text/plain" });
    }
    
    if (!file) {
        showToast("Please choose a file or paste syllabus/document text", "error");
        return;
    }
    
    if (progressContainer) progressContainer.classList.remove("hidden");
    if (progressBar) progressBar.style.width = "30%";
    if (progressMsg) progressMsg.textContent = "Uploading document and extracting raw text...";
    if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = "Ingesting..."; }
    
    const formData = new FormData();
    formData.append("file", file);
    if (trackName) formData.append("track_name", trackName);
    
    const token = localStorage.getItem("token") || "";
    
    const progressTimer = setTimeout(() => {
        if (progressBar) progressBar.style.width = "70%";
        if (progressMsg) progressMsg.textContent = "Analyzing structure & running persona AI module extraction...";
    }, 1200);
    
    try {
        const response = await fetch("/api/pipelines/import-document", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${token}`
            },
            body: formData
        });
        
        clearTimeout(progressTimer);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || data.message || "Failed to import document");
        }
        
        if (progressBar) progressBar.style.width = "100%";
        if (progressMsg) progressMsg.textContent = `Success! ${data.topics_created || data.total_extracted || 0} modules ingested.`;
        
        showToast(
            `Extracted ${data.topics_created || 0} new topic modules into "${esc(data.track_name || 'Campaign')}"!`,
            "success"
        );
        
        setTimeout(() => {
            closeImportDocumentModal();
            fetchCourses();
            switchTab("modules");
        }, 1200);
    } catch (err) {
        clearTimeout(progressTimer);
        showToast(err.message || "Document ingestion failed", "error");
        if (progressMsg) progressMsg.textContent = `Error: ${err.message}`;
        if (progressBar) progressBar.style.width = "0%";
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `<span>Ingest & Extract Topics</span>`;
        }
    }
}

/* ==============================================================================
   BUG 1: CONTENT PIPELINES IMPORT DOCUMENT MODAL CONTROLLERS & EVENT BINDINGS
   ============================================================================== */
function openImportDocModal(defaultTrack = "") {
    const modal = document.getElementById("modal-import-document") || document.getElementById("modal-import-campaign-document");
    if (!modal) return;
    const trackInput = document.getElementById("import-track-name") || document.getElementById("import-doc-track-name");
    const fileInput = document.getElementById("import-file-input") || document.getElementById("import-doc-file-input");
    const progress = document.getElementById("import-upload-progress") || document.getElementById("import-doc-progress");
    const submitBtn = document.getElementById("btn-submit-import") || document.getElementById("btn-submit-doc-import");

    if (trackInput) trackInput.value = defaultTrack || "";
    if (fileInput) fileInput.value = "";
    if (progress) progress.classList.add("hidden");
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = "Start Extraction";
    }
    modal.classList.remove("hidden");
}

function closeImportDocModal() {
    const m1 = document.getElementById("modal-import-document");
    if (m1) m1.classList.add("hidden");
    const m2 = document.getElementById("modal-import-campaign-document");
    if (m2) m2.classList.add("hidden");
}

async function handleImportDocSubmit(e) {
    if (e) e.preventDefault();
    const modal = document.getElementById("modal-import-document") || document.getElementById("modal-import-campaign-document");
    const fileInput = document.getElementById("import-file-input") || document.getElementById("import-doc-file-input");
    const trackInput = document.getElementById("import-track-name") || document.getElementById("import-doc-track-name");
    const progress = document.getElementById("import-upload-progress") || document.getElementById("import-doc-progress");
    const submitBtn = document.getElementById("btn-submit-import") || document.getElementById("btn-submit-doc-import");

    const file = fileInput?.files?.[0] || selectedCampaignFile;
    const trackName = trackInput?.value?.trim() || "";

    if (!file) {
        showToast("Please select a document file to upload (PDF, DOCX, XLSX, CSV, TXT)", "error");
        return;
    }

    if (progress) progress.classList.remove("hidden");
    if (submitBtn) submitBtn.disabled = true;

    const fd = new FormData();
    fd.append("file", file);
    if (trackName) fd.append("track_name", trackName);

    try {
        const res = await api("/api/pipelines/import-document", {
            method: "POST",
            body: fd
        });
        showToast(`Document imported! ${res.topics_created || 0} topics added to track "${res.track_name || trackName || 'Campaign'}"`, "success");
    } catch (err) {
        console.error("Import error:", err);
        showToast(err.message || "Failed to import document", "error");
    } finally {
        if (submitBtn) submitBtn.disabled = false;
        if (progress) progress.classList.add("hidden");
        if (modal) modal.classList.add("hidden");
        if (typeof fetchCourses === "function") fetchCourses();
        if (typeof fetchPipelines === "function") fetchPipelines();
    }
}

/* ==============================================================================
   BUG 4: TRENDING RADAR MANAGE FEEDS MODAL CONTROLLERS & EVENT BINDINGS
   ============================================================================== */
async function openManageFeedsModal() {
    const modal = document.getElementById("modal-manage-feeds") || document.getElementById("modal-manage-trending-feeds");
    if (!modal) return;
    modal.classList.remove("hidden");
    await renderFeedsList();
}

function closeManageFeedsModal() {
    const m1 = document.getElementById("modal-manage-feeds");
    if (m1) m1.classList.add("hidden");
    const m2 = document.getElementById("modal-manage-trending-feeds");
    if (m2) m2.classList.add("hidden");
}

async function renderFeedsList() {
    const container = document.getElementById("feeds-list-container");
    if (!container) return;
    container.innerHTML = `<div class="p-4 text-center text-xs text-slate-400">Loading feeds...</div>`;
    try {
        const res = await api("/api/trending/sources");
        const sources = res.sources || (Array.isArray(res) ? res : []);
        if (!sources.length) {
            container.innerHTML = `<div class="p-4 text-center text-xs text-slate-500">No RSS feed sources configured. Add one below!</div>`;
            return;
        }
        container.innerHTML = sources.map(feed => `
            <div class="flex items-center justify-between p-2.5 rounded-lg bg-[#0B0F17] border border-slate-800 text-xs">
                <div class="min-w-0 flex-1 pr-2">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-slate-200 truncate">${esc(feed.feed_name)}</span>
                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-orange-500/10 text-orange-400 border border-orange-500/20 font-mono">${esc(feed.category_label || feed.category_id)}</span>
                    </div>
                    <div class="text-[10px] text-slate-500 font-mono truncate mt-0.5">${esc(feed.feed_url)}</div>
                </div>
                <button type="button" class="btn-delete-feed text-rose-400 hover:text-rose-300 px-2.5 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-xs font-semibold transition-colors flex-shrink-0" data-feed-id="${feed.id}">
                    Delete
                </button>
            </div>
        `).join("");

        container.querySelectorAll(".btn-delete-feed").forEach(btn => {
            btn.addEventListener("click", async (e) => {
                const feedId = e.currentTarget.getAttribute("data-feed-id");
                if (!feedId) return;
                try {
                    await api(`/api/trending/sources/${feedId}`, { method: "DELETE" });
                    showToast("Feed deleted successfully", "success");
                    await renderFeedsList();
                    if (typeof fetchTrendingCategories === "function") fetchTrendingCategories();
                    if (typeof loadTrendingCategories === "function") loadTrendingCategories();
                } catch (err) {
                    showToast("Failed to delete feed: " + err.message, "error");
                }
            });
        });
    } catch (err) {
        container.innerHTML = `<div class="p-4 text-center text-xs text-rose-400">Failed to load feeds: ${esc(err.message)}</div>`;
    }
}

async function handleAddFeedSubmit(e) {
    if (e) e.preventDefault();
    const catLabelInput = document.getElementById("feed-cat-label");
    const nameInput = document.getElementById("feed-name");
    const urlInput = document.getElementById("feed-url");

    const category_label = catLabelInput?.value?.trim() || "";
    const feed_name = nameInput?.value?.trim() || "";
    const feed_url = urlInput?.value?.trim() || "";

    if (!category_label || !feed_name || !feed_url) {
        showToast("Please fill in category, source name, and RSS feed URL", "error");
        return;
    }

    const category_id = category_label.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || "general";

    try {
        await api("/api/trending/sources", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                category_id,
                category_label,
                feed_name,
                feed_url
            })
        });
        showToast(`Feed "${feed_name}" added to category "${category_label}"`, "success");
        if (catLabelInput) catLabelInput.value = "";
        if (nameInput) nameInput.value = "";
        if (urlInput) urlInput.value = "";
        await renderFeedsList();
        if (typeof fetchTrendingCategories === "function") fetchTrendingCategories();
        if (typeof loadTrendingCategories === "function") loadTrendingCategories();
    } catch (err) {
        showToast("Failed to add feed: " + err.message, "error");
    }
}

// Global wiring setup function invoked both on DOMContentLoaded and immediately
function initEnterpriseModalListeners() {
    // Bug 1: Import buttons & form
    const btnImport = document.getElementById("btn-import-campaign");
    if (btnImport && !btnImport._wired) {
        btnImport._wired = true;
        btnImport.addEventListener("click", () => openImportDocModal());
    }

    const formImportDoc = document.getElementById("form-import-document");
    if (formImportDoc && !formImportDoc._wired) {
        formImportDoc._wired = true;
        formImportDoc.addEventListener("submit", handleImportDocSubmit);
    }

    document.querySelectorAll(".btn-close-import-modal").forEach(btn => {
        if (!btn._wired) {
            btn._wired = true;
            btn.addEventListener("click", closeImportDocModal);
        }
    });

    // Bug 4: Manage Feeds buttons & form
    const btnFeeds = document.getElementById("btn-manage-feeds");
    if (btnFeeds && !btnFeeds._wired) {
        btnFeeds._wired = true;
        btnFeeds.addEventListener("click", () => openManageFeedsModal());
    }

    const formFeed = document.getElementById("form-add-feed");
    if (formFeed && !formFeed._wired) {
        formFeed._wired = true;
        formFeed.addEventListener("submit", handleAddFeedSubmit);
    }

    document.querySelectorAll(".btn-close-feeds-modal").forEach(btn => {
        if (!btn._wired) {
            btn._wired = true;
            btn.addEventListener("click", closeManageFeedsModal);
        }
    });

    // Bug 3: Promo form binding
    const promoForm = document.getElementById("form-launch-promo");
    if (promoForm && !promoForm._wired) {
        promoForm._wired = true;
        promoForm.addEventListener("submit", submitPromoAd);
    }
}

// Delegated click listener for dynamic elements like .btn-import-topic
document.addEventListener("click", (e) => {
    const importTopicBtn = e.target.closest(".btn-import-topic");
    if (importTopicBtn) {
        e.preventDefault();
        const courseName = importTopicBtn.getAttribute("data-course-name") || "";
        openImportDocModal(courseName);
    }
    const closeImportBtn = e.target.closest(".btn-close-import-modal");
    if (closeImportBtn) {
        e.preventDefault();
        closeImportDocModal();
    }
    const closeFeedBtn = e.target.closest(".btn-close-feeds-modal");
    if (closeFeedBtn) {
        e.preventDefault();
        closeManageFeedsModal();
    }
    const manageFeedsBtn = e.target.closest("#btn-manage-feeds, .btn-manage-feeds");
    if (manageFeedsBtn) {
        e.preventDefault();
        openManageFeedsModal();
    }
    const importCampaignBtn = e.target.closest("#btn-import-campaign, .btn-import-campaign");
    if (importCampaignBtn) {
        e.preventDefault();
        openImportDocModal();
    }
    const checkUpdatesBtn = e.target.closest("#btn-check-updates");
    if (checkUpdatesBtn) {
        e.preventDefault();
        checkForUpdates();
    }
    const applyOtaBtn = e.target.closest("#btn-apply-ota");
    if (applyOtaBtn) {
        e.preventDefault();
        applyOtaUpdate();
    }
    const uploadManualBtn = e.target.closest("#btn-upload-manual-update");
    if (uploadManualBtn) {
        e.preventDefault();
        uploadManualUpdate();
    }
});

// Run wire-up immediately and on DOMContentLoaded
initEnterpriseModalListeners();
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initEnterpriseModalListeners);
}

/* ==============================================================================
   ENTERPRISE OVER-THE-AIR (OTA) UPDATE & LIFE-CYCLE CONTROLLER
   ============================================================================== */
let latestOtaReleaseData = null;
let stagedManualPatchFile = null;
let restartCountdownTimer = null;

async function fetchUpdateStatus() {
    try {
        const res = await api("/api/system/update/status");
        latestOtaReleaseData = res;
        const currentVer = res.current_version || res.version || "4.0.0";
        renderVersionOracleStatus(res);
        
        // Installed version cards
        const curVerEls = document.querySelectorAll("#current-installed-version, #ota-current-version");
        curVerEls.forEach(el => {
            el.textContent = currentVer.startsWith("v") ? currentVer : `v${currentVer}`;
        });
        const statusBadge = document.getElementById("ota-status-badge");
        if (statusBadge) statusBadge.textContent = currentVer.startsWith("v") ? currentVer : `v${currentVer}`;

        // Git Commit Hash, Target Arch, and Build Date
        const commitPill = document.getElementById("current-git-commit-pill");
        if (commitPill) {
            const shortCommit = (res.git_commit || "dev").substring(0, 7);
            commitPill.textContent = `commit: ${shortCommit}`;
        }
        const archEl = document.getElementById("current-target-arch");
        if (archEl) {
            archEl.textContent = res.target_arch || "linux-x86_64 (.so native)";
        }
        const buildDateEl = document.getElementById("current-build-date");
        if (buildDateEl) {
            if (res.build_date) {
                try {
                    const bd = new Date(res.build_date);
                    buildDateEl.textContent = `${bd.toLocaleDateString()} ${bd.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
                } catch(e) {
                    buildDateEl.textContent = res.build_date;
                }
            } else {
                buildDateEl.textContent = "Production Core";
            }
        }

        // Channel & Repo settings
        const repoInput = document.getElementById("config-github-repo");
        if (repoInput && !repoInput.value) repoInput.value = res.github_releases_repo || res.github_repo || "";

        const channelSelect = document.getElementById("config-update-channel");
        if (channelSelect) channelSelect.value = res.update_channel || "stable";

        const patPill = document.getElementById("github-pat-status-pill");
        if (patPill) {
            if (res.has_pat) {
                patPill.textContent = `PAT Configured (${res.pat_masked})`;
                patPill.className = "px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
            } else {
                patPill.textContent = "Public Channel (No PAT)";
                patPill.className = "px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20";
            }
        }

        const autoCheckToggle = document.getElementById("toggle-auto-check");
        if (autoCheckToggle) autoCheckToggle.checked = Boolean(res.auto_check_updates);

        const lastCheckEl = document.getElementById("last-check-timestamp");
        if (lastCheckEl) {
            if (res.last_update_check) {
                try {
                    const d = new Date(res.last_update_check);
                    lastCheckEl.textContent = `Last: ${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
                } catch(e) {
                    lastCheckEl.textContent = `Last: ${res.last_update_check}`;
                }
            } else {
                lastCheckEl.textContent = "Last: Never";
            }
        }

        await fetchOtaAuditLedger();

        return res;
    } catch (err) {
        console.error("fetchUpdateStatus error:", err);
        return null;
    }
}

function renderVersionOracleStatus(status) {
    const panel = document.getElementById("staged-ota-panel");
    const heading = document.getElementById("ota-banner-heading");
    const subheading = document.getElementById("ota-banner-subheading");
    const changelog = document.getElementById("ota-changelog-content");
    const navBadge = document.getElementById("nav-update-badge");
    const applyButton = document.getElementById("btn-hot-patch-now");
    const applyFooter = applyButton?.parentElement;
    const progress = document.getElementById("ota-live-progress");
    const assetPill = document.getElementById("ota-asset-name-pill");
    if (!panel || !heading || !changelog) return;

    const currentVersion = status.current_version || "4.0.0";
    const latestVersion = status.latest_version || currentVersion;
    const updateAvailable = status.update_available === true;
    const oracleOffline = status.offline === true || status.oracle_reachable === false;
    const applyButtons = [
        document.getElementById("btn-hot-patch-now"),
        document.getElementById("btn-apply-system-update")
    ].filter(Boolean);

    panel.classList.remove("hidden");
    if (applyFooter) applyFooter.classList.toggle("hidden", status.patch_available !== true);
    applyButtons.forEach(button => {
        button.disabled = status.patch_available !== true || button.dataset.applying === "true";
    });
    if (progress) progress.classList.add("hidden");
    if (assetPill) assetPill.classList.add("hidden");
    if (navBadge) navBadge.classList.toggle("hidden", !updateAvailable);
    if (subheading && status.patch_available) {
        subheading.textContent = "A verified application patch is ready. Persistent customer data is protected.";
    } else if (subheading && updateAvailable) {
        subheading.textContent = "A newer version is available, but no automatic patch archive is published.";
    }

    if (oracleOffline) {
        heading.textContent = "Version Oracle is currently unreachable";
        heading.className = "text-base sm:text-lg font-black text-amber-400 flex items-center gap-2";
    } else if (status.oracle_reachable === null || status.state === "checking") {
        heading.textContent = "Checking Version Oracle...";
        heading.className = "text-base sm:text-lg font-black text-slate-400 flex items-center gap-2";
    } else if (updateAvailable) {
        heading.textContent = `Version Oracle Online · Update available: v${latestVersion}`;
        heading.className = "text-base sm:text-lg font-black text-emerald-400 flex items-center gap-2";
    } else {
        heading.textContent = `Version Oracle Online · System is up to date (v${currentVersion})`;
        heading.className = "text-base sm:text-lg font-black text-emerald-400 flex items-center gap-2";
    }

    changelog.replaceChildren();
    if (oracleOffline) {
        const offlineMessage = document.createElement("p");
        offlineMessage.className = "text-amber-300";
        offlineMessage.textContent = status.error || "Could not reach GitHub. Check the network and retry.";
        changelog.appendChild(offlineMessage);
        return;
    }
    if (status.oracle_reachable === null || status.state === "checking") {
        const checkingMessage = document.createElement("p");
        checkingMessage.className = "text-slate-400";
        checkingMessage.textContent = "The Version Oracle check is running in the background.";
        changelog.appendChild(checkingMessage);
        return;
    }

    const list = document.createElement("ul");
    list.className = "list-disc pl-5 space-y-1";
    const entries = Array.isArray(status.changelog) ? status.changelog : [];
    for (const entry of entries) {
        const item = document.createElement("li");
        item.textContent = entry;
        list.appendChild(item);
    }
    if (!entries.length) {
        const item = document.createElement("li");
        item.textContent = "No changelog entries provided.";
        list.appendChild(item);
    }
    changelog.appendChild(list);

    if (updateAvailable && status.update_instructions) {
        const instructionSection = document.createElement("div");
        instructionSection.className = "mt-4 pt-3 border-t border-slate-700";
        const label = document.createElement("p");
        label.className = "mb-2 text-purple-300 font-bold";
        label.textContent = "Container update instructions";
        const code = document.createElement("pre");
        code.className = "overflow-x-auto rounded-lg bg-black/40 p-3 text-emerald-300";
        const command = document.createElement("code");
        command.textContent = status.update_instructions;
        code.appendChild(command);
        const copyButton = document.createElement("button");
        copyButton.type = "button";
        copyButton.className = "mt-2 rounded-lg bg-purple-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-purple-500";
        copyButton.textContent = "Copy update command";
        copyButton.addEventListener("click", async () => {
            try {
                if (navigator.clipboard?.writeText) {
                    await navigator.clipboard.writeText(status.update_instructions);
                } else {
                    const temporaryInput = document.createElement("textarea");
                    temporaryInput.value = status.update_instructions;
                    temporaryInput.setAttribute("readonly", "");
                    temporaryInput.style.position = "fixed";
                    temporaryInput.style.opacity = "0";
                    document.body.appendChild(temporaryInput);
                    temporaryInput.select();
                    const copied = document.execCommand("copy");
                    temporaryInput.remove();
                    if (!copied) throw new Error("Clipboard access is not available in this browser.");
                }
                showToast("Update command copied to clipboard.", "success");
            } catch (error) {
                showToast("Could not copy the update command: " + error.message, "error");
            }
        });
        instructionSection.append(label, code, copyButton);
        changelog.appendChild(instructionSection);
    }
}

async function loadUpdateLedger() {
    try {
        const ledger = await api("/api/system/update/ledger");
        const rows = Array.isArray(ledger) ? ledger : [];
        renderUpdateAuditLedger(rows.map(item => ({
            applied_at: item.applied_date,
            from_version: item.from_version,
            to_version: item.target_version,
            git_commit: "OTA",
            applied_by: "OTA",
            status: item.status,
            details: item.details
        })));
    } catch (err) {
        console.error("fetchOtaAuditLedger error:", err);
        const tbody = document.getElementById("updateAuditLedgerBody");
        if (tbody) tbody.innerHTML = `<tr><td colspan="7" class="py-8 text-center text-rose-400 italic">Could not load OTA audit records.</td></tr>`;
    }
}

function renderUpdateAuditLedger(history) {
    const tbody = document.getElementById("updateAuditLedgerBody");
    if (!tbody) return;

    if (!history || !history.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="py-8 text-center text-slate-400 italic">No update history recorded yet. Patches and migrations will appear here.</td></tr>`;
        return;
    }

    tbody.innerHTML = history.map(item => {
        let displayTime = item.applied_at || "--";
        try {
            const d = new Date(item.applied_at);
            displayTime = `${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        } catch(e) {}

        const statusUpper = (item.status || "SUCCESS").toUpperCase();
        let badgeCls = "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
        if (statusUpper.includes("FAIL")) badgeCls = "bg-rose-500/10 text-rose-400 border-rose-500/20";
        if (statusUpper.includes("ROLL")) badgeCls = "bg-amber-500/10 text-amber-400 border-amber-500/20";

        const commitHash = item.git_commit ? item.git_commit.substring(0, 7) : "core";

        return `
            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                <td class="py-3 px-3 text-slate-500 dark:text-slate-400 font-mono text-[11px] whitespace-nowrap">
                    ${esc(displayTime)}
                </td>
                <td class="py-3 px-3 font-mono">
                    <span class="text-slate-400">v${esc(item.from_version || "4.0.0")}</span>
                </td>
                <td class="py-3 px-3 font-mono font-bold text-slate-800 dark:text-slate-200">
                    <span class="text-purple-400">v${esc(item.to_version || "--")}</span>
                </td>
                <td class="py-3 px-3 font-mono text-[11px]">
                    <span class="px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">${esc(commitHash)}</span>
                </td>
                <td class="py-3 px-3 text-slate-600 dark:text-slate-400 text-xs">
                    ${esc(item.applied_by || "admin")}
                </td>
                <td class="py-3 px-3">
                    <span class="px-2 py-0.5 rounded font-mono text-[10px] font-bold border ${badgeCls}">
                        ${esc(statusUpper)}
                    </span>
                </td>
                <td class="py-3 px-3 text-slate-500 dark:text-slate-400 text-[11px] max-w-[200px] truncate" title="${esc(item.details || '')}">
                    ${esc(item.details || "--")}
                </td>
            </tr>
        `;
    }).join("");
}

async function fetchOtaAuditLedger() {
    return loadUpdateLedger();
}

async function refreshVersionStatus() {
    return fetchUpdateStatus();
}

async function checkSystemUpdates() {
    const btn = document.getElementById("btn-check-updates-tab") || document.getElementById("btn-check-updates");
    const btnText = document.getElementById("btn-check-updates-text");

    if (btn) btn.disabled = true;
    if (btnText) btnText.innerHTML = `<span class="inline-block animate-spin mr-1">↻</span> Checking GitHub...`;

    try {
        const status = await api("/api/system/update/check", { method: "POST" });
        if (!status) {
            showToast("Failed to query the version oracle.", "error");
            return;
        }
        latestOtaReleaseData = status;
        renderVersionOracleStatus(status);
        await fetchUpdateStatus();
        if (status.oracle_reachable === false || status.offline) {
            showToast("Version Oracle is currently unreachable.", "warning");
            return;
        }
        showToast(
            status.update_available
                ? `Update Available: v${status.latest_version}!`
                : `System is up to date (v${status.current_version}).`,
            status.update_available ? "info" : "success"
        );
        const lastCheckEl = document.getElementById("last-check-timestamp");
        if (lastCheckEl) {
            const checkedAt = status.last_checked_at ? new Date(status.last_checked_at) : new Date();
            lastCheckEl.textContent = `Last: ${checkedAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
        }
    } catch (err) {
        console.error("checkSystemUpdates error:", err);
        showToast("Failed to query update server: " + err.message, "error");
    } finally {
        if (btn) btn.disabled = false;
        if (btnText) btnText.textContent = "Check for Updates";
    }
}

async function applySystemUpdate() {
    if (latestOtaReleaseData?.patch_available !== true) {
        showToast("No verified OTA patch is ready. Check for updates first.", "error");
        return;
    }

    const targetVer = latestOtaReleaseData.latest_version || latestOtaReleaseData.latest || "new release";
    const confirmed = confirm(
        `Postall_V4 will apply update [${targetVer}] and restart the application container.\n\n` +
        `• Only backend/ and frontend/ application files will be updated\n` +
        `• The database, license, uploaded assets, and environment settings are preserved\n` +
        `• The web dashboard will reload automatically in 15 seconds\n\n` +
        `Proceed with hot-patch?`
    );
    if (!confirmed) return;

    const liveProgress = document.getElementById("ota-live-progress");
    const stepText = document.getElementById("ota-progress-step-text");
    const barFill = document.getElementById("ota-progress-bar-fill");
    const percentEl = document.getElementById("ota-progress-percent");
    const applyButtons = [
        document.getElementById("btn-hot-patch-now"),
        document.getElementById("btn-apply-system-update")
    ].filter(Boolean);
    const applyButtonText = document.getElementById("btn-apply-system-update-text");
    applyButtons.forEach(button => {
        button.disabled = true;
        button.dataset.applying = "true";
    });
    if (applyButtonText) applyButtonText.innerHTML = `<span class="inline-block animate-spin mr-1">↻</span> Applying Update...`;

    if (liveProgress) liveProgress.classList.remove("hidden");
    if (stepText) stepText.textContent = "Step 1/4: Downloading verified release package...";
    if (barFill) barFill.style.width = "30%";
    if (percentEl) percentEl.textContent = "30%";

    try {
        await api("/api/system/update/apply", { method: "POST" });
        if (stepText) stepText.textContent = "Update accepted. Applying files and restarting...";
        if (barFill) barFill.style.width = "100%";
        if (percentEl) percentEl.textContent = "100%";
        showToast("Update accepted. The container is restarting.", "success");
        startRestartCountdown(15, `Release ${targetVer} accepted. Reconnecting in`);
    } catch (err) {
        console.error("applySystemUpdate error:", err);
        showToast("OTA update failed: " + err.message, "error");
        if (liveProgress) liveProgress.classList.add("hidden");
        applyButtons.forEach(button => {
            button.dataset.applying = "false";
        });
        if (applyButtonText) applyButtonText.textContent = "Apply Update";
        renderVersionOracleStatus(latestOtaReleaseData);
    }
}

async function confirmAndApplyOtaUpdate() {
    return applySystemUpdate();
}

function handleManualPatchFileSelected(files) {
    if (!files || !files.length) return;
    const file = files[0];
    if (!file.name.toLowerCase().endsWith(".zip")) {
        showToast("Invalid file: Update archive must be a .zip file.", "error");
        return;
    }

    stagedManualPatchFile = file;
    const nameEl = document.getElementById("manual-patch-filename");
    const sizeEl = document.getElementById("manual-patch-filesize");
    const detailsBox = document.getElementById("manual-patch-file-details");

    if (nameEl) nameEl.textContent = file.name;
    if (sizeEl) sizeEl.textContent = `${(file.size / (1024 * 1024)).toFixed(2)} MB`;
    if (detailsBox) detailsBox.classList.remove("hidden");
}

async function confirmAndApplyManualPatch() {
    if (!stagedManualPatchFile) {
        showToast("Please choose a .zip patch archive first.", "error");
        return;
    }

    const confirmed = confirm(
        `Postall_V4 will extract '${stagedManualPatchFile.name}' and restart the application container.\n\n` +
        `• A pre-flight backup will be automatically saved to data/backups/\n` +
        `• Persistent /data, database, and .env are strictly preserved\n` +
        `• The web dashboard will reload automatically in 15 seconds\n\n` +
        `Proceed with manual patch?`
    );
    if (!confirmed) return;

    const btn = document.getElementById("btn-apply-manual-patch");
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="inline-block animate-spin mr-1">↻</span> Uploading & Extracting...`;
    }

    const formData = new FormData();
    formData.append("patch_archive", stagedManualPatchFile);

    try {
        const res = await api("/api/system/update/manual-upload", {
            method: "POST",
            body: formData
        });

        startRestartCountdown(15, `Manual patch '${stagedManualPatchFile.name}' extracted. Reconnecting in`);
    } catch (err) {
        console.error("Manual patch error:", err);
        showToast("Manual patch failed: " + err.message, "error");
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg><span>Apply Manual Patch</span>`;
        }
    }
}

async function saveUpdateConfiguration() {
    const repo = (document.getElementById("config-github-repo")?.value || "").trim();
    const pat = (document.getElementById("config-github-pat")?.value || "").trim();
    const channel = document.getElementById("config-update-channel")?.value || "stable";
    const autoCheck = document.getElementById("toggle-auto-check")?.checked ?? true;

    try {
        await api("/api/system/update/config", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                github_repo: repo,
                github_pat: pat || undefined,
                update_channel: channel,
                auto_check_updates: autoCheck
            })
        });
        showToast("Update channel configuration saved.", "success");
        await fetchUpdateStatus();
    } catch (err) {
        showToast("Failed to save configuration: " + err.message, "error");
    }
}

async function toggleAutoCheckUpdates(checked) {
    try {
        await api("/api/system/update/config", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ auto_check_updates: checked })
        });
        showToast(`Automatic update checks ${checked ? 'enabled' : 'disabled'}.`, "info");
    } catch (err) {
        showToast("Failed to toggle auto check: " + err.message, "error");
    }
}

async function fetchUpdateSnapshots() {
    const tbody = document.getElementById("snapshots-ledger-tbody");
    if (!tbody) return;

    try {
        const res = await api("/api/system/update/snapshots");
        const list = res.snapshots || [];

        if (!list.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="py-8 text-center text-slate-400 italic">No snapshots available in data/backups/ yet. (Snapshots are automatically created before updates).</td></tr>`;
            return;
        }

        tbody.innerHTML = list.map(snap => {
            const sizeMb = (snap.size_bytes / (1024 * 1024)).toFixed(2);
            let displayTime = snap.created_at || "--";
            try {
                const d = new Date(snap.created_at);
                displayTime = `${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
            } catch(e) {}

            return `
                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                    <td class="py-3 px-3 font-mono font-bold text-slate-800 dark:text-slate-200">
                        <div class="flex items-center gap-2">
                            <span class="text-purple-400">📦</span>
                            <span class="truncate max-w-[220px]" title="${esc(snap.filename)}">${esc(snap.filename)}</span>
                        </div>
                    </td>
                    <td class="py-3 px-3">
                        <span class="px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                            ${esc(snap.version || "pre-update")}
                        </span>
                    </td>
                    <td class="py-3 px-3 text-slate-500 dark:text-slate-400 font-mono text-[11px] whitespace-nowrap">
                        ${esc(displayTime)}
                    </td>
                    <td class="py-3 px-3 font-mono text-slate-400">
                        ${sizeMb} MB
                    </td>
                    <td class="py-3 px-3 text-right">
                        <button onclick="confirmRollback('${esc(snap.filename)}')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition-colors inline-flex items-center gap-1">
                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"></path></svg>
                            <span>Rollback</span>
                        </button>
                    </td>
                </tr>
            `;
        }).join("");
    } catch (err) {
        console.error("fetchUpdateSnapshots error:", err);
        tbody.innerHTML = `<tr><td colspan="5" class="py-8 text-center text-rose-400 italic">Error reading snapshots: ${esc(err.message)}</td></tr>`;
    }
}

async function confirmRollback(snapshotFilename) {
    const confirmed = confirm(
        `DANGER: Rollback to snapshot '${snapshotFilename}'?\n\n` +
        `• This will restore application files to this historical point\n` +
        `• Persistent /data and postall.db remain untouched\n` +
        `• Container will immediately reboot upon extraction\n\n` +
        `Execute rollback?`
    );
    if (!confirmed) return;

    try {
        await api("/api/system/update/rollback", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ snapshot_filename: snapshotFilename })
        });

        startRestartCountdown(15, `Rollback to '${snapshotFilename}' applied. Container cycling in`);
    } catch (err) {
        showToast("Rollback failed: " + err.message, "error");
    }
}

function startRestartCountdown(seconds = 15, messagePrefix = "Container cycling in") {
    if (restartCountdownTimer) clearInterval(restartCountdownTimer);

    const modal = document.getElementById("modal-restart-countdown");
    const secondsEl = document.getElementById("countdown-seconds");
    const messageEl = document.getElementById("countdown-modal-message");
    const circle = document.getElementById("countdown-circle-progress");

    if (modal) modal.classList.remove("hidden");
    let remaining = seconds;
    const totalCircumference = 264;

    const updateDisplay = () => {
        if (secondsEl) secondsEl.textContent = remaining;
        if (messageEl) {
            messageEl.textContent = `${messagePrefix} ${remaining} seconds. The dashboard will automatically reload.`;
        }
        if (circle) {
            const fraction = (seconds - remaining) / seconds;
            circle.style.strokeDashoffset = (fraction * totalCircumference).toString();
        }
    };

    updateDisplay();

    restartCountdownTimer = setInterval(() => {
        remaining -= 1;
        if (remaining <= 0) {
            clearInterval(restartCountdownTimer);
            if (secondsEl) secondsEl.textContent = "0";
            if (messageEl) messageEl.textContent = "Reloading application...";
            setTimeout(() => {
                window.location.reload();
            }, 800);
        } else {
            updateDisplay();
        }
    }, 1000);
}

function scrollToBackupsLedger() {
    const el = document.getElementById("section-backups-ledger");
    if (el) el.scrollIntoView({ behavior: "smooth" });
}

function toggleOtaAccordion() {
    const body = document.getElementById("ota-accordion-body");
    const chevron = document.getElementById("ota-accordion-chevron");
    if (!body) return;
    const isHidden = body.classList.contains("hidden");
    if (isHidden) {
        body.classList.remove("hidden");
        if (chevron) chevron.classList.remove("-rotate-90");
    } else {
        body.classList.add("hidden");
        if (chevron) chevron.classList.add("-rotate-90");
    }
}

// Legacy wrappers for automated test suite compatibility
async function applyOtaUpdate() {
    const confirmation = confirm("Ensure no drafts are currently generating. Proceed?");
    if (!confirmation) return;
    const downloadUrl = latestOtaReleaseData ? latestOtaReleaseData.download_url : "";
    try {
        await api("/api/system/update/apply-ota", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ download_url: downloadUrl })
        });
        showToast("Update applied. Container restarting... please refresh in 10 seconds.", "success");
        startRestartCountdown(15);
    } catch(e) {
        showToast("OTA update failed: " + e.message, "error");
    }
}

async function uploadManualUpdate() {
    const confirmation = confirm("Ensure no drafts are currently generating. Proceed?");
    if (!confirmation) return;
    const fileInput = document.getElementById("manual-patch-file-input") || document.getElementById("ota-manual-file");
    if (!fileInput || !fileInput.files.length) return showToast("Please select a .zip update package first.", "error");
    const formData = new FormData();
    formData.append("patch_archive", fileInput.files[0]);
    formData.append("file", fileInput.files[0]);
    try {
        await api("/api/system/update/manual", { method: "POST", body: formData });
        showToast("Update applied. Container restarting... please refresh in 10 seconds.", "success");
        startRestartCountdown(15);
    } catch(e) {
        showToast("Manual update failed: " + e.message, "error");
    }
}

// Global window bindings & backward compatibility
window.fetchUpdateStatus = fetchUpdateStatus;
window.refreshVersionStatus = refreshVersionStatus;
window.loadUpdateLedger = loadUpdateLedger;
window.applySystemUpdate = applySystemUpdate;
window.checkSystemUpdates = checkSystemUpdates;
window.confirmAndApplyOtaUpdate = confirmAndApplyOtaUpdate;
window.handleManualPatchFileSelected = handleManualPatchFileSelected;
window.confirmAndApplyManualPatch = confirmAndApplyManualPatch;
window.saveUpdateConfiguration = saveUpdateConfiguration;
window.toggleAutoCheckUpdates = toggleAutoCheckUpdates;
window.fetchUpdateSnapshots = fetchUpdateSnapshots;
window.confirmRollback = confirmRollback;
window.scrollToBackupsLedger = scrollToBackupsLedger;
window.toggleOtaAccordion = toggleOtaAccordion;
window.checkForUpdates = checkSystemUpdates;
window.applyOtaUpdate = applyOtaUpdate;
window.uploadManualUpdate = uploadManualUpdate;

// Initial silent fetch on script load
if (typeof fetchUpdateStatus === "function") {
    setTimeout(() => { fetchUpdateStatus(); }, 1500);
}


/* ==============================================================================
   Postall_V4 — MASTER PULSE: VISIBILITY-GATED UNIFIED POLLING ENGINE
   Replaces multiple scattered setInterval calls with a single, tab-aware loop.
   All API calls are skipped when the page is hidden to save bandwidth and CPU.
   ============================================================================== */
(function initMasterPulse() {
    const PULSE_INTERVAL_MS = 30000; // 30-second heartbeat

    function masterPulse() {
        // Gate: skip all polling when the browser tab is hidden/background
        if (document.hidden) return;

        // Determine which tab is currently visible
        const activeTab = document.querySelector(".tab-content:not(.hidden)");
        const activeTabId = activeTab ? (activeTab.id || "").replace("tab-", "") : "overview";

        // Always refresh approval badge (sidebar indicator)
        if (typeof fetchApprovalCount === "function") {
            fetchApprovalCount().catch(() => {});
        }

        // Tab-specific refreshes — only poll what the user can actually see
        switch (activeTabId) {
            case "overview":
                if (typeof fetchMetrics === "function") fetchMetrics().catch(() => {});
                if (typeof fetchAutopilotStatus === "function") fetchAutopilotStatus().catch(() => {});
                if (typeof fetchPipeline === "function") fetchPipeline().catch(() => {});
                if (typeof fetchContentKpis === "function") fetchContentKpis().catch(() => {});
                break;
            case "health":
            case "integrations":
                if (typeof fetchIntegrations === "function") fetchIntegrations().catch(() => {});
                break;
            case "approval":
                if (typeof fetchDrafts === "function") fetchDrafts("current").catch(() => {});
                break;
            case "notifications":
                if (typeof fetchNotifications === "function") fetchNotifications().catch(() => {});
                break;
            case "command":
                if (typeof renderTaskQueueMonitor === "function") renderTaskQueueMonitor().catch(() => {});
                break;
            default:
                // For all other tabs, just keep the metrics fresh in the background
                if (typeof fetchMetrics === "function") fetchMetrics().catch(() => {});
        }
    }

    // Start the pulse loop
    setInterval(masterPulse, PULSE_INTERVAL_MS);

    // Also run a pulse immediately when the tab becomes visible again after being hidden
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) {
            masterPulse();
        }
    });
})();


/* ==============================================================================
   Postall_V4 — SETTINGS QUICK-FILTER
   Powers the #settings-nav-filter input to hide/show nav buttons live.
   ============================================================================== */
function filterSettingsNav(query) {
    const nav = document.getElementById("settings-nav");
    if (!nav) return;
    const q = (query || "").trim().toLowerCase();
    const buttons = nav.querySelectorAll("button.settings-nav-btn");
    const groupLabels = nav.querySelectorAll("div[class*='text-[10px]']");

    if (!q) {
        // No filter — show everything
        buttons.forEach(btn => btn.classList.remove("hidden"));
        groupLabels.forEach(lbl => lbl.classList.remove("hidden"));
        return;
    }

    // Track which groups have at least one visible button
    const visibleGroups = new Set();

    buttons.forEach(btn => {
        const text = (btn.textContent || "").toLowerCase();
        const matches = text.includes(q);
        btn.classList.toggle("hidden", !matches);
        if (matches) {
            // Find the preceding group label
            let prev = btn.previousElementSibling;
            while (prev) {
                if (prev.matches("div[class*='text-[10px]']")) {
                    visibleGroups.add(prev);
                    break;
                }
                prev = prev.previousElementSibling;
            }
        }
    });

    // Show/hide group labels based on whether they have visible children
    groupLabels.forEach(lbl => {
        lbl.classList.toggle("hidden", !visibleGroups.has(lbl));
    });
}

// Expose globally for oninput handler
window.filterSettingsNav = filterSettingsNav;
