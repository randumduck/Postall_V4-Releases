"""Postall_V4 - SCIM 2.0 Identity Lifecycle Management Engine (RFC 7643 / RFC 7644)
Provides automated identity provisioning, synchronization, and automated de-provisioning
for Okta, Microsoft Entra ID (Azure AD), CyberArk, PingIdentity, and OneLogin.
"""
import json
import logging
import secrets
import re
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List

from fastapi import APIRouter, Header, HTTPException, Query, Response, status
from pydantic import BaseModel, Field

from backend.database import get_db, hash_password

logger = logging.getLogger("postall.scim")

scim_router = APIRouter(prefix="/scim/v2", tags=["SCIM 2.0 Directory Ingestion"])

# ==============================================================================
# SCIM CONSTANTS & SCHEMAS
# ==============================================================================

SCHEMA_USER = "urn:ietf:params:scim:schemas:core:2.0:User"
SCHEMA_LIST_RESPONSE = "urn:ietf:params:scim:api:messages:2.0:ListResponse"
SCHEMA_ERROR = "urn:ietf:params:scim:api:messages:2.0:Error"
SCHEMA_SERVICE_PROVIDER_CONFIG = "urn:ietf:params:scim:schemas:core:2.0:ServiceProviderConfig"
SCHEMA_RESOURCE_TYPE = "urn:ietf:params:scim:schemas:core:2.0:ResourceType"

def _scim_error(status_code: int, detail: str, scim_type: Optional[str] = None):
    err = {
        "schemas": [SCHEMA_ERROR],
        "status": str(status_code),
        "detail": detail
    }
    if scim_type:
        err["scimType"] = scim_type
    return Response(
        content=json.dumps(err),
        status_code=status_code,
        media_type="application/scim+json"
    )

# ==============================================================================
# SCIM AUTHENTICATION MIDDLEWARE HELPER
# ==============================================================================

def verify_scim_token(authorization: Optional[str] = Header(None)) -> str:
    """Verifies incoming SCIM bearer token against platform configured token or Admin JWT."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="SCIM Bearer Authentication token required.",
            headers={"WWW-Authenticate": 'Bearer realm="Postall_V4 SCIM 2.0"'}
        )
    token = authorization.split(" ", 1)[1].strip()

    # 1. Check database setting scim_token or Vault
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key='scim_token'").fetchone()
    db_token = row["value"] if row and row["value"] else None
    
    # 2. Check settings scim_enabled
    row_en = db.execute("SELECT value FROM settings WHERE key='scim_enabled'").fetchone()
    scim_enabled = row_en["value"] if row_en else "1"
    db.close()

    if scim_enabled in ("0", "false", "disabled", "off"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="SCIM 2.0 interface is disabled on this server.")

    # If scim_token is explicitly configured, match it
    if db_token and secrets.compare_digest(token, db_token):
        return "scim-agent"

    # Alternatively, allow valid admin JWT token
    try:
        from backend.main import current_user, get_user_record
        user_sub = current_user(authorization=authorization)
        user_rec = get_user_record(user_sub)
        if (user_rec.get("role") or "").lower() == "admin":
            return user_sub
    except Exception:
        pass

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid SCIM 2.0 authorization bearer token.",
        headers={"WWW-Authenticate": 'Bearer realm="Postall_V4 SCIM 2.0"'}
    )

# ==============================================================================
# SCIM USER FORMATTER
# ==============================================================================

def user_to_scim_resource(user_row: dict) -> Dict[str, Any]:
    """Converts a database user row into an RFC 7643 SCIM User representation."""
    uid = str(user_row.get("id"))
    username = str(user_row.get("username") or "")
    email = str(user_row.get("email") or "")
    is_active = bool(user_row.get("is_active", 1))
    role = str(user_row.get("role") or "editor").lower()
    created_at = user_row.get("created_at") or datetime.now(timezone.utc).isoformat()
    last_login = user_row.get("last_login_at") or created_at
    external_id = str(user_row.get("external_id") or "")

    res: Dict[str, Any] = {
        "schemas": [SCHEMA_USER],
        "id": uid,
        "userName": username,
        "name": {
            "formatted": username,
            "familyName": username,
            "givenName": username
        },
        "displayName": username,
        "active": is_active,
        "emails": [
            {
                "value": email or f"{username}@local.internal",
                "type": "work",
                "primary": True
            }
        ],
        "roles": [
            {
                "value": role,
                "primary": True
            }
        ],
        "meta": {
            "resourceType": "User",
            "created": created_at,
            "lastModified": last_login,
            "location": f"/scim/v2/Users/{uid}"
        }
    }
    if external_id:
        res["externalId"] = external_id
    return res

# ==============================================================================
# SCIM SPECIFICATION DISCOVERY ENDPOINTS
# ==============================================================================

@scim_router.get("/ServiceProviderConfig")
def get_service_provider_config():
    """RFC 7643 Section 5: Discover SCIM service provider capabilities."""
    return {
        "schemas": [SCHEMA_SERVICE_PROVIDER_CONFIG],
        "documentationUri": "https://github.com/postall/postall/wiki/SCIM-2.0",
        "patch": {"supported": True},
        "bulk": {"supported": False, "maxOperations": 0, "maxPayloadSize": 0},
        "filter": {"supported": True, "maxResults": 200},
        "changePassword": {"supported": False},
        "sort": {"supported": False},
        "etag": {"supported": False},
        "authenticationSchemes": [
            {
                "name": "OAuth Bearer Token",
                "description": "Authentication scheme using standard HTTP Bearer token",
                "specUri": "http://www.rfc-editor.org/info/rfc6750",
                "type": "oauthbearertoken",
                "primary": True
            }
        ]
    }

@scim_router.get("/ResourceTypes")
def get_resource_types():
    """RFC 7643 Section 6: Discover SCIM supported resource types."""
    return [
        {
            "schemas": [SCHEMA_RESOURCE_TYPE],
            "id": "User",
            "name": "User",
            "endpoint": "/scim/v2/Users",
            "description": "Postall_V4 Operator and Author Accounts",
            "schema": SCHEMA_USER
        }
    ]

# ==============================================================================
# SCIM USERS ENDPOINTS (RFC 7644)
# ==============================================================================

@scim_router.get("/Users")
def list_scim_users(
    filter: Optional[str] = Query(None),
    startIndex: int = Query(1, ge=1),
    count: int = Query(50, ge=1, le=200),
    caller=Header(None)
):
    """RFC 7644 Section 3.4.2: List users with filtering (e.g. userName eq "admin")."""
    verify_scim_token(caller)

    db = get_db()
    users_all = [dict(r) for r in db.execute("SELECT * FROM users ORDER BY id ASC").fetchall()]
    db.close()

    # Filter parsing (Simple support for userName eq "..." and emails.value eq "...")
    filtered_users = []
    if filter:
        # Match pattern: userName eq "value" or userName eq 'value'
        match_un = re.search(r'userName\s+eq\s+["\']([^"\']+)["\']', filter, re.IGNORECASE)
        match_em = re.search(r'emails(?:\.value)?\s+eq\s+["\']([^"\']+)["\']', filter, re.IGNORECASE)
        match_ext = re.search(r'externalId\s+eq\s+["\']([^"\']+)["\']', filter, re.IGNORECASE)

        for u in users_all:
            matched = False
            if match_un and (u.get("username", "").lower() == match_un.group(1).lower()):
                matched = True
            elif match_em and (u.get("email", "").lower() == match_em.group(1).lower()):
                matched = True
            elif match_ext and (u.get("external_id", "") == match_ext.group(1)):
                matched = True
            if matched:
                filtered_users.append(u)
    else:
        filtered_users = users_all

    total_results = len(filtered_users)
    offset = startIndex - 1
    page_users = filtered_users[offset : offset + count]

    resources = [user_to_scim_resource(u) for u in page_users]

    return {
        "schemas": [SCHEMA_LIST_RESPONSE],
        "totalResults": total_results,
        "startIndex": startIndex,
        "itemsPerPage": len(resources),
        "Resources": resources
    }

@scim_router.get("/Users/{user_id}")
def get_scim_user(user_id: str, caller=Header(None)):
    """RFC 7644 Section 3.4.1: Retrieve single user by ID."""
    verify_scim_token(caller)

    db = get_db()
    u = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    db.close()

    if not u:
        return _scim_error(404, f"User with id '{user_id}' not found.")

    return user_to_scim_resource(dict(u))

@scim_router.post("/Users", status_code=status.HTTP_201_CREATED)
def create_scim_user(payload: Dict[str, Any], caller=Header(None)):
    """RFC 7644 Section 3.3: Provision a new user from IdP."""
    verify_scim_token(caller)

    username = payload.get("userName")
    if not username:
        return _scim_error(400, "Attribute 'userName' is required.", "invalidValue")

    username = str(username).strip()
    external_id = payload.get("externalId", "")
    active = 1 if payload.get("active", True) else 0

    # Extract email
    email = ""
    emails = payload.get("emails", [])
    if isinstance(emails, list) and emails:
        email = emails[0].get("value", "")

    # Extract role
    role = "editor"
    roles = payload.get("roles", [])
    if isinstance(roles, list) and roles:
        role_val = str(roles[0].get("value", "editor")).lower()
        if role_val in ("admin", "editor", "viewer"):
            role = role_val

    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
    if existing:
        db.close()
        return _scim_error(409, f"User '{username}' already exists.", "uniqueness")

    # Generate cryptographically secure random password hash
    dummy_pass = secrets.token_urlsafe(24)
    hashed_pass = hash_password(dummy_pass)

    now_iso = datetime.now(timezone.utc).isoformat()
    cursor = db.execute(
        """
        INSERT INTO users (username, password_hash, role, email, is_active, external_id, created_at, sso_provider)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'scim')
        """,
        (username, hashed_pass, role, email, active, external_id, now_iso)
    )
    new_id = cursor.lastrowid
    db.commit()

    created_row = dict(db.execute("SELECT * FROM users WHERE id=?", (new_id,)).fetchone())
    db.close()

    logger.info(f"[SCIM 2.0] Successfully provisioned new user '{username}' (ID: {new_id}, Active: {active})")
    return user_to_scim_resource(created_row)

@scim_router.patch("/Users/{user_id}")
def patch_scim_user(user_id: str, payload: Dict[str, Any], caller=Header(None)):
    """RFC 7644 Section 3.5.2: Patch user attributes (notably active=false for de-provisioning)."""
    verify_scim_token(caller)

    db = get_db()
    u = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if not u:
        db.close()
        return _scim_error(404, f"User '{user_id}' not found.")

    operations = payload.get("Operations", [])
    if not isinstance(operations, list):
        db.close()
        return _scim_error(400, "Patch operation format invalid; expected 'Operations' array.", "invalidSyntax")

    updates = []
    params = []

    for op in operations:
        op_type = str(op.get("op", "")).lower()
        path = str(op.get("path", "")).lower()
        val = op.get("value")

        if op_type in ("replace", "add"):
            # Case A: {"op": "replace", "path": "active", "value": false}
            if path == "active" or (isinstance(val, dict) and "active" in val):
                active_bool = val if path == "active" else val.get("active")
                updates.append("is_active = ?")
                params.append(1 if active_bool in (True, 1, "true", "True") else 0)

            # Case B: {"op": "replace", "path": "userName", "value": "new_name"}
            elif path == "username" or (isinstance(val, dict) and "userName" in val):
                un_val = val if path == "username" else val.get("userName")
                updates.append("username = ?")
                params.append(str(un_val).strip())

            # Case C: {"op": "replace", "path": "emails[type eq \"work\"].value", "value": "..."}
            elif "email" in path or (isinstance(val, dict) and "email" in val):
                em_val = val if "email" in path else val.get("email")
                updates.append("email = ?")
                params.append(str(em_val).strip())

            # Case D: role modification
            elif "role" in path or (isinstance(val, dict) and "roles" in val):
                role_val = val if "role" in path else val.get("roles")
                if isinstance(role_val, list) and role_val:
                    role_val = role_val[0].get("value")
                if str(role_val).lower() in ("admin", "editor", "viewer"):
                    updates.append("role = ?")
                    params.append(str(role_val).lower())

    if updates:
        params.append(user_id)
        db.execute(f"UPDATE users SET {', '.join(updates)} WHERE id=?", params)
        db.commit()

    updated_row = dict(db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone())
    db.close()

    logger.info(f"[SCIM 2.0] Patched user ID {user_id}. Active status: {updated_row.get('is_active')}")
    return user_to_scim_resource(updated_row)

@scim_router.put("/Users/{user_id}")
def update_scim_user(user_id: str, payload: Dict[str, Any], caller=Header(None)):
    """RFC 7644 Section 3.5.1: Replace/update entire user record."""
    verify_scim_token(caller)

    db = get_db()
    u = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if not u:
        db.close()
        return _scim_error(404, f"User '{user_id}' not found.")

    username = str(payload.get("userName") or u["username"]).strip()
    active = 1 if payload.get("active", True) else 0

    email = u["email"]
    emails = payload.get("emails", [])
    if isinstance(emails, list) and emails:
        email = emails[0].get("value", "")

    external_id = payload.get("externalId", u["external_id"] if "external_id" in u.keys() else "")

    role = u["role"]
    roles = payload.get("roles", [])
    if isinstance(roles, list) and roles:
        r_val = str(roles[0].get("value", "")).lower()
        if r_val in ("admin", "editor", "viewer"):
            role = r_val

    db.execute(
        "UPDATE users SET username=?, email=?, is_active=?, external_id=?, role=? WHERE id=?",
        (username, email, active, external_id, role, user_id)
    )
    db.commit()
    updated_row = dict(db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone())
    db.close()

    logger.info(f"[SCIM 2.0] Replaced user ID {user_id} via PUT.")
    return user_to_scim_resource(updated_row)

@scim_router.delete("/Users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_scim_user(user_id: str, caller=Header(None)):
    """RFC 7644 Section 3.6: Delete or permanently deactivate user."""
    verify_scim_token(caller)

    db = get_db()
    u = db.execute("SELECT id, username FROM users WHERE id=?", (user_id,)).fetchone()
    if not u:
        db.close()
        return _scim_error(404, f"User '{user_id}' not found.")

    # Never delete the primary 'admin' account; deactivate it if requested
    if u["username"] == "admin":
        db.execute("UPDATE users SET is_active=0 WHERE id=?", (user_id,))
    else:
        db.execute("DELETE FROM users WHERE id=?", (user_id,))
    db.commit()
    db.close()

    logger.info(f"[SCIM 2.0] Deleted user ID {user_id}")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
