"""
Universal Document Ingestion Parser for Postall_V4
===================================================
Extracts high-fidelity plain text from enterprise documents:
- PDF (.pdf) via pypdf
- Word Documents (.docx) via python-docx
- Spreadsheets (.xlsx, .csv) via openpyxl and csv
- Plain Text & Markdown (.txt, .md) via UTF-8 decoding
"""

import csv
import io
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("document_parser")

try:
    import pypdf
except ImportError:
    pypdf = None

try:
    import docx
except ImportError:
    docx = None

try:
    import openpyxl
except ImportError:
    openpyxl = None


def extract_text_from_file(file_bytes: bytes, filename: str, max_chars: int = 60000) -> str:
    """
    Extracts structured, human-readable text from uploaded document bytes.
    Caps extracted text to max_chars to avoid downstream context window blowouts.
    """
    if not file_bytes:
        return ""

    ext = Path(filename).suffix.lower().strip()
    extracted_text = ""

    try:
        if ext == ".pdf":
            extracted_text = _extract_pdf(file_bytes)
        elif ext in (".docx", ".doc"):
            extracted_text = _extract_docx(file_bytes)
        elif ext in (".xlsx", ".xls"):
            extracted_text = _extract_xlsx(file_bytes)
        elif ext == ".csv":
            extracted_text = _extract_csv(file_bytes)
        elif ext in (".txt", ".md", ".json", ".tsv"):
            extracted_text = file_bytes.decode("utf-8", errors="replace")
        else:
            # Fallback: attempt UTF-8 string decoding
            extracted_text = file_bytes.decode("utf-8", errors="replace")
    except Exception as exc:
        logger.error(f"Failed to parse document '{filename}': {exc}", exc_info=True)
        # Fallback to UTF-8 lossy decoding if possible
        try:
            extracted_text = file_bytes.decode("utf-8", errors="ignore")
        except Exception:
            extracted_text = f"[Error extracting text from {filename}: {exc}]"

    # Clean whitespace and enforce character ceiling
    cleaned = "\n".join(line.strip() for line in extracted_text.splitlines() if line.strip())
    if len(cleaned) > max_chars:
        cleaned = cleaned[:max_chars] + f"\n\n[... Document truncated at {max_chars} characters ...]"

    return cleaned


def _extract_pdf(file_bytes: bytes) -> str:
    """Extracts text page-by-page from PDF."""
    if pypdf is None:
        raise ImportError("pypdf is not installed. Install with 'pip install pypdf'")

    reader = pypdf.PdfReader(io.BytesIO(file_bytes))
    pages_text = []
    for idx, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        if text.strip():
            pages_text.append(f"--- Page {idx + 1} ---\n{text.strip()}")
    return "\n\n".join(pages_text)


def _extract_docx(file_bytes: bytes) -> str:
    """Extracts text across paragraphs and tables from DOCX."""
    if docx is None:
        raise ImportError("python-docx is not installed. Install with 'pip install python-docx'")

    doc = docx.Document(io.BytesIO(file_bytes))
    lines = []

    # Paragraphs
    for p in doc.paragraphs:
        txt = p.text.strip()
        if txt:
            lines.append(txt)

    # Tables
    for table in doc.tables:
        for row in table.rows:
            row_cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
            if row_cells:
                lines.append(" | ".join(row_cells))

    return "\n".join(lines)


def _extract_xlsx(file_bytes: bytes) -> str:
    """Extracts tabular records from XLSX worksheets."""
    if openpyxl is None:
        raise ImportError("openpyxl is not installed. Install with 'pip install openpyxl'")

    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
    lines = []

    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        lines.append(f"=== Sheet: {sheet_name} ===")
        for row in sheet.iter_rows(values_only=True):
            if any(row):
                row_str = " | ".join(str(cell).strip() if cell is not None else "" for cell in row)
                lines.append(row_str)

    return "\n".join(lines)


def _extract_csv(file_bytes: bytes) -> str:
    """Extracts structured rows from CSV bytes."""
    decoded = file_bytes.decode("utf-8", errors="replace")
    reader = csv.reader(io.StringIO(decoded))
    lines = []
    for row in reader:
        if any(row):
            lines.append(" | ".join(cell.strip() for cell in row))
    return "\n".join(lines)
