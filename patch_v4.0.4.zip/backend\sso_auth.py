"""
Postall_V4 Enterprise SSO Engine (OIDC / OAuth 2.0)
Supports OpenID Connect with Microsoft Entra ID, Okta, and Google Workspace.
"""
import os
import json
import logging
import secrets
import hashlib
import base64
from typing import Optional, Dict, Any
from fastapi import Request, HTTPException
from fastapi.responses import RedirectResponse
from authlib.integrations.starlette_client import OAuth
from backend.database import get_db

logger = logging.getLogger("sso_auth")

oauth = OAuth()
_sso_configured = False

def get_sso_config() -> Dict[str, Any]:
    """Retrieve SSO settings from the database."""
    try:
        db = get_db()
        rows = {r["key"]: r["value"] for r in db.execute(
            "SELECT key, value FROM settings WHERE key IN ('sso_enabled', 'sso_client_id', 'sso_client_secret', 'sso_metadata_url', 'server_base_url')"
        )}
        db.close()
        return {
            "enabled": str(rows.get("sso_enabled", "0")).strip().lower() in {"1", "true", "on", "yes"},
            "client_id": str(rows.get("sso_client_id", "") or "").strip(),
            "client_secret": str(rows.get("sso_client_secret", "") or "").strip(),
            "metadata_url": str(rows.get("sso_metadata_url", "") or "").strip(),
            "server_base_url": str(rows.get("server_base_url", "") or "").strip()
        }
    except Exception as exc:
        logger.error(f"Failed to read SSO config: {exc}")
        return {"enabled": False, "client_id": "", "client_secret": "", "metadata_url": "", "server_base_url": ""}

def setup_sso(client_id: str, client_secret: str, metadata_url: str) -> bool:
    """Registers the dynamic OIDC client named 'corporate_sso' using the metadata URL."""
    global _sso_configured
    if not client_id or not metadata_url:
        return False
    try:
        oauth.register(
            name="corporate_sso",
            client_id=client_id,
            client_secret=client_secret or None,
            server_metadata_url=metadata_url,
            client_kwargs={"scope": "openid email profile"}
        )
        _sso_configured = True
        logger.info(f"OIDC SSO client registered successfully with discovery URL: {metadata_url}")
        return True
    except Exception as exc:
        logger.error(f"Failed to setup SSO client: {exc}")
        return False

def get_or_init_sso_client():
    """Returns the registered corporate_sso client, re-initializing if needed."""
    cfg = get_sso_config()
    if not cfg["enabled"]:
        return None
    if not cfg["client_id"] or not cfg["metadata_url"]:
        return None
    if setup_sso(cfg["client_id"], cfg["client_secret"], cfg["metadata_url"]):
        return oauth.create_client("corporate_sso")
    return None

async def login_via_sso(request: Request):
    """Generates the authorization URL and redirects the user to their corporate identity provider."""
    cfg = get_sso_config()
    if not cfg["enabled"]:
        raise HTTPException(400, "Corporate SSO is currently disabled.")
    
    client = get_or_init_sso_client()
    if not client:
        raise HTTPException(400, "SSO identity provider is not properly configured. Check Metadata URL and Client ID.")

    # Determine redirect URI
    server_base = cfg.get("server_base_url") or str(request.base_url).rstrip("/")
    redirect_uri = f"{server_base.rstrip('/')}/api/auth/sso/callback"

    return await client.authorize_redirect(request, redirect_uri)

async def sso_callback(request: Request, token_generator_fn):
    """
    Authorizes callback, fetches id_token and userinfo.
    Checks if the user exists; if missing, auto-provisions a new user.
    Returns a redirect to the dashboard with the JWT token.
    """
    client = get_or_init_sso_client()
    if not client:
        raise HTTPException(400, "SSO is not configured or disabled.")

    try:
        token = await client.authorize_access_token(request)
    except Exception as exc:
        logger.error(f"SSO token exchange failed: {exc}")
        return RedirectResponse(url=f"/login?error=sso_failed&msg={exc}", status_code=302)

    userinfo = token.get("userinfo")
    if not userinfo:
        try:
            userinfo = await client.userinfo(token=token)
        except Exception:
            pass

    if not userinfo and "id_token" in token:
        # Fallback to parsing payload of id_token
        try:
            raw_id = token["id_token"].split(".")[1]
            userinfo = json.loads(base64.urlsafe_b64decode(raw_id + "=" * (-len(raw_id) % 4)))
        except Exception:
            pass

    if not userinfo:
        raise HTTPException(400, "Failed to retrieve user profile from Identity Provider.")

    email = userinfo.get("email") or ""
    username = userinfo.get("preferred_username") or (email.split("@")[0] if email else "sso_user")
    name = userinfo.get("name") or username

    db = get_db()
    # Check if user exists by email or username
    user = None
    if email:
        user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not user and username:
        user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()

    if not user:
        # Auto-provision new user under default settings
        dummy_salt = secrets.token_bytes(16)
        dummy_hash = "pbkdf2$" + base64.urlsafe_b64encode(dummy_salt).decode() + "$" + hashlib.pbkdf2_hmac("sha256", secrets.token_hex(16).encode(), dummy_salt, 210000).hex()
        cur = db.execute(
            "INSERT INTO users (username, password_hash, email, role, is_active, sso_provider, must_reset, must_change_password) VALUES (?, ?, ?, 'editor', 1, 'oidc', 0, 0)",
            (username, dummy_hash, email)
        )
        db.commit()
        user = db.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
        logger.info(f"Auto-provisioned new SSO user: {username} ({email})")
    else:
        db.execute("UPDATE users SET last_login_at=datetime('now'), sso_provider='oidc' WHERE id=?", (user["id"],))
        db.commit()

    db.close()

    # Generate Postall_V4 JWT session token
    session_token = token_generator_fn(user["username"])
    logger.info(f"SSO login successful for user '{user['username']}' via OIDC")

    return RedirectResponse(url=f"/dashboard?token={session_token}&sso=1", status_code=302)
