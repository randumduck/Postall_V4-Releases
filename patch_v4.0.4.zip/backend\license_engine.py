"""
Postall_V4 - Ed25519 Asymmetric Licensing Enforcement Engine
==============================================================================
Implements hardened cryptographic verification of Ed25519 signed enterprise
license packages. Supports Trial, Production, and Enterprise license tiers.
"""

import base64
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import ed25519

logger = logging.getLogger(__name__)

# Master Public Key (64-character raw hex derived offline in License Forge)
LICENSE_PUBLIC_KEY = "5d91dc231e482a76f3711ae9b091846024a8ca1d1b3e0981234bd6c7fc3c2260"

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
LICENSE_FILE = DATA_DIR / "license.key"


class MissingLicenseError(Exception):
    """Raised when data/license.key is absent from disk."""
    pass


class LicenseInvalidError(Exception):
    """Raised when the license signature is invalid, tampered with, or expired."""
    pass


def _extract_container_components(raw_bytes: bytes) -> Tuple[bytes, dict, bytes]:
    """
    Decodes the raw base64 license payload and extracts:
    (signature_bytes_64, payload_dict, canonical_payload_bytes)
    
    Supports two formats:
    1. Base64 encoded JSON container: {"payload": {...}, "signature": "<base64_sig>"}
    2. Base64 encoded binary concat: 64 bytes raw signature + UTF-8 JSON payload bytes
    """
    try:
        decoded = base64.b64decode(raw_bytes.strip())
    except Exception as exc:
        raise LicenseInvalidError(f"License file is not valid Base64: {exc}")

    # Case 1: Decoded bytes are a JSON container
    try:
        container_text = decoded.decode("utf-8")
        if container_text.strip().startswith("{"):
            container = json.loads(container_text)
            if "payload" in container and "signature" in container:
                payload = container["payload"]
                sig_raw = container["signature"]
                if isinstance(sig_raw, str):
                    signature_bytes = base64.b64decode(sig_raw)
                else:
                    signature_bytes = bytes(sig_raw)

                if len(signature_bytes) != 64:
                    raise LicenseInvalidError(f"Invalid signature length: {len(signature_bytes)} bytes (expected 64)")

                canonical_payload_bytes = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode("utf-8")
                return signature_bytes, payload, canonical_payload_bytes
    except UnicodeDecodeError:
        pass
    except (json.JSONDecodeError, KeyError, ValueError) as exc:
        if isinstance(exc, LicenseInvalidError):
            raise
        pass

    # Case 2: Binary format: first 64 bytes is the raw Ed25519 signature
    if len(decoded) < 65:
        raise LicenseInvalidError(f"License data too short ({len(decoded)} bytes). Expected at least 65 bytes.")

    signature_bytes = decoded[:64]
    payload_raw_bytes = decoded[64:]
    try:
        payload = json.loads(payload_raw_bytes.decode("utf-8"))
    except Exception as exc:
        raise LicenseInvalidError(f"Unable to parse license JSON payload: {exc}")

    canonical_payload_bytes = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode("utf-8")
    return signature_bytes, payload, canonical_payload_bytes


DEMO_DURATION_SECONDS = 3 * 86400  # 3 days (72 hours)


def get_or_create_demo_start() -> int:
    """Retrieves or initializes the 3-day demo mode start timestamp."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    demo_file = DATA_DIR / ".demo_started"
    if demo_file.is_file():
        try:
            return int(demo_file.read_text(encoding="utf-8").strip())
        except Exception:
            pass

    # Check database settings
    try:
        from .database import get_db
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key='demo_mode_started_at'").fetchone()
        if row and row["value"]:
            val = int(row["value"])
            demo_file.write_text(str(val), encoding="utf-8")
            db.close()
            return val
        now = int(time.time())
        db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('demo_mode_started_at', ?)", (str(now),))
        db.commit()
        db.close()
        demo_file.write_text(str(now), encoding="utf-8")
        return now
    except Exception:
        now = int(time.time())
        try:
            demo_file.write_text(str(now), encoding="utf-8")
        except Exception:
            pass
        return now


def get_demo_license_state() -> dict:
    """
    Evaluates the 3-day demo trial period.
    If the 3-day period is active, returns a valid demo license structure.
    If the 3-day period has elapsed, raises LicenseInvalidError to trigger full lockout.
    """
    demo_start = get_or_create_demo_start()
    demo_expires = demo_start + DEMO_DURATION_SECONDS
    now = int(time.time())

    if now > demo_expires:
        exp_iso = datetime.fromtimestamp(demo_expires, tz=timezone.utc).isoformat()
        raise LicenseInvalidError(
            f"Demo mode trial expired on {exp_iso}. A valid Ed25519 enterprise license key is required to activate Postall_V4."
        )

    seconds_left = max(0, demo_expires - now)
    days_remaining = max(0, int(seconds_left / 86400))
    hours_remaining = max(1, int(seconds_left / 3600))
    iso_str = datetime.fromtimestamp(demo_expires, tz=timezone.utc).isoformat()

    return {
        "client": "Demo Evaluation User",
        "client_name": "Demo Evaluation User",
        "type": "Demo",
        "license_type": "Demo (3-Day Trial)",
        "is_demo": True,
        "demo_active": True,
        "expires_at": demo_expires,
        "expires_at_iso": iso_str,
        "license_id": "POSTALL-DEMO-3DAYS",
        "days_remaining": days_remaining,
        "hours_remaining": hours_remaining,
        "features": [
            "core_engine",
            "autonomous_social_autopilot",
            "multi_model_ai_synthesis",
            "enterprise_infographics_v2",
            "omnichannel_distribution"
        ],
        "raw_payload": {
            "client": "Demo Evaluation User",
            "type": "demo",
            "expires_at": demo_expires
        }
    }


def verify_license(allow_demo: bool = True) -> dict:
    """
    Verifies data/license.key:
    - If missing: if allow_demo=True, falls back to 3-day Demo Mode (raises LicenseInvalidError if demo expired).
      If allow_demo=False, raises MissingLicenseError.
    - If present: Base64 decodes and extracts the 64-byte signature and JSON payload.
    - Cryptographically validates the signature with LICENSE_PUBLIC_KEY.
    - Validates expiration time against current system time (raises LicenseInvalidError if expired).
    - Returns standardized parsed payload:
        {"client": "...", "type": "...", "expires_at": UNIX_TIMESTAMP, "is_demo": bool, ...}
    """
    if not LICENSE_FILE.is_file():
        if allow_demo:
            return get_demo_license_state()
        raise MissingLicenseError(f"No license file found at {LICENSE_FILE.relative_to(ROOT_DIR)}")

    try:
        raw_b64 = LICENSE_FILE.read_bytes()
    except Exception as exc:
        raise LicenseInvalidError(f"Failed reading license file: {exc}")

    signature_bytes, payload, canonical_bytes = _extract_container_components(raw_b64)

    # 1. Cryptographic Ed25519 Verification
    try:
        pub_key_bytes = bytes.fromhex(LICENSE_PUBLIC_KEY)
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(pub_key_bytes)
        public_key.verify(signature_bytes, canonical_bytes)
    except InvalidSignature:
        raise LicenseInvalidError("Cryptographic Ed25519 verification failed: Tampered or invalid signature.")
    except Exception as exc:
        raise LicenseInvalidError(f"Cryptographic verification error: {exc}")

    # 2. Expiration Verification
    raw_exp = payload.get("expires_at")
    if raw_exp is None:
        raise LicenseInvalidError("License payload missing mandatory 'expires_at' property.")

    # Parse expires_at into UNIX timestamp
    exp_ts: float
    iso_str: str
    if isinstance(raw_exp, (int, float)):
        exp_ts = float(raw_exp)
        iso_str = datetime.fromtimestamp(exp_ts, tz=timezone.utc).isoformat()
    else:
        try:
            # Handle ISO string e.g. '2036-09-25T18:22:37.248530+00:00'
            dt = datetime.fromisoformat(str(raw_exp).replace("Z", "+00:00"))
            exp_ts = dt.timestamp()
            iso_str = dt.isoformat()
        except Exception:
            try:
                exp_ts = float(str(raw_exp))
                iso_str = datetime.fromtimestamp(exp_ts, tz=timezone.utc).isoformat()
            except Exception as exc:
                raise LicenseInvalidError(f"Unrecognized 'expires_at' format ({raw_exp}): {exc}")

    current_ts = time.time()
    if current_ts > exp_ts:
        raise LicenseInvalidError(f"License has expired at {iso_str} (current time: {datetime.now(timezone.utc).isoformat()})")

    # 3. Standardize License Type (Trial, Production, Enterprise)
    raw_type = str(payload.get("type") or payload.get("license_type") or "Production").strip().lower()
    if "trial" in raw_type or "testing" in raw_type or "sandbox" in raw_type:
        license_tier = "Trial"
    elif "enterprise" in raw_type or "cluster" in raw_type or "unlimited" in raw_type:
        license_tier = "Enterprise"
    else:
        license_tier = "Production"

    client_name = str(payload.get("client") or payload.get("client_name") or "Enterprise Client").strip()
    license_id = str(payload.get("license_id") or "POSTALL-LIC").strip()

    days_remaining = max(0, int((exp_ts - current_ts) / 86400))

    result = {
        "client": client_name,
        "client_name": client_name,
        "type": license_tier,
        "license_type": license_tier,
        "is_demo": False,
        "demo_active": False,
        "expires_at": int(exp_ts),
        "expires_at_iso": iso_str,
        "license_id": license_id,
        "days_remaining": days_remaining,
        "hours_remaining": days_remaining * 24,
        "features": payload.get("features", []),
        "raw_payload": payload
    }

    return result


def activate_license_key(key_string: str) -> dict:
    """
    Writes the given Base64 key string to data/license.key and performs immediate verification.
    If valid, returns the parsed payload. If invalid, the temporary file is removed (or reverted)
    and an exception is raised.
    """
    clean_key = key_string.strip()
    if not clean_key:
        raise LicenseInvalidError("License key string cannot be empty.")

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    backup_file = DATA_DIR / "license.key.prev"

    if LICENSE_FILE.is_file():
        try:
            backup_file.write_bytes(LICENSE_FILE.read_bytes())
        except Exception:
            pass

    try:
        LICENSE_FILE.write_text(clean_key, encoding="utf-8")
        verified_data = verify_license()
        if backup_file.is_file():
            try:
                backup_file.unlink()
            except Exception:
                pass
        return verified_data
    except Exception as exc:
        # Revert on failure
        if backup_file.is_file():
            try:
                LICENSE_FILE.write_bytes(backup_file.read_bytes())
                backup_file.unlink()
            except Exception:
                pass
        raise
