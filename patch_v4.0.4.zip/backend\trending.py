"""
Postall_V4 — Trending Radar RSS Ingestion Service
=================================================
Fetches, sanitizes, caches, and normalizes multi-category industry RSS news feeds:
- Cybersecurity & CVE Alerts (The Hacker News, CISA, BleepingComputer, Security Affairs)
- Technology & Cloud (TechCrunch, Ars Technica, The Verge)
- AI & Machine Learning (MIT Technology Review AI, TechCrunch AI, VentureBeat AI)
- Business & Finance (MarketWatch, Yahoo Finance, Reuters Business)
- Fashion & Lifestyle (Vogue Business, Fashionista)

Features:
- Concurrency via asyncio and httpx (5-second timeout)
- Non-blocking parsing via asyncio.to_thread(feedparser.parse, ...)
- SQLite trending_cache with 30-minute freshness TTL
- Robust HTML tag stripping and UTF-8 sanitization
- Resilient fallback to stale cache if external networks fail
"""

import asyncio
import html
import json
import logging
import re
import unicodedata
from datetime import datetime, timezone
from typing import Dict, List, Optional

import feedparser
import httpx
from backend.database import get_db, get_trending_sources, get_trending_categories_summary

logger = logging.getLogger("trending_radar")

CATEGORIES_METADATA = [
    {
        "id": "cybersecurity",
        "label": "Cybersecurity & CVEs",
        "icon": "🛡️",
        "description": "Critical vulnerabilities, zero-days, and enterprise threat intelligence."
    },
    {
        "id": "technology",
        "label": "Tech & Cloud",
        "icon": "💻",
        "description": "Cloud infrastructure, systems architecture, DevOps, and enterprise tech."
    },
    {
        "id": "ai_data",
        "label": "AI & ML",
        "icon": "🤖",
        "description": "Frontier LLMs, autonomous agents, neural architectures, and AI research."
    },
    {
        "id": "business_finance",
        "label": "Business & ROI",
        "icon": "📈",
        "description": "Market shifts, macroeconomic trends, enterprise software ROI, and funding."
    },
    {
        "id": "fashion_lifestyle",
        "label": "Fashion & Trends",
        "icon": "👗",
        "description": "High-fashion developments, luxury retail technology, and lifestyle design."
    }
]

CATEGORY_FEEDS: Dict[str, List[Dict[str, str]]] = {
    "cybersecurity": [
        {"name": "The Hacker News", "url": "https://feeds.feedburner.com/TheHackersNews"},
        {"name": "CISA Advisories", "url": "https://www.cisa.gov/cybersecurity-advisories.xml"},
        {"name": "BleepingComputer", "url": "https://www.bleepingcomputer.com/feed/"},
        {"name": "Security Affairs", "url": "https://securityaffairs.com/feed"},
    ],
    "technology": [
        {"name": "TechCrunch", "url": "https://techcrunch.com/feed/"},
        {"name": "Ars Technica", "url": "https://feeds.arstechnica.com/arstechnica/index"},
        {"name": "The Verge", "url": "https://www.theverge.com/rss/index.xml"},
    ],
    "ai_data": [
        {"name": "MIT Technology Review AI", "url": "https://www.technologyreview.com/topic/artificial-intelligence/feed"},
        {"name": "TechCrunch AI", "url": "https://techcrunch.com/category/artificial-intelligence/feed/"},
        {"name": "VentureBeat AI", "url": "https://venturebeat.com/category/ai/feed/"},
    ],
    "business_finance": [
        {"name": "MarketWatch Top Stories", "url": "https://feeds.content.dowjones.io/public/rss/mw_topstories"},
        {"name": "Yahoo Finance", "url": "https://finance.yahoo.com/news/rssindex"},
        {"name": "Reuters Business", "url": "https://www.reutersagency.com/feed/?taxonomy=best-sectors&post_type=best"},
    ],
    "fashion_lifestyle": [
        {"name": "Vogue Business", "url": "https://www.vogue.com/feed/rss"},
        {"name": "Fashionista", "url": "https://fashionista.com/.rss/excerpt/"},
    ]
}

HTTP_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Postall_V4-Radar/4.0"
    ),
    "Accept": "application/rss+xml, application/xml, text/xml, */*",
}


def clean_html(raw_html: str) -> str:
    """Removes HTML markup, strips unwanted entities, and collapses redundant whitespace."""
    if not raw_html:
        return ""
    # Strip HTML tags
    cleaned = re.sub(r"<[^>]+>", " ", raw_html)
    # Unescape HTML entities (e.g., &amp;, &quot;)
    cleaned = html.unescape(cleaned)
    # Collapse multiple whitespace characters into single space
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def sanitize_utf8(text: str) -> str:
    """Normalizes text to clean printable UTF-8 (NFKC form)."""
    if not text:
        return ""
    normalized = unicodedata.normalize("NFKC", text)
    # Filter non-printable control characters
    return "".join(ch for ch in normalized if ch.isprintable() or ch in "\n\r\t ").strip()


async def fetch_single_feed(feed_info: Dict[str, str]) -> List[Dict[str, str]]:
    """
    Fetches and parses a single RSS feed via httpx with a 5s timeout,
    falling back to direct feedparser.parse in a worker thread.
    """
    name = feed_info.get("name", "Unknown Source")
    url = feed_info.get("url", "")
    if not url:
        return []

    parsed = None
    try:
        async with httpx.AsyncClient(timeout=5.0, headers=HTTP_HEADERS, follow_redirects=True) as client:
            resp = await client.get(url)
            if resp.status_code == 200 and resp.text:
                parsed = await asyncio.to_thread(feedparser.parse, resp.text)
    except Exception as exc:
        logger.debug(f"Direct HTTP fetch failed for {name} ({url}): {exc}. Falling back to feedparser.parse thread.")

    if not parsed or not getattr(parsed, "entries", None):
        try:
            parsed = await asyncio.to_thread(feedparser.parse, url)
        except Exception as exc:
            logger.warning(f"Failed to parse feed {name} ({url}): {exc}")
            return []

    articles: List[Dict[str, str]] = []
    for entry in getattr(parsed, "entries", []):
        raw_title = entry.get("title", "")
        raw_summary = (
            entry.get("summary")
            or entry.get("description")
            or (entry.get("content", [{}])[0].get("value") if entry.get("content") else "")
            or ""
        )
        title = sanitize_utf8(clean_html(raw_title))
        summary = sanitize_utf8(clean_html(raw_summary))
        link = entry.get("link", "")
        published = entry.get("published") or entry.get("updated") or ""

        # Require a valid headline
        if not title:
            continue

        # Trim summary to a clean excerpt
        if len(summary) > 300:
            summary = summary[:297].rstrip() + "..."

        articles.append({
            "title": title,
            "summary": summary,
            "source": name,
            "link": link,
            "published": published
        })

    return articles


def get_available_categories() -> List[Dict[str, str]]:
    """Returns the dynamic list of trending radar categories from the database."""
    try:
        cats = get_trending_categories_summary()
        if cats:
            return cats
    except Exception as exc:
        logger.warning(f"Error fetching dynamic categories: {exc}")
    return CATEGORIES_METADATA


async def fetch_trending_articles(category: str, limit: int = 15) -> List[Dict[str, str]]:
    """
    Fetches real-time articles for the specified category:
    1. Checks SQLite trending_cache for freshness (< 30 minutes).
    2. Dynamically queries active URLs from trending_sources.
    3. Fetches category feeds concurrently with 5-second timeout.
    4. Normalizes and caches output.
    5. Falls back to stale cache or empty list on network failure.
    """
    category = category.lower().strip()

    # Step 1: Check fresh SQLite cache (< 30 minutes)
    try:
        db = get_db()
        cached = db.execute(
            """
            SELECT payload_json FROM trending_cache
            WHERE category = ? AND updated_at >= datetime('now', '-30 minutes')
            """,
            (category,)
        ).fetchone()
        db.close()
        if cached and cached["payload_json"]:
            articles = json.loads(cached["payload_json"])
            if articles:
                return articles[:limit]
    except Exception as exc:
        logger.warning(f"Cache check error for category {category}: {exc}")

    # Step 2: Fetch active feeds dynamically from database
    feeds: List[Dict[str, str]] = []
    try:
        active_sources = [s for s in get_trending_sources(category) if s.get("is_active", 1)]
        feeds = [{"name": s["feed_name"], "url": s["feed_url"]} for s in active_sources]
    except Exception as exc:
        logger.warning(f"Failed to query dynamic trending sources: {exc}")

    if not feeds:
        feeds = CATEGORY_FEEDS.get(category, [])

    tasks = [fetch_single_feed(f) for f in feeds]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    aggregated: List[Dict[str, str]] = []
    seen_titles = set()

    for res in results:
        if isinstance(res, list):
            for art in res:
                t_lower = art["title"].lower()
                if t_lower not in seen_titles:
                    seen_titles.add(t_lower)
                    aggregated.append(art)

    # Step 3: Handle results and update cache
    if aggregated:
        # Cap articles to requested limit
        result_articles = aggregated[:limit]
        try:
            db = get_db()
            db.execute(
                """
                INSERT OR REPLACE INTO trending_cache (category, payload_json, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
                """,
                (category, json.dumps(result_articles))
            )
            db.commit()
            db.close()
        except Exception as exc:
            logger.warning(f"Failed to persist trending cache for {category}: {exc}")
        return result_articles

    # Step 4: Fallback to any stale cache if live network failed completely
    logger.warning(f"Live feeds for category '{category}' returned 0 articles. Checking stale cache fallback.")
    try:
        db = get_db()
        stale = db.execute(
            "SELECT payload_json FROM trending_cache WHERE category = ?",
            (category,)
        ).fetchone()
        db.close()
        if stale and stale["payload_json"]:
            articles = json.loads(stale["payload_json"])
            if articles:
                return articles[:limit]
    except Exception:
        pass

    return []
