"""Enterprise REST API publisher for LinkedIn and X (Twitter).
Replaces fragile Playwright browser automation with official, compliance-regulated REST endpoints.
"""
from __future__ import annotations

import os
import time
import sqlite3
from pathlib import Path
from typing import Optional, Dict, Any

import requests
try:
    from requests_oauthlib import OAuth1
except ImportError:
    OAuth1 = None  # type: ignore

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "data" / "postall.db"


def log_system_event(level: str, module: str, message: str) -> None:
    """Safely append structured audit log directly to postall.db."""
    if DB_PATH.exists():
        try:
            conn = sqlite3.connect(DB_PATH, timeout=10.0)
            conn.execute(
                "INSERT INTO system_logs(timestamp, level, module, message) VALUES(datetime('now'), ?, ?, ?)",
                (level.upper(), module.upper(), message[:1000])
            )
            conn.commit()
            conn.close()
        except Exception:
            pass



def _get_setting(key: str) -> Optional[str]:
    """Retrieve setting from postall.db or environment variable fallback."""
    if DB_PATH.exists():
        try:
            conn = sqlite3.connect(DB_PATH)
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            conn.close()
            if row and row["value"]:
                return str(row["value"]).strip()
        except Exception:
            pass
    # Env fallback
    env_map = {
        "linkedin_access_token": "LINKEDIN_ACCESS_TOKEN",
        "x_user_access_token": "X_USER_ACCESS_TOKEN",
        "x_api_key": "X_API_KEY",
        "x_api_secret": "X_API_SECRET",
        "x_access_token": "X_ACCESS_TOKEN",
        "x_access_token_secret": "X_ACCESS_TOKEN_SECRET",
    }
    env_var = env_map.get(key, key.upper())
    val = os.getenv(env_var)
    return val.strip() if val else None


def trim_post_text(text: str, limit: int = 280) -> str:
    """Gracefully trim text for Twitter's 280 character limit with weighted unicode cost."""
    clean = " ".join(text.split())
    if sum(2 if ord(c) > 127 else 1 for c in clean) <= limit:
        return clean
    trimmed = []
    weight = 0
    for char in clean:
        cost = 2 if ord(char) > 127 else 1
        if weight + cost > limit - 2:
            break
        trimmed.append(char)
        weight += cost
    result = "".join(trimmed).rsplit(" ", 1)[0].rstrip(" ,;:-")
    return result + "…"


def append_custom_hashtags(text: str) -> str:
    """Cleanly append custom hashtags with line breaks if configured."""
    if not text:
        return ""
    tags = _get_setting("custom_hashtags")
    if not tags or not str(tags).strip():
        return text
    tags_list = [t if t.startswith("#") else f"#{t}" for t in str(tags).split() if t]
    if not tags_list:
        return text
    formatted_tags = " ".join(tags_list)
    clean_text = text.rstrip()
    if formatted_tags in clean_text:
        return clean_text
    return f"{clean_text}\n\n{formatted_tags}"


# ============================================================================
# LINKEDIN PUBLISHER (Official UGC / Assets REST API)
# ============================================================================

def get_linkedin_token() -> str:
    token = _get_setting("linkedin_access_token")
    if not token:
        raise RuntimeError("LinkedIn Access Token is not configured. Add it in System Settings.")
    return token


def verify_linkedin_connection(token: Optional[str] = None) -> Dict[str, Any]:
    """Verify LinkedIn token permissions and fetch profile info via OpenID or /v2/me."""
    tok = token or get_linkedin_token()
    headers = {
        "Authorization": f"Bearer {tok}",
        "X-Restli-Protocol-Version": "2.0.0"
    }
    
    # 1. Try OpenID UserInfo (standard for new LinkedIn Apps)
    res = requests.get("https://api.linkedin.com/v2/userinfo", headers=headers, timeout=15)
    if res.status_code == 200:
        data = res.json()
        sub = data.get("sub")
        if not sub or not str(sub).strip():
            raise RuntimeError("LinkedIn OpenID /v2/userinfo returned empty sub (person ID).")
        person_id = str(sub).strip()
        name = data.get("name") or f"{data.get('given_name', '')} {data.get('family_name', '')}".strip() or "LinkedIn Member"
        return {
            "status": "connected",
            "platform": "linkedin",
            "name": name,
            "sub": person_id,
            "author_urn": f"urn:li:person:{person_id}",
            "email": data.get("email"),
            "picture": data.get("picture")
        }
    
    # 2. Fallback to /v2/me (legacy Sign In with LinkedIn)
    res2 = requests.get("https://api.linkedin.com/v2/me", headers=headers, timeout=15)
    if res2.status_code == 200:
        data2 = res2.json()
        person_id = data2.get("id")
        if not person_id or not str(person_id).strip():
            raise RuntimeError("LinkedIn /v2/me returned empty person ID.")
        person_id = str(person_id).strip()
        fname = data2.get("localizedFirstName", "")
        lname = data2.get("localizedLastName", "")
        name = f"{fname} {lname}".strip() or "LinkedIn Member"
        return {
            "status": "connected",
            "platform": "linkedin",
            "name": name,
            "sub": person_id,
            "author_urn": f"urn:li:person:{person_id}"
        }
        
    err_detail = ""
    for r in (res, res2):
        try:
            j = r.json()
            err_detail = j.get("message") or j.get("error_description") or str(j)
            if err_detail:
                break
        except Exception:
            if r.text:
                err_detail = r.text
    if not err_detail:
        err_detail = f"HTTP {res.status_code}"
    raise RuntimeError(f"LinkedIn verification rejected (HTTP {res.status_code}): {err_detail}")


def publish_to_linkedin(post_text: str, image_path: Optional[str | Path] = None) -> Dict[str, Any]:
    """Publish text and optional infographic to LinkedIn using hardened official REST APIs with status polling."""
    token = get_linkedin_token()
    profile = verify_linkedin_connection(token)
    
    # Strict URN Verification: must follow urn:li:person:{person_id} with non-null ID
    sub = profile.get("sub")
    if not sub or not str(sub).strip():
        raise RuntimeError("LinkedIn person ID is missing or null. Check LinkedIn app scopes (openid, profile, w_member_social).")
    
    person_id = str(sub).strip()
    author_urn = f"urn:li:person:{person_id}"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "X-Restli-Protocol-Version": "2.0.0",
        "Content-Type": "application/json"
    }

    # Append custom hashtags cleanly if configured
    final_post_text = append_custom_hashtags(post_text)

    asset_urn = None
    if image_path:
        img_p = Path(image_path)
        if not img_p.is_absolute():
            img_p = ROOT / img_p
        # If path points to an SVG, use the converted PNG if available
        if img_p.suffix.lower() == ".svg" and img_p.with_suffix(".png").exists():
            img_p = img_p.with_suffix(".png")

        img_bytes = None
        if img_p.exists():
            img_bytes = img_p.read_bytes()
        else:
            try:
                from backend.storage import get_storage_provider
                img_bytes = get_storage_provider().get_file(str(image_path))
            except Exception:
                img_bytes = None

        if img_bytes:
            # Step 1 (Register Asset): Call /v2/assets?action=registerUpload with SYNCHRONOUS_UPLOAD
            log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_REG] Registering asset upload for {author_urn}")
            reg_url = "https://api.linkedin.com/v2/assets?action=registerUpload"
            reg_payload = {
                "registerUploadRequest": {
                    "recipes": ["urn:li:digitalmediaRecipe:feedshare-image"],
                    "owner": author_urn,
                    "serviceRelationships": [
                        {
                            "relationshipType": "OWNER",
                            "identifier": "urn:li:userGeneratedContent"
                        }
                    ],
                    "supportedUploadMechanism": ["SYNCHRONOUS_UPLOAD"]
                }
            }
            reg_res = requests.post(reg_url, headers=headers, json=reg_payload, timeout=30)
            if reg_res.status_code not in (200, 201):
                err_detail = ""
                try:
                    err_json = reg_res.json()
                    err_detail = err_json.get("message") or err_json.get("error_description") or str(err_json)
                except Exception:
                    err_detail = reg_res.text or f"HTTP {reg_res.status_code}"
                log_system_event("ERROR", "LINKEDIN", f"[LINKEDIN_REG] Failed (HTTP {reg_res.status_code}): {err_detail[:200]}")
                raise RuntimeError(f"LinkedIn image registration rejected (HTTP {reg_res.status_code}): {err_detail}")
            
            reg_data = reg_res.json()
            try:
                asset_urn = reg_data["value"]["asset"]
                upload_url = reg_data["value"]["uploadMechanism"]["com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest"]["uploadUrl"]
            except KeyError as ke:
                raise RuntimeError(f"LinkedIn image registration returned unexpected payload structure: {reg_data}") from ke
            
            log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_REG] Registered asset {asset_urn}")

            # Step 2 (Binary Upload): PUT binary image data with image/png Content-Type
            log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_UPLOAD] Uploading {len(img_bytes)} bytes binary PNG payload")
            upload_headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "image/png"
            }
            upload_res = requests.put(upload_url, data=img_bytes, headers=upload_headers, timeout=60)
            if upload_res.status_code not in (200, 201):
                err_detail = upload_res.text or f"HTTP {upload_res.status_code}"
                log_system_event("ERROR", "LINKEDIN", f"[LINKEDIN_UPLOAD] Binary upload rejected (HTTP {upload_res.status_code}): {err_detail[:200]}")
                raise RuntimeError(f"LinkedIn image binary upload rejected (HTTP {upload_res.status_code}): {err_detail}")
            
            log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_UPLOAD] Binary upload succeeded (HTTP {upload_res.status_code})")

            # Step 3 (Asset Status Polling): Poll /v2/assets/{asset_id} up to 3 times (1-second sleep)
            asset_id = asset_urn.split(":")[-1]
            poll_url = f"https://api.linkedin.com/v2/assets/{asset_id}"
            poll_headers = {
                "Authorization": f"Bearer {token}",
                "X-Restli-Protocol-Version": "2.0.0"
            }
            asset_available = False
            for attempt in range(1, 4):
                log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_POLL] Verifying asset status for {asset_id} (attempt {attempt}/3)")
                try:
                    poll_res = requests.get(poll_url, headers=poll_headers, timeout=15)
                    if poll_res.status_code == 200:
                        poll_json = poll_res.json()
                        st = poll_json.get("status")
                        recipes = poll_json.get("recipes", [])
                        recipe_status = recipes[0].get("status") if recipes else None
                        log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_POLL] Asset {asset_id} status: {st}, recipe_status: {recipe_status}")
                        if st == "AVAILABLE" or recipe_status == "AVAILABLE":
                            asset_available = True
                            break
                    else:
                        log_system_event("WARNING", "LINKEDIN", f"[LINKEDIN_POLL] Attempt {attempt} status HTTP {poll_res.status_code}")
                except Exception as exc:
                    log_system_event("WARNING", "LINKEDIN", f"[LINKEDIN_POLL] Attempt {attempt} error: {exc}")
                if attempt < 3:
                    time.sleep(1)

            if not asset_available:
                log_system_event("WARNING", "LINKEDIN", f"[LINKEDIN_POLL] Asset {asset_id} polling did not confirm AVAILABLE; proceeding with publish attempt")

    # Step 4 (Publish UGC Post): Dispatch /v2/ugcPosts
    ugc_url = "https://api.linkedin.com/v2/ugcPosts"
    if asset_urn:
        ugc_payload = {
            "author": author_urn,
            "lifecycleState": "PUBLISHED",
            "specificContent": {
                "com.linkedin.ugc.ShareContent": {
                    "shareCommentary": {"text": final_post_text},
                    "shareMediaCategory": "IMAGE",
                    "media": [
                        {
                            "status": "READY",
                            "description": {"text": "Course visual summary"},
                            "media": asset_urn,
                            "title": {"text": "Infographic"}
                        }
                    ]
                }
            },
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
        }
    else:
        ugc_payload = {
            "author": author_urn,
            "lifecycleState": "PUBLISHED",
            "specificContent": {
                "com.linkedin.ugc.ShareContent": {
                    "shareCommentary": {"text": final_post_text},
                    "shareMediaCategory": "NONE"
                }
            },
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
        }

    log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_PUBLISH] Submitting UGC post for {author_urn}")
    post_res = requests.post(ugc_url, headers=headers, json=ugc_payload, timeout=30)
    if post_res.status_code not in (200, 201):
        err_detail = ""
        try:
            err_json = post_res.json()
            err_detail = err_json.get("message") or err_json.get("error_description") or str(err_json)
        except Exception:
            err_detail = post_res.text or f"HTTP {post_res.status_code}"
        log_system_event("ERROR", "LINKEDIN", f"[LINKEDIN_PUBLISH] Post rejected (HTTP {post_res.status_code}): {err_detail[:200]}")
        raise RuntimeError(f"LinkedIn /v2/ugcPosts rejected post (HTTP {post_res.status_code}): {err_detail}")

    post_data = post_res.json()
    post_urn = post_data.get("id")
    if not post_urn:
        raise RuntimeError(f"LinkedIn returned success status but missing post URN ID: {post_data}")
    
    post_url = f"https://www.linkedin.com/feed/update/{post_urn}/"
    log_system_event("INFO", "LINKEDIN", f"[LINKEDIN_PUBLISH] Post published successfully: {post_url}")

    return {
        "status": "success",
        "post_id": post_urn,
        "post_url": post_url,
        "platform": "linkedin"
    }


class LinkedInPublisher:
    """Class wrapper providing explicit 4-step LinkedIn asset and post verification."""
    def __init__(self, token: Optional[str] = None):
        self.token = token or _get_setting("linkedin_access_token")

    def register_upload(self, author_urn: str) -> tuple[str, str]:
        """Step 1 (Register Asset): Call /v2/assets?action=registerUpload with SYNCHRONOUS_UPLOAD."""
        tok = self.token or get_linkedin_token()
        headers = {"Authorization": f"Bearer {tok}", "X-Restli-Protocol-Version": "2.0.0", "Content-Type": "application/json"}
        reg_payload = {
            "registerUploadRequest": {
                "recipes": ["urn:li:digitalmediaRecipe:feedshare-image"],
                "owner": author_urn,
                "serviceRelationships": [{"relationshipType": "OWNER", "identifier": "urn:li:userGeneratedContent"}],
                "supportedUploadMechanism": ["SYNCHRONOUS_UPLOAD"]
            }
        }
        res = requests.post("https://api.linkedin.com/v2/assets?action=registerUpload", headers=headers, json=reg_payload, timeout=30)
        if res.status_code not in (200, 201):
            raise RuntimeError(f"LinkedIn image registration rejected (HTTP {res.status_code}): {res.text}")
        data = res.json()
        return data["value"]["asset"], data["value"]["uploadMechanism"]["com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest"]["uploadUrl"]

    def upload_binary_image(self, upload_url: str, image_bytes: bytes) -> bool:
        """Step 2 (Binary Upload): PUT raw image bytes with Content-Type: image/png."""
        tok = self.token or get_linkedin_token()
        res = requests.put(upload_url, data=image_bytes, headers={"Authorization": f"Bearer {tok}", "Content-Type": "image/png"}, timeout=60)
        return res.status_code in (200, 201)

    def poll_asset_status(self, asset_urn: str, max_retries: int = 3, sleep_sec: float = 1.0) -> bool:
        """Step 3 (Asset Status Polling): Query /v2/assets/{asset_id} until AVAILABLE."""
        tok = self.token or get_linkedin_token()
        asset_id = asset_urn.split(":")[-1]
        headers = {"Authorization": f"Bearer {tok}", "X-Restli-Protocol-Version": "2.0.0"}
        for _ in range(max_retries):
            try:
                res = requests.get(f"https://api.linkedin.com/v2/assets/{asset_id}", headers=headers, timeout=15)
                if res.status_code == 200:
                    d = res.json()
                    if d.get("status") == "AVAILABLE" or (d.get("recipes") and d["recipes"][0].get("status") == "AVAILABLE"):
                        return True
            except Exception:
                pass
            time.sleep(sleep_sec)
        return False

    def publish_ugc_post(self, author_urn: str, post_text: str, asset_urn: Optional[str] = None) -> Dict[str, Any]:
        """Step 4 (Publish UGC Post): Dispatch /v2/ugcPosts and validate HTTP 201."""
        tok = self.token or get_linkedin_token()
        headers = {"Authorization": f"Bearer {tok}", "X-Restli-Protocol-Version": "2.0.0", "Content-Type": "application/json"}
        payload = {
            "author": author_urn,
            "lifecycleState": "PUBLISHED",
            "specificContent": {
                "com.linkedin.ugc.ShareContent": {
                    "shareCommentary": {"text": post_text},
                    "shareMediaCategory": "IMAGE" if asset_urn else "NONE",
                    **({"media": [{"status": "READY", "description": {"text": "Visual summary"}, "media": asset_urn, "title": {"text": "Infographic"}}]} if asset_urn else {})
                }
            },
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
        }
        res = requests.post("https://api.linkedin.com/v2/ugcPosts", headers=headers, json=payload, timeout=30)
        if res.status_code not in (200, 201):
            raise RuntimeError(f"LinkedIn UGC post creation rejected (HTTP {res.status_code}): {res.text}")
        data = res.json()
        post_urn = data.get("id") or ""
        return {
            "status": "success",
            "post_id": post_urn,
            "post_url": f"https://www.linkedin.com/feed/update/{post_urn}/",
            "platform": "linkedin"
        }

    def publish_post(self, post_text: str, image_path: Optional[str | Path] = None) -> Dict[str, Any]:
        return publish_to_linkedin(post_text, image_path)



# ============================================================================
# X (TWITTER) PUBLISHER (API v2 & v1.1 Media REST API)
# ============================================================================

def get_x_credentials() -> Dict[str, Optional[str]]:
    return {
        "api_key": _get_setting("x_api_key") or _get_setting("x_consumer_key"),
        "api_secret": _get_setting("x_api_secret") or _get_setting("x_consumer_secret"),
        "access_token": _get_setting("x_access_token"),
        "access_token_secret": _get_setting("x_access_token_secret"),
        "user_access_token": _get_setting("x_user_access_token"),
    }


def verify_x_connection(
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
    access_token: Optional[str] = None,
    access_token_secret: Optional[str] = None,
    user_access_token: Optional[str] = None,
) -> Dict[str, Any]:
    """Verify X API connection and fetch authenticated user profile."""
    creds = get_x_credentials()
    k = api_key or creds["api_key"]
    ks = api_secret or creds["api_secret"]
    at = access_token or creds["access_token"]
    ats = access_token_secret or creds["access_token_secret"]
    uat = user_access_token or creds["user_access_token"]

    url = "https://api.twitter.com/2/users/me"

    # Try OAuth 1.0a first if full set is present
    if k and ks and at and ats and OAuth1 is not None:
        auth = OAuth1(k, ks, at, ats)
        res = requests.get(url, auth=auth, timeout=15)
    elif uat:
        headers = {"Authorization": f"Bearer {uat}"}
        res = requests.get(url, headers=headers, timeout=15)
    else:
        raise RuntimeError("No X credentials configured. Please configure OAuth 1.0a or OAuth 2.0 User Token in Settings.")

    if res.status_code == 200:
        data = res.json().get("data", {})
        return {
            "status": "connected",
            "platform": "x",
            "username": data.get("username"),
            "name": data.get("name"),
            "id": data.get("id")
        }

    err_msg = res.text or f"HTTP {res.status_code}"
    raise RuntimeError(f"X authentication failed (HTTP {res.status_code}): {err_msg}")


def publish_to_x(post_text: str, image_path: Optional[str | Path] = None) -> Dict[str, Any]:
    """Publish text and optional media to X using API v2 and v1.1 upload."""
    creds = get_x_credentials()
    k, ks, at, ats = creds["api_key"], creds["api_secret"], creds["access_token"], creds["access_token_secret"]
    uat = creds["user_access_token"]

    has_oauth1 = bool(k and ks and at and ats and OAuth1 is not None)
    if not has_oauth1 and not uat:
        raise RuntimeError("X credentials are not configured. Configure in System Settings.")

    media_id = None
    if image_path and has_oauth1:
        img_p = Path(image_path)
        if not img_p.is_absolute():
            img_p = ROOT / img_p
        if img_p.suffix.lower() == ".svg" and img_p.with_suffix(".png").exists():
            img_p = img_p.with_suffix(".png")

        img_bytes = None
        if img_p.exists():
            img_bytes = img_p.read_bytes()
        else:
            try:
                from backend.storage import get_storage_provider
                img_bytes = get_storage_provider().get_file(str(image_path))
            except Exception:
                img_bytes = None

        if img_bytes:
            upload_url = "https://upload.twitter.com/1.1/media/upload.json"
            auth = OAuth1(k, ks, at, ats)
            files = {"media": img_bytes}
            up_res = requests.post(upload_url, auth=auth, files=files, timeout=45)
            if up_res.status_code in (200, 201, 202):
                media_id = up_res.json().get("media_id_string")

    final_text = append_custom_hashtags(post_text)
    trimmed_text = trim_post_text(final_text, limit=280)
    tweet_payload: Dict[str, Any] = {"text": trimmed_text}
    if media_id:
        tweet_payload["media"] = {"media_ids": [media_id]}

    tweet_url = "https://api.twitter.com/2/tweets"
    if has_oauth1:
        auth = OAuth1(k, ks, at, ats)
        post_res = requests.post(tweet_url, auth=auth, json=tweet_payload, timeout=20)
    else:
        headers = {"Authorization": f"Bearer {uat}", "Content-Type": "application/json"}
        post_res = requests.post(tweet_url, headers=headers, json=tweet_payload, timeout=20)

    if post_res.status_code not in (200, 201):
        err_detail = ""
        try:
            err_json = post_res.json()
            err_detail = err_json.get("detail") or err_json.get("title") or err_json.get("message") or str(err_json)
        except Exception:
            err_detail = post_res.text or f"HTTP {post_res.status_code}"
        raise RuntimeError(f"X API rejected post (HTTP {post_res.status_code}): {err_detail}")

    data = post_res.json().get("data", {})
    tweet_id = data.get("id") or ""
    post_url = f"https://x.com/i/web/status/{tweet_id}" if tweet_id else "https://x.com"

    return {
        "status": "success",
        "tweet_id": tweet_id,
        "post_url": post_url,
        "platform": "x"
    }


# ============================================================================
# BACKWARD COMPATIBILITY
# ============================================================================

def publish_draft(body: str, asset: Optional[str] = None, project_root: Optional[Path] = None) -> Optional[str]:
    """Compatibility drop-in for previous Playwright-based publish_draft."""
    image_path = None
    if asset:
        base = project_root or ROOT
        image_path = base / asset
    result = publish_to_linkedin(post_text=body, image_path=image_path)
    return result.get("post_url")
