"""
Postall_V4 - Enterprise Pluggable Secrets Manager (backend/vault.py)
Provides zero-leak secret storage with transparent encryption-at-rest.
Supports two enterprise operational modes:
  1. Mode A: Local Encrypted Vault (Fernet AES-256-CBC-HMAC-SHA256) with persistent key isolation.
  2. Mode B: HashiCorp Vault REST API (AppRole/Token auth) with local cache & graceful fallback.
"""

import os
import sys
import json
import base64
import hashlib
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

# Sensitive key names that should always be encrypted at rest
SENSITIVE_SECRET_KEYS = {
    "gemini_api_key",
    "gemini_api_keys",
    "linkedin_access_token",
    "linkedin_client_secret",
    "twitter_api_secret",
    "twitter_access_token",
    "twitter_access_token_secret",
    "smtp_password",
    "github_pat",
    "webhook_secret",
    "jwt_secret_key"
}

_CIPHER_PREFIX = "enc:fernet:v1:"
_MASTER_KEY_FILE = Path(__file__).resolve().parent.parent / "data" / ".vault_master.key"

# In-memory secret cache for Vault
_memory_cache: Dict[str, Tuple[str, float]] = {}
_CACHE_TTL_SECONDS = 120


def _get_or_create_master_key() -> bytes:
    """
    Acquire or generate a 32-byte URL-safe base64 Fernet encryption key.
    Checks environment variable POSTALL_MASTER_KEY first, then local key file.
    """
    env_key = os.getenv("POSTALL_MASTER_KEY", "").strip()
    if env_key:
        try:
            raw = env_key.encode("utf-8")
            if len(base64.urlsafe_b64decode(raw)) == 32:
                return raw
        except Exception:
            # Derive 32-byte key via SHA-256
            return base64.urlsafe_b64encode(hashlib.sha256(env_key.encode("utf-8")).digest())

    _MASTER_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if _MASTER_KEY_FILE.exists():
        try:
            content = _MASTER_KEY_FILE.read_bytes().strip()
            if len(base64.urlsafe_b64decode(content)) == 32:
                return content
        except Exception:
            pass

    # Generate new Cryptographically secure 32-byte key
    try:
        from cryptography.fernet import Fernet
        key = Fernet.generate_key()
    except Exception:
        key = base64.urlsafe_b64encode(os.urandom(32))

    try:
        _MASTER_KEY_FILE.write_bytes(key)
        # Lock down file permissions to read/write for owner only (0600) on POSIX
        if os.name == "posix":
            os.chmod(_MASTER_KEY_FILE, 0o600)
    except Exception as e:
        print(f"[VAULT] Warning: Could not write master key file: {e}")

    return key


def _get_fernet():
    """Lazily initialize Fernet cipher instance."""
    from cryptography.fernet import Fernet
    return Fernet(_get_or_create_master_key())


def encrypt_value(plaintext: str) -> str:
    """Encrypt a plaintext string using Fernet AES-256 symmetric cipher."""
    if not plaintext:
        return ""
    if plaintext.startswith(_CIPHER_PREFIX):
        return plaintext  # Already encrypted
    try:
        f = _get_fernet()
        ciphertext = f.encrypt(plaintext.encode("utf-8")).decode("utf-8")
        return f"{_CIPHER_PREFIX}{ciphertext}"
    except Exception as e:
        print(f"[VAULT] Encryption failed: {e}")
        return plaintext


def decrypt_value(stored_value: str) -> str:
    """Decrypt a stored ciphertext value or return plaintext if not encrypted."""
    if not stored_value or not isinstance(stored_value, str):
        return stored_value or ""
    if not stored_value.startswith(_CIPHER_PREFIX):
        return stored_value  # Plaintext compatibility
    ciphertext = stored_value[len(_CIPHER_PREFIX):]
    try:
        f = _get_fernet()
        decrypted_bytes = f.decrypt(ciphertext.encode("utf-8"))
        return decrypted_bytes.decode("utf-8")
    except Exception as e:
        print(f"[VAULT] Decryption failed for secret: {e}")
        return stored_value


class HashiCorpVaultClient:
    """REST client for external HashiCorp Vault server."""

    def __init__(self):
        self.vault_addr = os.getenv("VAULT_ADDR", "").rstrip("/")
        self.vault_token = os.getenv("VAULT_TOKEN", "")
        self.path_prefix = os.getenv("VAULT_PATH_PREFIX", "secret/data/postall").strip("/")
        self.role_id = os.getenv("VAULT_ROLE_ID", "")
        self.secret_id = os.getenv("VAULT_SECRET_ID", "")
        self.is_enabled = bool(self.vault_addr)

    def authenticate_approle(self) -> bool:
        """Authenticate using AppRole and obtain client token."""
        if not self.vault_addr or not self.role_id or not self.secret_id:
            return False
        url = f"{self.vault_addr}/v1/auth/approle/login"
        payload = json.dumps({"role_id": self.role_id, "secret_id": self.secret_id}).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                token = data.get("auth", {}).get("client_token")
                if token:
                    self.vault_token = token
                    return True
        except Exception as e:
            print(f"[VAULT] AppRole auth failed: {e}")
        return False

    def get_secret(self, key: str) -> Optional[str]:
        """Fetch secret from HashiCorp Vault KV v2."""
        if not self.is_enabled:
            return None
        if not self.vault_token and self.role_id:
            self.authenticate_approle()
        if not self.vault_token:
            return None

        url = f"{self.vault_addr}/v1/{self.path_prefix}/{key}"
        req = urllib.request.Request(url, headers={"X-Vault-Token": self.vault_token})
        try:
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                # KV v2 stores values in data.data
                val = data.get("data", {}).get("data", {}).get("value")
                if val is not None:
                    return str(val)
                return data.get("data", {}).get("value")
        except urllib.error.HTTPError as he:
            if he.code != 404:
                print(f"[VAULT] Vault HTTP {he.code}: {he.reason}")
        except Exception as e:
            print(f"[VAULT] Error fetching secret '{key}': {e}")
        return None

    def set_secret(self, key: str, value: str) -> bool:
        """Store secret in HashiCorp Vault KV v2."""
        if not self.is_enabled:
            return False
        if not self.vault_token and self.role_id:
            self.authenticate_approle()
        if not self.vault_token:
            return False

        url = f"{self.vault_addr}/v1/{self.path_prefix}/{key}"
        payload = json.dumps({"data": {"value": value}}).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers={"X-Vault-Token": self.vault_token, "Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                return resp.status in (200, 204)
        except Exception as e:
            print(f"[VAULT] Error writing secret '{key}': {e}")
            return False

    def health(self) -> Dict[str, Any]:
        """Check Vault health endpoint."""
        if not self.is_enabled:
            return {"configured": False, "status": "Disabled (Using Local Fernet Vault)"}
        try:
            url = f"{self.vault_addr}/v1/sys/health"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return {
                    "configured": True,
                    "status": "Healthy & Unsealed" if data.get("initialized") and not data.get("sealed") else "Sealed",
                    "version": data.get("version", "unknown"),
                    "cluster_name": data.get("cluster_name", "")
                }
        except Exception as e:
            return {"configured": True, "status": f"Unreachable ({str(e)})"}


_vault_client = HashiCorpVaultClient()


def _get_db():
    from backend.database import get_db
    return get_db()


def get_secret(key: str, default: str = "") -> str:
    """
    High-level secret accessor with caching, Vault integration, and encrypted DB fallback.
    """
    now = time.time()
    # 1. Check in-memory cache
    if key in _memory_cache:
        val, expiry = _memory_cache[key]
        if now < expiry:
            return val

    # 2. Check external HashiCorp Vault if enabled
    if _vault_client.is_enabled:
        remote_val = _vault_client.get_secret(key)
        if remote_val is not None:
            _memory_cache[key] = (remote_val, now + _CACHE_TTL_SECONDS)
            return remote_val

    # 3. Fallback to Local Encrypted SQLite store
    db = _get_db()
    try:
        row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        if row and row["value"]:
            decrypted = decrypt_value(row["value"])
            _memory_cache[key] = (decrypted, now + _CACHE_TTL_SECONDS)
            return decrypted
    finally:
        db.close()

    # 4. Fallback to OS environment variable
    env_val = os.getenv(key.upper()) or os.getenv(key)
    if env_val:
        return env_val

    return default


def set_secret(key: str, value: str) -> bool:
    """
    Store a secret securely with encryption at rest and Vault sync.
    """
    now = time.time()
    _memory_cache[key] = (value, now + _CACHE_TTL_SECONDS)

    # 1. Write to HashiCorp Vault if enabled
    if _vault_client.is_enabled:
        _vault_client.set_secret(key, value)

    # 2. Always persist encrypted copy in SQLite settings
    encrypted = encrypt_value(value) if key in SENSITIVE_SECRET_KEYS else value
    db = _get_db()
    try:
        db.execute("""
            INSERT INTO settings (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value
        """, (key, encrypted))
        db.commit()

        # Audit event
        try:
            from backend.audit_streamer import log_audit_event
            log_audit_event("system", "SECRET_STORED", "secret", key, "SUCCESS", details={"key": key, "encrypted": key in SENSITIVE_SECRET_KEYS})
        except Exception:
            pass

        return True
    except Exception as e:
        print(f"[VAULT] Failed to save secret '{key}': {e}")
        return False
    finally:
        db.close()


def migrate_plaintext_to_vault() -> Dict[str, Any]:
    """
    Migrate existing plaintext credentials in SQLite to Fernet encrypted tokens.
    Safe to run repeatedly; skips already encrypted values.
    """
    db = _get_db()
    migrated = []
    skipped = []
    try:
        rows = db.execute("SELECT key, value FROM settings").fetchall()
        for r in rows:
            k = r["key"]
            v = r["value"]
            if k in SENSITIVE_SECRET_KEYS and v:
                if not v.startswith(_CIPHER_PREFIX):
                    enc = encrypt_value(v)
                    db.execute("UPDATE settings SET value = ? WHERE key = ?", (enc, k))
                    migrated.append(k)
                else:
                    skipped.append(k)
        db.commit()
    finally:
        db.close()

    return {
        "status": "success",
        "migrated_count": len(migrated),
        "migrated_keys": migrated,
        "already_encrypted_keys": skipped
    }


def get_vault_status() -> Dict[str, Any]:
    """Return status of the Pluggable Secrets Engine."""
    provider = "HashiCorp Vault + Local Fernet Fallback" if _vault_client.is_enabled else "Local Encrypted Fernet Vault (Zero-Leak Mode)"
    v_health = _vault_client.health()
    
    # Count encrypted keys in DB
    db = _get_db()
    enc_count = 0
    total_sensitive = 0
    try:
        rows = db.execute("SELECT key, value FROM settings").fetchall()
        for r in rows:
            if r["key"] in SENSITIVE_SECRET_KEYS:
                total_sensitive += 1
                if r["value"] and r["value"].startswith(_CIPHER_PREFIX):
                    enc_count += 1
    finally:
        db.close()

    return {
        "status": "Encrypted" if enc_count > 0 else "Operational",
        "mode": "hashicorp_vault" if _vault_client.is_enabled else "fernet_aes256",
        "master_key_present": _MASTER_KEY_FILE.exists() or bool(os.getenv("POSTALL_MASTER_KEY")),
        "active_provider": provider,
        "encryption_algorithm": "AES-256-CBC with HMAC-SHA256 (Fernet)",
        "hashicorp_vault": v_health,
        "local_key_file": str(_MASTER_KEY_FILE),
        "key_file_exists": _MASTER_KEY_FILE.exists(),
        "encrypted_secrets_count": enc_count,
        "total_sensitive_secrets": total_sensitive,
        "cached_keys_in_memory": len(_memory_cache)
    }
