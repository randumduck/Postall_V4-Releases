"""Postall_V4 FastAPI service.

All business data is kept in data/postall.db; legacy Excel, Streamlit and vanguard.db
scripts are deliberately not imported by this application.
"""
import base64, hashlib, hmac, html, json, os, re, secrets, smtplib, time, asyncio, zipfile, requests, sqlite3, logging, httpx, shutil
import ipaddress, socket, uuid
try:
    import ldap3
except ImportError:
    ldap3 = None
try:
    from cryptography.hazmat.primitives.asymmetric import ed25519
except ImportError:
    ed25519 = None
from contextlib import asynccontextmanager
from types import SimpleNamespace
from io import BytesIO
import psutil
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from html.parser import HTMLParser
from pathlib import Path
from typing import Optional, Union, Dict, Any, List, Tuple
from urllib.parse import quote, urlparse, urlunparse
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from fastapi import FastAPI, HTTPException, Depends, Header, BackgroundTasks, UploadFile, File, Form, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, Response, StreamingResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from .database import (
    get_db, init_db, checkpoint_db, purge_all_tables,
    add_notification, get_notifications, mark_all_notifications_read, get_unread_notifications_count,
    get_all_users, get_user_by_id, get_user_by_username, create_user, update_user, delete_user,
    is_setup_completed, set_setup_completed, check_data_volume_persistence,
    get_branding_settings, set_branding_settings,
    get_trending_sources, add_trending_source, delete_trending_source, toggle_trending_source
)
from .trending import (
    get_available_categories,
    fetch_trending_articles
)
from .document_parser import (
    extract_text_from_file
)
from .license_engine import (
    LICENSE_PUBLIC_KEY, verify_license, activate_license_key,
    MissingLicenseError, LicenseInvalidError
)
from .update_engine import (
    CURRENT_VERSION,
    get_current_version,
    get_version_manifest,
    check_version_oracle,
    check_github_update,
    check_github_releases,
    create_snapshot,
    create_pre_update_snapshot,
    apply_update,
    apply_ota_update,
    extract_update_payload,
    rollback_snapshot,
    list_snapshots,
    trigger_restart,
    trigger_graceful_restart,
    trigger_container_restart,
    log_update_history,
    get_update_history
)
from .ota_updater import (
    apply_latest_patch,
    check_ota_update,
    get_update_status as get_cached_ota_status,
    init_audit_ledger as init_ota_audit_ledger,
    list_update_audit_ledger,
    periodic_ota_worker,
)
from .social_publisher import (
    publish_to_linkedin,
    publish_to_x,
    verify_linkedin_connection,
    verify_x_connection,
    publish_draft,
)
from .personas import (
    get_persona_profile,
    get_post_system_prompt,
    get_svg_guidance,
    get_all_personas,
)
from .ai_router import (
    generate_text as ai_router_generate_text,
    test_provider_connection,
    register_local_llm_runner,
)
from .guardrails import (
    redact_pii,
    check_brand_safety,
    sanitize_violation_header,
)

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")
SECRET = os.getenv("JWT_SECRET", "change-this-secret")
logger = logging.getLogger(__name__)
local_llm = None
local_llm_lock = asyncio.Lock()
AUTOPILOT_LAST_TICK = datetime.now(timezone.utc).isoformat()

def load_local_model():
    global local_llm
    from huggingface_hub import hf_hub_download
    from llama_cpp import Llama
    local_model_file = ROOT / "data" / "models" / "qwen2.5-1.5b-instruct-q4_k_m.gguf"
    if local_model_file.is_file():
        model_path = str(local_model_file)
    else:
        model_path = hf_hub_download(
            repo_id="Qwen/Qwen2.5-1.5B-Instruct-GGUF",
            filename="qwen2.5-1.5b-instruct-q4_k_m.gguf",
            local_dir=str(ROOT / "data" / "models"),
        )
    local_llm = Llama(model_path=model_path, n_ctx=2048, verbose=False)


# ==============================================================================
# ASYMMETRIC ED25519 ENTERPRISE LICENSING & TELEMETRY CORE
# ==============================================================================
LICENSE_VALID = False
LICENSE_PAYLOAD: Dict[str, Any] = {}
LAST_LICENSE_ERROR: Optional[str] = None
_AI_STANDBY_WARNING_EMITTED = False

class LicenseActivateIn(BaseModel):
    license_key: str = Field(min_length=10, description="Base64 license key string")

def get_machine_id() -> str:
    """Derives a stable, cryptographic hardware identity string for the host machine."""
    try:
        node = uuid.getnode()
        return hashlib.sha256(f"POSTALL-HWID-{node}".encode("utf-8")).hexdigest()[:16]
    except Exception:
        return "UNKNOWN-HWID"


def _license_binding_value(payload: Dict[str, Any]) -> Optional[str]:
    for key in ("machine_id", "hwid", "device_id", "node_id", "bound_hwid", "bound_machine_id"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def verify_system_clock_integrity() -> bool:
    """Rejects clock rollback attempts before any runtime API work proceeds."""
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key='last_known_timestamp'").fetchone()
    db.close()
    last_known = (row["value"] if row and row["value"] is not None else "0.0").strip() if row else "0.0"
    try:
        last_known_ts = float(last_known)
    except (TypeError, ValueError):
        last_known_ts = 0.0
    current_time = time.time()
    if current_time < last_known_ts:
        raise RuntimeError("SYSTEM LOCKED: System clock rollback detected")
    try:
        db = get_db()
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('last_known_timestamp', ?)", (str(current_time),))
        db.commit()
        db.close()
    except Exception:
        pass
    return True


def bootstrap_active_license_from_db() -> Optional[Dict[str, Any]]:
    """Reloads any persisted active license directly from SQLite during startup."""
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key='active_license_key' LIMIT 1").fetchone()
    if not row or not str(row["value"] or "").strip():
        db.close()
        return None
    raw_key = str(row["value"]).strip()
    db.close()

    license_path = ROOT / "data" / "license.key"
    license_path.parent.mkdir(parents=True, exist_ok=True)
    previous = None
    if license_path.exists():
        try:
            previous = license_path.read_bytes()
        except Exception:
            previous = None
    try:
        license_path.write_text(raw_key, encoding="utf-8")
        payload = verify_license()
    except Exception:
        if previous is not None:
            try:
                license_path.write_bytes(previous)
            except Exception:
                pass
        raise

    bound_hwid = _license_binding_value(payload)
    machine_id = get_machine_id()
    db = get_db()
    existing_bound = db.execute("SELECT value FROM settings WHERE key='license_hwid_bound' LIMIT 1").fetchone()
    db.close()
    current_bound = (existing_bound["value"] if existing_bound and existing_bound["value"] else "").strip() if existing_bound else ""
    if current_bound and current_bound != machine_id:
        raise LicenseInvalidError(f"License is bound to a different machine: {current_bound} != {machine_id}")
    if bound_hwid and bound_hwid != machine_id:
        raise LicenseInvalidError(f"License is bound to a different machine: {bound_hwid} != {machine_id}")

    db = get_db()
    db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('license_hwid_bound', ?)", (machine_id,))
    db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('license_activated_at', ?)", (datetime.now(timezone.utc).isoformat(),))
    db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('last_known_timestamp', ?)", (str(time.time()),))
    db.commit()
    db.close()
    return payload


def sync_license_state(app_instance=None) -> bool:
    """Synchronizes in-memory and app.state license verification."""
    global LICENSE_VALID, LICENSE_PAYLOAD, LAST_LICENSE_ERROR
    try:
        verify_system_clock_integrity()
        try:
            lic_data = bootstrap_active_license_from_db() or verify_license()
        except Exception:
            lic_data = verify_license()
        LICENSE_VALID = True
        LICENSE_PAYLOAD = lic_data
        LAST_LICENSE_ERROR = None
        if app_instance is not None:
            app_instance.state.license_data = lic_data
        elif "app" in globals() and hasattr(globals()["app"], "state"):
            globals()["app"].state.license_data = lic_data
        return True
    except Exception as exc:
        LICENSE_VALID = False
        LICENSE_PAYLOAD = {}
        LAST_LICENSE_ERROR = str(exc)
        if app_instance is not None:
            app_instance.state.license_data = None
        elif "app" in globals() and hasattr(globals()["app"], "state"):
            globals()["app"].state.license_data = None
        logger.warning("[LICENSE] System running in UNLICENSED mode (%s: %s)", type(exc).__name__, exc)
        return False

def verify_system_license() -> bool:
    """Legacy helper bridging to verify_license()."""
    return sync_license_state()

def send_license_warning_email(days_remaining: int, client_name: str, expiry_date: str) -> bool:
    """Dispatches an automated license expiry warning email via SMTP."""
    try:
        db = get_db()
        settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
        admin_row = db.execute("SELECT email FROM users WHERE username='admin' LIMIT 1").fetchone()
        db.close()

        host = settings.get("smtp_host") or os.getenv("SMTP_HOST")
        sender = settings.get("smtp_sender") or os.getenv("EMAIL_SENDER")
        receiver = settings.get("smtp_receiver") or (admin_row["email"] if admin_row and admin_row["email"] else os.getenv("EMAIL_RECEIVER"))
        if not host or not sender or not receiver:
            logger.info("[LICENSE] SMTP not fully configured; skipping license warning email.")
            return False

        msg = EmailMessage()
        msg["Subject"] = f"[CRITICAL ACTION REQUIRED] Postall_V4 License Expires in {days_remaining} Day{'s' if days_remaining != 1 else ''}"
        msg["From"] = sender
        msg["To"] = receiver
        content = (
            f"Dear Administrator,\n\n"
            f"This is an automated operational alert from the Postall_V4 Core Engine.\n\n"
            f"Your enterprise cryptographic license for '{client_name}' will expire in {days_remaining} day{'s' if days_remaining != 1 else ''}.\n"
            f"Official Expiration Date: {expiry_date}\n\n"
            f"When the license expires, core background publishing, AI generation pipelines, and API services will be locked (HTTP 402 Payment Required).\n\n"
            f"Please generate an updated license key using License Forge and activate it via the Postall_V4 Dashboard Activation Center.\n\n"
            f"Best regards,\n"
            f"Postall_V4 Autonomous System\n"
        )
        msg.set_content(content)
        password = settings.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD", "")
        port = int(settings.get("smtp_port") or os.getenv("SMTP_PORT", "587"))

        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            if password:
                smtp.login(sender, password)
            smtp.send_message(msg)
        logger.info("[LICENSE] Dispatched expiry alert email for %d days remaining.", days_remaining)
        return True
    except Exception as exc:
        logger.warning("[LICENSE] Failed dispatching expiry warning email: %s", exc)
        return False

async def license_monitor_loop(app_instance):
    """
    Background expiry loop running asynchronously every 24 hours.
    - Calculates days_remaining from app.state.license_data['expires_at'].
    - If days_remaining is exactly 30, 14, 7, 3, or 1: dispatches warning email via SMTP.
    - If days_remaining <= 30: inserts a row into notifications table once per day.
    """
    while True:
        try:
            lic = getattr(app_instance.state, "license_data", None)
            if lic is None:
                try:
                    lic = verify_license()
                    app_instance.state.license_data = lic
                    global LICENSE_VALID, LICENSE_PAYLOAD
                    LICENSE_VALID = True
                    LICENSE_PAYLOAD = lic
                except Exception:
                    lic = None

            if lic:
                exp_ts = lic.get("expires_at")
                if isinstance(exp_ts, (int, float)):
                    days_remaining = max(0, int((exp_ts - time.time()) / 86400))
                else:
                    dt = datetime.fromisoformat(str(exp_ts).replace("Z", "+00:00"))
                    days_remaining = max(0, int((dt.timestamp() - time.time()) / 86400))

                client_name = lic.get("client") or lic.get("client_name") or "Enterprise Client"
                exp_str = lic.get("expires_at_iso") or str(exp_ts)

                # Send email on exact milestone days
                if days_remaining in (30, 14, 7, 3, 1):
                    await asyncio.to_thread(send_license_warning_email, days_remaining, client_name, exp_str)

                # Insert notification row once per day if <= 30 days
                if days_remaining <= 30:
                    today_prefix = datetime.now().strftime("%Y-%m-%d")
                    db = get_db()
                    existing = db.execute(
                        "SELECT id FROM notifications WHERE category='warning' AND title='License Expiring Soon' AND created_at LIKE ? LIMIT 1",
                        (f"{today_prefix}%",)
                    ).fetchone()
                    if not existing:
                        category = "critical" if days_remaining <= 3 else "warning"
                        msg_text = (
                            f"Your Postall_V4 license ({lic.get('type', 'Enterprise')}) for '{client_name}' "
                            f"will expire in {days_remaining} day{'s' if days_remaining != 1 else ''} ({exp_str}). "
                            f"Renew and activate a new key to prevent system lockout."
                        )
                        db.execute(
                            "INSERT INTO notifications (category, title, message, is_read) VALUES (?, ?, ?, 0)",
                            (category, "License Expiring Soon", msg_text)
                        )
                        db.commit()
                    db.close()
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.error("[LICENSE MONITOR] Error in license monitor loop: %s", exc)

        await asyncio.sleep(86400)

async def telemetry_loop():
    """
    Background telemetry heartbeat task that runs once on startup and once every 24 hours.
    Dispatches a signed hardware telemetry ping silently without blocking or crashing.
    """
    while True:
        try:
            lic = LICENSE_PAYLOAD if LICENSE_VALID else {}
            lic_id = lic.get("license_id", "UNLICENSED") if LICENSE_VALID else "UNLICENSED"
            payload = {
                "license_id": lic_id,
                "machine_id": get_machine_id(),
                "version": "v4.1",
                "status": "active" if LICENSE_VALID else "unlicensed",
                "client_name": lic.get("client") or lic.get("client_name") or "Unlicensed",
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            def _post_ping():
                try:
                    requests.post("https://telemetry.yourdomain.com/ping", json=payload, timeout=8)
                except Exception:
                    pass
            await asyncio.to_thread(_post_ping)
            logger.debug("[TELEMETRY] Telemetry heartbeat dispatched silently.")
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.debug("[TELEMETRY] Telemetry ping caught exception: %s", exc)
        await asyncio.sleep(86400)

@asynccontextmanager
async def lifespan(_app):
    global LICENSE_VALID, LICENSE_PAYLOAD
    init_db()
    rotate_post_archives()

    try:
        verify_system_clock_integrity()
    except Exception as exc:
        _app.state.license_data = None
        LICENSE_VALID = False
        LICENSE_PAYLOAD = {}
        logger.warning("[LICENSE] System startup blocked: %s", exc)
        log("ERROR", "LICENSE", "SYSTEM LOCKED: System clock rollback detected")

    # Cryptographic verification on startup stored in app.state.license_data. Prefer SQLite-backed activation to survive restore/backup operations.
    try:
        boot_lic = bootstrap_active_license_from_db() if not (ROOT / "data" / "license.key").exists() else None
        _app.state.license_data = boot_lic or verify_license()
        LICENSE_VALID = True
        LICENSE_PAYLOAD = _app.state.license_data
        logger.info("[LICENSE] Verified valid %s license for '%s' (Expires: %s)",
                    _app.state.license_data.get("type"), _app.state.license_data.get("client"), _app.state.license_data.get("expires_at_iso"))
        log("INFO", "LICENSE", f"Active {_app.state.license_data.get('type')} license verified for '{_app.state.license_data.get('client')}'")
    except Exception as exc:
        _app.state.license_data = None
        LICENSE_VALID = False
        LICENSE_PAYLOAD = {}
        logger.warning("[LICENSE] System starting in UNLICENSED mode: %s", exc)
        log("WARNING", "LICENSE", f"No valid license detected ({type(exc).__name__}). Core API locked.")

    log("INFO","CORE","Postall_V4 initialized with postall.db")
    try:
        db_init = get_db()
        p_row = db_init.execute("SELECT value FROM settings WHERE key='post_time'").fetchone()
        tz_row = db_init.execute("SELECT value FROM settings WHERE key='timezone'").fetchone()
        if p_row and p_row["value"]:
            reschedule_upcoming_drafts_to_new_post_time(db_init, p_row["value"], tz_row["value"] if tz_row else None)
        db_init.close()
    except Exception as exc:
        logger.warning("Could not synchronize scheduled drafts on startup: %s", exc)
    async def _load_local_model_bg():
        try:
            await asyncio.to_thread(load_local_model)
            log("INFO","LOCAL_LLM","Postall_V4 AI engine (Qwen2.5-1.5B-Instruct) loaded with n_ctx=1024 (non-blocking startup)")
        except Exception as exc:
            global local_llm
            local_llm = None
            logger.error("Local LLM startup failed; FastAPI will continue without it (%s: %s)", type(exc).__name__, exc)
            log("ERROR","LOCAL_LLM",f"Local model unavailable at startup ({type(exc).__name__}): {str(exc)[:240]}")
    asyncio.create_task(_load_local_model_bg())

    # Enterprise P2 Capabilities: SIEM Audit Worker, Vault Migration, and Social BI
    try:
        from backend.audit_streamer import ensure_worker_started, log_audit_event
        ensure_worker_started()
        log_audit_event("system", "SYSTEM_STARTUP", "core", None, "SUCCESS", details={"version": "4.0.1"})
    except Exception as exc:
        logger.warning(f"Could not initialize SIEM audit worker: {exc}")

    try:
        from backend.vault import migrate_plaintext_to_vault
        migrate_plaintext_to_vault()
    except Exception as exc:
        logger.warning(f"Vault secret migration skipped: {exc}")

    try:
        from backend.social_analytics import harvest_social_analytics
        asyncio.create_task(asyncio.to_thread(harvest_social_analytics))
    except Exception as exc:
        logger.warning(f"Initial social analytics harvest deferred: {exc}")

    scheduler = asyncio.create_task(scheduler_loop())
    telemetry_task = asyncio.create_task(telemetry_loop())
    license_monitor_task = asyncio.create_task(license_monitor_loop(_app))
    try:
        init_ota_audit_ledger()
        ota_task = asyncio.create_task(periodic_ota_worker())
    except Exception:
        logger.exception("Could not initialize the OTA updater.")
        ota_task = None
    try:
        yield
    finally:
        scheduler.cancel()
        telemetry_task.cancel()
        license_monitor_task.cancel()
        tasks = (scheduler, telemetry_task, license_monitor_task, ota_task)
        for t in tasks:
            if t is not None:
                t.cancel()
        for t in tasks:
            if t is None:
                continue
            try:
                await t
            except asyncio.CancelledError:
                pass

from starlette.middleware.sessions import SessionMiddleware
app = FastAPI(title="Postall_V4", version="2.1.0", description="Enterprise AI Content Orchestration & Governance Platform", lifespan=lifespan)
app.add_middleware(SessionMiddleware, secret_key=SECRET)
app.mount("/static", StaticFiles(directory=ROOT / "frontend" / "static"), name="static")

@app.middleware("http")
async def setup_initialization_middleware(request: Request, call_next):
    path = request.url.path
    if path.startswith("/static") or path == "/favicon.ico" or path.startswith("/healthz") or path == "/metrics":
        return await call_next(request)

    completed = is_setup_completed()
    if not completed:
        if path == "/setup" or path == "/setup.html" or path.startswith("/api/setup"):
            return await call_next(request)

        if path.startswith("/api/"):
            return JSONResponse(
                status_code=403,
                content={
                    "detail": "Setup Incomplete: System must be initialized via Setup Wizard.",
                    "status": "setup_incomplete",
                    "setup_url": "/setup"
                }
            )

        return RedirectResponse(url="/setup", status_code=307)

    if path == "/setup" or path == "/setup.html":
        return RedirectResponse(url="/dashboard", status_code=307)

    return await call_next(request)

@app.middleware("http")
async def license_enforcement_middleware(request, call_next):
    path = request.url.path
    if path.startswith("/api/"):
        try:
            verify_system_clock_integrity()
        except Exception:
            return JSONResponse(
                status_code=402,
                content={
                    "detail": "SYSTEM LOCKED: System clock rollback detected",
                    "status": "system_clock_rollback",
                    "error": "HTTP 402 / SYSTEM LOCKED: System clock rollback detected"
                }
            )

        exempt = (
            path.startswith("/api/token") or
            path.startswith("/api/auth") or
            path.startswith("/api/license") or
            path.startswith("/api/health") or
            path.startswith("/api/audit") or
            path.startswith("/api/vault") or
            path.startswith("/api/analytics") or
            path.startswith("/api/storage") or
            path.startswith("/api/tasks")
        )
        license_data = getattr(request.app.state, "license_data", None)
        if not exempt and license_data is None:
            return JSONResponse(
                status_code=402,
                content={
                    "detail": "Payment Required: Valid License Required",
                    "status": "license_required",
                    "error": "HTTP 402 Payment Required: System Locked. Valid Ed25519 License Required."
                }
            )
    return await call_next(request)

def check_license_admin_permission(authorization: Optional[str] = Header(None)):
    """Blocks authenticated non-admin users (editors, viewers) from activating or managing licenses."""
    if authorization and authorization.lower().startswith("bearer "):
        try:
            raw, sig = authorization.split(" ", 1)[1].split(".")
            expected = hmac.new(SECRET.encode(), raw.encode(), hashlib.sha256).hexdigest()
            payload = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw)%4)))
            if hmac.compare_digest(sig, expected) and payload.get("exp", 0) >= time.time():
                role = (payload.get("role") or "").lower()
                if not role:
                    user_rec = get_user_record(payload.get("sub", ""))
                    role = (user_rec.get("role") or "admin").lower()
                if role != "admin":
                    raise HTTPException(403, "Administrative privileges required to activate or manage licenses")
        except HTTPException:
            raise
        except Exception:
            pass

@app.get("/api/license")
def get_license_info():
    is_valid = sync_license_state(app)
    return {
        "valid": is_valid,
        "machine_id": get_machine_id(),
        "payload": getattr(app.state, "license_data", None),
        "status": "active" if is_valid else "inactive_or_expired",
        "error": LAST_LICENSE_ERROR
    }

@app.post("/api/license/reload")
def reload_license_info(_=Depends(check_license_admin_permission)):
    is_valid = sync_license_state(app)
    return {
        "valid": is_valid,
        "machine_id": get_machine_id(),
        "payload": getattr(app.state, "license_data", None),
        "status": "active" if is_valid else "inactive_or_expired",
        "error": LAST_LICENSE_ERROR
    }

@app.post("/api/license/activate")
def activate_license(req: LicenseActivateIn, _=Depends(check_license_admin_permission)):
    """Accepts a Base64 Ed25519 key, validates it against the current machine, and persists activation metadata."""
    clean_key = req.license_key.strip()
    try:
        data = activate_license_key(clean_key)
        machine_id = get_machine_id()
        bound_hwid = _license_binding_value(data)
        db = get_db()
        existing_bound = db.execute("SELECT value FROM settings WHERE key='license_hwid_bound' LIMIT 1").fetchone()
        current_bound = (existing_bound["value"] if existing_bound and existing_bound["value"] else "").strip() if existing_bound else ""
        db.close()
        if current_bound and current_bound != machine_id:
            raise LicenseInvalidError(f"License is bound to a different machine: {current_bound} != {machine_id}")
        if bound_hwid and bound_hwid != machine_id:
            raise LicenseInvalidError(f"License is bound to a different machine: {bound_hwid} != {machine_id}")

        db = get_db()
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('active_license_key', ?)", (clean_key,))
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('license_activated_at', ?)", (datetime.now(timezone.utc).isoformat(),))
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('license_hwid_bound', ?)", (machine_id,))
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('last_known_timestamp', ?)", (str(time.time()),))
        db.commit()
        db.close()

        app.state.license_data = data
        global LICENSE_VALID, LICENSE_PAYLOAD
        LICENSE_VALID = True
        LICENSE_PAYLOAD = data
        purge_stale_license_notifications(data)
        add_notification(
            "info",
            "License Activated",
            f"License successfully activated for {data.get('client')} ({data.get('type')}). Valid until {data.get('expires_at_iso')}."
        )
        log("INFO", "LICENSE", f"License successfully activated for '{data.get('client')}' ({data.get('type')})")
        return {
            "status": "success",
            "message": "License activated successfully",
            "license": data,
            "machine_id": machine_id,
            "bound_hwid": bound_hwid or machine_id,
        }
    except Exception as exc:
        logger.error("[LICENSE] License activation failed: %s", exc)
        raise HTTPException(status_code=400, detail=f"License activation failed: {exc}")

def purge_stale_license_notifications(license_data: Optional[Dict[str, Any]]) -> int:
    """Remove expired-license warnings once a verified license has over 30 days left."""
    if not license_data:
        return 0

    try:
        expires_at = license_data.get("expires_at")
        if isinstance(expires_at, (int, float)):
            days_remaining = int((expires_at - time.time()) / 86400)
        else:
            expires_at = license_data.get("expires_at_iso") or expires_at
            if not expires_at:
                return 0
            expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            days_remaining = int((expiry.timestamp() - time.time()) / 86400)
    except (TypeError, ValueError, OverflowError):
        logger.warning("[LICENSE] Could not calculate expiry while cleaning stale notifications.")
        return 0

    if days_remaining <= 30:
        return 0

    db = get_db()
    try:
        deleted = db.execute(
            "DELETE FROM notifications WHERE title LIKE '%License Expiring%'"
        ).rowcount
        db.commit()
        return deleted
    except sqlite3.Error as exc:
        logger.warning("[LICENSE] Could not remove stale expiry notifications: %s", exc)
        return 0
    finally:
        db.close()

@app.get("/api/notifications")
def api_get_notifications(limit: int = 50, unread_only: bool = False):
    """Returns recent system notifications and unread badge count."""
    if LICENSE_VALID:
        purge_stale_license_notifications(LICENSE_PAYLOAD)
    return {
        "status": "success",
        "notifications": get_notifications(limit=limit, unread_only=unread_only),
        "unread_count": get_unread_notifications_count()
    }

@app.post("/api/notifications/read-all")
def api_mark_notifications_read():
    """Marks all unread notifications as read."""
    count = mark_all_notifications_read()
    return {
        "status": "success",
        "marked_read": count,
        "unread_count": 0
    }

@app.get("/api/telemetry")
def get_telemetry_info():
    lic = getattr(app.state, "license_data", None)
    return {
        "machine_id": get_machine_id(),
        "license_id": lic.get("license_id", "UNLICENSED") if lic else "UNLICENSED",
        "status": "active" if lic else "unlicensed",
        "version": "v4.1"
    }


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    return "pbkdf2$" + base64.urlsafe_b64encode(salt).decode() + "$" + hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 210000).hex()
def verify_password(password, stored):
    try:
        _, s, digest = stored.split("$"); salt = base64.urlsafe_b64decode(s.encode())
        return hmac.compare_digest(hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 210000).hex(), digest)
    except (ValueError, TypeError): return False
def token_for(user):
    payload = {"sub": user, "exp": int(time.time()) + 86400}
    raw = base64.urlsafe_b64encode(json.dumps(payload, separators=(",",":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), raw.encode(), hashlib.sha256).hexdigest()
    return raw + "." + sig

def token_for_mfa(user):
    payload = {"sub": user, "mfa_pending": True, "exp": int(time.time()) + 300}
    raw = base64.urlsafe_b64encode(json.dumps(payload, separators=(",",":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), raw.encode(), hashlib.sha256).hexdigest()
    return raw + "." + sig

def verify_mfa_token(token):
    try:
        raw, sig = token.split(".")
        expected = hmac.new(SECRET.encode(), raw.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        payload = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw)%4)))
        if payload.get("exp", 0) < time.time() or not payload.get("mfa_pending"):
            return None
        return payload.get("sub")
    except Exception:
        return None

def current_user(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.lower().startswith("bearer "): raise HTTPException(401, "Authentication required")
    try:
        raw, sig = authorization.split(" ",1)[1].split("."); expected = hmac.new(SECRET.encode(), raw.encode(), hashlib.sha256).hexdigest()
        payload = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw)%4)))
        if not hmac.compare_digest(sig, expected) or payload["exp"] < time.time(): raise ValueError()
        if payload.get("mfa_pending"): raise ValueError("MFA verification incomplete")
    except Exception: raise HTTPException(401, "Invalid or expired token")
    return payload["sub"]

def get_user_record(username: str) -> dict:
    u = get_user_by_username(username)
    if not u:
        raise HTTPException(401, "User session invalid or user not found.")
    if not u.get("is_active", 1):
        raise HTTPException(403, "Your account has been deactivated. Please contact an administrator.")
    return u

def require_role(allowed_roles: list):
    def dependency(auth_username: str = Depends(current_user)):
        user_rec = get_user_record(auth_username)
        user_role = (user_rec.get("role") or "admin").lower()
        if user_role not in allowed_roles:
            raise HTTPException(403, f"Access Forbidden: Role '{user_role}' lacks permission for this critical operation.")
        return user_rec
    return dependency

require_admin = require_role(["admin"])
require_editor = require_role(["admin", "editor"])

class UserCreateIn(BaseModel):
    username: str = Field(min_length=3, max_length=50)
    email: Optional[str] = ""
    password: str = Field(min_length=4)
    role: str = Field(default="editor")
    must_change_password: bool = False

class UserUpdateIn(BaseModel):
    email: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None
    password: Optional[str] = None
    must_change_password: Optional[bool] = None

def log(level, module, message):
    db=get_db()
    try:
        setup_row = db.execute("SELECT value FROM settings WHERE key='is_setup_complete'").fetchone()
        if not setup_row or str(setup_row["value"]).strip().lower() not in {"1", "true", "yes", "completed"}:
            return
        setting=db.execute("SELECT value FROM settings WHERE key='timezone'").fetchone()
        try:
            log_timezone = ZoneInfo(setting["value"] if setting and setting["value"] else "Asia/Kolkata")
        except (ZoneInfoNotFoundError, ValueError):
            log_timezone = ZoneInfo("Asia/Kolkata")
        db.execute("INSERT INTO system_logs(timestamp,level,module,message) VALUES(?,?,?,?)",
                   (datetime.now(log_timezone).isoformat(timespec="seconds"),level,module,message))
        db.commit()
    finally:
        db.close()

def configured_timezone():
    db=get_db()
    setting=db.execute("SELECT value FROM settings WHERE key='timezone'").fetchone()
    db.close()
    try:
        return ZoneInfo(setting["value"] if setting and setting["value"] else "Asia/Kolkata")
    except (ZoneInfoNotFoundError,ValueError):
        return ZoneInfo("Asia/Kolkata")

def local_datetime_label(value,tz=None):
    if not value:
        return ""
    tz=tz or configured_timezone()
    try:
        parsed=datetime.fromisoformat(str(value).replace("Z","+00:00"))
    except ValueError:
        return str(value)
    if parsed.tzinfo is None:
        parsed=parsed.replace(tzinfo=tz)
    return parsed.astimezone(tz).strftime("%Y-%m-%d %H:%M %Z")

def local_llm_status():
    _, enabled=ai_engine_settings()
    if not enabled:
        return "Disabled"
    return "Online" if local_llm is not None else "Standby"
def asset_file(asset_path):
    if not asset_path:
        return None
    relative = Path(asset_path.replace("\\", "/"))
    candidate = (ROOT / relative).resolve()
    try:
        candidate.relative_to(ROOT.resolve())
    except ValueError:
        return None
    return candidate
def safe_slug(value):
    slug = re.sub(r"[^A-Za-z0-9]+", "-", str(value or "on-demand")).strip("-").lower()
    return slug[:80] or "on-demand"
async def artifact_slug(topic_name, on_event=None,on_usage=None):
    prompt=f'Return one short, descriptive, lowercase, hyphen-separated folder slug for this topic. Output only the slug: "{topic_name[:180]}"'
    try:
        proposed=await execute_task("light",prompt,on_event=on_event,on_usage=on_usage)
        slug=safe_slug(proposed.strip().strip("`'\""))
        if slug not in {"", "on-demand"}:
            return slug
        raise RuntimeError("Local/AI slug result did not contain a usable slug")
    except RuntimeError as exc:
        fallback=safe_slug(topic_name)
        log("WARNING","AI_ROUTER",f"Slug generation failed; using sanitized topic text ({type(exc).__name__})")
        if on_event: on_event("Slug generation failed; using a sanitized topic-name fallback.")
        return fallback
def post_artifact_dir(topic_name, created_at, slug=None):
    stamp = created_at.strftime("%Y%m%d-%H%M%S")
    return ROOT / "data" / "posts" / created_at.strftime("%Y-%m") / f"{slug or safe_slug(topic_name)}-{stamp}"
def rotate_post_archives():
    posts_root = ROOT / "data" / "posts"
    posts_root.mkdir(parents=True, exist_ok=True)
    current = datetime.now(configured_timezone()).strftime("%Y-%m")
    db = get_db()
    for folder in posts_root.iterdir():
        if not folder.is_dir() or folder.name >= current or not re.fullmatch(r"\d{4}-\d{2}", folder.name):
            continue
        if db.execute("SELECT 1 FROM post_archives WHERE archive_month=?", (folder.name,)).fetchone():
            continue
        archive = posts_root / f"{folder.name}.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
            for item in folder.rglob("*"):
                if item.is_file():
                    bundle.write(item, item.relative_to(folder.parent))
        db.execute("INSERT INTO post_archives(archive_month,archive_path) VALUES(?,?)", (folder.name, str(archive.relative_to(ROOT))))
    db.commit()
    db.close()
def send_notification(d):
    db=get_db(); settings={r["key"]:r["value"] for r in db.execute("SELECT key,value FROM settings")}; db.close()
    host=settings.get("smtp_host") or os.getenv("SMTP_HOST") or "smtp.gmail.com"; sender=settings.get("smtp_sender") or os.getenv("EMAIL_SENDER")
    receiver=settings.get("smtp_receiver") or os.getenv("EMAIL_RECEIVER")
    if not host or not sender or not receiver: raise RuntimeError("SMTP is not configured")
    subject, content, asset = draft_email_content(d, scheduled=True)
    msg=EmailMessage(); msg["Subject"]=subject; msg["From"]=sender; msg["To"]=receiver
    msg.set_content(content)
    attach_asset(msg, asset)
    password=settings.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD","")
    with smtplib.SMTP(host,int(settings.get("smtp_port") or os.getenv("SMTP_PORT","587")),timeout=15) as smtp:
        smtp.starttls(); smtp.login(sender,password); smtp.send_message(msg)
def append_custom_hashtags(body: str) -> str:
    """Cleanly append custom hashtags with line breaks if configured."""
    if not body:
        return ""
    try:
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key='custom_hashtags'").fetchone()
        db.close()
        tags = str(row["value"]).strip() if (row and row["value"]) else ""
    except Exception:
        tags = ""
    if not tags:
        return body
    tags_list = [t if t.startswith("#") else f"#{t}" for t in tags.split() if t]
    if not tags_list:
        return body
    formatted_tags = " ".join(tags_list)
    body_clean = body.rstrip()
    if formatted_tags in body_clean:
        return body_clean
    return f"{body_clean}\n\n{formatted_tags}"

def draft_email_content(d, scheduled=False):
    db=get_db()
    course = db.execute("SELECT name FROM courses WHERE id=?", (d["course_id"],)).fetchone() if d["course_id"] else None
    topic = db.execute("SELECT title FROM topics WHERE id=?", (d["topic_id"],)).fetchone() if d["topic_id"] else None
    settings_dict = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
    db.close()
    topic_name = topic["title"] if topic else (d["prompt"] or "On-demand LinkedIn post")
    course_name = course["name"] if course else "On-demand request"
    final_body = append_custom_hashtags(d["body"])
    server_base_url = (settings_dict.get("server_base_url") or "http://172.19.74.165:8000").rstrip("/")
    if scheduled:
        schedule = local_datetime_label(d["scheduled_at"]) if d["scheduled_at"] else "the scheduled time"
        subject = f"NOTIFICATION: LinkedIn Post for {course_name} scheduled at {schedule}"
        approve_token = create_action_token(d["id"], "approve_schedule", valid_hours=48)
        reject_token = create_action_token(d["id"], "reject", valid_hours=48)
        approve_url = f"{server_base_url}/api/actions/magic-link?token={approve_token}&decision=approve"
        reject_url = f"{server_base_url}/api/actions/magic-link?token={reject_token}&decision=reject"
        greeting = (
            f"Hello,\n\nThis is an automated notification that your topic '{topic_name}' under course '{course_name}' "
            f"is scheduled to be published to LinkedIn at {schedule}.\n\n"
            f"--- QUICK ACTIONS ---\n"
            f"[Approve & Keep Scheduled]: {approve_url}\n"
            f"[Reject / Cancel Post]: {reject_url}\n"
            f"[Open Dashboard to Edit / Regenerate]: {server_base_url}\n"
        )
    else:
        subject = f"Postall_V4 preview: {topic_name}"
        greeting = f"Hello,\n\nHere is the generated LinkedIn post preview for '{topic_name}'" + (f" under course '{course_name}'." if course else ".")
    return subject, f"{greeting}\n\n--- PLANNED CONTENT PREVIEW ---\n\n{final_body}\n\nThe visual diagram infographic for this post is attached.\n\nRegards,\nPostall_V4 Autopilot Engine", asset_file(d["asset_path"]) if d["asset_path"] else None

def send_publish_success_email(topic_name: str, post_url: str, settings: dict):
    host = settings.get("smtp_host") or os.getenv("SMTP_HOST")
    sender = settings.get("smtp_sender") or os.getenv("EMAIL_SENDER")
    receiver = settings.get("smtp_receiver") or os.getenv("EMAIL_RECEIVER")
    if not host or not sender or not receiver:
        return
    msg = EmailMessage()
    msg["Subject"] = f"🚀 Successfully Published: {topic_name}"
    msg["From"] = sender
    msg["To"] = receiver
    msg.set_content(
        f"Hello,\n\n🚀 Today's post '{topic_name}' has been successfully published to LinkedIn!\n\n"
        f"View live post: {post_url}\n\n"
        f"Regards,\nPostall_V4 Autopilot Engine"
    )
    password = settings.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD", "")
    port = int(settings.get("smtp_port") or os.getenv("SMTP_PORT", "587"))
    try:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            if password:
                smtp.login(sender, password)
            smtp.send_message(msg)
    except Exception as exc:
        log("WARNING", "EMAIL", f"Failed to send celebratory email: {exc}")

def attach_asset(msg, asset):
    png = asset.with_suffix(".png") if asset else None
    if png and png.exists():
        asset = png
    if asset and asset.exists():
        subtype = "png" if asset.suffix.lower() == ".png" else "svg+xml"
        msg.add_attachment(asset.read_bytes(), maintype="image", subtype=subtype, filename=asset.name)

async def scheduler_loop():
    await asyncio.sleep(2)
    from backend.task_queue import DistributedLock, get_task_queue
    task_queue = get_task_queue()
    while True:
        # Process any pending asynchronous tasks in the resilient task queue
        try:
            for _ in range(5):
                if not task_queue.process_one():
                    break
        except Exception as exc:
            logger.debug(f"[TASK_QUEUE] Worker execution error: {exc}")

        try:
            # 1. Autonomous Daily Course Pipeline: check buffer and auto-fill queue with cluster leader lock
            with DistributedLock("autopilot_tick_lock", ttl_seconds=90) as acquired:
                if acquired:
                    await run_autopilot_tick()
        except Exception as exc:
            log("ERROR", "AUTOPILOT", f"Autopilot tick error: {exc}")

        try:
            with DistributedLock("scheduler_publish_lock", ttl_seconds=90) as acquired:
                if acquired:
                    db = get_db()
                    settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
                    try:
                        tz = ZoneInfo(settings.get("timezone") or "Asia/Kolkata")
                    except ZoneInfoNotFoundError:
                        tz = ZoneInfo("Asia/Kolkata")
                    now = datetime.now(tz)
                    try:
                        notification_time = datetime.strptime(settings.get("notification_time", "08:00"), "%H:%M").time()
                    except ValueError:
                        notification_time = datetime.strptime("08:00", "%H:%M").time()
                    scheduled = db.execute("SELECT * FROM drafts WHERE status IN ('SCHEDULED', 'APPROVED') AND scheduled_at IS NOT NULL").fetchall()
                    db.close()
                    due = []
                    for d in scheduled:
                        try:
                            scheduled_at = datetime.fromisoformat(d["scheduled_at"].replace("Z", "+00:00"))
                            if scheduled_at.tzinfo is None:
                                scheduled_at = scheduled_at.replace(tzinfo=tz)
                            scheduled_local = scheduled_at.astimezone(tz)
                        except (TypeError, ValueError):
                            log("ERROR", "SCHEDULER", f"Invalid schedule for draft {d['id']}")
                            continue
                        # Pre-post notification at notification_time
                        if d["notification_sent_at"] is None and now.date() == scheduled_local.date() and notification_time <= now.time() < scheduled_local.time():
                            try:
                                send_notification(d)
                                try:
                                    d_obj = draft(d["id"], "scheduler")
                                    asyncio.create_task(dispatch_platform_alerts("draft_ready", d_obj))
                                except Exception:
                                    pass
                                db = get_db()
                                db.execute("UPDATE drafts SET notification_sent_at=CURRENT_TIMESTAMP WHERE id=?", (d["id"],))
                                db.commit()
                                db.close()
                                log("INFO", "EMAIL", f"Pre-post notification email dispatched for draft {d['id']}")
                            except Exception as exc:
                                log("ERROR", "EMAIL", f"Draft {d['id']} notification failed: {exc}")
                        # Auto-publisher at post_time
                        if now >= scheduled_local:
                            due.append(d)
                    for d in due:
                        await asyncio.to_thread(_publish, d["id"])
        except Exception as exc:
            log("ERROR", "SCHEDULER", str(exc))
        await asyncio.sleep(60)
def row(r): return dict(r) if r else None

class Login(BaseModel):
    username: str
    password: str
    auth_type: Optional[str] = "local"

class ForgotPasswordIn(BaseModel):
    username_or_email: str = Field(min_length=1)

class ResetPasswordIn(BaseModel):
    new_password: str
    confirm_password: str

class PasswordChange(BaseModel): current_password: str; new_password: str = Field(min_length=8)
class CourseIn(BaseModel): name: str = Field(min_length=1); description: str = ""; syllabus_url: str = ""
class TopicIn(BaseModel): course_id: int; title: str = Field(min_length=1); details: Optional[str] = ""
class ImportTopicsIn(BaseModel): content: str = Field(min_length=1)
class GenerateIn(BaseModel): prompt: str = Field(min_length=3); format: str = "infographic"; course_id: Optional[int]=None; topic_id: Optional[int]=None
class ScheduleIn(BaseModel): scheduled_at: str
class RejectIn(BaseModel): reason: str = ""
class SettingsIn(BaseModel):
    post_time: Optional[str] = None
    notification_time: Optional[str] = None
    timezone: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[str] = None
    smtp_sender: Optional[str] = None
    smtp_receiver: Optional[str] = None
    smtp_app_password: Optional[str] = None
    gemini_key: Optional[str] = None
    gemini_api_key: Optional[str] = None
    gemini_api_key_1: Optional[str] = None
    gemini_api_key_2: Optional[str] = None
    ai_primary_model: Optional[str] = None
    ai_temperature: Optional[str] = None
    dry_run_mode: Optional[str] = None
    linkedin_access_token: Optional[str] = None
    x_api_key: Optional[str] = None
    x_api_secret: Optional[str] = None
    x_access_token: Optional[str] = None
    x_access_token_secret: Optional[str] = None
    x_user_access_token: Optional[str] = None
    enable_gemini_api: Optional[bool] = None
    enable_local_llm: Optional[bool] = None
    custom_hashtags: Optional[str] = None
    workspace_persona: Optional[str] = None
    ai_provider: Optional[str] = None
    openai_api_key: Optional[str] = None
    openai_base_url: Optional[str] = None
    openai_model: Optional[str] = None
    deepseek_api_key: Optional[str] = None
    deepseek_base_url: Optional[str] = None
    deepseek_model: Optional[str] = None
    mistral_api_key: Optional[str] = None
    mistral_base_url: Optional[str] = None
    mistral_model: Optional[str] = None
    claude_api_key: Optional[str] = None
    claude_model: Optional[str] = None
    custom_ai_api_key: Optional[str] = None
    custom_ai_base_url: Optional[str] = None
    custom_ai_model: Optional[str] = None
    server_base_url: Optional[str] = None
    slack_webhook_url: Optional[str] = None
    teams_webhook_url: Optional[str] = None
    alert_on_draft_ready: Optional[Union[bool, int, str]] = None
    alert_on_publish_success: Optional[Union[bool, int, str]] = None
    alert_on_failure: Optional[Union[bool, int, str]] = None
    autopilot_enabled: Optional[Union[bool, int, str]] = None
    autopilot_buffer_days: Optional[Union[int, str]] = None
    enable_branding: Optional[Union[bool, int, str]] = None
    custom_brand_name: Optional[str] = None
    custom_brand_tagline: Optional[str] = None
    github_repo_url: Optional[str] = None
    github_repo: Optional[str] = None
    github_pat: Optional[str] = None
    update_channel: Optional[str] = "stable"
    auto_check_updates: Optional[Union[bool, int, str]] = None
    last_update_check: Optional[str] = None
    dlp_enabled: Optional[Union[bool, int, str]] = None
    brand_safety_enabled: Optional[Union[bool, int, str]] = None
    banned_keywords: Optional[str] = None
    competitor_names: Optional[str] = None
    sso_enabled: Optional[Union[bool, int, str]] = None
    sso_client_id: Optional[str] = None
    sso_client_secret: Optional[str] = None
    sso_metadata_url: Optional[str] = None
    storage_backend: Optional[str] = None
    s3_endpoint_url: Optional[str] = None
    s3_bucket_name: Optional[str] = None
    s3_region: Optional[str] = None
    s3_access_key: Optional[str] = None
    s3_secret_key: Optional[str] = None

class DraftEditIn(BaseModel):
    body: str

class CheckTextIn(BaseModel):
    text: str

class ApplyOtaIn(BaseModel):
    download_url: Optional[str] = None
    expected_sha256: Optional[str] = None
    sha256: Optional[str] = None
    version: Optional[str] = None

class RollbackIn(BaseModel):
    snapshot_filename: str

class UpdateConfigIn(BaseModel):
    github_repo: Optional[str] = None
    github_releases_repo: Optional[str] = None
    github_pat: Optional[str] = None
    update_channel: Optional[str] = "stable"
    auto_check_updates: Optional[Union[bool, int, str]] = True

class PruneLogsIn(BaseModel):
    days: int = 30

class SocialTestIn(BaseModel):
    platform: str
    token: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    access_token: Optional[str] = None
    access_token_secret: Optional[str] = None

class TestProviderIn(BaseModel):
    provider: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    model: Optional[str] = None
    user_access_token: Optional[str] = None

class EmailIn(BaseModel): draft_id: Optional[int] = None
class PublishIn(BaseModel): platforms: list[str] = Field(min_length=1)
class TestWebhooksIn(BaseModel):
    slack_webhook_url: Optional[str] = None
    teams_webhook_url: Optional[str] = None


class SetupCompleteIn(BaseModel):
    admin_password: str
    license_key: Optional[str] = ""
    workspace_persona: Optional[str] = "tech_academy"
    ai_provider: Optional[str] = "local"
    ai_api_key: Optional[str] = ""
    ai_base_url: Optional[str] = None
    ai_model: Optional[str] = None
    enable_ldap: Optional[bool] = False
    telemetry_enabled: Optional[bool] = True


@app.get("/", response_class=HTMLResponse)
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(): return (ROOT/"frontend/dashboard.html").read_text(encoding="utf8")
@app.get("/login", response_class=HTMLResponse)
def login_page(): return (ROOT/"frontend/login.html").read_text(encoding="utf8")
@app.get("/setup", response_class=HTMLResponse)
@app.get("/setup.html", response_class=HTMLResponse)
def setup_page():
    setup_file = ROOT / "frontend" / "setup.html"
    if not setup_file.is_file():
        raise HTTPException(404, "Setup page not found")
    return HTMLResponse(content=setup_file.read_text(encoding="utf8"))

@app.get("/api/setup/status")
def api_setup_status():
    """Returns whether setup has been completed and volume health."""
    return {
        "is_setup_complete": is_setup_completed(),
        "volume": check_data_volume_persistence(),
        "default_persona": "tech_academy"
    }

@app.get("/api/setup/check-volume")
def api_setup_check_volume():
    """Validates data/ directory write persistence and detects unmounted Docker containers."""
    return check_data_volume_persistence()

@app.post("/api/setup/test-provider")
async def api_setup_test_provider(req: TestProviderIn):
    """Tests AI provider connectivity directly during the Setup Wizard flow."""
    return await test_provider_connection(
        provider=req.provider,
        api_key=req.api_key or "",
        base_url=req.base_url,
        model=req.model
    )

@app.post("/api/setup/complete")
def api_setup_complete(req: SetupCompleteIn):
    """
    Finalizes the First-Run Setup Wizard:
    1. Sets new admin password and bypasses legacy must_reset prompt (must_reset = 0).
    2. Validates & activates Ed25519 license key.
    3. Persists chosen workspace persona, AI keys, LDAP preference, and telemetry flag.
    4. Sets is_setup_complete = 1, unlocking the application.
    """
    pwd = (req.admin_password or "").strip()
    if len(pwd) < 8:
        raise HTTPException(400, "Administrator password must be at least 8 characters long.")

    # Action 1: Set new admin password and clear must_reset flag
    db = get_db()
    hashed = hash_password(pwd)
    db.execute(
        "UPDATE users SET password_hash = ?, must_reset = 0, must_change_password = 0, is_active = 1 WHERE username = 'admin'",
        (hashed,)
    )

    # Action 2: Activate license if provided
    license_status = "unlicensed"
    clean_key = (req.license_key or "").strip()
    if clean_key:
        try:
            lic_data = activate_license_key(clean_key)
            license_status = lic_data.get("type", "Active")
            app.state.license_data = lic_data
        except Exception as exc:
            db.close()
            raise HTTPException(400, f"Invalid Ed25519 License Key: {exc}")
    else:
        try:
            lic_data = verify_license(allow_demo=True)
            license_status = lic_data.get("type", "Demo")
            app.state.license_data = lic_data
        except Exception:
            pass

    # Action 3: Persist settings
    persona = (req.workspace_persona or "tech_academy").strip()
    provider = (req.ai_provider or "local").strip().lower()
    api_key = (req.ai_api_key or "").strip()
    ldap_val = "1" if req.enable_ldap else "0"
    telemetry_val = "1" if req.telemetry_enabled else "0"

    settings_updates = [
        ("workspace_persona", persona),
        ("ai_provider", provider),
        ("ai_provider_status", "ready" if provider != "gemini" or api_key else "standby"),
        ("enable_ldap", ldap_val),
        ("telemetry_enabled", telemetry_val),
        ("is_setup_complete", "1"),
    ]

    if provider == "gemini":
        settings_updates.append(("gemini_api_key", api_key))
        settings_updates.append(("enable_gemini_api", "1" if api_key else "0"))
    elif provider == "openai":
        settings_updates.append(("openai_api_key", api_key))
        if req.ai_base_url: settings_updates.append(("openai_base_url", req.ai_base_url.strip()))
        if req.ai_model: settings_updates.append(("openai_model", req.ai_model.strip()))
    elif provider == "deepseek":
        settings_updates.append(("deepseek_api_key", api_key))
        if req.ai_base_url: settings_updates.append(("deepseek_base_url", req.ai_base_url.strip()))
        if req.ai_model: settings_updates.append(("deepseek_model", req.ai_model.strip()))
    elif provider == "mistral":
        settings_updates.append(("mistral_api_key", api_key))
        if req.ai_base_url: settings_updates.append(("mistral_base_url", req.ai_base_url.strip()))
        if req.ai_model: settings_updates.append(("mistral_model", req.ai_model.strip()))
    elif provider == "claude":
        settings_updates.append(("claude_api_key", api_key))
        if req.ai_model: settings_updates.append(("claude_model", req.ai_model.strip()))
    elif provider == "custom":
        settings_updates.append(("custom_ai_api_key", api_key))
        if req.ai_base_url: settings_updates.append(("custom_ai_base_url", req.ai_base_url.strip()))
        if req.ai_model: settings_updates.append(("custom_ai_model", req.ai_model.strip()))

    for k, v in settings_updates:
        db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, v))
        try:
            db.execute(f"UPDATE settings SET {k} = ?", (v,))
        except Exception:
            pass

    db.commit()
    db.close()

    # Action 4: Set setup completed flag
    set_setup_completed(True, telemetry=bool(req.telemetry_enabled))

    log("INFO", "SETUP", f"Enterprise Setup Wizard completed: admin passkey updated, persona='{persona}', provider='{provider}', license='{license_status}'")
    return {
        "status": "success",
        "message": "Postall_V4 Initialized Successfully. Redirecting to login...",
        "redirect_url": "/login",
        "license_status": license_status
    }

def authenticate_ldap(username: str, password: str) -> bool:
    if not ldap3:
        raise HTTPException(500, "LDAP library (ldap3) is not installed on the server.")
    db = get_db()
    s = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings WHERE key LIKE 'ldap_%'").fetchall()}
    db.close()
    
    host = s.get("ldap_host") or os.getenv("LDAP_HOST") or ""
    domain = s.get("ldap_domain") or os.getenv("LDAP_DOMAIN") or ""
    port = int(s.get("ldap_port") or os.getenv("LDAP_PORT") or 389)
    use_ssl = (s.get("ldap_use_ssl") or os.getenv("LDAP_USE_SSL") or "0").lower() in ("1", "true")
    
    if not host:
        raise HTTPException(400, "LDAP is not configured. Please set LDAP_HOST and LDAP_DOMAIN in System Settings or .env.")

    # Format user principal
    if "@" in username:
        bind_user = username
    elif domain:
        bind_user = f"{username}@{domain}"
    else:
        bind_user = username

    try:
        server = ldap3.Server(host, port=port, use_ssl=use_ssl, get_info=ldap3.NONE, connect_timeout=5)
        conn = ldap3.Connection(server, user=bind_user, password=password, authentication=ldap3.SIMPLE, auto_bind=True)
        conn.unbind()
        return True
    except Exception as exc:
        log("WARNING", "AUTH", f"LDAP bind failed for user '{username}': {exc}")
        return False

@app.post("/api/auth/login")
@app.post("/api/token")
def login(req: Login):
    auth_type = (req.auth_type or "local").lower().strip()
    
    # 1. LDAP Authentication
    if auth_type == "ldap":
        success = authenticate_ldap(req.username, req.password)
        if not success:
            log("WARNING", "AUTH", f"Failed LDAP authentication for user '{req.username}'")
            raise HTTPException(401, "LDAP authentication failed. Please verify credentials or directory status.")
        
        # Provision or verify user in local database
        db = get_db()
        u = db.execute("SELECT * FROM users WHERE username=?", (req.username,)).fetchone()
        if not u:
            dummy_hash = hash_password(secrets.token_urlsafe(16))
            db.execute("INSERT INTO users(username, password_hash, must_reset, must_change_password) VALUES (?, ?, 0, 0)", (req.username, dummy_hash))
            db.commit()
        db.close()
        
        log("INFO", "AUTH", f"LDAP login successful for user '{req.username}'")
        token = token_for(req.username)
        return {
            "status": "success",
            "access_token": token,
            "token": token,
            "token_type": "bearer",
            "auth_type": "ldap",
            "must_reset": False
        }

    # 2. Local Authentication
    db = get_db()
    u = db.execute("SELECT * FROM users WHERE username=?", (req.username,)).fetchone()
    db.close()
    
    if not u:
        log("WARNING", "AUTH", f"Failed local login attempt for non-existent user '{req.username}'")
        raise HTTPException(401, "Invalid credentials")
        
    if "is_active" in u.keys() and not u["is_active"]:
        log("WARNING", "AUTH", f"Login rejected for deactivated account '{req.username}'")
        raise HTTPException(403, "Account deactivated. Please contact your system administrator.")

    valid = verify_password(req.password, u["password_hash"])
    if not valid and u["must_reset"] and u["username"] == "admin" and req.password in ("admin", "password"):
        valid = True
        
    if not valid:
        log("WARNING", "AUTH", f"Failed local password check for user '{req.username}'")
        raise HTTPException(401, "Invalid credentials")
        
    must_change = False
    try:
        must_change = bool(u["must_change_password"]) or bool(u["must_reset"])
    except (IndexError, KeyError):
        must_change = bool(u["must_reset"])
        
    user_role = u["role"] if "role" in u.keys() and u["role"] else "admin"
    if must_change:
        temp_token = token_for(req.username)
        return {
            "status": "force_reset",
            "token": temp_token,
            "access_token": temp_token,
            "token_type": "bearer",
            "must_reset": True,
            "message": "Password reset required before accessing dashboard.",
            "user": {
                "id": u["id"],
                "username": u["username"],
                "email": u["email"] if "email" in u.keys() else "",
                "role": user_role
            }
        }
        
    try:
        db = get_db()
        db.execute("UPDATE users SET last_login_at=? WHERE id=?", (datetime.now(timezone.utc).isoformat(), u["id"]))
        db.commit()
        db.close()
    except Exception:
        pass

    log("INFO", "AUTH", f"User '{req.username}' logged in successfully (local)")
    try:
        from backend.audit_streamer import log_audit_event
        log_audit_event(req.username, "AUTH_LOGIN", "session", str(u["id"]), "SUCCESS", details={"role": user_role, "auth_type": "local"})
    except Exception:
        pass

    # Check if MFA is enabled for this user
    if "mfa_enabled" in u.keys() and bool(u["mfa_enabled"]):
        temp_token = token_for_mfa(req.username)
        log("INFO", "AUTH", f"User '{req.username}' password verified, MFA challenge required")
        try:
            from backend.audit_streamer import log_audit_event
            log_audit_event(req.username, "AUTH_MFA_CHALLENGE_ISSUED", "session", str(u["id"]), "PENDING", details={"role": user_role})
        except Exception:
            pass
        return JSONResponse(
            status_code=403,
            content={
                "detail": "MFA_REQUIRED",
                "status": "mfa_required",
                "temp_token": temp_token,
                "message": "Two-factor authentication code required to complete sign-in."
            }
        )

    token = token_for(req.username)
    user_role = u["role"] if "role" in u.keys() and u["role"] else "admin"
    return {
        "status": "success",
        "access_token": token,
        "token": token,
        "token_type": "bearer",
        "must_reset": False,
        "user": {
            "id": u["id"],
            "username": u["username"],
            "email": u["email"] if "email" in u.keys() else "",
            "role": user_role
        }
    }

@app.post("/api/auth/forgot-password")
def forgot_password(req: ForgotPasswordIn):
    target = req.username_or_email.strip()
    db = get_db()
    u = db.execute("SELECT * FROM users WHERE username=? OR (email=? AND email != '')", (target, target)).fetchone()
    s = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings").fetchall()}
    
    if not u and target.lower() in ("admin", (s.get("smtp_receiver") or "").lower(), (s.get("smtp_sender") or "").lower()):
        u = db.execute("SELECT * FROM users WHERE username='admin'").fetchone()
        
    if not u:
        db.close()
        raise HTTPException(404, "No user account found matching the provided username or email address.")
        
    # Generate secure temporary 10-character password using secrets.token_urlsafe(8)
    temp_pw = secrets.token_urlsafe(8)[:10]
    temp_hash = hash_password(temp_pw)
    
    db.execute("UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?", (temp_hash, u["id"]))
    db.commit()
    db.close()
    
    receiver = (dict(u).get("email") or "").strip() or s.get("smtp_receiver") or os.getenv("EMAIL_RECEIVER") or s.get("smtp_sender")
    host = s.get("smtp_host") or os.getenv("SMTP_HOST") or "smtp.gmail.com"
    sender = s.get("smtp_sender") or os.getenv("EMAIL_SENDER")
    smtp_pass = s.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD", "")
    port = int(s.get("smtp_port") or os.getenv("SMTP_PORT", "587"))
    smtp_sent = False
    
    if host and sender and receiver:
        msg = EmailMessage()
        msg["Subject"] = "Postall_V4 · Temporary Password Recovery"
        msg["From"] = sender
        msg["To"] = receiver
        msg.set_content(
            f"SECURITY NOTICE: Postall_V4 Password Recovery\n\n"
            f"Account: {u['username']}\n"
            f"Your temporary one-time password is:\n\n"
            f"    {temp_pw}\n\n"
            f"Please log in using this temporary password. You will be required to set a new permanent password immediately upon login.\n"
            f"If you did not initiate this request, please contact your administrator."
        )
        try:
            with smtplib.SMTP(host, port, timeout=15) as smtp:
                smtp.starttls()
                if smtp_pass:
                    smtp.login(sender, smtp_pass)
                smtp.send_message(msg)
            smtp_sent = True
            log("INFO", "AUTH", f"Temporary password dispatched via SMTP to {receiver} for user '{u['username']}'")
        except Exception as exc:
            log("WARNING", "AUTH", f"Failed sending temporary password via SMTP ({exc})")
    else:
        log("INFO", "AUTH", f"SMTP not configured; temporary password '{temp_pw}' generated for '{u['username']}'")
        
    return {
        "status": "ok",
        "smtp_delivered": smtp_sent,
        "dev_temp_pw": temp_pw,
        "temp_password": temp_pw,
        "message": "Temporary password sent to email."
    }

@app.post("/api/auth/reset-password")
def reset_password(req: ResetPasswordIn, user=Depends(current_user)):
    if req.new_password != req.confirm_password:
        raise HTTPException(400, "New password and confirmation do not match.")
    if len(req.new_password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters in length.")
        
    db = get_db()
    u = db.execute("SELECT id FROM users WHERE username=?", (user,)).fetchone()
    if not u:
        db.close()
        raise HTTPException(404, "User account not found.")
        
    new_hash = hash_password(req.new_password)
    db.execute("UPDATE users SET password_hash=?, must_change_password=0, must_reset=0 WHERE id=?", (new_hash, u["id"]))
    db.commit()
    db.close()
    
    log("INFO", "AUTH", f"Password reset completed successfully for user '{user}'")
    fresh_token = token_for(user)
    return {
        "status": "ok",
        "message": "Password successfully reset. Launching session...",
        "access_token": fresh_token,
        "token": fresh_token,
        "token_type": "bearer"
    }

@app.post("/api/auth/password")
def change_password(req: PasswordChange, user=Depends(current_user)):
    db=get_db(); u=db.execute("SELECT password_hash, must_reset FROM users WHERE username=?",(user,)).fetchone()
    if not u:
        db.close(); raise HTTPException(404, "User not found")
    valid = verify_password(req.current_password, u["password_hash"])
    if not valid and u["must_reset"] and user == "admin" and req.current_password in ("admin", "password"):
        valid = True
    if not valid:
        db.close(); raise HTTPException(400, "Current password is incorrect")
    db.execute("UPDATE users SET password_hash=?,must_reset=0 WHERE username=?",(hash_password(req.new_password),user))
    db.commit(); db.close(); log("INFO","AUTH","Password changed"); return {"status":"ok"}

# ==============================================================================
# ENTERPRISE SSO & MULTI-FACTOR AUTHENTICATION (MFA)
# ==============================================================================
import pyotp
from backend.sso_auth import login_via_sso, sso_callback, get_sso_config

class MfaVerifyIn(BaseModel):
    code: str
    temp_token: Optional[str] = None

@app.get("/api/auth/sso/status")
def sso_status():
    """Returns SSO readiness for frontend login buttons."""
    cfg = get_sso_config()
    return {
        "status": "success",
        "sso_enabled": cfg["enabled"],
        "client_configured": bool(cfg["client_id"] and cfg["metadata_url"])
    }

@app.get("/api/auth/sso/login")
async def sso_login_route(request: Request):
    """Initiates OIDC login flow with corporate identity provider."""
    return await login_via_sso(request)

@app.get("/api/auth/sso/callback")
async def sso_callback_route(request: Request):
    """Processes OIDC identity token callback."""
    return await sso_callback(request, token_for)

@app.post("/api/auth/mfa/setup")
def setup_mfa(user=Depends(current_user)):
    """Generates TOTP secret and provisioning URI for the user."""
    db = get_db()
    u = db.execute("SELECT id, username, mfa_secret, mfa_enabled FROM users WHERE username=?", (user,)).fetchone()
    if not u:
        db.close()
        raise HTTPException(404, "User not found")
    
    secret = pyotp.random_base32()
    db.execute("UPDATE users SET mfa_secret=? WHERE id=?", (secret, u["id"]))
    db.commit()
    db.close()
    
    totp = pyotp.TOTP(secret)
    provisioning_uri = totp.provisioning_uri(name=user, issuer_name="Postall_V4")
    return {
        "status": "success",
        "secret": secret,
        "provisioning_uri": provisioning_uri,
        "mfa_enabled": bool(u["mfa_enabled"]),
        "message": "Enter this secret key or scan the QR code into Google Authenticator or Authy."
    }

@app.post("/api/auth/mfa/verify")
def verify_mfa(req: MfaVerifyIn, authorization: Optional[str] = Header(None)):
    """
    Verifies TOTP 6-digit code.
    Case A: Login challenge verification via temp_token.
    Case B: Enabling MFA during initial setup via authenticated session.
    """
    code = (req.code or "").strip()
    if not code or len(code) != 6 or not code.isdigit():
        raise HTTPException(400, "Invalid code format. 6-digit number required.")

    # Case A: Login Challenge completion with temp_token
    if req.temp_token:
        username = verify_mfa_token(req.temp_token)
        if not username:
            raise HTTPException(401, "Expired or invalid MFA challenge token. Please log in again.")
        db = get_db()
        row = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        db.close()
        if not row:
            raise HTTPException(404, "User not found")
        u = dict(row)
        if not u.get("mfa_secret"):
            raise HTTPException(400, "MFA is not configured for this user account.")
        totp = pyotp.TOTP(u["mfa_secret"])
        if not totp.verify(code, valid_window=1):
            log("WARNING", "AUTH", f"Invalid MFA code attempted for user '{username}'")
            try:
                from backend.audit_streamer import log_audit_event
                log_audit_event(username, "AUTH_MFA_CHALLENGE", "session", str(u["id"]), "FAILED", details={"error": "Invalid TOTP code"})
            except Exception: pass
            raise HTTPException(401, "Invalid verification code. Please check your authenticator app.")
            
        # Success: Issue full JWT session token
        token = token_for(username)
        user_role = u.get("role") or "admin"
        log("INFO", "AUTH", f"MFA challenge verified successfully for user '{username}'")
        try:
            from backend.audit_streamer import log_audit_event
            log_audit_event(username, "AUTH_MFA_CHALLENGE", "session", str(u["id"]), "SUCCESS", details={"role": user_role})
        except Exception: pass
        return {
            "status": "success",
            "token": token,
            "access_token": token,
            "token_type": "bearer",
            "username": username,
            "user": {
                "id": u["id"],
                "username": username,
                "email": u.get("email") or "",
                "role": user_role
            }
        }

    # Case B: Authenticated user activating MFA during setup
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Authentication or temp_token required.")
    
    auth_user = current_user(authorization)
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE username=?", (auth_user,)).fetchone()
    if not row:
        db.close()
        raise HTTPException(404, "User not found")
    u = dict(row)
    if not u.get("mfa_secret"):
        db.close()
        raise HTTPException(400, "MFA setup was not initiated. Please request setup first.")
        
    totp = pyotp.TOTP(u["mfa_secret"])
    if not totp.verify(code, valid_window=1):
        db.close()
        raise HTTPException(400, "Invalid verification code. Could not verify authenticator.")
        
    db.execute("UPDATE users SET mfa_enabled=1 WHERE id=?", (u["id"],))
    db.commit()
    db.close()
    
    log("INFO", "AUTH", f"User '{auth_user}' successfully enabled Multi-Factor Authentication (TOTP)")
    try:
        from backend.audit_streamer import log_audit_event
        log_audit_event(auth_user, "MFA_ENABLED", "user", str(u["id"]), "SUCCESS")
    except Exception: pass
    
    return {
        "status": "success",
        "mfa_enabled": True,
        "message": "Two-Factor Authentication is now enabled for your account."
    }

@app.post("/api/auth/mfa/disable")
def disable_mfa(user=Depends(current_user)):
    """Allows authenticated user to disable their own MFA."""
    db = get_db()
    db.execute("UPDATE users SET mfa_enabled=0, mfa_secret=NULL WHERE username=?", (user,))
    db.commit()
    db.close()
    log("INFO", "AUTH", f"User '{user}' disabled Multi-Factor Authentication")
    return {"status": "success", "mfa_enabled": False, "message": "Two-Factor Authentication disabled."}

@app.post("/api/users/{user_id}/reset-mfa")
def reset_user_mfa(user_id: int, admin_user=Depends(require_admin)):
    """Admin action to clear/reset MFA for a locked-out user."""
    db = get_db()
    target = db.execute("SELECT id, username FROM users WHERE id=?", (user_id,)).fetchone()
    if not target:
        db.close()
        raise HTTPException(404, "User not found")
    db.execute("UPDATE users SET mfa_enabled=0, mfa_secret=NULL WHERE id=?", (user_id,))
    db.commit()
    db.close()
    log("INFO", "AUTH", f"Admin '{admin_user['username']}' reset MFA for user #{user_id} ('{target['username']}')")
    try:
        from backend.audit_streamer import log_audit_event
        log_audit_event(admin_user["username"], "MFA_ADMIN_RESET", "user", str(user_id), "SUCCESS", details={"target_username": target["username"]})
    except Exception: pass
    return {"status": "success", "message": f"MFA has been reset for user '{target['username']}'."}

# ==============================================================================
# ENTERPRISE USER MANAGEMENT & RBAC ENDPOINTS
# ==============================================================================

@app.get("/api/auth/me")
def get_current_user_profile(username: str = Depends(current_user)):
    """Returns profile and RBAC permissions for the currently authenticated user."""
    user_rec = get_user_record(username)
    role = (user_rec.get("role") or "admin").lower()
    user_dict = {
        "id": user_rec["id"],
        "username": user_rec["username"],
        "email": user_rec.get("email") or "",
        "role": role,
        "is_active": bool(user_rec.get("is_active", 1)),
        "mfa_enabled": bool(user_rec.get("mfa_enabled", 0)),
        "sso_provider": user_rec.get("sso_provider") or "local",
        "last_login_at": user_rec.get("last_login_at") or ""
    }
    return {
        "status": "success",
        "user": user_dict,
        **user_dict,
        "permissions": {
            "can_manage_users": role == "admin",
            "can_edit_settings": role == "admin",
            "can_activate_license": role == "admin",
            "can_backup_restore": role == "admin",
            "can_purge": role == "admin",
            "can_generate": role in ("admin", "editor"),
            "can_approve_drafts": role in ("admin", "editor"),
            "can_edit_courses": role in ("admin", "editor"),
            "is_view_only": role == "viewer"
        }
    }

@app.get("/api/users")
def api_get_users(user=Depends(require_admin)):
    """Returns list of all registered users (Admin only)."""
    users = get_all_users()
    return {"status": "success", "users": users}

@app.post("/api/users")
def api_create_user(req: UserCreateIn, user=Depends(require_admin)):
    """Creates a new user with designated role (Admin only)."""
    existing = get_user_by_username(req.username)
    if existing:
        raise HTTPException(409, f"A user with username '{req.username}' already exists.")
    role = req.role.strip().lower()
    if role not in ("admin", "editor", "viewer"):
        raise HTTPException(400, "Role must be 'admin', 'editor', or 'viewer'.")
    pw_hash = hash_password(req.password)
    uid = create_user(
        username=req.username,
        password_hash=pw_hash,
        role=role,
        email=req.email or "",
        must_change_password=req.must_change_password
    )
    add_notification("info", "User Account Created", f"New user '{req.username}' created with role '{role}' by {user['username']}.")
    log("INFO", "USER_MGMT", f"User '{req.username}' (role: {role}) created by '{user['username']}'")
    return {"status": "success", "message": f"User '{req.username}' created successfully.", "user_id": uid}

@app.put("/api/users/{user_id}")
def api_update_user(user_id: int, req: UserUpdateIn, user=Depends(require_admin)):
    """Updates an existing user's role, status, email, or password (Admin only)."""
    target_user = get_user_by_id(user_id)
    if not target_user:
        raise HTTPException(404, "User account not found.")

    # Guard: Prevent an admin from deactivating themselves
    if target_user["username"] == user["username"] and req.is_active is False:
        raise HTTPException(400, "Security restriction: You cannot deactivate your own active session account.")

    # Guard: Prevent removing or demoting the last active admin
    if target_user.get("role") == "admin":
        if (req.role and req.role.lower() != "admin") or (req.is_active is False):
            all_users = get_all_users()
            active_admins = [u for u in all_users if u.get("role") == "admin" and u.get("is_active", 1)]
            if len(active_admins) <= 1:
                raise HTTPException(400, "Security restriction: Cannot demote or disable the last remaining active Administrator.")

    pw_hash = hash_password(req.password) if req.password else None
    role = req.role.strip().lower() if req.role else None
    if role and role not in ("admin", "editor", "viewer"):
        raise HTTPException(400, "Role must be 'admin', 'editor', or 'viewer'.")

    update_user(
        user_id=user_id,
        role=role,
        email=req.email,
        is_active=req.is_active,
        password_hash=pw_hash,
        must_change_password=req.must_change_password
    )
    log("INFO", "USER_MGMT", f"User #{user_id} ('{target_user['username']}') updated by '{user['username']}'")
    return {"status": "success", "message": f"User '{target_user['username']}' updated successfully."}

@app.delete("/api/users/{user_id}")
def api_delete_user(user_id: int, user=Depends(require_admin)):
    """Deletes a user account (Admin only)."""
    target_user = get_user_by_id(user_id)
    if not target_user:
        raise HTTPException(404, "User account not found.")

    if target_user["username"] == user["username"]:
        raise HTTPException(400, "Security restriction: You cannot delete your own account.")

    if target_user.get("role") == "admin":
        all_users = get_all_users()
        active_admins = [u for u in all_users if u.get("role") == "admin"]
        if len(active_admins) <= 1:
            raise HTTPException(400, "Security restriction: Cannot delete the last remaining Administrator account.")

    delete_user(user_id)
    log("INFO", "USER_MGMT", f"User #{user_id} ('{target_user['username']}') deleted by '{user['username']}'")
    return {"status": "success", "message": f"User '{target_user['username']}' deleted successfully."}


# Trending Radar and RSS endpoints are registered in Section: Dynamic RSS Sources & Document Ingestion below.

def active_workspace_id(x_workspace_id: Optional[str] = Header(None, alias="X-Workspace-Id")) -> int:
    try:
        if x_workspace_id is not None and str(x_workspace_id).strip():
            ws_id = int(str(x_workspace_id).strip())
            return max(1, ws_id)
    except (ValueError, TypeError):
        pass
    return 1

class WorkspaceIn(BaseModel):
    name: str
    persona: Optional[str] = "tech_academy"

# =====================================================================
# MULTI-TENANT WORKSPACE APIS (Phase 2 P1)
# =====================================================================

@app.get("/api/workspaces")
def get_workspaces(user=Depends(current_user)):
    db = get_db()
    rows = db.execute("SELECT id, name, slug, persona, is_default, created_at FROM workspaces ORDER BY is_default DESC, id ASC").fetchall()
    db.close()
    return [{"id": r["id"], "name": r["name"], "slug": r["slug"], "persona": r["persona"] or "tech_academy", "is_default": bool(r["is_default"]), "created_at": str(r["created_at"] or "")} for r in rows]

@app.post("/api/workspaces")
def create_workspace(req: WorkspaceIn, user=Depends(current_user)):
    name = (req.name or "").strip()
    if not name:
        raise HTTPException(400, "Workspace name cannot be empty")
    persona = (req.persona or "tech_academy").strip()
    base_slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:40] or "workspace"
    slug = base_slug
    db = get_db()
    idx = 1
    while db.execute("SELECT 1 FROM workspaces WHERE slug=?", (slug,)).fetchone():
        slug = f"{base_slug}-{idx}"
        idx += 1
    cur = db.execute("INSERT INTO workspaces(name, slug, persona, is_default) VALUES(?, ?, ?, 0)", (name, slug, persona))
    ws_id = cur.lastrowid
    db.commit()
    db.close()
    log("INFO", "WORKSPACE", f"Created workspace #{ws_id} ('{name}', slug='{slug}') by user '{user}'")
    return {"id": ws_id, "name": name, "slug": slug, "persona": persona, "is_default": False}

@app.delete("/api/workspaces/{workspace_id}")
def delete_workspace(workspace_id: int, user=Depends(require_admin)):
    db = get_db()
    ws = db.execute("SELECT * FROM workspaces WHERE id=?", (workspace_id,)).fetchone()
    if not ws:
        db.close()
        raise HTTPException(404, "Workspace not found")
    if ws["is_default"]:
        db.close()
        raise HTTPException(400, "Cannot delete default workspace")
    db.execute("DELETE FROM drafts WHERE workspace_id=?", (workspace_id,))
    db.execute("DELETE FROM topics WHERE workspace_id=?", (workspace_id,))
    db.execute("DELETE FROM courses WHERE workspace_id=?", (workspace_id,))
    db.execute("DELETE FROM workspaces WHERE id=?", (workspace_id,))
    db.commit()
    db.close()
    log("INFO", "WORKSPACE", f"Deleted workspace #{workspace_id} ('{ws['name']}') by admin '{user['username']}'")
    return {"status": "success", "workspace_id": workspace_id, "message": f"Workspace '{ws['name']}' deleted."}

# =====================================================================
# COURSES & TOPICS (Workspace-Scoped)
# =====================================================================

@app.get("/api/courses")
def courses(user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db(); cs=db.execute("SELECT * FROM courses WHERE workspace_id=? ORDER BY id", (ws_id,)).fetchall()
    out=[] 
    for c in cs: out.append({"id":c["id"],"name":c["name"],"description":c["description"],"topics":[row(x) for x in db.execute("SELECT * FROM topics WHERE course_id=? ORDER BY id",(c["id"],)).fetchall()]})
    db.close(); return out

@app.post("/api/courses")
def add_course(req: CourseIn, user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db()
    try:
        cur=db.execute("INSERT INTO courses(name,description,syllabus_url,workspace_id) VALUES(?,?,?,?)",(req.name.strip(),req.description,req.syllabus_url.strip(),ws_id))
        db.commit()
    except Exception:
        db.close()
        raise HTTPException(409,"Course already exists")
    db.close()
    return {"id":cur.lastrowid,"name":req.name.strip()}

@app.delete("/api/courses/{course_id}")
def delete_course(course_id: int, user=Depends(current_user)):
    db=get_db()
    course=db.execute("SELECT name FROM courses WHERE id=?",(course_id,)).fetchone()
    if not course:
        db.close()
        raise HTTPException(404,"Course not found")
    topic_ids=[r["id"] for r in db.execute("SELECT id FROM topics WHERE course_id=?",(course_id,)).fetchall()]
    db.execute("DELETE FROM drafts WHERE course_id=?",(course_id,))
    if topic_ids:
        marks=",".join("?" for _ in topic_ids)
        db.execute(f"DELETE FROM drafts WHERE topic_id IN ({marks})",topic_ids)
        db.execute(f"DELETE FROM topics WHERE id IN ({marks})",topic_ids)
    db.execute("DELETE FROM courses WHERE id=?",(course_id,))
    db.commit()
    db.close()
    log("INFO","COURSES",f"Deleted course {course['name']}")
    return {"status":"deleted","course_id":course_id}

@app.post("/api/topics")
def add_topic(req: TopicIn, user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db()
    if not db.execute("SELECT 1 FROM courses WHERE id=?",(req.course_id,)).fetchone(): db.close(); raise HTTPException(404,"Course not found")
    cur=db.execute("INSERT INTO topics(course_id,title,details,source,workspace_id) VALUES(?,?,?,?,?)",
                   (req.course_id,req.title.strip(),(req.details or "").strip(),"Manual Entry",ws_id))
    db.commit(); db.close()
    return {"id":cur.lastrowid}

@app.post("/api/courses/{course_id}/import-topics")
def import_course_topics(course_id: int, req: ImportTopicsIn, user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db = get_db()
    course = db.execute("SELECT id, name FROM courses WHERE id=?", (course_id,)).fetchone()
    if not course:
        db.close()
        raise HTTPException(404, "Course not found")
    lines = [line.strip() for line in req.content.splitlines() if line.strip()]
    added = 0
    for line in lines:
        clean_title = re.sub(r"^[\s*•\-\d\.\)]+", "", line).strip()
        if not clean_title or len(clean_title) < 2:
            continue
        cursor = db.execute(
            "INSERT INTO topics(course_id, title, details, source, workspace_id) SELECT ?, ?, ?, 'Manual Import', ? WHERE NOT EXISTS (SELECT 1 FROM topics WHERE course_id=? AND title=?)",
            (course_id, clean_title[:240], f"Imported topic for {course['name']}.", ws_id, course_id, clean_title[:240])
        )
        added += cursor.rowcount
    db.commit()
    db.close()
    log("INFO", "COURSES", f"Imported {added} topics for {course['name']} in workspace #{ws_id}")
    return {"topics_added": added, "course_id": course_id}
@app.get("/api/courses/{course_id}/export")
def export_course(course_id: int, user=Depends(current_user)):
    db=get_db()
    course=db.execute("SELECT * FROM courses WHERE id=?",(course_id,)).fetchone()
    if not course:
        db.close()
        raise HTTPException(404,"Course not found")
    topics=db.execute("SELECT title,details FROM topics WHERE course_id=? ORDER BY id",(course_id,)).fetchall()
    db.close()

    def paragraph(text, style=None):
        style_attr=f' text:style-name="{style}"' if style else ""
        return f"<text:p{style_attr}>{html.escape(str(text or ''), quote=False)}</text:p>"

    title=paragraph(course["name"],"Title")
    source=paragraph(f"Official syllabus source: {course['syllabus_url'] or 'Not recorded'}")
    body=title+source
    if course["description"]:
        body+=paragraph(course["description"])
    if topics:
        body+=paragraph("Syllabus topics","Heading")
        for index, topic in enumerate(topics,1):
            body+=paragraph(f"{index}. {topic['title']}","Topic")
            if topic["details"]:
                body+=paragraph(topic["details"])
    else:
        body+=paragraph("No syllabus topics have been populated yet.")
    content=f'''<?xml version="1.0" encoding="UTF-8"?>
<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.2">
<office:body><office:text>{body}</office:text></office:body></office:document-content>'''
    styles='''<?xml version="1.0" encoding="UTF-8"?>
<office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.2">
<office:styles>
<style:style style:name="Title" style:family="paragraph"><style:text-properties fo:font-size="18pt" fo:font-weight="bold" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"/></style:style>
<style:style style:name="Heading" style:family="paragraph"><style:text-properties fo:font-size="14pt" fo:font-weight="bold" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"/></style:style>
<style:style style:name="Topic" style:family="paragraph"><style:text-properties fo:font-weight="bold" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"/></style:style>
</office:styles></office:document-styles>'''
    manifest='''<?xml version="1.0" encoding="UTF-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
<manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.text"/>
<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>
<manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>
</manifest:manifest>'''
    output=BytesIO()
    with zipfile.ZipFile(output,"w") as document:
        document.writestr("mimetype","application/vnd.oasis.opendocument.text",compress_type=zipfile.ZIP_STORED)
        document.writestr("content.xml",content)
        document.writestr("styles.xml",styles)
        document.writestr("META-INF/manifest.xml",manifest)
    filename=f"{safe_slug(course['name'])}-syllabus.odt"
    return Response(output.getvalue(),media_type="application/vnd.oasis.opendocument.text",
                    headers={"Content-Disposition":f'attachment; filename="{quote(filename)}"'})
@app.post("/api/topics/bulk-delete")
def delete_topics(topic_ids: list[int], user=Depends(current_user)):
    if not topic_ids:
        raise HTTPException(400, "Select at least one topic")
    db=get_db()
    marks=",".join("?" for _ in topic_ids)
    db.execute(f"DELETE FROM drafts WHERE topic_id IN ({marks})", topic_ids)
    deleted=db.execute(f"DELETE FROM topics WHERE id IN ({marks})", topic_ids).rowcount
    db.commit(); db.close()
    log("INFO", "COURSES", f"Deleted {deleted} selected topics")
    return {"status":"deleted","count":deleted}
@app.delete("/api/topics/{topic_id}")
def delete_topic(topic_id: int, user=Depends(current_user)):
    db=get_db()
    topic=db.execute("SELECT title FROM topics WHERE id=?", (topic_id,)).fetchone()
    if not topic:
        db.close()
        raise HTTPException(404, "Topic not found")
    db.execute("DELETE FROM drafts WHERE topic_id=?", (topic_id,))
    db.execute("DELETE FROM topics WHERE id=?", (topic_id,))
    db.commit(); db.close()
    log("INFO", "COURSES", f"Deleted topic {topic['title']}")
    return {"status":"deleted","topic_id":topic_id}
@app.post("/api/modules/add")
def legacy_add(req: dict, user=Depends(current_user)): return add_topic(TopicIn(course_id=int(req.get("course_id",1)),title=req.get("topic") or req.get("name","")),user)

@app.post("/api/courses/{course_id}/populate")
@app.post("/api/modules/populate/{course_name}")
async def populate(course_id: Optional[int]=None, course_name: Optional[str]=None, user=Depends(current_user)):
    db=get_db(); c=db.execute("SELECT * FROM courses WHERE id=?" if course_id else "SELECT * FROM courses WHERE name=?",(course_id or course_name,)).fetchone()
    if not c: db.close(); raise HTTPException(404,"Course not found")
    ws_id = c["workspace_id"] if "workspace_id" in c.keys() and c["workspace_id"] else 1
    cached=db.execute("SELECT source_url,topics_json FROM course_syllabus_cache WHERE course_id=?",(c["id"],)).fetchone()
    if cached:
        cached_topics=json.loads(cached["topics_json"])
        added=0
        for topic in cached_topics:
            cursor=db.execute(
                "INSERT INTO topics(course_id,title,details,source,workspace_id) SELECT ?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM topics WHERE course_id=? AND title=?)",
                (c["id"],topic["title"],topic.get("details",""),"Syllabus Cache",ws_id,c["id"],topic["title"]),
            )
            added+=cursor.rowcount
        topics=[dict(topic) for topic in db.execute("SELECT id,title,status,details FROM topics WHERE course_id=? ORDER BY id",(c["id"],)).fetchall()]
        db.commit()
        db.close()
        return {"topics_added":added,"topics":topics,"source_url":cached["source_url"],"cached":True}
    db.close()

    quota_exhausted = False
    source_url = ""
    topic_source = ""
    topics = []
    try:
        source_url, syllabus_text = await asyncio.to_thread(fetch_official_syllabus,c["name"],c["syllabus_url"])
        topics = await ai_topics(c["name"], source_url, syllabus_text)
        topic_source = f"Official Syllabus ({urlparse(source_url).hostname})"
    except HTTPException as exc:
        if exc.status_code == 429:
            quota_exhausted = True
            log("WARNING","SYLLABUS",f"Gemini quota exhausted while populating '{c['name']}'. Falling back to local AI outline...")
        else:
            log("ERROR","SYLLABUS",f"Could not populate {c['name']}: {exc.detail}")
            raise
    except Exception as exc:
        log("ERROR","SYLLABUS",f"Unexpected error populating '{c['name']}' ({type(exc).__name__}): {exc}")
        raise

    if quota_exhausted:
        topics = await generate_local_syllabus(c["name"])
        source_url = "Postall_V4 AI Fallback (Search Quota Exhausted)"
        topic_source = "Postall_V4 AI Fallback (Search Quota Exhausted)"

    db=get_db()
    added=0
    for topic in topics:
        cursor=db.execute(
            "INSERT INTO topics(course_id,title,details,source,workspace_id) SELECT ?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM topics WHERE course_id=? AND title=?)",
            (c["id"],topic["title"],topic.get("details",""),topic_source,ws_id,c["id"],topic["title"]),
        )
        added += cursor.rowcount
    if not quota_exhausted:
        db.execute("UPDATE courses SET syllabus_url=? WHERE id=?",(source_url,c["id"]))
        db.execute("INSERT INTO course_syllabus_cache(course_id,source_url,topics_json) VALUES(?,?,?)",
                   (c["id"],source_url,json.dumps(topics,ensure_ascii=False)))
    db.commit(); db.close()
    log("INFO","SYLLABUS",f"Populated {c['name']} via {topic_source} ({added} new topics)")
    response_data = {
        "topics_added": added,
        "topics": topics,
        "source_url": source_url,
        "cached": False,
    }
    if quota_exhausted:
        response_data["warning"] = "Gemini quota exhausted. Generated topics using local AI fallback."
        response_data["fallback"] = True
    return response_data

def gemini_api_keys():
    db_keys = []
    try:
        db = get_db()
        for k in ("gemini_api_key", "gemini_key", "gemini_api_key_1", "gemini_api_key_2"):
            row = db.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone()
            if row and row["value"] and str(row["value"]).strip():
                db_keys.append(str(row["value"]).strip())
        db.close()
    except Exception:
        pass
    env_keys = [os.getenv(name) for name in ("GEMINI_API_KEY", "GEMINI_API_KEY_1", "GEMINI_API_KEY_2") if os.getenv(name) and os.getenv(name).strip()]
    return list(dict.fromkeys(db_keys + env_keys))

def is_dry_run() -> bool:
    try:
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key='dry_run_mode'").fetchone()
        db.close()
        if row and str(row["value"]).strip() in {"1", "true", "on", "yes"}:
            return True
    except Exception:
        pass
    return os.getenv("DRY_RUN_MODE", "0").lower() in {"1", "true", "on", "yes"}

_MODELS_CACHE = {"timestamp": 0.0, "models": []}

async def discover_available_gemini_models(api_key: Optional[str] = None) -> list[str]:
    global _MODELS_CACHE
    now = time.time()
    if _MODELS_CACHE["models"] and (now - _MODELS_CACHE["timestamp"] < 86400):
        return list(_MODELS_CACHE["models"])

    candidate_keys = [api_key] if api_key else gemini_api_keys()
    if not candidate_keys:
        return ["gemini-flash-lite-latest", "gemini-1.5-flash", "gemini-1.5-pro"]

    discovered = []
    for key in candidate_keys:
        try:
            from google import genai
            client = genai.Client(api_key=key)
            try:
                raw_models = await asyncio.to_thread(lambda: list(client.models.list()))
                for m in raw_models:
                    m_name = getattr(m, "name", "") or ""
                    m_id = m_name.replace("models/", "").strip()
                    if not m_id or "gemini" not in m_id.lower():
                        continue
                    actions = getattr(m, "supported_actions", None) or getattr(m, "supported_generation_methods", None) or []
                    if actions and not any("generateContent" in str(a) for a in actions):
                        continue
                    lowered = m_id.lower()
                    if any(x in lowered for x in ("deprecated", "exp-", "preview", "vision", "2.0-flash", "2.5-flash")):
                        continue
                    if m_id not in discovered:
                        discovered.append(m_id)
                if discovered:
                    break
            finally:
                client.close()
        except Exception as exc:
            log("WARNING", "AI_DISCOVERY", f"Model discovery failed with key ({type(exc).__name__}: {str(exc)[:120]})")

    if not discovered:
        discovered = ["gemini-flash-lite-latest", "gemini-1.5-flash", "gemini-1.5-pro"]
    else:
        def model_sort_key(name):
            n = name.lower()
            if "3.8" in n and "flash" in n: return 0
            if "flash-lite" in n: return 1
            if "flash-latest" in n: return 2
            if "flash" in n: return 3
            if "pro" in n: return 4
            return 5
        discovered.sort(key=model_sort_key)

    _MODELS_CACHE["timestamp"] = now
    _MODELS_CACHE["models"] = discovered
    log("INFO", "AI_DISCOVERY", f"Discovered {len(discovered)} active Gemini models (primary: {discovered[0]})")
    return list(discovered)

def gemini_models():
    primary_pref = None
    try:
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key='ai_primary_model'").fetchone()
        db.close()
        if row and row["value"] and str(row["value"]).strip():
            val = str(row["value"]).strip()
            if val not in {"gemini-2.5-flash", "gemini-2.0-flash", "models/gemini-2.5-flash", "models/gemini-2.0-flash"}:
                primary_pref = val
    except Exception:
        pass
    configured_models = os.getenv("GEMINI_MODELS")
    if configured_models:
        models = [model.strip() for model in configured_models.split(",") if model.strip()]
    else:
        configured_model = os.getenv("GEMINI_MODEL")
        if configured_model in {"gemini-2.5-flash", "gemini-2.0-flash", "models/gemini-2.5-flash", "models/gemini-2.0-flash"}:
            configured_model = None
        discovered = _MODELS_CACHE.get("models") or []
        if discovered:
            models = list(discovered)
        else:
            models = [m for m in (configured_model, "gemini-flash-lite-latest", "gemini-1.5-flash", "gemini-1.5-pro") if m]
    if primary_pref:
        models = [primary_pref] + [m for m in models if m != primary_pref]
    return list(dict.fromkeys(models))

def gemini_quota_error(exc):
    return ("429" in str(exc).upper() or "RESOURCE_EXHAUSTED" in str(exc).upper()
            or getattr(exc,"status_code",None)==429 or getattr(exc,"code",None)==429)

def gemini_not_found_error(exc):
    msg = str(exc).upper()
    return ("404" in msg or "NOT_FOUND" in msg or "NO LONGER AVAILABLE" in msg
            or getattr(exc, "status_code", None) == 404 or getattr(exc, "code", None) == 404)

def record_ai_usage(model, response):
    usage=getattr(response,"usage_metadata",None)
    prompt_tokens=getattr(usage,"prompt_token_count",0) or 0
    output_tokens=getattr(usage,"candidates_token_count",0) or 0
    total_tokens=getattr(usage,"total_token_count",0) or prompt_tokens+output_tokens
    db=get_db()
    try:
        db.execute(
            """INSERT INTO api_usage(model,request_count,prompt_tokens,output_tokens,total_tokens)
               VALUES(?,1,?,?,?)
               ON CONFLICT(model) DO UPDATE SET
                 request_count=request_count+1,
                 prompt_tokens=prompt_tokens+excluded.prompt_tokens,
                 output_tokens=output_tokens+excluded.output_tokens,
                 total_tokens=total_tokens+excluded.total_tokens""",
            (model,prompt_tokens,output_tokens,total_tokens),
        )
        db.commit()
    except sqlite3.Error as exc:
        log("ERROR","AI",f"Could not record model usage ({type(exc).__name__})")
    finally:
        db.close()
    return {"prompt_tokens":prompt_tokens,"output_tokens":output_tokens,"total_tokens":total_tokens,
            "usage_reported":usage is not None}

def ai_text(prompt, on_usage=None, on_event=None):
    keys=gemini_api_keys()
    if not keys: return None
    models=gemini_models()
    if not models: return None
    try:
        from google import genai
        for model in models:
            all_keys_quota_exhausted=True
            for key in keys:
                client=None
                try:
                    client=genai.Client(api_key=key)
                    try:
                        chat=client.chats.create(model=model)
                        response=chat.send_message(prompt)
                        all_keys_quota_exhausted=False
                        usage=record_ai_usage(model,response)
                        if on_usage: on_usage({"model":model,**usage})
                        if getattr(response,"text",None):
                            if on_event: on_event(f"Generated response with {model}.")
                            return response.text
                    except Exception as exc:
                        if gemini_not_found_error(exc):
                            log("WARNING","AI",f"Gemini {model} returned 404 NOT_FOUND; trying fallback model...")
                            break
                        if not gemini_quota_error(exc):
                            all_keys_quota_exhausted=False
                        if on_event: on_event(f"{model} request failed: {type(exc).__name__}.")
                        log("WARNING","AI",f"Gemini {model} failed ({type(exc).__name__}: {str(exc)[:180]})")
                except Exception as exc:
                    all_keys_quota_exhausted=False
                    log("WARNING","AI",f"Gemini client failed ({type(exc).__name__}: {str(exc)[:180]})")
                finally:
                    if client:
                        client.close()
            if all_keys_quota_exhausted:
                log("WARNING","AI",f"Gemini quota exhausted for all configured keys on {model}; trying fallback models")
                if on_event: on_event(f"Quota exhausted for {model} on all configured keys; trying fallback model.")
    except Exception as exc:
        log("ERROR","AI",f"Gemini client initialization failed ({type(exc).__name__}): {str(exc)[:180]}")
        return None
    return None

def ai_engine_settings():
    db=get_db()
    try:
        settings={r["key"]:r["value"] for r in db.execute(
            "SELECT key,value FROM settings WHERE key IN ('enable_gemini_api','enable_local_llm')"
        )}
    finally:
        db.close()
    def enabled(value,default=True):
        if value is None: return default
        return str(value).strip().lower() not in {"0","false","off","no","disabled"}
    return enabled(settings.get("enable_gemini_api")),enabled(settings.get("enable_local_llm"))

async def run_gemini_task(prompt, on_usage=None, on_event=None):
    result=await asyncio.to_thread(ai_text,prompt,on_usage,on_event)
    if not result or not result.strip():
        raise RuntimeError("Gemini API failed to return generated content")
    log("INFO","AI_ROUTER","Gemini processed task")
    return result.strip()


def retrieve_local_memory(query: str) -> str:
    """Performs a lightweight LIKE %query% search against local_llm_memory to fetch past context."""
    if not query or not query.strip():
        return ""
    try:
        clean_q = query.strip()[:100]
        with get_db() as db:
            rows = db.execute(
                "SELECT learning_data FROM local_llm_memory WHERE context_key LIKE ? OR learning_data LIKE ? ORDER BY id DESC LIMIT 3",
                (f"%{clean_q}%", f"%{clean_q}%")
            ).fetchall()
            if rows:
                memories = [str(r["learning_data"]).strip() for r in rows if r["learning_data"]]
                return " | ".join(memories)
    except Exception as exc:
        log("WARN", "LOCAL_LLM", f"retrieve_local_memory error: {exc}")
    return ""

async def run_local_task(prompt, on_usage=None, on_event=None, max_tokens=128):
    global local_llm
    # In-context memory retrieval
    memory = retrieve_local_memory(prompt)
    effective_prompt = f"Recall this previously learned context: {memory}\n\n{prompt}" if memory else prompt

    async with local_llm_lock:
        model=local_llm
        if model is None:
            raise RuntimeError("Local LLM is not loaded")
        result=await asyncio.to_thread(model,effective_prompt,max_tokens=max_tokens)
    try:
        text=result["choices"][0]["text"]
    except (KeyError,IndexError,TypeError) as exc:
        raise RuntimeError("Local LLM returned an invalid completion response") from exc
    if not isinstance(text,str) or not text.strip():
        raise RuntimeError("Local LLM returned an empty completion")
    usage=result.get("usage") if isinstance(result,dict) else None
    prompt_tokens=int((usage or {}).get("prompt_tokens",0) or 0)
    output_tokens=int((usage or {}).get("completion_tokens",0) or 0)
    total_tokens=int((usage or {}).get("total_tokens",prompt_tokens+output_tokens) or 0)
    if usage:
        record_ai_usage("Qwen2.5-1.5B-Instruct-GGUF",SimpleNamespace(usage_metadata=SimpleNamespace(
            prompt_token_count=prompt_tokens,candidates_token_count=output_tokens,total_token_count=total_tokens)))
    if on_usage:
        on_usage({"model":"Qwen2.5-1.5B-Instruct-GGUF","engine":"local",
                  "prompt_tokens":prompt_tokens,"output_tokens":output_tokens,
                  "total_tokens":total_tokens,"usage_reported":bool(usage)})
    if on_event: on_event("Local LLM completed inference.")
    log("INFO","AI_ROUTER","Local LLM processed task")
    return text.strip()

async def generate_with_local_llm(prompt: str, max_tokens: int = 180) -> str:
    return await run_local_task(prompt, max_tokens=max_tokens)

async def generate_alert_summary(topic: str, post_body: str) -> dict:
    """Uses the local Qwen model to create a concise notification summary."""
    prompt = (
        f"You are an executive notification assistant. Given this post about '{topic}', "
        f"write a crisp 2-sentence executive summary followed by 3 brief bullet points of key takeaways.\n\n"
        f"Post:\n{post_body[:1200]}\n\n"
        f"Format:\nSummary: <text>\nTakeaways:\n- <pt1>\n- <pt2>\n- <pt3>"
    )
    try:
        raw = await generate_with_local_llm(prompt, max_tokens=180)
        return {"raw_summary": raw}
    except Exception:
        return {"raw_summary": f"New post ready for review: {topic}"}

async def generate_local_syllabus(course_name: str) -> list[dict]:
    prompt = (
        f"Generate a study syllabus outline for '{course_name}'. "
        f"Provide 6 core domains. Output ONLY a JSON array of objects with keys 'title' and 'details'."
    )
    try:
        raw_text = await run_local_task(prompt, max_tokens=380)
        match = re.search(r"\[.*\]", raw_text, re.S)
        if match:
            parsed = json.loads(match.group(0))
            if isinstance(parsed, list) and len(parsed) >= 3:
                normalized = []
                for item in parsed:
                    if isinstance(item, dict) and item.get("title"):
                        normalized.append({
                            "title": str(item["title"]).strip()[:240],
                            "details": str(item.get("details", "")).strip()[:3000] or f"Technical domains and concepts for {course_name}."
                        })
                if normalized:
                    return normalized
    except Exception as exc:
        log("WARNING", "SYLLABUS", f"Local LLM syllabus outline failed ({type(exc).__name__}: {str(exc)[:120]}); building standard domain curriculum.")

    base_domains = [
        (f"{course_name} Architecture & Fundamentals", "Core architecture principles, system components, foundational design patterns, and deployment prerequisites."),
        (f"{course_name} Configuration & Implementation", "Hands-on setup, configuration parameters, deployment strategies, and integration workflows."),
        (f"{course_name} Security, Identity & Governance", "Access controls, least privilege policies, encryption, audit compliance, and threat mitigation."),
        (f"{course_name} Performance, Monitoring & Diagnostics", "Telemetry collection, metric analysis, alerting pipelines, and incident troubleshooting."),
        (f"{course_name} High Availability & Disaster Recovery", "Fault tolerance, automated failover mechanisms, backup strategies, and multi-region resilience."),
        (f"{course_name} Automation, CI/CD & Best Practices", "Infrastructure as Code, pipeline integration, automated validation, and enterprise production guidelines."),
    ]
    return [{"title": title, "details": details} for title, details in base_domains]

# Register the local Qwen LLM runner with the unified AI router
register_local_llm_runner(run_local_task)

async def execute_task(task_type: str, prompt: str, on_usage=None, on_event=None, system_prompt: str = "") -> str:
    """Unified AI task dispatcher routing through ai_router with automatic cloud & offline fallbacks."""
    try:
        return await ai_router_generate_text(
            prompt=prompt,
            system_prompt=system_prompt,
            on_event=on_event,
            on_usage=on_usage
        )
    except Exception as exc:
        log("ERROR", "AI_ROUTER", f"Task '{task_type}' failed across all providers: {str(exc)[:250]}")
        raise RuntimeError(f"AI task generation failed: {exc}") from exc

def create_action_token(draft_id: int, action: str, valid_hours: int = 48) -> str:
    token = secrets.token_urlsafe(32)
    expires_at = (datetime.now(timezone.utc) + timedelta(hours=valid_hours)).isoformat(timespec="seconds")
    db = get_db()
    try:
        db.execute(
            "INSERT INTO action_tokens(token, draft_id, action_type, expires_at) VALUES(?,?,?,?)",
            (token, draft_id, action, expires_at)
        )
        db.commit()
    finally:
        db.close()
    return token


def find_next_available_schedule_slot(db, exclude_draft_id: Optional[int] = None) -> datetime:
    tz = configured_timezone()
    now_tz = datetime.now(tz)
    post_time_str = "09:00"
    row = db.execute("SELECT value FROM settings WHERE key='post_time'").fetchone()
    if row and row["value"]:
        post_time_str = str(row["value"]).strip()
    try:
        parts = [int(p) for p in post_time_str.split(":", 1)]
        hour, minute = parts[0], parts[1]
    except Exception:
        hour, minute = 9, 0

    scheduled_rows = db.execute(
        "SELECT id, scheduled_at FROM drafts WHERE scheduled_at IS NOT NULL AND status IN ('APPROVED','SCHEDULED') AND id != ?",
        (exclude_draft_id or -1,)
    ).fetchall()
    booked_dates = set()
    for sr in scheduled_rows:
        try:
            dt = datetime.fromisoformat(str(sr["scheduled_at"]).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            booked_dates.add(dt.astimezone(tz).date())
        except Exception:
            pass

    candidate_date = now_tz.date()
    candidate_dt = datetime(candidate_date.year, candidate_date.month, candidate_date.day, hour, minute, tzinfo=tz)
    if candidate_dt <= now_tz:
        candidate_date += timedelta(days=1)
        candidate_dt = datetime(candidate_date.year, candidate_date.month, candidate_date.day, hour, minute, tzinfo=tz)

    while candidate_dt.date() in booked_dates:
        candidate_date += timedelta(days=1)
        candidate_dt = datetime(candidate_date.year, candidate_date.month, candidate_date.day, hour, minute, tzinfo=tz)

    return candidate_dt.astimezone(timezone.utc)

def reschedule_upcoming_drafts_to_new_post_time(db, new_post_time_str: str, tz_name: Optional[str] = None) -> int:
    """When the daily post_time or timezone changes in settings, update all upcoming scheduled/approved drafts
    to use the new target time on their respective calendar dates.
    """
    if not tz_name:
        row = db.execute("SELECT value FROM settings WHERE key='timezone'").fetchone()
        tz_name = row["value"] if row and row["value"] else "Asia/Kolkata"
    try:
        tz = ZoneInfo(tz_name)
    except Exception:
        tz = ZoneInfo("Asia/Kolkata")

    try:
        parts = [int(p) for p in str(new_post_time_str).strip().split(":", 1)]
        target_hour, target_minute = parts[0], parts[1]
    except Exception:
        return 0

    rows = db.execute(
        "SELECT id, scheduled_at FROM drafts WHERE status IN ('SCHEDULED', 'APPROVED') AND scheduled_at IS NOT NULL"
    ).fetchall()

    updated = 0
    for r in rows:
        try:
            dt = datetime.fromisoformat(str(r["scheduled_at"]).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            local_dt = dt.astimezone(tz)
            new_local = datetime(local_dt.year, local_dt.month, local_dt.day, target_hour, target_minute, tzinfo=tz)
            new_utc_iso = new_local.astimezone(timezone.utc).isoformat()
            db.execute("UPDATE drafts SET scheduled_at=? WHERE id=?", (new_utc_iso, r["id"]))
            updated += 1
        except Exception as exc:
            logger.warning("Failed to reschedule draft %s: %s", r["id"], exc)

    if updated:
        db.commit()
        log("INFO", "SCHEDULER", f"Rescheduled {updated} active drafts to new target time {new_post_time_str} ({tz_name})")
    return updated

def render_magic_link_response(success: bool, title: str, message: str, details: str = "", draft_info: Optional[dict] = None, server_base_url: str = "") -> HTMLResponse:
    brand_url = server_base_url or "/"
    is_approved = "Approved" in title
    is_rejected = "Rejected" in title
    status_color = "#10b981" if is_approved else ("#ef4444" if is_rejected else "#f59e0b")
    status_badge_bg = "rgba(16, 185, 129, 0.12)" if is_approved else ("rgba(239, 68, 68, 0.12)" if is_rejected else "rgba(245, 158, 11, 0.12)")
    status_icon = "✓" if is_approved else ("✕" if is_rejected else "⚠")
    
    draft_meta_html = ""
    if draft_info:
        draft_meta_html = f"""
        <div style="background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 16px; margin: 20px 0; text-align: left;">
            <div style="font-size: 11px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px;">Target Post Information</div>
            <div style="font-size: 15px; font-weight: 600; color: #f8fafc; margin-bottom: 6px;">{html.escape(draft_info.get("topic_name") or draft_info.get("prompt") or f"Draft #{draft_info.get('id','')}")}</div>
            <div style="font-size: 12px; color: #60a5fa; font-family: monospace;">Module: {html.escape(draft_info.get("course_name") or "On-Demand")} · ID: #{draft_info.get("id")}</div>
            {f'<div style="font-size: 12px; color: #34d399; margin-top: 8px; font-family: monospace;">📅 Scheduled For: {html.escape(draft_info.get("scheduled_display", ""))}</div>' if draft_info.get("scheduled_display") else ''}
        </div>
        """

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html.escape(title)} - Postall_V4</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: #070a14;
            color: #f1f5f9;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background-image: 
                radial-gradient(at 0% 0%, rgba(37, 99, 235, 0.12) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.12) 0px, transparent 50%);
        }}
        .card {{
            background: #0f172a;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px 32px;
            max-width: 520px;
            width: 100%;
            text-align: center;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(12px);
        }}
        .icon-circle {{
            width: 72px;
            height: 72px;
            border-radius: 50%;
            background: {status_badge_bg};
            border: 2px solid {status_color};
            color: {status_color};
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 24px;
        }}
        h1 {{
            font-size: 22px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 12px;
            letter-spacing: -0.02em;
        }}
        p.message {{
            font-size: 14px;
            line-height: 1.6;
            color: #94a3b8;
            margin-bottom: 16px;
        }}
        p.details {{
            font-size: 12px;
            color: #64748b;
            font-family: 'JetBrains Mono', monospace;
            margin-bottom: 20px;
        }}
        .btn {{
            display: inline-block;
            background: #2563eb;
            color: #ffffff;
            font-weight: 700;
            font-size: 14px;
            padding: 12px 28px;
            border-radius: 10px;
            text-decoration: none;
            transition: all 0.2s ease;
            box-shadow: 0 4px 14px 0 rgba(37, 99, 235, 0.39);
        }}
        .btn:hover {{
            background: #1d4ed8;
            transform: translateY(-1px);
        }}
        .brand-footer {{
            margin-top: 32px;
            font-size: 11px;
            color: #475569;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            font-weight: 600;
        }}
    </style>
</head>
<body>
    <div class="card">
        <div class="icon-circle">{status_icon}</div>
        <h1>{html.escape(title)}</h1>
        <p class="message">{html.escape(message)}</p>
        {draft_meta_html}
        {f'<p class="details">{html.escape(details)}</p>' if details else ''}
        <div style="margin-top: 24px;">
            <a href="{brand_url}" class="btn">Open Postall_V4 Dashboard</a>
        </div>
        <div class="brand-footer">Postall_V4 Engine · Autonomous Social Operations</div>
    </div>
</body>
</html>"""
    return HTMLResponse(content=html_content, status_code=200 if success else 400)

def send_interactive_draft_email(draft, approve_url, reject_url, raw_summary, settings):
    host = settings.get("smtp_host") or os.getenv("SMTP_HOST") or "smtp.gmail.com"
    sender = settings.get("smtp_sender") or os.getenv("EMAIL_SENDER")
    receiver = settings.get("smtp_receiver") or os.getenv("EMAIL_RECEIVER")
    if not host or not sender or not receiver:
        return
    
    topic_name = draft.get("topic_name") or draft.get("prompt") or f"Draft #{draft['id']}"
    course_name = draft.get("course_name") or "On-Demand"
    subject = f"Action Required: Review Draft #{draft['id']} - {topic_name}"
    
    summary_html = html.escape(raw_summary).replace("\n", "<br>")
    preview_snippet = html.escape((draft.get("body") or "")[:450])
    
    html_content = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #080d1a; color: #cbd5e1; margin: 0; padding: 24px; }}
  .container {{ max-width: 620px; margin: 0 auto; background: #0f172a; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }}
  .header {{ background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%); padding: 28px 24px; border-bottom: 1px solid #312e81; }}
  .brand {{ font-size: 11px; font-weight: 800; letter-spacing: 0.15em; color: #818cf8; text-transform: uppercase; margin-bottom: 8px; }}
  .title {{ font-size: 20px; font-weight: 700; color: #ffffff; margin: 0 0 8px 0; }}
  .badge {{ display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; background: rgba(59,130,246,0.15); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); }}
  .body {{ padding: 24px; }}
  .card {{ background: #131d35; border: 1px solid #1e293b; border-radius: 12px; padding: 18px; margin-bottom: 20px; }}
  .card-title {{ font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #94a3b8; margin-bottom: 10px; }}
  .summary-text {{ font-size: 13px; line-height: 1.6; color: #e2e8f0; }}
  .preview-box {{ font-size: 13px; line-height: 1.5; color: #94a3b8; font-style: italic; border-left: 3px solid #3b82f6; padding-left: 12px; }}
  .actions {{ margin: 28px 0 16px 0; }}
  .btn {{ display: inline-block; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: 700; text-decoration: none; text-align: center; }}
  .footer {{ padding: 16px 24px; background: #0b1120; border-top: 1px solid #1e293b; font-size: 11px; color: #64748b; text-align: center; }}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="brand">Postall_V4 Automation Engine · Action Required</div>
      <h1 class="title">{html.escape(topic_name)}</h1>
      <span class="badge">Module: {html.escape(course_name)} · Draft #{draft['id']}</span>
    </div>
    <div class="body">
      <div class="card" style="border-left: 3px solid #818cf8;">
        <div class="card-title">🤖 Postall_V4 AI Executive Summary &amp; Key Takeaways</div>
        <div class="summary-text">{summary_html}</div>
      </div>
      <div class="card">
        <div class="card-title">📝 Technical Post Preview Snippet</div>
        <div class="preview-box">{preview_snippet}...</div>
      </div>
      <p style="font-size: 12px; color: #94a3b8; margin-bottom: 16px;">
        Click below to approve and assign to the next schedule slot, or reject:
      </p>
      <div class="actions">
        <a href="{approve_url}" class="btn" style="background:#10b981; color:#ffffff !important; margin-right:12px;">✓ Approve &amp; Schedule</a>
        <a href="{reject_url}" class="btn" style="background:#ef4444; color:#ffffff !important;">✕ Reject Post</a>
      </div>
      <div style="margin-top:20px; font-size:11px; color:#64748b;">
        Action links are secured with single-use cryptographic tokens valid for 48 hours.
      </div>
    </div>
    <div class="footer">
      Generated automatically by Postall_V4 Engine · High-Performance Social Publishing Platform
    </div>
  </div>
</body>
</html>"""

    plain_content = f"""Postall_V4 | Action Required: Review Draft #{draft['id']}
Topic: {topic_name}
Module: {course_name}

Postall_V4 AI Summary:
{raw_summary}

Approve & Schedule (Magic Link):
{approve_url}

Reject (Magic Link):
{reject_url}
"""

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = receiver
    msg.set_content(plain_content)
    msg.add_alternative(html_content, subtype="html")
    
    asset = asset_file(draft.get("asset_path")) if draft.get("asset_path") else None
    attach_asset(msg, asset)
    
    password = settings.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD", "")
    with smtplib.SMTP(host, int(settings.get("smtp_port") or os.getenv("SMTP_PORT", "587")), timeout=15) as smtp:
        smtp.starttls()
        smtp.login(sender, password)
        smtp.send_message(msg)

async def send_webhook(client: httpx.AsyncClient, url: str, payload: dict, channel_name: str):
    if not url:
        return
    try:
        resp = await client.post(url, json=payload, timeout=10.0)
        if resp.status_code >= 400:
            log("ERROR", "ALERT_ENGINE", f"{channel_name} webhook rejected (HTTP {resp.status_code}): {resp.text[:200]}")
        else:
            log("INFO", "ALERT_ENGINE", f"{channel_name} alert dispatched successfully")
    except Exception as exc:
        log("ERROR", "ALERT_ENGINE", f"Failed to deliver {channel_name} webhook: {str(exc)[:200]}")

async def dispatch_platform_alerts(event_type: str, draft: dict, error_message: Optional[str] = None):
    try:
        db = get_db()
        settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
        db.close()

        server_base_url = (settings.get("server_base_url") or "http://172.19.74.165:8000").rstrip("/")
        slack_webhook = (settings.get("slack_webhook_url") or "").strip()
        teams_webhook = (settings.get("teams_webhook_url") or "").strip()

        if event_type == "draft_ready":
            if settings.get("alert_on_draft_ready", "1") == "0":
                return
            did = draft.get("id")
            if not did:
                return
            topic_name = draft.get("topic_name") or draft.get("prompt") or f"Draft #{did}"
            course_name = draft.get("course_name") or "On-Demand"
            
            approve_token = create_action_token(did, "approve_schedule", valid_hours=48)
            reject_token = create_action_token(did, "reject", valid_hours=48)
            approve_url = f"{server_base_url}/api/actions/magic-link?token={approve_token}&decision=approve"
            reject_url = f"{server_base_url}/api/actions/magic-link?token={reject_token}&decision=reject"

            summary_res = await generate_alert_summary(topic_name, draft.get("body", ""))
            raw_summary = summary_res.get("raw_summary", f"New technical post ready for review: {topic_name}")

            try:
                await asyncio.to_thread(send_interactive_draft_email, draft, approve_url, reject_url, raw_summary, settings)
                log("INFO", "ALERT_ENGINE", f"Interactive review email dispatched for draft #{did}")
            except Exception as e:
                log("WARNING", "ALERT_ENGINE", f"Email alert skipped/failed for draft #{did}: {e}")

            if slack_webhook:
                slack_payload = {
                    "text": f"🚨 Review Required: #{did} · {topic_name}",
                    "blocks": [
                        {
                            "type": "header",
                            "text": {"type": "plain_text", "text": f"🚨 Review Required: #{did} · {topic_name[:70]}"}
                        },
                        {
                            "type": "section",
                            "fields": [
                                {"type": "mrkdwn", "text": f"*Module:* {course_name}"},
                                {"type": "mrkdwn", "text": f"*Status:* Awaiting Approval"}
                            ]
                        },
                        {
                            "type": "section",
                            "text": {
                                "type": "mrkdwn",
                                "text": f"*Postall_V4 AI Executive Summary:*\n{raw_summary}\n\n*Preview Snippet:*\n>{(draft.get('body','')[:280]).replace(chr(10), ' ')}..."
                            }
                        },
                        {
                            "type": "actions",
                            "elements": [
                                {
                                    "type": "button",
                                    "text": {"type": "plain_text", "text": "Approve & Schedule"},
                                    "style": "primary",
                                    "url": approve_url
                                },
                                {
                                    "type": "button",
                                    "text": {"type": "plain_text", "text": "Reject"},
                                    "style": "danger",
                                    "url": reject_url
                                }
                            ]
                        }
                    ]
                }
                async with httpx.AsyncClient() as client:
                    await send_webhook(client, slack_webhook, slack_payload, "Slack")

            if teams_webhook:
                teams_payload = {
                    "@type": "MessageCard",
                    "@context": "http://schema.org/extensions",
                    "themeColor": "0076D7",
                    "summary": f"Review Required: {topic_name}",
                    "title": f"🚨 Review Required: #{did} · {topic_name}",
                    "sections": [
                        {
                            "facts": [
                                {"name": "Module", "value": course_name},
                                {"name": "Draft ID", "value": f"#{did}"}
                            ],
                            "text": f"**Postall_V4 AI Executive Summary:**\n\n{raw_summary}"
                        }
                    ],
                    "potentialAction": [
                        {
                            "@type": "OpenUri",
                            "name": "Approve & Schedule",
                            "targets": [{"os": "default", "uri": approve_url}]
                        },
                        {
                            "@type": "OpenUri",
                            "name": "Reject",
                            "targets": [{"os": "default", "uri": reject_url}]
                        }
                    ]
                }
                async with httpx.AsyncClient() as client:
                    await send_webhook(client, teams_webhook, teams_payload, "Teams")

        elif event_type == "publish_success":
            if settings.get("alert_on_publish_success", "1") == "0":
                return
            did = draft.get("id")
            topic_name = draft.get("topic_name") or draft.get("prompt") or f"Draft #{did}"
            post_url = draft.get("post_url") or draft.get("linkedin_url") or "https://www.linkedin.com"
            time_label = datetime.now(configured_timezone()).strftime("%Y-%m-%d %H:%M %Z")
            celebration_text = f"🚀 Today's post '{topic_name}' has been successfully published to LinkedIn! View post: {post_url}"

            # 1. Email celebratory notification
            try:
                await asyncio.to_thread(send_publish_success_email, topic_name, post_url, settings)
                log("INFO", "ALERT_ENGINE", f"Celebratory publish email sent for '{topic_name}'")
            except Exception as e:
                log("WARNING", "ALERT_ENGINE", f"Celebratory email delivery failed: {e}")

            # 2. Slack celebratory alert
            if slack_webhook:
                slack_payload = {
                    "text": celebration_text,
                    "blocks": [
                        {
                            "type": "header",
                            "text": {"type": "plain_text", "text": "🚀 Post Published to LinkedIn"}
                        },
                        {
                            "type": "section",
                            "text": {
                                "type": "mrkdwn",
                                "text": f"*Draft #{did}* · {topic_name}\n\n{celebration_text}\n\n*Published At:* {time_label}"
                            }
                        },
                        {
                            "type": "actions",
                            "elements": [
                                {
                                    "type": "button",
                                    "text": {"type": "plain_text", "text": "View Post on LinkedIn ↗"},
                                    "style": "primary",
                                    "url": post_url
                                }
                            ]
                        }
                    ]
                }
                async with httpx.AsyncClient() as client:
                    await send_webhook(client, slack_webhook, slack_payload, "Slack")

            # 3. Teams celebratory alert
            if teams_webhook:
                teams_payload = {
                    "@type": "MessageCard",
                    "@context": "http://schema.org/extensions",
                    "themeColor": "28A745",
                    "summary": f"🚀 Post Published: {topic_name}",
                    "title": f"🚀 Today's post '{topic_name}' has been successfully published to LinkedIn!",
                    "text": f"Successfully published to LinkedIn at {time_label}.\n\nView post: [{post_url}]({post_url})",
                    "potentialAction": [
                        {
                            "@type": "OpenUri",
                            "name": "View Post on LinkedIn",
                            "targets": [{"os": "default", "uri": post_url}]
                        }
                    ]
                }
                async with httpx.AsyncClient() as client:
                    await send_webhook(client, teams_webhook, teams_payload, "Teams")

        elif event_type == "publish_failed":
            if settings.get("alert_on_failure", "1") == "0":
                return
            did = draft.get("id")
            topic_name = draft.get("topic_name") or draft.get("prompt") or f"Draft #{did}"
            err = error_message or "Social publication failed"
            time_label = datetime.now(configured_timezone()).strftime("%Y-%m-%d %H:%M %Z")

            if slack_webhook:
                slack_payload = {
                    "text": f"❌ Publish Pipeline Failed: #{did}",
                    "blocks": [
                        {
                            "type": "header",
                            "text": {"type": "plain_text", "text": "❌ Publish Pipeline Failed"}
                        },
                        {
                            "type": "section",
                            "text": {
                                "type": "mrkdwn",
                                "text": f"*Draft #{did}* · {topic_name}\n*Error Trace:*\n```{str(err)[:500]}```\n*Time:* {time_label}\n\nReview System Logs on the dashboard for diagnostics."
                            }
                        }
                    ]
                }
                async with httpx.AsyncClient() as client:
                    await send_webhook(client, slack_webhook, slack_payload, "Slack")

            if teams_webhook:
                teams_payload = {
                    "@type": "MessageCard",
                    "@context": "http://schema.org/extensions",
                    "themeColor": "DC3545",
                    "summary": f"Publish Failed: #{did}",
                    "title": f"❌ Publish Failed: #{did} · {topic_name}",
                    "text": f"**Error Trace:**\n\n`{str(err)[:500]}`\n\n*Time:* {time_label}"
                }
                async with httpx.AsyncClient() as client:
                    await send_webhook(client, teams_webhook, teams_payload, "Teams")

    except Exception as exc:
        log("ERROR", "ALERT_ENGINE", f"dispatch_platform_alerts exception: {exc}")

def fire_alert(event_type: str, draft_data: dict, error_message: Optional[str] = None):
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(dispatch_platform_alerts(event_type, draft_data, error_message))
    except RuntimeError:
        try:
            asyncio.run(dispatch_platform_alerts(event_type, draft_data, error_message))
        except Exception as e:
            log("WARNING", "ALERT_ENGINE", f"fire_alert async execution failed: {e}")
    except Exception as exc:
        log("WARNING", "ALERT_ENGINE", f"fire_alert exception: {exc}")

@app.get("/api/actions/magic-link", response_class=HTMLResponse)
async def magic_link_action(token: str = "", decision: str = ""):
    token = (token or "").strip()
    decision = (decision or "").strip().lower()

    db = get_db()
    settings_dict = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
    server_base_url = (settings_dict.get("server_base_url") or "http://172.19.74.165:8000").rstrip("/")

    if not token or decision not in {"approve", "reject"}:
        db.close()
        return render_magic_link_response(
            success=False,
            title="Invalid Action Request",
            message="The requested remote action link is missing required parameters or is malformed.",
            details="Error code: ERR_INVALID_MAGIC_LINK_PARAMS",
            server_base_url=server_base_url
        )

    token_row = db.execute("SELECT * FROM action_tokens WHERE token=?", (token,)).fetchone()
    if not token_row:
        db.close()
        return render_magic_link_response(
            success=False,
            title="Link Not Found",
            message="This action link was not found or is unrecognized.",
            details="The link token does not exist in the database.",
            server_base_url=server_base_url
        )

    if token_row["used_at"] is not None:
        db.close()
        return render_magic_link_response(
            success=False,
            title="Link Expired or Already Processed",
            message=f"This action link was already processed on {token_row['used_at']} UTC.",
            details="Magic action tokens are single-use only to prevent duplicate state transitions.",
            server_base_url=server_base_url
        )

    try:
        exp_dt = datetime.fromisoformat(str(token_row["expires_at"]).replace("Z", "+00:00"))
        if exp_dt.tzinfo is None:
            exp_dt = exp_dt.replace(tzinfo=timezone.utc)
        if exp_dt <= datetime.now(timezone.utc):
            db.close()
            return render_magic_link_response(
                success=False,
                title="Action Link Expired",
                message="This security link has expired (48-hour validity limit). Please review the draft directly from the Postall_V4 dashboard.",
                details=f"Link expired at {token_row['expires_at']}.",
                server_base_url=server_base_url
            )
    except Exception as exc:
        log("WARNING", "MAGIC_LINK", f"Expiration parse error: {exc}")

    did = token_row["draft_id"]
    draft_row = db.execute(
        "SELECT d.*, t.title topic_name, c.name course_name FROM drafts d "
        "LEFT JOIN topics t ON t.id=d.topic_id LEFT JOIN courses c ON c.id=d.course_id WHERE d.id=?",
        (did,)
    ).fetchone()

    if not draft_row:
        db.close()
        return render_magic_link_response(
            success=False,
            title="Draft Not Found",
            message=f"The draft #{did} associated with this action token could not be found.",
            details="Draft was deleted or migrated.",
            server_base_url=server_base_url
        )

    tz = configured_timezone()
    draft_info = {
        "id": did,
        "topic_name": draft_row["topic_name"] or draft_row["prompt"],
        "course_name": draft_row["course_name"] or "On-Demand",
        "prompt": draft_row["prompt"]
    }

    if decision == "approve":
        slot_dt = find_next_available_schedule_slot(db, exclude_draft_id=did)
        slot_iso = slot_dt.isoformat()
        slot_display = local_datetime_label(slot_iso, tz)
        draft_info["scheduled_display"] = slot_display

        db.execute(
            "UPDATE drafts SET status='APPROVED', scheduled_at=?, approved_at=CURRENT_TIMESTAMP WHERE id=?",
            (slot_iso, did)
        )
        db.execute("UPDATE action_tokens SET used_at=CURRENT_TIMESTAMP WHERE id=?", (token_row["id"],))
        db.commit()
        db.close()
        log("INFO", "MAGIC_LINK", f"Draft #{did} approved via magic link. Scheduled for {slot_display}")
        return render_magic_link_response(
            success=True,
            title="Decision Recorded: Post Approved & Scheduled",
            message=f"Draft #{did} has been approved and successfully queued for automated publication.",
            details=f"Publication scheduled for: {slot_display}",
            draft_info=draft_info,
            server_base_url=server_base_url
        )
    else:
        db.execute(
            "UPDATE drafts SET status='REJECTED', rejected_reason='Rejected via Magic Link' WHERE id=?",
            (did,)
        )
        db.execute("UPDATE action_tokens SET used_at=CURRENT_TIMESTAMP WHERE id=?", (token_row["id"],))
        db.commit()
        db.close()
        log("INFO", "MAGIC_LINK", f"Draft #{did} rejected via magic link.")
        return render_magic_link_response(
            success=True,
            title="Decision Recorded: Post Rejected",
            message=f"Draft #{did} was marked as rejected and removed from the active publishing queue.",
            details="Status changed to REJECTED. You can review or edit this draft at any time from the dashboard.",
            draft_info=draft_info,
            server_base_url=server_base_url
        )


class SyllabusTextParser(HTMLParser):
    skipped={"script","style","svg","nav","footer","header","noscript","form"}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip_depth=0
        self.parts=[]
    def handle_starttag(self, tag, attrs):
        if tag in self.skipped:
            self.skip_depth += 1
    def handle_endtag(self, tag):
        if tag in self.skipped and self.skip_depth:
            self.skip_depth -= 1
    def handle_data(self, data):
        if not self.skip_depth:
            text=" ".join(data.split())
            if text:
                self.parts.append(text)

def validate_syllabus_url(url):
    parsed=urlparse((url or "").strip())
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password
            or parsed.port not in (None,443) or parsed.hostname.lower().endswith((".local",".internal",".localhost"))):
        raise HTTPException(400,"Official syllabus source must be a public HTTPS URL.")
    try:
        addresses={item[4][0] for item in socket.getaddrinfo(parsed.hostname,None)}
    except socket.gaierror as exc:
        raise HTTPException(502,"The discovered syllabus host could not be resolved.") from exc
    if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
        raise HTTPException(400,"The syllabus source must resolve only to public internet addresses.")
    return urlunparse(parsed._replace(fragment=""))

def grounded_source_match(candidate, grounded_urls):
    parsed_candidate=urlparse(candidate)
    candidate_key=(parsed_candidate.hostname or "").lower(),parsed_candidate.path.rstrip("/")
    for grounded in grounded_urls:
        parsed_grounded=urlparse(grounded)
        grounded_key=(parsed_grounded.hostname or "").lower(),parsed_grounded.path.rstrip("/")
        if candidate_key == grounded_key and parsed_candidate.scheme == parsed_grounded.scheme == "https":
            return grounded
    return None

def discover_official_syllabus_url(course):
    gemini_enabled,_=ai_engine_settings()
    if not gemini_enabled:
        log("WARNING","AI_ROUTER",f"Gemini is disabled; cannot search the web for an official syllabus for {course}")
        raise HTTPException(503,"Gemini API is disabled. Official syllabus discovery requires Gemini web search; enable Gemini or provide the course's official HTTPS URL.")
    keys=gemini_api_keys()
    if not keys:
        log("ERROR","AI_ROUTER",f"No Gemini API keys configured; cannot discover official syllabus for {course}")
        raise HTTPException(503,"Gemini API key is not configured; official syllabus discovery requires Gemini web search.")
    models=gemini_models()
    if not models:
        raise HTTPException(503,"No Gemini models are configured. Set GEMINI_MODELS or GEMINI_MODEL and retry.")
    prompt=f"""Find the current, official syllabus, exam outline, or certification blueprint for the course/certification named "{course}".
Use Google Search. Identify the issuing organization and choose its own official website page (not a training vendor, blog, forum, or study-note page).
Return ONLY the exact HTTPS URL of that official page, copied from a Google Search result. If the name is ambiguous, use the best-known certification meaning and choose the issuing organization's official site. If you cannot find an official source, return NONE."""
    log("INFO","AI_ROUTER",f"Using Gemini Google Search grounding to discover official syllabus for {course}")
    quota_exhausted=False
    search_returned_response=False
    try:
        from google import genai
        from google.genai.errors import ClientError
        for model in models:
            all_keys_quota_exhausted=True
            for key in keys:
                client=None
                try:
                    client=genai.Client(api_key=key)
                    try:
                        response=client.models.generate_content(
                            model=model,
                            contents=prompt,
                            config=genai.types.GenerateContentConfig(
                                tools=[genai.types.Tool(google_search=genai.types.GoogleSearch())]
                            ),
                        )
                        all_keys_quota_exhausted=False
                        record_ai_usage(model,response)
                        text=getattr(response,"text",None) or ""
                        search_returned_response=True
                        grounded_urls=[]
                        for candidate in getattr(response,"candidates",[]) or []:
                            metadata=getattr(candidate,"grounding_metadata",None)
                            for chunk in getattr(metadata,"grounding_chunks",[]) or []:
                                web=getattr(chunk,"web",None)
                                uri=getattr(web,"uri",None)
                                if uri:
                                    grounded_urls.append(uri)
                        urls=re.findall(r"https://[^\s<>\"')\]]+",text)
                        for url in urls:
                            matched=grounded_source_match(url.rstrip(".,;"),grounded_urls)
                            if matched:
                                log("INFO","SYLLABUS",f"Gemini found official syllabus for {course}: {urlparse(matched).hostname}")
                                return validate_syllabus_url(matched)
                        if text.strip().upper() == "NONE":
                            break
                        log("WARNING","SYLLABUS",f"Gemini {model} did not return a URL matching its grounded search sources")
                    except ClientError as exc:
                        if gemini_not_found_error(exc):
                            log("WARNING","SYLLABUS",f"Gemini {model} returned 404 NOT_FOUND; moving to next model...")
                            break
                        if gemini_quota_error(exc):
                            quota_exhausted=True
                            log("WARNING","SYLLABUS",f"Gemini key quota exhausted on {model} (429); rotating key...")
                        else:
                            all_keys_quota_exhausted=False
                        log("WARNING","SYLLABUS",f"Official source search via {model} failed ({type(exc).__name__}: {str(exc)[:180]})")
                    except Exception as exc:
                        all_keys_quota_exhausted=False
                        log("WARNING","SYLLABUS",f"Official source search via {model} failed ({type(exc).__name__}: {str(exc)[:180]})")
                except Exception as exc:
                    all_keys_quota_exhausted=False
                    log("WARNING","SYLLABUS",f"Gemini client failed ({type(exc).__name__}: {str(exc)[:180]})")
                finally:
                    if client:
                        client.close()
            if all_keys_quota_exhausted:
                log("WARNING","SYLLABUS",f"Gemini quota exhausted for all configured keys on {model}; trying fallback models")
    except HTTPException:
        raise
    except Exception as exc:
        log("ERROR","SYLLABUS",f"Gemini web search unavailable ({type(exc).__name__}: {str(exc)[:180]})")
        raise HTTPException(502,"Gemini web search could not discover the official syllabus. Check API access and retry.") from exc
    if quota_exhausted and not search_returned_response:
        raise HTTPException(429,"Gemini quota is exhausted across all configured keys.")
    raise HTTPException(404,f"Could not find an official syllabus source for '{course}'. Check the course name or retry after Gemini search is available.")

def resolve_syllabus_url(course, supplied_url=""):
    if supplied_url:
        return validate_syllabus_url(supplied_url)
    return discover_official_syllabus_url(course)

def fetch_official_syllabus(course, supplied_url=""):
    source_url=resolve_syllabus_url(course,supplied_url)
    current_url=source_url
    response=None
    for _ in range(6):
        parsed=urlparse(current_url)
        current_url=validate_syllabus_url(current_url)
        parsed=urlparse(current_url)
        try:
            response=requests.get(current_url,headers={"User-Agent":"Postall_V4-V4 syllabus reader/1.0"},timeout=20,allow_redirects=False,stream=True)
        except requests.RequestException as exc:
            raise HTTPException(502,f"Could not retrieve official syllabus source ({type(exc).__name__}).") from exc
        if response.is_redirect or response.is_permanent_redirect:
            location=response.headers.get("Location")
            response.close()
            if not location:
                raise HTTPException(502,"Official syllabus source returned a redirect without a destination.")
            from urllib.parse import urljoin
            current_url=urljoin(current_url,location)
            continue
        break
    else:
        raise HTTPException(502,"Official syllabus source redirected too many times.")
    try:
        response.raise_for_status()
        content_type=response.headers.get("Content-Type","").lower()
        if "html" not in content_type:
            raise HTTPException(502,"Official syllabus source did not return an HTML page.")
        chunks=[]; size=0
        for chunk in response.iter_content(65536):
            size+=len(chunk)
            if size>4*1024*1024:
                raise HTTPException(502,"Official syllabus source is larger than the supported download limit.")
            chunks.append(chunk)
        response.encoding=response.encoding or "utf-8"
        page=b"".join(chunks).decode(response.encoding,errors="replace")
    except requests.RequestException as exc:
        raise HTTPException(502,f"Could not read official syllabus source ({type(exc).__name__}).") from exc
    finally:
        response.close()
    parser=SyllabusTextParser()
    parser.feed(page)
    syllabus_text=re.sub(r"\s+"," "," ".join(parser.parts)).strip()
    if len(syllabus_text)<500:
        raise HTTPException(502,"The official page did not expose enough syllabus text to build a reliable outline.")
    return current_url,syllabus_text[:30000]

async def ai_topics(course, source_url, syllabus_text):
    prompt=f"""Build a study syllabus outline for the certification/course "{course}" using ONLY the official source text below.
Source URL: {source_url}
Return ONLY a valid JSON array of 3-15 objects. Each object must have:
- "title": a concise syllabus domain or objective title
- "details": a faithful summary of the exam objectives/content in that domain, retaining important named skills and concepts
Do not invent domains, percentages, or objectives absent from the source. Do not create generic LinkedIn topics.
Official source text:
{syllabus_text}"""
    try:
        text=await execute_task("heavy",prompt)
    except RuntimeError as exc:
        log("ERROR","SYLLABUS",f"Could not generate outline using Gemini/Local LLM ({type(exc).__name__})")
        raise HTTPException(502,f"Official syllabus was retrieved, but no enabled AI engine could produce the outline: {exc}") from exc
    try:
        match=re.search(r"\[.*\]",text,re.S)
        values=json.loads(match.group(0)) if match else None
        if not isinstance(values,list):
            raise ValueError("AI response did not contain a JSON list")
        normalized=[]
        for item in values:
            if isinstance(item,dict) and str(item.get("title","")).strip() and str(item.get("details","")).strip():
                normalized.append({"title":str(item["title"]).strip()[:240],"details":str(item["details"]).strip()[:3000]})
        if not 3<=len(normalized)<=15:
            raise ValueError("AI response did not contain 3-15 complete syllabus domains")
        return normalized
    except (ValueError,TypeError,json.JSONDecodeError) as exc:
        raise HTTPException(502,"AI returned an invalid syllabus outline. Retry the official-source population.") from exc

def visual_text(value, limit=300):
    text=html.unescape(str(value or ""))
    for _ in range(2):
        if not any(marker in text for marker in ("Ã¢", "â€™", "â€œ", "â€“", "Ã©")):
            break
        try:
            text=text.encode("cp1252").decode("utf-8")
        except (UnicodeEncodeError,UnicodeDecodeError):
            pass
    text=re.sub(r"(?m)^\s{0,3}#{1,6}\s*","",text)
    text=re.sub(r"\*\*(.*?)\*\*|__(.*?)__|~~(.*?)~~|`([^`]*)`|(?<!\*)\*([^*]+)\*(?!\*)",
                lambda match: next((group for group in match.groups() if group is not None),""),text)
    text=re.sub(r"!\[([^\]]*)\]\([^)]*\)",r"\1",text)
    text=re.sub(r"\[([^\]]+)\]\([^)]*\)",r"\1",text)
    text=re.sub(r"(?m)^\s*[-*+]\s+","",text)
    text=re.sub(r"\s+"," ",text).strip()
    if len(text)>limit:
        shortened=text[:limit-1].rsplit(" ",1)[0]
        text=(shortened or text[:limit-1])+"…"
    return text

def infographic_fallback(topic_name, body):
    source_lines=[visual_text(line,240) for line in body.splitlines() if visual_text(line,240)]
    sentences=[visual_text(sentence,280) for sentence in re.split(r"(?<=[.!?])\s+"," ".join(source_lines)) if visual_text(sentence,280)]
    claims=source_lines[1:] or sentences[1:] or source_lines
    summary=" ".join(sentences[:2]) or f"Technical overview of {visual_text(topic_name,140)}."
    cards=[{"title":visual_text(claim,70),"desc":visual_text(claim,220)} for claim in claims[:2]]
    if not cards:
        cards=[{"title":visual_text(topic_name,70),"desc":summary}]
    mechanics=[{"label":f"Step {index+1}","detail":visual_text(claim,220),"type":"flow"} for index,claim in enumerate(claims[2:5])]
    if not mechanics:
        mechanics=[{"label":"Core mechanic","detail":summary,"type":"card"}]
    points=[{"title":visual_text(claim,70),"desc":visual_text(claim,220)} for claim in claims[5:8]]
    if not points:
        points=[{"title":"Operational focus","desc":summary}]
    return {
        "title":visual_text(topic_name,100) or "Technical Brief",
        "subtitle":visual_text(sentences[0],180) if sentences else "A focused technical reference",
        "badges":["TECHNICAL BRIEF",visual_text(topic_name,32).upper()],
        "section1":{"heading":"1. WHAT IT IS","description":summary,"cards":cards},
        "section2":{"heading":"2. WHAT IT DOES — CORE MECHANICS","items":mechanics},
        "section3":{"heading":"3. WHY IT IS REQUIRED — OPERATIONAL DRIVERS","points":points},
        "footer_note":"Reference Architecture • Technical Quick-Guide",
    }

def normalize_infographic_content(content: dict, topic_name: str = "", body: str = "") -> dict:
    if not isinstance(content, dict):
        content = {}
    headline = visual_text(content.get("headline") or content.get("title") or topic_name or "Technical Architecture Brief", 80)
    subtitle = visual_text(content.get("subtitle") or "End-to-End Technical Workflow & System Mechanics", 140)
    
    # Layout type classification & detection
    layout_type = str(content.get("layout_type") or content.get("diagram_type") or "").lower().strip()
    if layout_type not in {"cheat_sheet", "comparison", "problem_solution", "process_timeline"}:
        t_low = (topic_name + " " + body[:200]).lower()
        if " vs " in t_low or "versus" in t_low or "difference" in t_low or "comparison" in t_low:
            layout_type = "comparison"
        elif "problem" in t_low or "challenge" in t_low or "issue" in t_low or "troubleshoot" in t_low or "fix" in t_low:
            layout_type = "problem_solution"
        elif "timeline" in t_low or "lifecycle" in t_low or "pipeline" in t_low or "flow" in t_low or "phase" in t_low:
            layout_type = "process_timeline"
        else:
            layout_type = "cheat_sheet"

    # Badges
    raw_badge = content.get("badge") or content.get("badges") or content.get("category_badge")
    badges = []
    if isinstance(raw_badge, list):
        badges = [visual_text(b, 24).upper() for b in raw_badge if visual_text(b, 24)]
    elif isinstance(raw_badge, str) and raw_badge.strip():
        badges = [visual_text(b, 24).upper() for b in raw_badge.split("/") if visual_text(b, 24)]
    if not badges:
        badges = [layout_type.replace("_", " ").upper(), "ARCHITECTURE"]

    # 1. Cheat Sheet (2x2 Grid with neon badges, titles, and 3 concise 3-5 word bullets)
    raw_cards = content.get("cards")
    cards = []
    if isinstance(raw_cards, list) and len(raw_cards) > 0:
        for idx, c in enumerate(raw_cards[:4]):
            if isinstance(c, dict):
                c_badge = visual_text(c.get("badge") or f"PILLAR 0{idx+1}", 18)
                c_title = visual_text(c.get("title") or f"Component 0{idx+1}", 26)
                raw_b = c.get("bullets") or c.get("points") or []
                c_bullets = [visual_text(b, 110) for b in raw_b[:3]] if isinstance(raw_b, list) else []
                cards.append({"badge": c_badge, "title": c_title, "bullets": c_bullets})
    if len(cards) < 4:
        topic = clamp_layout_text(topic_name or "Core Concept", 42, "Core Concept")
        topic_cards = [
            {"badge": "OVERVIEW", "title": "Overview", "bullets": [f"Key principles of {topic[:25]}", "Foundational architecture breakdown"]},
            {"badge": "ARCHITECTURE", "title": "Architecture", "bullets": ["Core functional building blocks", "Component integration & state flow"]},
            {"badge": "EXECUTION", "title": "Execution", "bullets": ["Standard operational mechanics", "Deployment & performance considerations"]},
            {"badge": "SUMMARY", "title": "Summary", "bullets": ["Primary strategic takeaways", "Recommended production runbook"]}
        ]
        while len(cards) < 4:
            cards.append(topic_cards[len(cards)])

    # 2. Comparison (Left Tool A / Old vs Right Tool B / New)
    left_col = content.get("left_col") or {}
    right_col = content.get("right_col") or {}
    if not isinstance(left_col, dict) or not left_col.get("points"):
        left_col = {
            "title": visual_text(left_col.get("title") if isinstance(left_col, dict) else "" or "Legacy / The Old Way", 26),
            "points": [
                "Monolithic shared database locks",
                "Manual scaling during traffic spikes",
                "Coupled tight service dependencies",
                "Single point of cascade failure"
            ]
        }
    if not isinstance(right_col, dict) or not right_col.get("points"):
        right_col = {
            "title": visual_text(right_col.get("title") if isinstance(right_col, dict) else "" or "Modern / The New Way", 26),
            "points": [
                "Decoupled event-driven bus",
                "Autonomous horizontal scaling",
                "Zero-trust isolated service enclaves",
                "High-availability active-active mesh"
            ]
        }

    # 3. Problem -> Solution
    challenge = content.get("challenge") or content.get("problem") or {}
    solution = content.get("solution") or {}
    if not isinstance(challenge, dict) or not challenge.get("points"):
        challenge = {
            "badge": visual_text(challenge.get("badge") if isinstance(challenge, dict) else "" or "THE CHALLENGE / BOTTLENECK", 28),
            "title": visual_text(challenge.get("title") if isinstance(challenge, dict) else "" or "High Latency & Monolithic Lock Contention", 38),
            "points": [
                "Cascading connection timeouts during traffic spikes",
                "Blocking database schema migrations with downtime",
                "Unbounded memory consumption in stateful nodes"
            ]
        }
    if not isinstance(solution, dict) or not solution.get("points"):
        solution = {
            "badge": visual_text(solution.get("badge") if isinstance(solution, dict) else "" or "THE ENGINEERED SOLUTION", 28),
            "title": visual_text(solution.get("title") if isinstance(solution, dict) else "" or "Asynchronous Event Mesh & Read Replicas", 38),
            "points": [
                "Decoupled pub/sub event stream absorbs spikes",
                "Distributed read replicas with zero-downtime updates",
                "Stateless micro-workers with automated scale-out"
            ]
        }

    # 4. Process Timeline (4 numbered circles connected by a vertical line)
    raw_steps = content.get("steps")
    steps = []
    if isinstance(raw_steps, list) and len(raw_steps) > 0:
        for idx, s in enumerate(raw_steps[:4]):
            if isinstance(s, dict):
                st_num = str(s.get("step") or f"0{idx+1}")[-2:]
                st_title = visual_text(s.get("title") or f"Stage {idx+1}", 28)
                st_desc = visual_text(s.get("desc") or s.get("detail") or "Standard operation lifecycle.", 50)
                st_badge = visual_text(s.get("badge") or f"STEP 0{idx+1}", 16)
                steps.append({"step": st_num, "title": st_title, "desc": st_desc, "badge": st_badge})
    if len(steps) < 4:
        default_steps = [
            {"step": "01", "badge": "OVERVIEW", "title": "Foundations", "desc": "Identify the key concepts and intended outcomes."},
            {"step": "02", "badge": "DESIGN", "title": "Architecture", "desc": "Map components, dependencies, and data flow."},
            {"step": "03", "badge": "EXECUTION", "title": "Implementation", "desc": "Apply the design through practical operating steps."},
            {"step": "04", "badge": "REVIEW", "title": "Validation", "desc": "Measure results and capture production learnings."}
        ]
        while len(steps) < 4:
            steps.append(default_steps[len(steps)])

    # Key Takeaways
    raw_takeaways = content.get("key_takeaways")
    takeaways = []
    if isinstance(raw_takeaways, list):
        takeaways = [visual_text(t, 100) for t in raw_takeaways if visual_text(t, 100)][:3]
    if len(takeaways) < 3:
        takeaways = [
            "Zero-latency TLS termination with hardware offload",
            "End-to-end cryptographic posture and mTLS mesh dispatch",
            "Continuous audit compliance with automated telemetry verification"
        ]

    # Backward compatibility with HTML/legacy sections
    section1 = {
        "heading": "1. WHAT IT IS",
        "description": subtitle,
        "cards": [
            {"title": cards[0]["title"], "desc": " · ".join(cards[0]["bullets"])},
            {"title": cards[1]["title"], "desc": " · ".join(cards[1]["bullets"])}
        ]
    }
    section2 = {
        "heading": "2. WHAT IT DOES — CORE MECHANICS",
        "items": [
            {"label": f"{s['step']}. {s['title']}", "detail": s["desc"], "type": "flow"}
            for s in steps
        ]
    }
    section3 = {
        "heading": "3. KEY ARCHITECTURAL TAKEAWAYS",
        "points": [
            {"title": f"Takeaway 0{idx+1}", "desc": t}
            for idx, t in enumerate(takeaways)
        ]
    }

    result = {
        "layout_type": layout_type,
        "diagram_type": layout_type,
        "title": headline,
        "headline": headline,
        "subtitle": subtitle,
        "badge": badges[0] if badges else "ARCHITECTURE",
        "badges": badges,
        "category_badge": badges[0] if badges else "ARCHITECTURE",
        "cards": cards,
        "left_col": left_col,
        "right_col": right_col,
        "challenge": challenge,
        "solution": solution,
        "steps": steps,
        "key_takeaways": takeaways,
        "section1": section1,
        "section2": section2,
        "section3": section3,
        "footer_note": visual_text(content.get("footer_note") or "Postall_V4 · Technical Quick-Guide", 100)
    }
    return clamp_infographic_layout(result)


def clamp_layout_text(value: Any, max_chars: int = 110, fallback: str = "") -> str:
    text = html.unescape(str(value or fallback)).replace("\r", " ").replace("\n", " ")
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > max_chars:
        text = text[:max_chars].rstrip()
    return text or fallback


def clamp_infographic_layout(content: dict) -> dict:
    if not isinstance(content, dict):
        return {}
    headline = clamp_layout_text(content.get("headline") or content.get("title") or "Technical Brief", 42, "Technical Brief")
    cards = []
    for item in (content.get("cards") or [])[:4]:
        if not isinstance(item, dict):
            continue
        badge = clamp_layout_text(item.get("badge") or "NODE", 28, "NODE")
        title = clamp_layout_text(item.get("title") or "Component", 28, "Component")
        bullets = []
        for bullet in (item.get("bullets") or item.get("points") or [])[:4]:
            b = clamp_layout_text(bullet, 110, "Technical detail")
            if b:
                bullets.append(b)
        if not bullets:
            bullets = ["Technical detail"]
        cards.append({"badge": badge, "title": title, "bullets": bullets[:4]})
    if not cards:
        cards = [{"badge": "NODE", "title": "Overview", "bullets": ["Technical detail"]}]

    steps = []
    for item in (content.get("steps") or [])[:4]:
        if not isinstance(item, dict):
            continue
        steps.append({
            "step": str(item.get("step") or "01")[:2],
            "badge": clamp_layout_text(item.get("badge") or "STEP", 28, "STEP"),
            "title": clamp_layout_text(item.get("title") or "Step", 28, "Step"),
            "desc": clamp_layout_text(item.get("desc") or item.get("detail") or "Technical detail", 110, "Technical detail")
        })
    if len(steps) < 1:
        steps = [{"step": "01", "badge": "STEP", "title": "Overview", "desc": "Technical detail"}]

    if isinstance(content.get("challenge"), dict):
        challenge = content["challenge"]
        challenge["badge"] = clamp_layout_text(challenge.get("badge") or "CHALLENGE", 28, "CHALLENGE")
        challenge["title"] = clamp_layout_text(challenge.get("title") or "Challenge", 28, "Challenge")
        challenge["points"] = [clamp_layout_text(p, 110, "Technical detail") for p in (challenge.get("points") or [])[:4]]
    else:
        challenge = content.get("challenge") or {}

    if isinstance(content.get("solution"), dict):
        solution = content["solution"]
        solution["badge"] = clamp_layout_text(solution.get("badge") or "SOLUTION", 28, "SOLUTION")
        solution["title"] = clamp_layout_text(solution.get("title") or "Solution", 28, "Solution")
        solution["points"] = [clamp_layout_text(p, 110, "Technical detail") for p in (solution.get("points") or [])[:4]]
    else:
        solution = content.get("solution") or {}

    result = dict(content)
    result["headline"] = headline
    result["title"] = headline
    result["cards"] = cards[:4]
    result["steps"] = steps[:4]
    if isinstance(result.get("challenge"), dict):
        result["challenge"] = challenge
    if isinstance(result.get("solution"), dict):
        result["solution"] = solution
    result["footer_note"] = clamp_layout_text(result.get("footer_note") or "Postall_V4 • Technical Quick-Guide", 110)
    return result


async def extract_diagram_with_local_llm(topic_name: str, body: str) -> dict:
    """Uses the Postall_V4 AI local model to parse visual layout JSON without cloud tokens."""
    prompt = (
        "You are a technical diagram designer. You must output ONLY raw, valid JSON. "
        "Do not wrap it in markdown ```json blocks. Do not add conversational text. "
        "The layout must contain at most 4 items and no extra text. "
        "Hard caps: headline <= 42 chars, node labels <= 28 chars, node body text <= 110 chars. "
        "No markdown fences, no nested markdown, no HTML tags, no conversational filler, and no trailing explanation after the JSON object.\n"
        f"Topic: '{topic_name}'.\n"
        "JSON schema example:\n"
        "{\"layout_type\":\"cheat_sheet\",\"headline\":\"Design Overview\",\"cards\":[{\"badge\":\"NODE 1\",\"title\":\"Overview\",\"bullets\":[\"Foundational concepts\",\"Core principles\"]},{\"badge\":\"NODE 2\",\"title\":\"Execution\",\"bullets\":[\"Operational mechanics\",\"Production outcomes\"]}]}\n"
        f"Post preview:\n{body[:1200]}"
    )
    try:
        raw = await run_local_task(prompt, max_tokens=350)
        match = re.search(r"\{.*\}", raw, re.S)
        if match:
            parsed = json.loads(match.group(0))
            if has_usable_infographic_schema(parsed):
                log("INFO", "GENERATOR", f"Postall_V4 AI successfully extracted visual diagram for '{topic_name}' (0 Gemini tokens)")
                return normalize_infographic_content(parsed, topic_name, body)
    except Exception as exc:
        log("WARNING", "GENERATOR", f"Postall_V4 AI diagram extraction failed ({exc}); using topic-aware fallback.")
    return dynamic_infographic_fallback(topic_name, body)


def has_usable_infographic_schema(content: Any) -> bool:
    if not isinstance(content, dict):
        return False
    cards = content.get("cards")
    if isinstance(cards, list) and any(
        isinstance(card, dict)
        and isinstance(card.get("title"), str)
        and card["title"].strip()
        and isinstance(card.get("bullets", card.get("points")), list)
        and any(isinstance(bullet, str) and bullet.strip() for bullet in card.get("bullets", card.get("points")))
        for card in cards
    ):
        return True
    steps = content.get("steps")
    if isinstance(steps, list) and any(
        isinstance(step, dict)
        and isinstance(step.get("title"), str)
        and step["title"].strip()
        and isinstance(step.get("desc", step.get("detail")), str)
        and step.get("desc", step.get("detail")).strip()
        for step in steps
    ):
        return True
    for side in ("left_col", "right_col"):
        section = content.get(side)
        if not isinstance(section, dict) or not isinstance(section.get("points"), list) or not section["points"]:
            break
    else:
        if all(isinstance(content.get(side, {}).get("points"), list) for side in ("left_col", "right_col")):
            return True
    challenge, solution = content.get("challenge"), content.get("solution")
    return (
        isinstance(challenge, dict)
        and isinstance(challenge.get("points"), list)
        and bool(challenge["points"])
        and isinstance(solution, dict)
        and isinstance(solution.get("points"), list)
        and bool(solution["points"])
    )


def dynamic_infographic_fallback(topic_title: str, body: str = "") -> dict:
    """Builds a topic-titled cheat sheet when generated infographic JSON is unusable."""
    clean_topic = clamp_layout_text(topic_title, 42, "Core Concept")
    fallback_json = {
        "layout": "cheat_sheet",
        "title": clean_topic,
        "nodes": [
            {"label": "Overview", "body": [f"Key principles of {clean_topic[:25]}", "Foundational architecture breakdown"]},
            {"label": "Architecture", "body": ["Core functional building blocks", "Component integration & state flow"]},
            {"label": "Execution", "body": ["Standard operational mechanics", "Deployment & performance considerations"]},
            {"label": "Summary", "body": ["Primary strategic takeaways", "Recommended production runbook"]}
        ]
    }
    fallback_content = {
        "layout_type": fallback_json["layout"],
        "headline": fallback_json["title"],
        "cards": [
            {"badge": node["label"].upper(), "title": node["label"], "bullets": node["body"]}
            for node in fallback_json["nodes"]
        ]
    }
    return normalize_infographic_content(fallback_content, topic_title, body)

async def generate_combined_content(topic_name: str, course_name: str = "", syllabus_details: str = "", on_usage=None, on_event=None) -> dict:
    """Unified single-shot prompt returning post_body and visual diagram JSON in ONE call, tailored by workspace persona."""
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key='workspace_persona'").fetchone()
    db.close()
    active_persona = row["value"] if row and row["value"] else "tech_academy"
    persona_system = get_post_system_prompt(active_persona)
    svg_guidance = get_svg_guidance(active_persona)

    course_context = f"Course context: {course_name}. " if course_name else ""
    syllabus_context = f"Syllabus objectives: {syllabus_details}. " if syllabus_details else ""
    badge_hint = course_name.split()[0].upper() if course_name else "ARCHITECTURE"

    prompt = f"""{persona_system}
{svg_guidance}

{course_context}{syllabus_context}
Topic: {topic_name}.

Generate BOTH a high-performing LinkedIn post AND a compact infographic JSON in ONE SINGLE JSON response.
Hard constraints:
- You must output ONLY raw, valid JSON. Do not wrap in markdown ```json blocks. Do not add conversational text.
- Layout JSON must contain at most 4 items or bullets total.
- headline max 42 characters.
- node labels max 28 characters.
- node body copy max 110 characters.
- No markdown fences, nested markdown, raw HTML, or trailing chatty text after the JSON object.
- Only valid JSON, no prose before or after.
Classify the topic into ONE of these 4 visual layout types based on the persona guidance:
- 'cheat_sheet': up to 4 cards; each card has a badge, a short title, and up to 4 bullet points.
- 'comparison': left/right comparison blocks with concise labels and short points.
- 'problem_solution': challenge and solution sections with short labels and short points.
- 'process_timeline': up to 4 sequential steps with short labels and descriptions.

Return ONLY valid JSON with this schema:
{{
  "post_body": "Detailed technical LinkedIn post with hooks, a concrete mechanism, a practical checklist with 3 actions, one thoughtful question, and 4-6 hashtags.",
  "infographic": {{
    "layout_type": "cheat_sheet",
    "headline": "{topic_name[:42]}",
    "category_badge": "{badge_hint}",
    "cards": [
      {{"badge": "OVERVIEW", "title": "Overview", "bullets": ["Core concepts", "Key principles"]}},
      {{"badge": "ARCHITECTURE", "title": "Architecture", "bullets": ["Main components", "System interactions"]}},
      {{"badge": "EXECUTION", "title": "Execution", "bullets": ["Operating steps", "Expected outcomes"]}},
      {{"badge": "SUMMARY", "title": "Summary", "bullets": ["Key takeaways", "Next actions"]}}
    ],
    "steps": [
      {{"step": "01", "badge": "OVERVIEW", "title": "Overview", "desc": "Foundational concepts and key principles."}},
      {{"step": "02", "badge": "DESIGN", "title": "Architecture", "desc": "Core components and their interactions."}},
      {{"step": "03", "badge": "EXECUTION", "title": "Execution", "desc": "Operational mechanics and implementation."}},
      {{"step": "04", "badge": "SUMMARY", "title": "Summary", "desc": "Outcomes, takeaways, and next steps."}}
    ]
  }}
}}"""
    try:
        raw = await execute_task("heavy", prompt, on_usage=on_usage, on_event=on_event)
        parsed = None
        match = re.search(r"\{.*\}", raw, re.S)
        if match:
            try:
                parsed = json.loads(match.group(0))
            except json.JSONDecodeError:
                decoder = json.JSONDecoder()
                for m in re.finditer(r"\{", raw):
                    try:
                        p, _ = decoder.raw_decode(raw[m.start():])
                        if isinstance(p, dict) and "post_body" in p:
                            parsed = p
                            break
                    except Exception:
                        continue

        if isinstance(parsed, dict) and "post_body" in parsed:
            post_body = str(parsed["post_body"]).strip()
            infographic_data = parsed.get("infographic")
            if not has_usable_infographic_schema(infographic_data):
                log("WARNING", "GENERATOR", f"Infographic JSON missing or malformed for '{topic_name}'; using topic-aware fallback.")
                normalized_infographic = dynamic_infographic_fallback(topic_name, post_body)
            else:
                normalized_infographic = normalize_infographic_content(infographic_data, topic_name, post_body)
            log("INFO", "GENERATOR", f"Single-shot generation succeeded for '{topic_name}' (Conserved 50% tokens)")
            return {"post_body": post_body, "infographic": normalized_infographic}
    except Exception as exc:
        log("WARNING", "GENERATOR", f"Single-shot generation fell back to sequential ({exc})")

    # Fallback to sequential if single-shot failed
    body = await execute_task("heavy", f"Write an engaging technical LinkedIn post about {topic_name}. Return only the post.", on_usage=on_usage, on_event=on_event)
    normalized_infographic = dynamic_infographic_fallback(topic_name, body)
    return {"post_body": body, "infographic": normalized_infographic}

async def infographic_content(topic_name, body, on_usage=None, on_event=None):
    """Backward compatibility wrapper: extracts diagram JSON using local LLM or fallback."""
    return await extract_diagram_with_local_llm(topic_name, body)

def wrap_svg_text(text: str, max_chars: int = 40, max_lines: int = 3) -> list[str]:
    words = str(text or "").split()
    if not words: return []
    lines = []
    curr = []
    curr_len = 0
    for w in words:
        if curr_len + len(w) + (1 if curr else 0) <= max_chars:
            curr.append(w)
            curr_len += len(w) + (1 if len(curr) > 1 else 0)
        else:
            if curr: lines.append(" ".join(curr))
            curr = [w]
            curr_len = len(w)
            if len(lines) >= max_lines: break
    if curr and len(lines) < max_lines:
        lines.append(" ".join(curr))
    return lines

def render_svg_lines(x: int, y: int, lines: list[str], line_height: int, fill: str, font_size: int, font_weight: str = "normal", text_anchor: str = "start") -> str:
    anchor_attr = f' text-anchor="{text_anchor}"' if text_anchor != "start" else ""
    return "\n".join(
        f'<text x="{x}" y="{y + i*line_height}"{anchor_attr} fill="{fill}" font-size="{font_size}" font-weight="{font_weight}" font-family="system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif">{html.escape(line)}</text>'
        for i, line in enumerate(lines)
    )

def build_svg_footer_branding(footer_note: str = "", date_label: str = "") -> str:
    """
    Renders clean, white-labeled footer elements for SVG infographics.
    - If enable_branding == 0 (default): NO tool name or branding is rendered.
    - If enable_branding == 1 and custom_brand_name is non-empty:
      Injects: <text x="60" y="1300" font-family="'Segoe UI', Inter, sans-serif" font-size="16" font-weight="600" fill="#94A3B8">{custom_brand_name} <tspan fill="#64748B" font-weight="400">• {custom_brand_tagline}</tspan></text>
    - Neutral footer note (technical guide / subtitle) and neutral dimension/date tags.
    """
    cfg = get_branding_settings()
    elements = []
    
    clean_note = footer_note.replace("Postall_V4 · ", "").replace("Postall_V4 · ", "").strip()
    if clean_note:
        elements.append(f'<text x="60" y="1275" fill="#64748B" font-size="20" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif">{html.escape(clean_note)}</text>')
        
    date_str = date_label.replace("Postall_V4 · ", "").replace("CAMPAIGN · ", "").strip()
    right_tag = f"{date_str} · 1080×1350" if date_str else "1080×1350"
    elements.append(f'<text x="1020" y="1275" text-anchor="end" fill="#64748B" font-size="20" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif">{html.escape(right_tag)}</text>')
    
    if cfg.get("enable_branding") and cfg.get("custom_brand_name"):
        b_name = html.escape(cfg["custom_brand_name"])
        b_tag = html.escape(cfg.get("custom_brand_tagline") or "")
        tag_span = f' <tspan fill="#64748B" font-weight="400">• {b_tag}</tspan>' if b_tag else ''
        elements.append(f'<text x="60" y="1300" font-family="\'Segoe UI\', Inter, sans-serif" font-size="16" font-weight="600" fill="#94A3B8">{b_name}{tag_span}</text>')
        
    return "\n  ".join(elements)

def render_cheat_sheet_svg(content: dict, created_at: datetime = None) -> str:
    created_at = created_at or datetime.now(timezone.utc)
    title = clamp_layout_text(content.get("headline") or content.get("title") or "Cloud Architecture Cheat Sheet", 42, "Cloud Architecture Cheat Sheet")
    badge = clamp_layout_text(content.get("category_badge") or content.get("badge") or "CHEAT SHEET", 28, "CHEAT SHEET")
    cards = content.get("cards") or []
    footer_note = clamp_layout_text(content.get("footer_note") or "Technical Quick-Guide", 110, "Technical Quick-Guide")
    date_label = created_at.astimezone(configured_timezone()).strftime("%d %b %Y").upper()

    card_coords = [
        (60, 260),   # Top Left
        (550, 260),  # Top Right
        (60, 740),   # Bottom Left
        (550, 740)   # Bottom Right
    ]
    card_w = 470
    card_h = 450
    colors = ["#38BDF8", "#10B981", "#818CF8", "#F59E0B"]

    cards_svg = []
    for idx, (cx, cy) in enumerate(card_coords):
        card = cards[idx] if idx < len(cards) else {}
        c_badge = html.escape(clamp_layout_text(card.get("badge") or f"PILLAR 0{idx+1}", 28, f"PILLAR 0{idx+1}").upper()[:18])
        c_title = clamp_layout_text(card.get("title") or f"Component {idx+1}", 28, f"Component {idx+1}")
        c_bullets = [clamp_layout_text(b, 110, "Technical detail") for b in (card.get("bullets") or ["High availability cluster", "Zero-trust verification", "Automated failover mesh"])][:3]
        col = colors[idx % len(colors)]

        bw = max(140, len(c_badge) * 14 + 30)
        bullets_markup = []
        for b_idx, b_text in enumerate(c_bullets):
            by = cy + 195 + (b_idx * 75)
            bullets_markup.append(f'''
    <!-- Bullet {b_idx+1} -->
    <circle cx="{cx + 36}" cy="{by - 8}" r="8" fill="{col}"/>
    {render_svg_lines(cx + 60, by, wrap_svg_text(b_text, 26, 2), 32, "#E2E8F0", 26)}''')

        cards_svg.append(f'''
    <!-- Card {idx+1} -->
    <rect x="{cx}" y="{cy}" width="{card_w}" height="{card_h}" rx="20" fill="#131C2E" stroke="#25354F" stroke-width="2"/>
    <rect x="{cx}" y="{cy}" width="{card_w}" height="8" rx="4" fill="{col}"/>
    
    <!-- Neon Badge -->
    <rect x="{cx + 28}" y="{cy + 32}" width="{bw}" height="42" rx="10" fill="rgba(56,189,248,0.12)" stroke="{col}" stroke-width="2"/>
    <text x="{cx + 28 + bw//2}" y="{cy + 61}" text-anchor="middle" fill="{col}" font-size="24" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif" letter-spacing="1">{c_badge}</text>
    
    <!-- Card Title -->
    {render_svg_lines(cx + 28, cy + 125, wrap_svg_text(c_title, 22, 2), 38, "#F8FAFC", 32, "bold")}
    <line x1="{cx + 28}" y1="{cy + 155}" x2="{cx + card_w - 28}" y2="{cy + 155}" stroke="#25354F" stroke-width="1.5"/>
    {"".join(bullets_markup)}
        ''')

    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350">
  <defs>
    <radialGradient id="bgGlow" cx="20%" cy="10%" r="60%">
      <stop offset="0%" stop-color="#38BDF8" stop-opacity="0.14"/>
      <stop offset="100%" stop-color="#070A14" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="1080" height="1350" fill="#070A14"/>
  <rect width="1080" height="1350" fill="url(#bgGlow)"/>
  <rect x="30" y="30" width="1020" height="1290" rx="24" fill="#0C1220" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Header -->
  <text x="60" y="90" fill="#38BDF8" font-size="24" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif" letter-spacing="2">VISUAL CHEAT SHEET</text>
  {render_svg_lines(60, 145, wrap_svg_text(title, 36, 2), 48, "#F8FAFC", 44, "bold")}
  
  <rect x="60" y="195" width="220" height="38" rx="8" fill="rgba(16,185,129,0.15)" stroke="#10B981" stroke-width="1.5"/>
  <text x="170" y="222" text-anchor="middle" fill="#6EE7B7" font-size="24" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif" letter-spacing="1">{html.escape(badge.upper())}</text>
  
  <line x1="60" y1="245" x2="1020" y2="245" stroke="#1E293B" stroke-width="2"/>
  
  <!-- 2x2 Grid Cards -->
  {"".join(cards_svg)}
  
  <!-- Footer -->
  <line x1="60" y1="1230" x2="1020" y2="1230" stroke="#1E293B" stroke-width="2"/>
  {build_svg_footer_branding(footer_note, date_label)}
</svg>'''

def render_comparison_svg(content: dict, created_at: datetime = None) -> str:
    created_at = created_at or datetime.now(timezone.utc)
    title = clamp_layout_text(content.get("headline") or content.get("title") or "Architecture Trade-offs & Shift", 42, "Architecture Trade-offs & Shift")
    badge = clamp_layout_text(content.get("category_badge") or content.get("badge") or "VERSUS", 28, "VERSUS")
    left = content.get("left_col") or content.get("left") or {}
    right = content.get("right_col") or content.get("right") or {}
    footer_note = clamp_layout_text(content.get("footer_note") or "Technical Comparison", 110, "Technical Comparison")
    date_label = created_at.astimezone(configured_timezone()).strftime("%d %b %Y").upper()

    left_title = clamp_layout_text(left.get("title") or content.get("left_title") or "The Old Way / Legacy", 28, "The Old Way / Legacy")
    right_title = clamp_layout_text(right.get("title") or content.get("right_title") or "The Modern Way / Scaled Architecture", 28, "The Modern Way / Scaled Architecture")
    left_points = [clamp_layout_text(p, 110, "Technical detail") for p in (left.get("points") or content.get("left_items") or ["Monolithic shared database", "Manual scaling under load", "Coupled service dependencies", "Single point of failure"])][:4]
    right_points = [clamp_layout_text(p, 110, "Technical detail") for p in (right.get("points") or content.get("right_items") or ["Event-driven microservices", "Autonomous horizontal scaling", "Zero-trust isolated enclaves", "High-availability multi-region"])][:4]

    left_points_svg = []
    for i, pt in enumerate(left_points):
        py = 430 + (i * 170)
        left_points_svg.append(f'''
    <!-- Cross Point {i+1} -->
    <circle cx="110" cy="{py}" r="22" fill="rgba(239,68,68,0.2)" stroke="#EF4444" stroke-width="2"/>
    <text x="110" y="{py + 8}" text-anchor="middle" fill="#EF4444" font-size="26" font-weight="bold">✕</text>
    {render_svg_lines(150, py + 8, wrap_svg_text(pt, 22, 3), 34, "#CBD5E1", 26)}
        ''')

    right_points_svg = []
    for i, pt in enumerate(right_points):
        py = 430 + (i * 170)
        right_points_svg.append(f'''
    <!-- Check Point {i+1} -->
    <circle cx="610" cy="{py}" r="22" fill="rgba(16,185,129,0.2)" stroke="#10B981" stroke-width="2"/>
    <text x="610" y="{py + 8}" text-anchor="middle" fill="#10B981" font-size="26" font-weight="bold">✓</text>
    {render_svg_lines(650, py + 8, wrap_svg_text(pt, 22, 3), 34, "#CBD5E1", 26)}
        ''')

    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350">
  <defs>
    <radialGradient id="compGlow" cx="50%" cy="15%" r="70%">
      <stop offset="0%" stop-color="#38BDF8" stop-opacity="0.12"/>
      <stop offset="100%" stop-color="#070A14" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="1080" height="1350" fill="#070A14"/>
  <rect width="1080" height="1350" fill="url(#compGlow)"/>
  <rect x="30" y="30" width="1020" height="1290" rx="24" fill="#0C1220" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Header -->
  <text x="60" y="85" fill="#38BDF8" font-size="24" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif" letter-spacing="2">ARCHITECTURAL COMPARISON</text>
  {render_svg_lines(60, 140, wrap_svg_text(title, 36, 2), 48, "#F8FAFC", 44, "bold")}
  <line x1="60" y1="210" x2="1020" y2="210" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Left Side: Old Way / Legacy -->
  <rect x="60" y="235" width="455" height="970" rx="18" fill="#18131E" stroke="#3A202A" stroke-width="2"/>
  <rect x="60" y="235" width="455" height="8" rx="4" fill="#EF4444"/>
  
  <rect x="90" y="265" width="230" height="42" rx="10" fill="rgba(239,68,68,0.15)" stroke="#EF4444" stroke-width="1.5"/>
  <text x="205" y="294" text-anchor="middle" fill="#FCA5A5" font-size="24" font-weight="bold">OLD APPROACH</text>
  {render_svg_lines(90, 355, wrap_svg_text(left_title, 20, 2), 40, "#F8FAFC", 34, "bold")}
  <line x1="90" y1="385" x2="485" y2="385" stroke="#3A202A" stroke-width="1.5"/>
  {"".join(left_points_svg)}
  
  <!-- Right Side: Modern Way -->
  <rect x="565" y="235" width="455" height="970" rx="18" fill="#0F1F22" stroke="#173E36" stroke-width="2"/>
  <rect x="565" y="235" width="455" height="8" rx="4" fill="#10B981"/>
  
  <rect x="595" y="265" width="230" height="42" rx="10" fill="rgba(16,185,129,0.15)" stroke="#10B981" stroke-width="1.5"/>
  <text x="710" y="294" text-anchor="middle" fill="#6EE7B7" font-size="24" font-weight="bold">MODERN PATTERN</text>
  {render_svg_lines(595, 355, wrap_svg_text(right_title, 20, 2), 40, "#F8FAFC", 34, "bold")}
  <line x1="595" y1="385" x2="990" y2="385" stroke="#173E36" stroke-width="1.5"/>
  {"".join(right_points_svg)}
  
  <!-- Center VS Badge -->
  <circle cx="540" cy="710" r="40" fill="#070A14" stroke="#38BDF8" stroke-width="3"/>
  <text x="540" y="720" text-anchor="middle" fill="#38BDF8" font-size="28" font-weight="bold">VS</text>
  
  <!-- Footer -->
  <line x1="60" y1="1230" x2="1020" y2="1230" stroke="#1E293B" stroke-width="2"/>
  {build_svg_footer_branding(footer_note, date_label)}
</svg>'''

def render_problem_solution_svg(content: dict, created_at: datetime = None) -> str:
    created_at = created_at or datetime.now(timezone.utc)
    title = clamp_layout_text(content.get("headline") or content.get("title") or "Solving System Bottlenecks", 42, "Solving System Bottlenecks")
    challenge = content.get("challenge") or content.get("problem") or {}
    solution = content.get("solution") or {}
    footer_note = clamp_layout_text(content.get("footer_note") or "Problem &amp; Solution Analysis", 110, "Problem &amp; Solution Analysis")
    date_label = created_at.astimezone(configured_timezone()).strftime("%d %b %Y").upper()

    c_title = clamp_layout_text(challenge.get("title") or content.get("problem_title") or "High Latency & Monolithic Lock Contention", 28, "High Latency & Monolithic Lock Contention")
    c_badge = clamp_layout_text(challenge.get("badge") or "THE CHALLENGE / BOTTLENECK", 28, "THE CHALLENGE / BOTTLENECK").upper()
    c_points = [clamp_layout_text(p, 110, "Technical detail") for p in (challenge.get("points") or content.get("problem_bullets") or ["Cascading connection timeouts during traffic spikes", "Blocking database schema migrations with downtime", "Unbounded memory consumption in stateful nodes"])][:3]

    s_title = clamp_layout_text(solution.get("title") or content.get("solution_title") or "Asynchronous Event Mesh & Read Replicas", 28, "Asynchronous Event Mesh & Read Replicas")
    s_badge = clamp_layout_text(solution.get("badge") or "THE ENGINEERED SOLUTION", 28, "THE ENGINEERED SOLUTION").upper()
    s_points = [clamp_layout_text(p, 110, "Technical detail") for p in (solution.get("points") or content.get("solution_bullets") or ["Decoupled pub/sub event stream absorbs spikes", "Distributed read replicas with zero-downtime updates", "Stateless micro-workers with automated scale-out"])][:3]

    challenge_bullets = []
    for i, pt in enumerate(c_points):
        by = 385 + (i * 65)
        challenge_bullets.append(f'''
    <circle cx="105" cy="{by - 8}" r="8" fill="#F43F5E"/>
    {render_svg_lines(130, by, wrap_svg_text(pt, 56, 1), 32, "#E2E8F0", 26)}''')

    solution_bullets = []
    for i, pt in enumerate(s_points):
        by = 880 + (i * 65)
        solution_bullets.append(f'''
    <circle cx="105" cy="{by - 8}" r="8" fill="#10B981"/>
    {render_svg_lines(130, by, wrap_svg_text(pt, 56, 1), 32, "#E2E8F0", 26)}''')

    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350">
  <defs>
    <radialGradient id="psGlow" cx="20%" cy="10%" r="60%">
      <stop offset="0%" stop-color="#F43F5E" stop-opacity="0.12"/>
      <stop offset="100%" stop-color="#070A14" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="1080" height="1350" fill="#070A14"/>
  <rect width="1080" height="1350" fill="url(#psGlow)"/>
  <rect x="30" y="30" width="1020" height="1290" rx="24" fill="#0C1220" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Header -->
  <text x="60" y="85" fill="#F43F5E" font-size="24" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif" letter-spacing="2">PROBLEM &amp; SOLUTION MATRIX</text>
  {render_svg_lines(60, 140, wrap_svg_text(title, 36, 2), 48, "#F8FAFC", 44, "bold")}
  <line x1="60" y1="205" x2="1020" y2="205" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Top Box: Challenge (Red Tinted) -->
  <rect x="60" y="225" width="960" height="390" rx="20" fill="#1E1218" stroke="#5E1D2D" stroke-width="2"/>
  <rect x="60" y="225" width="960" height="8" rx="4" fill="#F43F5E"/>
  
  <rect x="95" y="255" width="340" height="42" rx="10" fill="rgba(244,63,94,0.18)" stroke="#F43F5E" stroke-width="1.5"/>
  <text x="265" y="284" text-anchor="middle" fill="#FDA4AF" font-size="24" font-weight="bold">{html.escape(c_badge)}</text>
  
  {render_svg_lines(95, 335, wrap_svg_text(c_title, 42, 1), 38, "#F8FAFC", 32, "bold")}
  {"".join(challenge_bullets)}
  
  <!-- Center Arrow Transition -->
  <g transform="translate(0, 625)">
    <polygon points="540,85 505,45 525,45 525,5 555,5 555,45 575,45" fill="#38BDF8"/>
    <text x="540" y="-8" text-anchor="middle" fill="#38BDF8" font-size="24" font-weight="bold" letter-spacing="2">ARCHITECTURAL TRANSFORMATION</text>
  </g>
  
  <!-- Bottom Box: Solution (Green Tinted) -->
  <rect x="60" y="725" width="960" height="480" rx="20" fill="#0C201C" stroke="#155E4C" stroke-width="2"/>
  <rect x="60" y="725" width="960" height="8" rx="4" fill="#10B981"/>
  
  <rect x="95" y="755" width="340" height="42" rx="10" fill="rgba(16,185,129,0.18)" stroke="#10B981" stroke-width="1.5"/>
  <text x="265" y="784" text-anchor="middle" fill="#6EE7B7" font-size="24" font-weight="bold">{html.escape(s_badge)}</text>
  
  {render_svg_lines(95, 835, wrap_svg_text(s_title, 42, 1), 38, "#F8FAFC", 32, "bold")}
  {"".join(solution_bullets)}
  
  <!-- Footer -->
  <line x1="60" y1="1230" x2="1020" y2="1230" stroke="#1E293B" stroke-width="2"/>
  {build_svg_footer_branding(footer_note, date_label)}
</svg>'''

def render_process_timeline_svg(content: dict, created_at: datetime = None) -> str:
    created_at = created_at or datetime.now(timezone.utc)
    title = clamp_layout_text(content.get("headline") or content.get("title") or "End-to-End Execution Sequence", 42, "End-to-End Execution Sequence")
    steps = content.get("steps") or []
    footer_note = clamp_layout_text(content.get("footer_note") or "Execution Process Timeline", 110, "Execution Process Timeline")
    date_label = created_at.astimezone(configured_timezone()).strftime("%d %b %Y").upper()

    default_steps = [
        {"step": "01", "badge": "OVERVIEW", "title": "Foundations", "desc": "Identify the key concepts and intended outcomes."},
        {"step": "02", "badge": "DESIGN", "title": "Architecture", "desc": "Map components, dependencies, and data flow."},
        {"step": "03", "badge": "EXECUTION", "title": "Implementation", "desc": "Apply the design through practical operating steps."},
        {"step": "04", "badge": "REVIEW", "title": "Validation", "desc": "Measure results and capture production learnings."}
    ]

    steps_svg = []
    card_y_positions = [240, 480, 720, 960]
    for idx, sy in enumerate(card_y_positions):
        s_data = steps[idx] if idx < len(steps) else default_steps[idx]
        s_num = str(s_data.get("step") or f"0{idx+1}")[-2:]
        s_badge = clamp_layout_text(s_data.get("badge") or f"PHASE 0{idx+1}", 28, f"PHASE 0{idx+1}").upper()[:16]
        s_title = clamp_layout_text(s_data.get("title") or f"Execution Step {idx+1}", 28, f"Execution Step {idx+1}")
        s_desc = clamp_layout_text(s_data.get("desc") or s_data.get("detail") or "Standard operation lifecycle.", 110, "Standard operation lifecycle.")

        steps_svg.append(f'''
    <!-- Step {idx+1} Circle & Card -->
    <circle cx="130" cy="{sy + 85}" r="38" fill="#0C1220" stroke="#38BDF8" stroke-width="4"/>
    <text x="130" y="{sy + 95}" text-anchor="middle" fill="#FFFFFF" font-size="28" font-weight="bold">{s_num}</text>
    
    <rect x="210" y="{sy}" width="810" height="190" rx="16" fill="#131C2E" stroke="#25354F" stroke-width="2"/>
    <rect x="210" y="{sy}" width="6" height="190" rx="3" fill="#38BDF8"/>
    
    <rect x="240" y="{sy + 24}" width="160" height="34" rx="8" fill="rgba(56,189,248,0.14)" stroke="#38BDF8" stroke-width="1.5"/>
    <text x="320" y="{sy + 48}" text-anchor="middle" fill="#38BDF8" font-size="24" font-weight="bold">{html.escape(s_badge)}</text>
    
    {render_svg_lines(240, sy + 105, wrap_svg_text(s_title, 32, 1), 38, "#F8FAFC", 32, "bold")}
    {render_svg_lines(240, sy + 150, wrap_svg_text(s_desc, 44, 1), 30, "#94A3B8", 26)}
        ''')

    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350">
  <defs>
    <radialGradient id="tlGlow" cx="20%" cy="10%" r="60%">
      <stop offset="0%" stop-color="#38BDF8" stop-opacity="0.14"/>
      <stop offset="100%" stop-color="#070A14" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="1080" height="1350" fill="#070A14"/>
  <rect width="1080" height="1350" fill="url(#tlGlow)"/>
  <rect x="30" y="30" width="1020" height="1290" rx="24" fill="#0C1220" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Header -->
  <text x="60" y="85" fill="#38BDF8" font-size="24" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif" letter-spacing="2">PROCESS &amp; LIFECYCLE TIMELINE</text>
  {render_svg_lines(60, 140, wrap_svg_text(title, 36, 2), 48, "#F8FAFC", 44, "bold")}
  <line x1="60" y1="205" x2="1020" y2="205" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Vertical Timeline Line connecting the 4 circles -->
  <line x1="130" y1="325" x2="130" y2="1045" stroke="#38BDF8" stroke-width="6" stroke-linecap="round"/>
  
  <!-- 4 Step Cards -->
  {"".join(steps_svg)}
  
  <!-- Footer -->
  <line x1="60" y1="1230" x2="1020" y2="1230" stroke="#1E293B" stroke-width="2"/>
  {build_svg_footer_branding(footer_note, date_label)}
</svg>'''

def render_hero_banner_svg(promo: dict, created_at: datetime = None) -> str:
    created_at = created_at or datetime.now(timezone.utc)
    branding = get_branding_settings()
    brand_fallback = branding.get("custom_brand_name") if (branding.get("enable_branding") and branding.get("custom_brand_name")) else "FEATURED BRIEFING"
    brand = clamp_layout_text(promo.get("brand_name") or promo.get("brand") or brand_fallback, 28, "FEATURED BRIEFING").upper()
    objective = clamp_layout_text(promo.get("objective") or "EXCLUSIVE LAUNCH", 28, "EXCLUSIVE LAUNCH").upper()
    dates = clamp_layout_text(promo.get("key_dates") or promo.get("dates") or "OCTOBER 15, 2026 · 10:00 AM IST", 110, "OCTOBER 15, 2026 · 10:00 AM IST")
    headline = clamp_layout_text(promo.get("headline") or promo.get("context_hook") or "Master Full-Stack Cloud Automation", 42, "Master Full-Stack Cloud Automation")
    hook = clamp_layout_text(promo.get("context_hook") or "Production-ready enterprise systems architecture.", 110, "Production-ready enterprise systems architecture.")
    date_label = created_at.astimezone(configured_timezone()).strftime("%d %b %Y").upper()

    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350">
  <defs>
    <radialGradient id="heroGlow" cx="50%" cy="30%" r="70%">
      <stop offset="0%" stop-color="#38BDF8" stop-opacity="0.18"/>
      <stop offset="60%" stop-color="#1E1B4B" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="#070A14" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="btnGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#38BDF8"/>
      <stop offset="100%" stop-color="#818CF8"/>
    </linearGradient>
  </defs>
  <rect width="1080" height="1350" fill="#070A14"/>
  <rect width="1080" height="1350" fill="url(#heroGlow)"/>
  <rect x="30" y="30" width="1020" height="1290" rx="24" fill="#0C1220" stroke="#1E293B" stroke-width="2"/>
  
  <!-- Top Brand / Logo Bar -->
  <text x="540" y="100" text-anchor="middle" fill="#38BDF8" font-size="28" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif" letter-spacing="4">{html.escape(brand)}</text>
  
  <!-- Objective Pill -->
  <rect x="390" y="130" width="300" height="42" rx="10" fill="rgba(56,189,248,0.15)" stroke="#38BDF8" stroke-width="1.5"/>
  <text x="540" y="159" text-anchor="middle" fill="#38BDF8" font-size="24" font-weight="bold" letter-spacing="2">{html.escape(objective)}</text>
  
  <!-- Large Centered Headline -->
  {render_svg_lines(540, 270, wrap_svg_text(headline, 28, 3), 64, "#F8FAFC", 52, "bold", "middle")}
  
  <!-- Highlighted Date Banner Card -->
  <rect x="100" y="470" width="880" height="220" rx="22" fill="#131C2E" stroke="#F59E0B" stroke-width="2.5"/>
  
  <!-- Calendar Icon / Badge -->
  <rect x="390" y="505" width="300" height="40" rx="8" fill="rgba(245,158,11,0.18)" stroke="#F59E0B" stroke-width="1.5"/>
  <text x="540" y="533" text-anchor="middle" fill="#FBBF24" font-size="24" font-weight="bold" letter-spacing="2">KEY DATE &amp; DEADLINE</text>
  
  <text x="540" y="615" text-anchor="middle" fill="#F8FAFC" font-size="40" font-weight="bold" font-family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif">{html.escape(dates)}</text>
  <text x="540" y="660" text-anchor="middle" fill="#10B981" font-size="24" font-weight="bold">LIMITED CAPACITY · LIVE SESSION</text>
  
  <!-- Value Proposition Box -->
  <rect x="100" y="730" width="880" height="300" rx="20" fill="#0F172A" stroke="#25354F" stroke-width="2"/>
  <text x="140" y="785" fill="#38BDF8" font-size="26" font-weight="bold" letter-spacing="1">WHAT YOU WILL GAIN:</text>
  {render_svg_lines(140, 840, wrap_svg_text(hook, 52, 4), 44, "#E2E8F0", 28)}
  
  <!-- Call To Action Button -->
  <rect x="240" y="1080" width="600" height="90" rx="45" fill="url(#btnGrad)"/>
  <text x="540" y="1136" text-anchor="middle" fill="#070A14" font-size="30" font-weight="bold" letter-spacing="1">CLAIM YOUR SPOT NOW →</text>
  
  <!-- Footer -->
  <line x1="60" y1="1230" x2="1020" y2="1230" stroke="#1E293B" stroke-width="2"/>
  {build_svg_footer_branding("Marketing &amp; Promo Suite", date_label)}
</svg>'''

def build_infographic_svg(content: dict, created_at: datetime) -> str:
    content = normalize_infographic_content(content)
    layout = content.get("layout_type", "cheat_sheet")
    if layout == "comparison":
        return render_comparison_svg(content, created_at)
    elif layout == "problem_solution":
        return render_problem_solution_svg(content, created_at)
    elif layout == "process_timeline":
        return render_process_timeline_svg(content, created_at)
    else:
        return render_cheat_sheet_svg(content, created_at)

def make_asset(draft_id, body, kind, topic_name, created_at, slug=None, content=None):
    content = content or infographic_fallback(topic_name, body)
    content = normalize_infographic_content(content, topic_name, body)
    folder = post_artifact_dir(topic_name, created_at, slug)
    folder.mkdir(parents=True, exist_ok=True)
    asset_root = ROOT / "data" / "assets"
    asset_root.mkdir(parents=True, exist_ok=True)

    # 1. Build and save pure SVG (1080x1350)
    svg_document = build_infographic_svg(content, created_at)
    (folder / "infographic.svg").write_text(svg_document, encoding="utf-8")
    (asset_root / f"draft-{draft_id}.svg").write_text(svg_document, encoding="utf-8")

    # 2. Build and save HTML and README for backward compatibility
    def esc(value): return html.escape(str(value or ""), quote=True)
    badges = "".join(f'<span class="badge">{esc(badge)}</span>' for badge in content["badges"])
    cards = "".join(f'<article class="content-card"><h3>{esc(card["title"])}</h3><p>{esc(card["desc"])}</p></article>' for card in content["section1"]["cards"])
    mechanics = "".join(f'<article class="content-card mechanic" data-type="{esc(item["type"])}"><span class="eyebrow">{esc(item["label"])}</span><p>{esc(item["detail"])}</p></article>' for item in content["section2"]["items"])
    drivers = "".join(f'<article class="content-card driver"><h3>{esc(point["title"])}</h3><p>{esc(point["desc"])}</p></article>' for point in content["section3"]["points"])
    document = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=1080, initial-scale=1">
<style>
*{{box-sizing:border-box}}html,body{{margin:0;width:1080px;height:1350px;background:#070A14;color:#e2e8f0;font-family:Inter,"Segoe UI",Roboto,Arial,sans-serif}}
body{{background-image:linear-gradient(rgba(148,163,184,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(148,163,184,.035) 1px,transparent 1px),radial-gradient(ellipse at 8% 0%,rgba(56,189,248,.12),transparent 38%);background-size:32px 32px,32px 32px,auto}}
.canvas{{position:relative;margin:30px;width:1020px;height:1290px;padding:44px 48px 36px;overflow:hidden;border:1px solid #1e293b;border-radius:24px;background:rgba(12,18,32,.96);box-shadow:0 24px 80px rgba(0,0,0,.42)}}
header{{height:190px;border-bottom:1px solid #1e293b;padding-bottom:16px}}.brand{{color:#38BDF8;font-size:24px;font-weight:800;letter-spacing:2px;text-transform:uppercase}}h1{{font-size:44px;line-height:1.12;margin:12px 0 7px;color:#f8fafc;overflow-wrap:anywhere}}.subtitle{{font-size:24px;line-height:1.3;color:#94a3b8}}.badges{{display:flex;flex-wrap:wrap;gap:8px;margin-top:9px}}.badge{{border:1px solid rgba(16,185,129,.38);background:rgba(16,185,129,.1);color:#6ee7b7;padding:5px 12px;border-radius:99px;font-size:24px;font-weight:800;letter-spacing:1px}}
main{{padding-top:18px}}.section{{margin:0 0 17px}}.section h2{{margin:0 0 9px;color:#38BDF8;font-size:24px;letter-spacing:1.15px;text-transform:uppercase}}.summary{{padding:12px 15px;margin:0 0 10px;border-left:2px solid #10B981;border-radius:4px 10px 10px 4px;background:#111a29;color:#cbd5e1;font-size:24px;line-height:1.4}}
.grid{{display:grid;gap:12px}}.two{{grid-template-columns:repeat(2,minmax(0,1fr))}}.three{{grid-template-columns:repeat(3,minmax(0,1fr))}}.content-card{{min-width:0;padding:14px 16px;border:1px solid #263244;border-radius:12px;background:rgba(22,31,48,.9);border-top:3px solid #10B981}}.content-card h3{{margin:0 0 6px;color:#f1f5f9;font-size:26px;line-height:1.2}}.content-card p{{margin:0;color:#cbd5e1;font-size:24px;line-height:1.38;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere}}
footer{{position:absolute;left:48px;right:48px;bottom:28px;padding-top:12px;border-top:1px solid #1e293b;color:#64748b;font-size:24px;letter-spacing:1px;text-transform:uppercase;display:flex;justify-content:space-between}}
</style></head><body><div class="canvas">
<header><div class="brand">Postall_V4 · Technical Knowledge Brief</div><h1>{esc(content["title"])}</h1><div class="subtitle">{esc(content["subtitle"])}</div><div class="badges">{badges}</div></header>
<main>
<section class="section"><h2>{esc(content["section1"]["heading"])}</h2><p class="summary">{esc(content["section1"]["description"])}</p><div class="grid two">{cards}</div></section>
<section class="section"><h2>{esc(content["section2"]["heading"])}</h2><div class="grid two">{mechanics}</div></section>
</main><footer><span>{esc(content["footer_note"])}</span><span>Postall_V4 · {created_at.astimezone(configured_timezone()).strftime("%d %b %Y")}</span></footer>
</div></body></html>'''
    (folder / "infographic.html").write_text(document, encoding="utf-8")
    (folder / "README.md").write_text(body + "\n\n---\nGenerated by Postall_V4\n", encoding="utf-8")

    # 3. Convert SVG to PNG using CairoSVG (1080x1350 mobile-optimized)
    image_path = asset_root / f"draft-{draft_id}.png"
    try:
        import cairosvg
        cairosvg.svg2png(bytestring=svg_document.encode("utf-8"), write_to=str(image_path), output_width=1080, output_height=1350)
    except Exception as exc:
        log("ERROR", "ASSETS", f"CairoSVG rendering failed ({type(exc).__name__}: {exc})")
        if not image_path.exists():
            return str((asset_root / f"draft-{draft_id}.svg").relative_to(ROOT))

    if image_path.exists():
        (folder / "infographic.png").write_bytes(image_path.read_bytes())
        try:
            from backend.storage import get_storage_provider
            sp = get_storage_provider()
            rel_path = str(image_path.relative_to(ROOT))
            sp.save_file(rel_path, image_path.read_bytes(), content_type="image/png")
        except Exception as exc:
            logger.debug(f"[STORAGE] Storage sync error: {exc}")
    return str(image_path.relative_to(ROOT))
@app.post("/api/generate")
async def generate(req: GenerateIn, user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    try:
        return await generate_draft(req, user, ws_id=ws_id)
    except RuntimeError as exc:
        raise HTTPException(503,str(exc)) from exc

@app.post("/api/generate/stream")
async def generate_stream(req: GenerateIn, user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    events=asyncio.Queue()
    loop=asyncio.get_running_loop()
    finished=object()
    def report(message,kind="info",**data):
        event={"type":kind,"message":message,**data}
        loop.call_soon_threadsafe(events.put_nowait,event)
    async def run():
        try:
            result=await generate_draft(req, user, report, ws_id=ws_id)
            report("Draft and infographic are ready.","complete",draft_id=result["id"],draft=result)
        except HTTPException as exc:
            report(exc.detail,"error",status_code=exc.status_code)
        except RuntimeError as exc:
            log("ERROR","GENERATOR",f"On-demand generation failed: {str(exc)[:240]}")
            report(str(exc),"error")
        except Exception as exc:
            log("ERROR","GENERATOR",f"On-demand generation failed ({type(exc).__name__}): {str(exc)[:240]}")
            report(f"Generation failed: {type(exc).__name__}. Check System Logs for details.","error")
        finally:
            loop.call_soon_threadsafe(events.put_nowait,finished)
    task=asyncio.create_task(run())
    async def stream():
        waiting_seconds=0
        while True:
            try:
                event=await asyncio.wait_for(events.get(),timeout=5)
            except asyncio.TimeoutError:
                waiting_seconds+=5
                event={"type":"progress","message":f"Generation is still running ({waiting_seconds}s). Waiting for AI response or asset rendering..."}
            if event is finished:
                break
            yield f"data: {json.dumps(event,ensure_ascii=False)}\n\n"
        await task
    return StreamingResponse(stream(),media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

def check_and_apply_brand_safety(post_body: str, initial_status: str = "DRAFT") -> Tuple[str, str, List[str]]:
    """
    Post-Flight Brand Safety Engine:
    Validates generated post content against banned PR keywords and competitor names.
    If violations are detected, forcefully sets status to 'FLAGGED_VIOLATION' and
    prepends a warning header.
    Returns: (final_body, final_status, violations_list)
    """
    if not post_body:
        return post_body, initial_status, []
    try:
        db = get_db()
        settings_rows = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings WHERE key IN ('brand_safety_enabled', 'banned_keywords', 'competitor_names')")}
        db.close()
    except Exception as exc:
        logger.warning("Could not read brand safety settings: %s", exc)
        return post_body, initial_status, []

    bs_enabled = str(settings_rows.get("brand_safety_enabled", "1")).strip().lower() not in {"0", "false", "off", "no", "disabled"}
    if not bs_enabled:
        return post_body, initial_status, []

    banned = settings_rows.get("banned_keywords", "") or ""
    competitors = settings_rows.get("competitor_names", "") or ""

    clean_body = sanitize_violation_header(post_body)
    violations = check_brand_safety(clean_body, banned, competitors)
    if violations:
        violation_str = ", ".join(violations)
        banner = f"[⚠️ BRAND SAFETY VIOLATION DETECTED: Contains terms: {violation_str}] \n\n {clean_body}"
        return banner, "FLAGGED_VIOLATION", violations

    return clean_body, initial_status, []

async def generate_draft(req: GenerateIn, user, progress=None, ws_id: int = 1):
    def report(message, kind="info", **data):
        if progress:
            progress(message, kind, **data)
    media_format = "video" if req.format.lower() in ("video", "motion", "animated") else "infographic"
    report(f"Request accepted: {req.prompt[:120]}")
    db = get_db()
    course = db.execute("SELECT name FROM courses WHERE id=?", (req.course_id,)).fetchone() if req.course_id else None
    topic = db.execute("SELECT title,details FROM topics WHERE id=?", (req.topic_id,)).fetchone() if req.topic_id else None
    db.close()
    course_name = course["name"] if course else ""
    syllabus_details = topic["details"] if topic and topic["details"] else ""
    topic_name = topic["title"] if topic else req.prompt
    course_context = f"Course context: {course_name}. " if course_name else ""
    syllabus_context = f"Syllabus objectives: {syllabus_details}. " if syllabus_details else f"Context: {req.prompt}. "

    usage = {}
    def usage_report(result):
        for key in ("prompt_tokens", "output_tokens", "total_tokens"):
            usage[key] = usage.get(key, 0) + int(result.get(key, 0) or 0)
        usage.update({key: value for key, value in result.items() if key not in {"prompt_tokens", "output_tokens", "total_tokens", "usage_reported"}})
        usage["usage_reported"] = usage.get("usage_reported", False) or result.get("usage_reported", False)
        if usage["usage_reported"]:
            report(f"AI usage so far: {usage['total_tokens']:,} tokens ({usage['prompt_tokens']:,} prompt / {usage['output_tokens']:,} output).", "usage", **usage)
        else:
            report(f"Token usage metadata was not returned by {result.get('model', result.get('engine', 'AI'))}.", "usage", **result)

    # Token Conservation & Single-Shot Strategy
    if req.course_id:
        report("Course module detected: Routing through Single-Shot Combined Generator (50% Token Conservation).")
        combined = await generate_combined_content(
            topic_name=topic_name,
            course_name=course_name,
            syllabus_details=syllabus_details,
            on_usage=usage_report,
            on_event=lambda message: report(message)
        )
        body = combined["post_body"]
        visual_content = combined["infographic"]
    else:
        report("On-Demand user prompt detected: Conserving Cloud tokens with Postall_V4 AI extraction.")
        course_context = f"Course context: {course_name}. " if course_name else ""
        syllabus_context = f"Syllabus objectives: {syllabus_details}. " if syllabus_details else f"Topic Context: {req.prompt}. "
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key='workspace_persona'").fetchone()
        db.close()
        active_persona = row["value"] if row and row["value"] else "tech_academy"
        persona_system = get_post_system_prompt(active_persona)

        prompt = f"""{persona_system}
{course_context}{syllabus_context}Write an original, high-impact post about: {req.prompt}.
Ensure formatting uses short paragraphs, bullet points, and actionable takeaways. Return only the post."""
        try:
            body = await execute_task("heavy", prompt, on_usage=usage_report, on_event=lambda message: report(message))
        except RuntimeError as exc:
            log("ERROR", "GENERATOR", f"No enabled engine generated on-demand post ({type(exc).__name__})")
            raise
        report("Offloading visual diagram extraction to Postall_V4 AI (0 Gemini tokens).")
        visual_content = await extract_diagram_with_local_llm(topic_name, body)

    # Deterministic slug (0 AI tokens)
    slug = re.sub(r"[^a-z0-9]+", "-", topic_name.lower()).strip("-")[:40] or f"post-{req.course_id or 1}"

    report("Saving draft and rendering Diagram-First infographic.")
    body, draft_status, violations = check_and_apply_brand_safety(body, "DRAFT")
    if violations:
        log("WARNING", "GUARDRAILS", f"Draft flagged for brand safety violations: {violations}")
        report(f"⚠️ Brand Safety Alert: Post flagged for violations ({', '.join(violations)}). Action required.", "warning")
    created_at = datetime.now(configured_timezone())
    db = get_db()
    cur = db.execute(
        "INSERT INTO drafts(course_id,topic_id,prompt,body,status,created_at,workspace_id) VALUES(?,?,?,?,?,?,?)",
        (req.course_id, req.topic_id, req.prompt, body, draft_status, created_at.isoformat(timespec="seconds"), ws_id)
    )
    did = cur.lastrowid
    db.commit()
    db.close()

    path = await asyncio.to_thread(make_asset, did, body, media_format, topic_name, created_at, slug, visual_content)
    artifact = str(post_artifact_dir(topic_name, created_at, slug).relative_to(ROOT))
    db = get_db()
    db.execute("UPDATE drafts SET asset_path=?,asset_type=?,artifact_path=? WHERE id=?", (path, media_format, artifact, did))
    db.commit()
    db.close()
    log("INFO", "GENERATOR", f"Draft {did} generated")
    report("Draft saved. Diagram-First infographic files and preview are ready.", "info", draft_id=did, usage=usage)
    d_obj = draft(did, user)
    asyncio.create_task(dispatch_platform_alerts("draft_ready", d_obj))
    return d_obj
@app.post("/api/modules/generate/{item_id}")
async def generate_topic(item_id: int, user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db(); t=db.execute("SELECT t.*, c.name course_name FROM topics t JOIN courses c ON c.id=t.course_id WHERE t.id=?",(item_id,)).fetchone(); db.close()
    if not t: raise HTTPException(404,"Topic not found")
    item_ws = t["workspace_id"] if "workspace_id" in t.keys() and t["workspace_id"] else ws_id
    return await generate(GenerateIn(prompt=t["title"],format="infographic",course_id=t["course_id"],topic_id=item_id),user,ws_id=item_ws)
@app.get("/api/drafts")
def drafts(status: Optional[str]=None, user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db(); q="SELECT d.*, t.title topic_name, c.name course_name FROM drafts d LEFT JOIN topics t ON t.id=d.topic_id LEFT JOIN courses c ON c.id=d.course_id WHERE d.workspace_id=?"; args=[ws_id] 
    if status: q+=" AND d.status=?"; args.append(status.upper())
    result=[row(x) for x in db.execute(q+" ORDER BY COALESCE(d.scheduled_at,d.created_at)",args).fetchall()]; db.close(); return result
@app.get("/api/drafts/{did}/asset")
def draft_asset(did: int, user=Depends(current_user)):
    db=get_db(); d=db.execute("SELECT asset_path FROM drafts WHERE id=?",(did,)).fetchone(); db.close()
    if not d or not d["asset_path"]:
        raise HTTPException(404,"Asset not found")
    asset_rel = d["asset_path"]
    asset = asset_file(asset_rel)
    if asset and asset.exists():
        media_type="image/png" if asset.suffix.lower()==".png" else "image/svg+xml"
        return FileResponse(asset, media_type=media_type)
    
    try:
        from backend.storage import get_storage_provider
        sp = get_storage_provider()
        data = sp.get_file(asset_rel)
        if data:
            media_type = "image/png" if asset_rel.lower().endswith(".png") else "image/svg+xml"
            return Response(content=data, media_type=media_type)
    except Exception:
        pass
    raise HTTPException(404,"Asset not found")
def draft(did,user):
    db=get_db(); d=row(db.execute("SELECT d.*, t.title topic_name, c.name course_name FROM drafts d LEFT JOIN topics t ON t.id=d.topic_id LEFT JOIN courses c ON c.id=d.course_id WHERE d.id=?",(did,)).fetchone()); db.close()
    if not d: raise HTTPException(404,"Draft not found")
    d["scheduled_at_display"]=local_datetime_label(d.get("scheduled_at"))
    return d
@app.post("/api/drafts/{did}/approve")
def approve(did:int,user=Depends(require_editor)):
    db=get_db()
    curr=db.execute("SELECT status,author_id FROM drafts WHERE id=?",(did,)).fetchone()
    if not curr:
        db.close()
        raise HTTPException(404,"Draft not found")
    if curr["status"] == "FLAGGED_VIOLATION":
        db.close()
        raise HTTPException(400, "Draft has brand safety violations. Edit and clear violations before approving.")
    # ── Phase 6 P1: Maker-Checker 4-Eyes Enforcement ──────────────────────
    mc_row = db.execute("SELECT value FROM settings WHERE key='maker_checker_enabled'").fetchone()
    if mc_row and str(mc_row["value"]).strip() in {"1", "true", "on", "yes"}:
        operator_id = user.get("id") if isinstance(user, dict) else None
        draft_author_id = curr["author_id"]
        if operator_id and draft_author_id and int(operator_id) == int(draft_author_id):
            db.close()
            raise HTTPException(
                status_code=403,
                detail="4-Eyes Principle Enforced: Post authors cannot approve or publish their own drafts. Peer review required."
            )
    # ── Record approval with reviewer identity ─────────────────────────────
    operator_id = user.get("id") if isinstance(user, dict) else None
    cur=db.execute(
        "UPDATE drafts SET status='APPROVED',approved_at=CURRENT_TIMESTAMP,approved_by=? WHERE id=? AND status='DRAFT'",
        (operator_id, did)
    )
    db.commit(); db.close()
    if not cur.rowcount: raise HTTPException(409,"Draft is not awaiting approval")
    username_str = user.get("username", str(user)) if isinstance(user, dict) else str(user)
    return draft(did, username_str)
@app.post("/api/drafts/{did}/reject")
def reject(did:int,req:RejectIn,user=Depends(require_editor)):
    db=get_db(); db.execute("UPDATE drafts SET status='REJECTED',rejected_reason=? WHERE id=?",(req.reason,did)); db.commit(); db.close(); return draft(did,user)
@app.post("/api/drafts/{did}/schedule")
def schedule(did:int,req:ScheduleIn,user=Depends(require_editor)):
    try: when=datetime.fromisoformat(req.scheduled_at.replace("Z","+00:00"))
    except ValueError: raise HTTPException(400,"scheduled_at must be ISO-8601")
    tz=configured_timezone()
    if when.tzinfo is None:
        when=when.replace(tzinfo=tz)
    else:
        when=when.astimezone(tz)
    if when <= datetime.now(tz):
        raise HTTPException(400,"scheduled_at must be in the future")
    db=get_db(); if_approved=db.execute("SELECT status FROM drafts WHERE id=?",(did,)).fetchone()
    if not if_approved: db.close(); raise HTTPException(404,"Draft not found")
    if if_approved["status"] == "FLAGGED_VIOLATION":
        db.close()
        raise HTTPException(400, "Draft is flagged for brand safety violations. Edit and resolve violations before scheduling.")
    if if_approved["status"] not in ("APPROVED","DRAFT"): db.close(); raise HTTPException(409,"Draft cannot be scheduled")
    scheduled=db.execute("SELECT id,scheduled_at FROM drafts WHERE scheduled_at IS NOT NULL AND status IN ('APPROVED','SCHEDULED') AND id<>?",(did,)).fetchall()
    for existing in scheduled:
        try:
            existing_at=datetime.fromisoformat(existing["scheduled_at"].replace("Z","+00:00"))
            if existing_at.tzinfo is None:
                existing_at=existing_at.replace(tzinfo=timezone.utc)
            if existing_at.astimezone(tz).date()==when.date():
                db.close()
                raise HTTPException(409,"Only one post per day is allowed in the configured timezone")
        except ValueError:
            log("WARNING","SCHEDULER",f"Ignoring invalid scheduled_at value for draft {existing['id']}")
    db.execute("UPDATE drafts SET scheduled_at=?,status='SCHEDULED' WHERE id=?",(when.astimezone(timezone.utc).isoformat(timespec="seconds"),did)); db.commit(); db.close(); return draft(did,user)
@app.post("/api/drafts/{did}/post-now")
def post_now(did:int,user=Depends(require_editor)): return publish(did,user)

@app.post("/api/drafts/{did}/publish")
def publish_selected(did:int,req:PublishIn,user=Depends(require_editor)):
    platforms=list(dict.fromkeys(str(value).strip().lower() for value in req.platforms))
    if not platforms or any(platform not in {"linkedin","x"} for platform in platforms):
        raise HTTPException(422,"Choose LinkedIn, X, or both.")
    db=get_db()
    item=db.execute("SELECT * FROM drafts WHERE id=?",(did,)).fetchone()
    configured={r["key"]:r["value"] for r in db.execute("SELECT key,value FROM settings WHERE key='x_user_access_token'")}
    db.close()
    if not item:
        raise HTTPException(404,"Draft not found")
    if item["status"] == "FLAGGED_VIOLATION":
        raise HTTPException(400, "Draft is flagged for brand safety violations. Edit and resolve violations before publishing.")

@app.post("/api/drafts/{did}/edit")
def edit_draft(did: int, req: DraftEditIn, user=Depends(require_editor)):
    db = get_db()
    d = db.execute("SELECT * FROM drafts WHERE id=?", (did,)).fetchone()
    if not d:
        db.close()
        raise HTTPException(404, "Draft not found")
    
    # Strip any existing brand safety header before checking
    raw_body = sanitize_violation_header(req.body.strip())
    
    # Re-evaluate brand safety
    new_body, new_status, violations = check_and_apply_brand_safety(raw_body, initial_status="DRAFT")
    
    db.execute("UPDATE drafts SET body=?, status=? WHERE id=?", (new_body, new_status, did))
    db.commit()
    db.close()
    log("INFO", "GUARDRAILS", f"Draft {did} edited by {user}. New status: {new_status}")
    return {
        "status": "success",
        "draft": draft(did, user),
        "violations": violations,
        "is_violation": bool(violations)
    }

@app.post("/api/guardrails/check-text")
def check_text_guardrails(req: CheckTextIn, user=Depends(current_user)):
    db = get_db()
    settings_rows = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings WHERE key IN ('dlp_enabled', 'brand_safety_enabled', 'banned_keywords', 'competitor_names')")}
    db.close()

    dlp_on = settings_rows.get("dlp_enabled", "1") not in {"0", "false", "off", "no", "disabled"}
    bs_on = settings_rows.get("brand_safety_enabled", "1") not in {"0", "false", "off", "no", "disabled"}
    banned = settings_rows.get("banned_keywords", "") or ""
    competitors = settings_rows.get("competitor_names", "") or ""

    scrubbed_text = redact_pii(req.text) if dlp_on else req.text
    violations = check_brand_safety(req.text, banned, competitors) if bs_on else []

    return {
        "dlp_enabled": dlp_on,
        "brand_safety_enabled": bs_on,
        "scrubbed_text": scrubbed_text,
        "violations": violations,
        "has_violations": len(violations) > 0
    }
    results=[]
    for platform in platforms:
        db=get_db()
        db.execute("BEGIN IMMEDIATE")
        previous=db.execute("SELECT status,post_url,created_at FROM social_publications WHERE draft_id=? AND platform=?",(did,platform)).fetchone()
        if previous and previous["status"]=="PUBLISHED":
            db.commit(); db.close()
            results.append({"platform":platform,"status":"PUBLISHED","post_url":previous["post_url"],"already_published":True})
            continue
        if previous and previous["status"]=="PUBLISHING":
            active=db.execute("SELECT datetime(?) >= datetime('now','-10 minutes')",(previous["created_at"],)).fetchone()[0]
            if active:
                db.commit(); db.close()
                results.append({"platform":platform,"status":"PUBLISHING","already_in_progress":True})
                continue
        db.execute(
            """INSERT INTO social_publications(draft_id,platform,status,post_url,error)
               VALUES(?,?,'PUBLISHING',NULL,NULL) ON CONFLICT(draft_id,platform) DO UPDATE SET
               status='PUBLISHING',post_url=NULL,error=NULL,created_at=CURRENT_TIMESTAMP""",
            (did,platform),
        )
        db.commit(); db.close()
        try:
            asset = asset_file(item["asset_path"])
            img_path = str(asset) if asset else None
            final_text = append_custom_hashtags(item["body"])
            if is_dry_run():
                log("INFO", "PUBLISH", f"[SAFE MODE / DRY RUN] Draft {did} to {platform}: Simulated successful publication without calling external API")
                post_url = f"https://example.com/dry-run/{platform}/draft-{did}"
                status = "dry_run"
                error = None
            elif platform == "linkedin":
                pub_res = publish_to_linkedin(final_text, image_path=img_path)
                post_url = pub_res.get("post_url")
                status = "PUBLISHED"
                error = None
            else:
                pub_res = publish_to_x(final_text, image_path=img_path)
                post_url = pub_res.get("post_url")
                status = "PUBLISHED"
                error = None
        except Exception as exc:
            status = "FAILED"
            error = str(exc)
            post_url = None
        db=get_db()
        db.execute(
            """INSERT INTO social_publications(draft_id,platform,status,post_url,error)
               VALUES(?,?,?,?,?) ON CONFLICT(draft_id,platform) DO UPDATE SET
               status=excluded.status,post_url=excluded.post_url,error=excluded.error,created_at=CURRENT_TIMESTAMP""",
            (did,platform,status,post_url,error),
        )
        if status in {"PUBLISHED", "dry_run"}:
            db.execute("UPDATE drafts SET status='PUBLISHED',published_at=CURRENT_TIMESTAMP WHERE id=?", (did,))
            if item["topic_id"]:
                db.execute("UPDATE topics SET status='PUBLISHED' WHERE id=?", (item["topic_id"],))
        db.commit(); db.close()
        log("INFO" if status in {"PUBLISHED", "dry_run"} else "ERROR","PUBLISH",f"Draft {did} {platform}: {status}" + (f" ({error})" if error else ""))
        results.append({
            "platform": platform,
            "status": status,
            "post_url": post_url,
            "error": error,
            "dry_run": status == "dry_run",
            "message": "Dry run complete - no API call made" if status == "dry_run" else (f"Published to {platform}" if status == "PUBLISHED" else error)
        })
        if status in {"PUBLISHED", "dry_run"}:
            try:
                d_alert = draft(did, "system")
            except Exception:
                d_alert = {"id": did}
            d_alert["post_url"] = post_url
            fire_alert("publish_success", d_alert)
        elif status == "FAILED":
            try:
                d_alert = draft(did, "system")
            except Exception:
                d_alert = {"id": did}
            fire_alert("publish_failed", d_alert, error_message=error)
    failed = [r for r in results if r["status"] == "FAILED"]
    if failed and len(failed) == len(results):
        raise HTTPException(status_code=500, detail="; ".join(f"{'LinkedIn' if r['platform'] == 'linkedin' else 'X'} publish rejected: {r['error']}" for r in failed))
    return {"draft_id":did,"results":results}

def publish(did,user):
    db=get_db()
    d=db.execute("SELECT * FROM drafts WHERE id=?",(did,)).fetchone()
    if not d:
        db.close()
        raise HTTPException(404,"Draft not found")
    if d["status"] == "FLAGGED_VIOLATION":
        db.close()
        raise HTTPException(400, "Draft is flagged for brand safety violations. Edit and resolve violations before publishing.")
    # ── Phase 6 P1: Maker-Checker 4-Eyes Enforcement ──────────────────────
    mc_row = db.execute("SELECT value FROM settings WHERE key='maker_checker_enabled'").fetchone()
    if mc_row and str(mc_row["value"]).strip() in {"1", "true", "on", "yes"}:
        operator_id = user.get("id") if isinstance(user, dict) else None
        draft_author_id = d["author_id"]
        if operator_id and draft_author_id and int(operator_id) == int(draft_author_id):
            db.close()
            raise HTTPException(
                status_code=403,
                detail="4-Eyes Principle Enforced: Post authors cannot approve or publish their own drafts. Peer review required."
            )
    db.close()
    return _publish(did)
def _publish(did):
    db=get_db(); d=db.execute("SELECT * FROM drafts WHERE id=?",(did,)).fetchone()
    if not d:
        db.close()
        raise HTTPException(404, "Draft not found")
    if d["status"] == "FLAGGED_VIOLATION":
        db.close()
        raise HTTPException(400, "Draft is flagged for brand safety violations. Edit and resolve violations before publishing.")

    asset = asset_file(d["asset_path"])
    img_path = str(asset) if asset else None
    final_text = append_custom_hashtags(d["body"])

    if is_dry_run():
        log("INFO", "LINKEDIN", f"[SAFE MODE / DRY RUN] Draft {did} published (simulated)")
        url = f"https://example.com/dry-run/linkedin/draft-{did}"
        db.execute("UPDATE drafts SET status='PUBLISHED',published_at=CURRENT_TIMESTAMP,publish_attempts=COALESCE(publish_attempts,0)+1 WHERE id=?",(did,))
        if d["topic_id"]:
            db.execute("UPDATE topics SET status='PUBLISHED' WHERE id=?", (d["topic_id"],))
        db.execute("INSERT INTO publish_events(draft_id,status,linkedin_url) VALUES(?,'DRY_RUN',?)",(did,url,))
        db.commit()
        db.close()
        d_dry = draft(did,"system")
        d_dry["post_url"] = url
        fire_alert("publish_success", d_dry)
        return {
            "status": "dry_run",
            "message": "Dry run complete - no API call made",
            "draft_id": did,
            "post_url": url,
            "draft": d_dry
        }

    try:
        res = publish_to_linkedin(final_text, image_path=img_path)
        url = res.get("post_url")
        db.execute("UPDATE drafts SET status='PUBLISHED',published_at=CURRENT_TIMESTAMP,publish_attempts=COALESCE(publish_attempts,0)+1 WHERE id=?",(did,))
        if d["topic_id"]:
            db.execute("UPDATE topics SET status='PUBLISHED' WHERE id=?", (d["topic_id"],))
        db.execute("INSERT INTO publish_events(draft_id,status,linkedin_url) VALUES(?,'PUBLISHED',?)",(did,url,))
        db.commit()
        log("INFO","LINKEDIN",f"Draft {did} published: {url}")
        d_published = draft(did,"system")
        d_published["post_url"] = url
        db.close()
        fire_alert("publish_success", d_published)
        return {
            "status": "success",
            "message": "Posted successfully to LinkedIn",
            "draft_id": did,
            "post_url": url,
            "draft": d_published
        }
    except Exception as exc:
        err_msg = str(exc)
        db.execute("UPDATE drafts SET status='PUBLISH_FAILED',publish_attempts=COALESCE(publish_attempts,0)+1 WHERE id=?",(did,))
        db.execute("INSERT INTO publish_events(draft_id,status,error) VALUES(?, 'FAILED',?)",(did,err_msg[:500]))
        db.commit()
        db.close()
        log("ERROR","LINKEDIN",f"Draft {did} failed: {err_msg}")
        try:
            d_fail = draft(did, "system")
        except Exception:
            d_fail = {"id": did}
        fire_alert("publish_failed", d_fail, error_message=err_msg)
        raise HTTPException(status_code=500, detail=f"LinkedIn publish rejected: {err_msg}")
@app.get("/api/calendar")
def calendar(user=Depends(current_user)):
    db=get_db(); out=[row(x) for x in db.execute("SELECT * FROM drafts WHERE scheduled_at IS NOT NULL ORDER BY datetime(scheduled_at)").fetchall()]; db.close()
    tz=configured_timezone()
    for item in out:
        item["scheduled_at_display"]=local_datetime_label(item.get("scheduled_at"),tz)
    return out
@app.get("/api/posts")
def posts(view: str = "all", user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    """Operational view used by the dashboard: upcoming, current or past."""
    db=get_db(); now=datetime.now(timezone.utc).isoformat()
    tz=configured_timezone()
    today=datetime.now(tz).date()
    day_start=datetime.combine(today,datetime.min.time(),tzinfo=tz).astimezone(timezone.utc).isoformat()
    day_end=datetime.combine(today+timedelta(days=1),datetime.min.time(),tzinfo=tz).astimezone(timezone.utc).isoformat()
    base="SELECT d.*, t.title topic_name, c.name course_name FROM drafts d LEFT JOIN topics t ON t.id=d.topic_id LEFT JOIN courses c ON c.id=d.course_id WHERE d.workspace_id=?"
    if view == "upcoming":
        q=base+" AND datetime(d.scheduled_at)>=datetime(?) AND d.status IN ('APPROVED','SCHEDULED') ORDER BY datetime(d.scheduled_at) ASC, d.id DESC"
        args=[ws_id, now]
    elif view == "past":
        q=base+" AND (d.published_at IS NOT NULL OR (d.scheduled_at IS NOT NULL AND datetime(d.scheduled_at)<datetime(?))) ORDER BY datetime(COALESCE(d.published_at,d.scheduled_at)) DESC, d.id DESC"
        args=[ws_id, now]
    elif view == "current":
        q=base+" AND (d.status IN ('DRAFT','APPROVED','FLAGGED_VIOLATION') OR (d.status='SCHEDULED' AND datetime(d.scheduled_at)>=datetime(?) AND datetime(d.scheduled_at)<datetime(?))) ORDER BY d.id DESC, datetime(COALESCE(d.scheduled_at,d.created_at)) DESC"
        args=[ws_id, day_start, day_end]
    else:
        q=base+" ORDER BY d.id DESC, datetime(COALESCE(d.scheduled_at,d.created_at)) DESC"
        args=[ws_id]

    out=[row(x) for x in db.execute(q,args).fetchall()]; db.close()
    for item in out:
        item["scheduled_at_display"]=local_datetime_label(item.get("scheduled_at"),tz)
    return out

@app.get("/api/ai/models")
async def get_available_ai_models(user=Depends(current_user)):
    models = await discover_available_gemini_models()
    primary_pref = None
    try:
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key='ai_primary_model'").fetchone()
        db.close()
        if row and row["value"] and str(row["value"]).strip():
            val = str(row["value"]).strip()
            if val not in {"gemini-2.5-flash", "gemini-2.0-flash", "models/gemini-2.5-flash", "models/gemini-2.0-flash"}:
                primary_pref = val
    except Exception:
        pass
    return {
        "models": models,
        "primary": primary_pref or (models[0] if models else "gemini-flash-lite-latest"),
        "cached": bool(_MODELS_CACHE["timestamp"])
    }

async def run_autopilot_tick(force: bool = False):
    """
    Autonomous Daily Course Pipeline Engine:
    - Maintains an active buffer of scheduled drafts for the next N days (default 3).
    - Refills the buffer by pulling unposted topics from active courses.
    - Generates post copy & diagram-first infographic via single-shot AI.
    - Inserts scheduled drafts with status='SCHEDULED' and updates topic to 'QUEUED'.
    """
    global AUTOPILOT_LAST_TICK
    AUTOPILOT_LAST_TICK = datetime.now(timezone.utc).isoformat()
    db = get_db()
    settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
    db.close()

    autopilot_enabled = str(settings.get("autopilot_enabled", "0")).strip().lower() in {"1", "true", "on", "yes"}
    if not autopilot_enabled:
        return

    db = get_db()
    unposted_count = db.execute(
        """SELECT COUNT(*) FROM topics t JOIN courses c ON c.id=t.course_id
           WHERE LOWER(t.status) IN ('pending', 'unposted') AND c.status='ACTIVE'"""
    ).fetchone()[0]
    db.close()
    if not unposted_count:
        return

    provider = str(settings.get("ai_provider") or "local").strip().lower()
    if settings.get("ai_provider_status") == "standby":
        return
    if provider == "gemini" and not gemini_api_keys():
        _set_ai_provider_standby("Gemini selected but no API key is configured.")
        return

    try:
        buffer_days = max(1, min(14, int(settings.get("autopilot_buffer_days", "3"))))
    except (ValueError, TypeError):
        buffer_days = 3

    tz = configured_timezone()
    now_tz = datetime.now(tz)

    # 1. Count upcoming scheduled posts in the buffer window
    db = get_db()
    scheduled_rows = db.execute(
        "SELECT id, scheduled_at, topic_id FROM drafts WHERE status IN ('SCHEDULED', 'APPROVED') AND scheduled_at IS NOT NULL"
    ).fetchall()

    upcoming_count = 0
    booked_dates = set()
    for sr in scheduled_rows:
        try:
            dt = datetime.fromisoformat(str(sr["scheduled_at"]).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            local_d = dt.astimezone(tz).date()
            booked_dates.add(local_d)
            if now_tz.date() <= local_d <= (now_tz.date() + timedelta(days=buffer_days)):
                upcoming_count += 1
        except Exception:
            pass

    # Published dates are also booked so we don't double-post on the same calendar day
    published_rows = db.execute("SELECT published_at, scheduled_at FROM drafts WHERE status='PUBLISHED'").fetchall()
    for pr in published_rows:
        for fld in ("published_at", "scheduled_at"):
            if pr[fld]:
                try:
                    dt = datetime.fromisoformat(str(pr[fld]).replace("Z", "+00:00"))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    booked_dates.add(dt.astimezone(tz).date())
                except Exception:
                    pass
    db.close()

    needed = (buffer_days - upcoming_count) if not force else max(1, buffer_days - upcoming_count)
    if needed <= 0 and not force:
        return

    log("INFO", "AUTOPILOT", f"Autopilot check: {upcoming_count} scheduled / {buffer_days} buffer target. Filling {needed} slot(s)...")

    for _ in range(needed):
        db = get_db()
        topic_row = db.execute(
            """SELECT t.id, t.course_id, t.title, t.details, c.name as course_name
               FROM topics t
               JOIN courses c ON c.id=t.course_id
               WHERE LOWER(t.status) IN ('pending', 'unposted')
                 AND c.status='ACTIVE'
               ORDER BY c.id ASC, t.id ASC
               LIMIT 1"""
        ).fetchone()

        if not topic_row:
            db.close()
            log("INFO", "AUTOPILOT", "No unposted syllabus topics remaining in active courses.")
            break

        topic_id = topic_row["id"]
        course_id = topic_row["course_id"]
        topic_title = topic_row["title"]
        course_name = topic_row["course_name"]
        topic_details = topic_row["details"] or ""

        # Transition topic status to QUEUED
        db.execute("UPDATE topics SET status='QUEUED' WHERE id=?", (topic_id,))
        db.commit()
        db.close()

        log("INFO", "AUTOPILOT", f"Autopilot auto-generating syllabus post for topic '{topic_title}' ({course_name})")

        try:
            combined = await generate_combined_content(
                topic_name=topic_title,
                course_name=course_name,
                syllabus_details=topic_details
            )
            body = combined["post_body"]
            visual_content = combined["infographic"]

            body, draft_status, violations = check_and_apply_brand_safety(body, "SCHEDULED")
            if violations:
                log("WARNING", "GUARDRAILS", f"Autopilot draft for '{topic_title}' flagged for brand safety violations: {violations}")

            db = get_db()
            slot_dt = find_next_available_schedule_slot(db)
            slot_iso = slot_dt.isoformat()

            created_at = datetime.now(tz)
            slug = re.sub(r"[^a-z0-9]+", "-", topic_title.lower()).strip("-")[:40] or f"topic-{topic_id}"

            t_ws = topic_row["workspace_id"] if "workspace_id" in topic_row.keys() and topic_row["workspace_id"] else 1
            cur = db.execute(
                """INSERT INTO drafts(course_id, topic_id, prompt, body, status, scheduled_at, created_at, workspace_id)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?)""",
                (course_id, topic_id, topic_title, body, draft_status, slot_iso, created_at.isoformat(timespec="seconds"), t_ws)
            )
            did = cur.lastrowid
            db.commit()
            db.close()

            path = await asyncio.to_thread(make_asset, did, body, "infographic", topic_title, created_at, slug, visual_content)
            artifact = str(post_artifact_dir(topic_title, created_at, slug).relative_to(ROOT))

            db = get_db()
            db.execute("UPDATE drafts SET asset_path=?, asset_type='infographic', artifact_path=? WHERE id=?", (path, artifact, did))
            db.commit()
            db.close()

            log("INFO", "AUTOPILOT", f"Autopilot successfully scheduled draft #{did} ('{topic_title}') for {local_datetime_label(slot_iso, tz)}")

            d_obj = draft(did, "autopilot")
            asyncio.create_task(dispatch_platform_alerts("draft_ready", d_obj))

        except Exception as exc:
            log("ERROR", "AUTOPILOT", f"Autopilot draft generation failed for '{topic_title}': {exc}")
            if _is_invalid_gemini_key_error(exc):
                _set_ai_provider_standby("Gemini API key was rejected; provider placed in standby.")
            db = get_db()
            db.execute("UPDATE topics SET status='PENDING' WHERE id=?", (topic_id,))
            db.commit()
            db.close()
            break


def _is_invalid_gemini_key_error(exc: Exception) -> bool:
    message = str(exc).lower()
    return any(marker in message for marker in (
        "api_key_invalid",
        "api key not valid",
        "invalid api key",
        "invalid api_key",
        "gemini api key is invalid",
    ))


def _set_ai_provider_standby(reason: str) -> None:
    global _AI_STANDBY_WARNING_EMITTED
    db = get_db()
    try:
        db.execute(
            "INSERT INTO settings(key,value) VALUES('ai_provider_status','standby') "
            "ON CONFLICT(key) DO UPDATE SET value='standby'"
        )
        db.commit()
    finally:
        db.close()
    if not _AI_STANDBY_WARNING_EMITTED:
        _AI_STANDBY_WARNING_EMITTED = True
        logger.warning("[AI] %s", reason)
        log("WARNING", "AI", reason)

@app.get("/api/autopilot/status")
def autopilot_status(user=Depends(current_user)):
    db = get_db()
    settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
    
    enabled = str(settings.get("autopilot_enabled", "0")).strip().lower() in {"1", "true", "on", "yes"}
    try:
        buffer_days = int(settings.get("autopilot_buffer_days", "3"))
    except Exception:
        buffer_days = 3
    post_time = settings.get("post_time", "09:00")
    notification_time = settings.get("notification_time", "08:00")
    
    tz = configured_timezone()
    now_tz = datetime.now(tz)
    
    scheduled = [row(x) for x in db.execute(
        """SELECT d.*, t.title as topic_name, c.name as course_name 
           FROM drafts d 
           LEFT JOIN topics t ON t.id=d.topic_id 
           LEFT JOIN courses c ON c.id=d.course_id 
           WHERE d.status IN ('SCHEDULED', 'APPROVED') AND d.scheduled_at IS NOT NULL
           ORDER BY datetime(d.scheduled_at) ASC"""
    ).fetchall()]
    
    queued_count = len(scheduled)
    
    courses = db.execute("SELECT id, name, status FROM courses WHERE status='ACTIVE'").fetchall()
    active_courses = []
    for c in courses:
        counts = {r["status"]: r["cnt"] for r in db.execute(
            "SELECT LOWER(status) as status, count(*) as cnt FROM topics WHERE course_id=? GROUP BY LOWER(status)", (c["id"],)
        ).fetchall()}
        unposted = counts.get("pending", 0) + counts.get("unposted", 0)
        queued = counts.get("queued", 0)
        published = counts.get("published", 0)
        active_courses.append({
            "id": c["id"],
            "name": c["name"],
            "unposted_count": unposted,
            "queued_count": queued,
            "published_count": published
        })
        
    db.close()
    
    next_post = None
    if scheduled:
        first = scheduled[0]
        try:
            s_dt = datetime.fromisoformat(str(first["scheduled_at"]).replace("Z", "+00:00"))
            if s_dt.tzinfo is None:
                s_dt = s_dt.replace(tzinfo=timezone.utc)
            s_local = s_dt.astimezone(tz)
            
            day_label = "Today" if s_local.date() == now_tz.date() else ("Tomorrow" if s_local.date() == (now_tz.date() + timedelta(days=1)) else s_local.strftime("%a, %d %b"))
            time_display = s_local.strftime("%I:%M %p")
            topic_str = first.get("topic_name") or first.get("prompt") or f"Draft #{first['id']}"
            course_str = first.get("course_name") or "On-Demand"
            
            next_post = {
                "id": first["id"],
                "topic": topic_str,
                "topic_name": topic_str,
                "course": course_str,
                "course_name": course_str,
                "scheduled_at": first["scheduled_at"],
                "scheduled_at_display": f"{day_label} at {time_display} ({course_str} - {topic_str})"
            }
        except Exception:
            pass
            
    total_unposted = sum(c.get("unposted_count", 0) for c in active_courses)
    return {
        "enabled": enabled,
        "buffer_days": buffer_days,
        "queued_days": queued_count,
        "queued_count": queued_count,
        "unposted_topics_count": total_unposted,
        "post_time": post_time,
        "notification_time": notification_time,
        "next_post": next_post,
        "next_scheduled_post": next_post,
        "active_courses": active_courses
    }

@app.post("/api/autopilot/toggle")
def autopilot_toggle(user=Depends(current_user)):
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key='autopilot_enabled'").fetchone()
    current = row["value"] if row else "0"
    new_val = "0" if current not in {"0", "false", "off", "no", "disabled"} else "1"
    db.execute("INSERT INTO settings(key, value) VALUES('autopilot_enabled', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (new_val,))
    db.commit()
    db.close()
    enabled = (new_val == "1")
    log("INFO", "AUTOPILOT", f"Autopilot {'resumed' if enabled else 'paused'} by user {user}")
    return {"status": "success", "enabled": enabled, "message": f"Autopilot {'activated' if enabled else 'paused'}."}

@app.post("/api/autopilot/run-now")
async def autopilot_run_now(user=Depends(current_user)):
    log("INFO", "AUTOPILOT", f"Manual trigger: Force run Autopilot initiated by {user}")
    try:
        await run_autopilot_tick(force=True)
        return {"status": "success", "message": "Autopilot queue generation completed successfully."}
    except Exception as exc:
        log("ERROR", "AUTOPILOT", f"Manual Autopilot run failed: {exc}")
        raise HTTPException(500, f"Autopilot execution failed: {exc}")

@app.get("/api/settings")
def settings(user=Depends(current_user)):
    db=get_db(); out={r["key"]:r["value"] for r in db.execute("SELECT key,value FROM settings WHERE key!='timezone_default_migrated'")}; db.close()
    out.setdefault("timezone","Asia/Kolkata")
    out.setdefault("ai_provider","local")
    out.setdefault("ai_provider_status","ready")
    out.setdefault("ai_primary_model","gemini-flash-lite-latest")
    if out.get("ai_primary_model") in {"gemini-2.5-flash", "gemini-2.0-flash", "models/gemini-2.5-flash", "models/gemini-2.0-flash"}:
        out["ai_primary_model"] = "gemini-flash-lite-latest"
    out.setdefault("ai_temperature","0.7")
    out.setdefault("dry_run_mode","0")
    out.setdefault("custom_hashtags","")
    out.setdefault("dlp_enabled", "1")
    out.setdefault("brand_safety_enabled", "1")
    out.setdefault("banned_keywords", "")
    out.setdefault("competitor_names", "")
    out["dlp_enabled"] = str(int(str(out.get("dlp_enabled","1")).strip().lower() not in {"0","false","off","no","disabled"}))
    out["brand_safety_enabled"] = str(int(str(out.get("brand_safety_enabled","1")).strip().lower() not in {"0","false","off","no","disabled"}))
    out.setdefault("server_base_url","http://172.19.74.165:8000")
    out.setdefault("slack_webhook_url","")
    out.setdefault("teams_webhook_url","")
    out.setdefault("storage_backend", "local")
    out.setdefault("s3_endpoint_url", "")
    out.setdefault("s3_bucket_name", "postall-assets")
    out.setdefault("s3_region", "us-east-1")
    out.setdefault("s3_access_key", "")
    has_s3_secret = bool((out.get("s3_secret_key") or os.getenv("S3_SECRET_KEY") or "").strip())
    out["has_s3_secret_key"] = has_s3_secret
    if "s3_secret_key" in out:
        out["s3_secret_key"] = "••••••••" if has_s3_secret else ""
    out.setdefault("alert_on_draft_ready","1")
    out.setdefault("alert_on_publish_success","1")
    out.setdefault("alert_on_failure","1")
    out.setdefault("autopilot_enabled","0")
    out.setdefault("autopilot_buffer_days","3")
    out["autopilot_enabled"] = str(int(str(out.get("autopilot_enabled","0")).strip().lower() not in {"0","false","off","no","disabled"}))
    for abf in ("alert_on_draft_ready","alert_on_publish_success","alert_on_failure"):
        out[abf]=str(int(str(out.get(abf,"1")).strip().lower() not in {"0","false","off","no","disabled"}))
    for key, env_key in (("smtp_host","SMTP_HOST"),("smtp_sender","EMAIL_SENDER"),("smtp_receiver","EMAIL_RECEIVER")):
        if not out.get(key) and os.getenv(env_key):
            out[key] = os.getenv(env_key)
            out[f"{key}_source"] = "environment"
        else:
            out[f"{key}_source"] = "database"

    # Booleans for Gemini key slots
    has_gemini_primary = bool((out.get("gemini_api_key") or out.get("gemini_key") or os.getenv("GEMINI_API_KEY") or "").strip())
    has_gemini_1 = bool((out.get("gemini_api_key_1") or os.getenv("GEMINI_API_KEY_1") or "").strip())
    has_gemini_2 = bool((out.get("gemini_api_key_2") or os.getenv("GEMINI_API_KEY_2") or "").strip())

    out["has_gemini_api_key"] = has_gemini_primary
    out["has_gemini_api_key_1"] = has_gemini_1
    out["has_gemini_api_key_2"] = has_gemini_2
    out["has_gemini_key"] = has_gemini_primary
    out["gemini_key_configured"] = "true" if (has_gemini_primary or has_gemini_1 or has_gemini_2) else "false"

    for key in ("enable_gemini_api","enable_local_llm","dry_run_mode"):
        out[key]=str(int(str(out.get(key,"1" if "enable" in key else "0")).strip().lower() not in {"0","false","off","no","disabled"}))
    out["local_llm_loaded"]="true" if local_llm is not None else "false"
    out["local_llm_status"]=local_llm_status()
    out["local_llm_model"]="Qwen2.5-1.5B-Instruct"
    
    # Social tokens fallback from environment
    if not out.get("linkedin_access_token") and os.getenv("LINKEDIN_ACCESS_TOKEN"):
        out["linkedin_access_token"] = os.getenv("LINKEDIN_ACCESS_TOKEN")
    for k, env_k in (
        ("x_api_key", "X_API_KEY"),
        ("x_api_secret", "X_API_SECRET"),
        ("x_access_token", "X_ACCESS_TOKEN"),
        ("x_access_token_secret", "X_ACCESS_TOKEN_SECRET"),
        ("x_user_access_token", "X_USER_ACCESS_TOKEN"),
    ):
        if not out.get(k) and os.getenv(env_k):
            out[k] = os.getenv(env_k)

    out["smtp_configured"]="true" if (out.get("smtp_sender") and out.get("smtp_receiver")) else "false"
    out["has_smtp_app_password"] = bool((out.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD") or "").strip())
    out["smtp_app_password_configured"]="true" if out["has_smtp_app_password"] else "false"
    
    # Flags for social configurations
    has_li = bool((out.get("linkedin_access_token") or "").strip())
    has_x_oauth1 = bool((out.get("x_api_key") or "").strip() and (out.get("x_access_token") or "").strip())
    has_x_oauth2 = bool((out.get("x_user_access_token") or "").strip())
    
    out["has_linkedin_access_token"] = has_li
    out["linkedin_configured"] = "true" if has_li else "false"
    out["linkedin_access_token_configured"] = "true" if has_li else "false"
    out["linkedin_session_configured"] = "true" if has_li else "false"  # backwards compatibility
    
    out["has_x_api_key"] = bool((out.get("x_api_key") or "").strip())
    out["has_x_api_secret"] = bool((out.get("x_api_secret") or "").strip())
    out["has_x_access_token"] = bool((out.get("x_access_token") or "").strip())
    out["has_x_access_token_secret"] = bool((out.get("x_access_token_secret") or "").strip())
    out["has_x_user_access_token"] = has_x_oauth2
    out["has_x_oauth1"] = has_x_oauth1
    out["has_x_oauth2"] = has_x_oauth2
    out["x_configured"] = "true" if (has_x_oauth1 or has_x_oauth2) else "false"
    out["x_oauth1_configured"] = "true" if has_x_oauth1 else "false"
    out["x_oauth2_configured"] = "true" if has_x_oauth2 else "false"

    # Multi-provider and persona defaults
    out.setdefault("workspace_persona", "tech_academy")
    out.setdefault("ai_provider", "gemini")
    out.setdefault("openai_base_url", "https://api.openai.com/v1")
    out.setdefault("openai_model", "gpt-4o")
    out.setdefault("deepseek_base_url", "https://api.deepseek.com/v1")
    out.setdefault("deepseek_model", "deepseek-chat")
    out.setdefault("mistral_base_url", "https://api.mistral.ai/v1")
    out.setdefault("mistral_model", "mistral-large-latest")
    out.setdefault("claude_model", "claude-3-5-sonnet-20241022")
    out.setdefault("custom_ai_base_url", "http://localhost:11434/v1")
    branding = get_branding_settings()
    out["enable_branding"] = branding["enable_branding"]
    out["custom_brand_name"] = branding["custom_brand_name"]
    out["custom_brand_tagline"] = branding["custom_brand_tagline"]

    out["has_openai_api_key"] = bool((out.get("openai_api_key") or "").strip())
    out["has_deepseek_api_key"] = bool((out.get("deepseek_api_key") or "").strip())
    out["has_mistral_api_key"] = bool((out.get("mistral_api_key") or "").strip())
    out["has_claude_api_key"] = bool((out.get("claude_api_key") or "").strip())
    out["has_custom_ai_api_key"] = bool((out.get("custom_ai_api_key") or "").strip())
    out["has_sso_client_secret"] = bool((out.get("sso_client_secret") or "").strip())

    # Clean secrets before returning to client (NEVER expose secret keys in plaintext)
    for sec_key in (
        "smtp_app_password", "gemini_key", "gemini_api_key", "gemini_api_key_1", "gemini_api_key_2",
        "openai_api_key", "deepseek_api_key", "mistral_api_key", "claude_api_key", "custom_ai_api_key",
        "linkedin_access_token", "x_api_key", "x_api_secret", "x_access_token", "x_access_token_secret", "x_user_access_token",
        "sso_client_secret"
    ):
        out.pop(sec_key, None)
    return out

@app.put("/api/settings")
@app.post("/api/settings")
def update_settings(req:SettingsIn,user=Depends(require_admin)):
    global _AI_STANDBY_WARNING_EMITTED
    db=get_db()
    values=req.model_dump(exclude_none=True)
    if values.get("timezone"):
        try:
            ZoneInfo(values["timezone"])
        except (ZoneInfoNotFoundError,ValueError) as exc:
            db.close()
            raise HTTPException(422,"Timezone must be a valid IANA timezone, such as Asia/Kolkata.") from exc
    
    gem_key = values.pop("gemini_key", None)
    if gem_key and str(gem_key).strip():
        values["gemini_api_key"] = str(gem_key).strip()
        os.environ["GEMINI_API_KEY"] = str(gem_key).strip()

    if "gemini_api_key" in values and str(values["gemini_api_key"]).strip():
        os.environ["GEMINI_API_KEY"] = str(values["gemini_api_key"]).strip()
    if "gemini_api_key_1" in values and str(values["gemini_api_key_1"]).strip():
        os.environ["GEMINI_API_KEY_1"] = str(values["gemini_api_key_1"]).strip()
    if "gemini_api_key_2" in values and str(values["gemini_api_key_2"]).strip():
        os.environ["GEMINI_API_KEY_2"] = str(values["gemini_api_key_2"]).strip()

    for bf in ("enable_gemini_api", "enable_local_llm"):
        if bf in values:
            values[bf] = "1" if values[bf] else "0"

    if "dry_run_mode" in values:
        v = str(values["dry_run_mode"]).strip().lower()
        values["dry_run_mode"] = "1" if v in {"1", "true", "on", "yes"} else "0"

    if "enable_branding" in values:
        v = str(values["enable_branding"]).strip().lower()
        values["enable_branding"] = "1" if (v in {"1", "true", "on", "yes"} or values["enable_branding"] is True) else "0"

    for abf in ("alert_on_draft_ready", "alert_on_publish_success", "alert_on_failure", "autopilot_enabled"):
        if abf in values:
            v = str(values[abf]).strip().lower()
            values[abf] = "1" if (v in {"1", "true", "on", "yes"} or values[abf] is True) else "0"

    if "autopilot_buffer_days" in values:
        try:
            values["autopilot_buffer_days"] = str(max(1, min(14, int(values["autopilot_buffer_days"]))))
        except Exception:
            values["autopilot_buffer_days"] = "3"

    if "auto_check_updates" in values:
        v = str(values["auto_check_updates"]).strip().lower()
        values["auto_check_updates"] = "1" if (v in {"1", "true", "on", "yes"} or values["auto_check_updates"] is True) else "0"

    for gbf in ("dlp_enabled", "brand_safety_enabled", "sso_enabled"):
        if gbf in values:
            v = str(values[gbf]).strip().lower()
            values[gbf] = "1" if (v in {"1", "true", "on", "yes"} or values[gbf] is True) else "0"

    SECRET_FIELDS = {
        "smtp_app_password", "gemini_key", "gemini_api_key", "gemini_api_key_1", "gemini_api_key_2",
        "openai_api_key", "deepseek_api_key", "mistral_api_key", "claude_api_key", "custom_ai_api_key",
        "linkedin_access_token", "x_api_key", "x_api_secret", "x_access_token", "x_access_token_secret", "x_user_access_token",
        "github_pat", "sso_client_secret", "s3_secret_key"
    }
    for k, v in values.items():
        if v is None:
            continue
        if k in SECRET_FIELDS and isinstance(v, str) and (not v.strip() or v.strip() == "••••••••"):
            continue
        db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v).strip()))

    configured_gemini_key = any(
        str(values.get(key) or "").strip()
        for key in ("gemini_key", "gemini_api_key", "gemini_api_key_1", "gemini_api_key_2")
    )
    if "ai_provider" in values or configured_gemini_key:
        provider = str(values.get("ai_provider") or db.execute(
            "SELECT value FROM settings WHERE key='ai_provider'"
        ).fetchone()["value"]).strip().lower()
        has_gemini_key = configured_gemini_key or bool(
            db.execute(
                "SELECT 1 FROM settings WHERE key IN ('gemini_api_key','gemini_api_key_1','gemini_api_key_2') "
                "AND value != '' LIMIT 1"
            ).fetchone()
        ) or bool(gemini_api_keys())
        provider_status = "ready" if provider != "gemini" or has_gemini_key else "standby"
        db.execute(
            "INSERT INTO settings(key,value) VALUES('ai_provider_status',?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (provider_status,)
        )
        if configured_gemini_key or "ai_provider" in values:
            _AI_STANDBY_WARNING_EMITTED = False

    if "s3_secret_key" in values and values["s3_secret_key"] and str(values["s3_secret_key"]).strip() and values["s3_secret_key"] != "••••••••":
        try:
            from backend.vault import set_secret
            set_secret("s3_secret_key", str(values["s3_secret_key"]).strip())
        except Exception:
            pass

    if any(k.startswith("s3_") or k == "storage_backend" for k in values.keys()):
        try:
            from backend.storage import get_storage_provider
            get_storage_provider(force_reload=True)
        except Exception:
            pass
    
    # If post_time or timezone is changed, automatically reschedule existing active drafts
    target_post_time = values.get("post_time")
    target_tz = values.get("timezone")
    if target_post_time or target_tz:
        if not target_post_time:
            p_row = db.execute("SELECT value FROM settings WHERE key='post_time'").fetchone()
            target_post_time = p_row["value"] if p_row and p_row["value"] else "09:00"
        reschedule_upcoming_drafts_to_new_post_time(db, target_post_time, target_tz)

    db.commit(); db.close(); return settings(user)

@app.get("/api/settings/backup-db")
def backup_db(user=Depends(require_admin)):
    from backend.database import DB_PATH
    if not DB_PATH.exists():
        raise HTTPException(404, "Database file not found.")
    now_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    return FileResponse(
        path=str(DB_PATH),
        filename=f"postall_backup_{now_str}.db",
        media_type="application/x-sqlite3"
    )

@app.post("/api/settings/clear-cache")
def clear_syllabus_cache(user=Depends(require_admin)):
    db = get_db()
    deleted = db.execute("DELETE FROM course_syllabus_cache").rowcount
    db.commit()
    db.close()
    log("INFO", "MAINTENANCE", f"Cleared syllabus cache ({deleted} entries removed)")
    return {"status": "success", "message": f"Syllabus cache cleared ({deleted} entries removed)."}

@app.post("/api/settings/prune-logs")
def prune_logs_endpoint(req: PruneLogsIn, user=Depends(require_admin)):
    days = max(1, req.days)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    db = get_db()
    deleted = db.execute("DELETE FROM system_logs WHERE datetime(timestamp) < datetime(?)", (cutoff,)).rowcount
    db.commit()
    db.close()
    log("INFO", "MAINTENANCE", f"Pruned system logs older than {days} days ({deleted} records removed)")
    return {"status": "success", "deleted_count": deleted, "message": f"Pruned {deleted} logs older than {days} days."}

@app.post("/api/settings/test-gemini-keys")
def test_gemini_keys_endpoint(user=Depends(require_admin)):
    db = get_db()
    settings_dict = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings WHERE key LIKE 'gemini%'").fetchall()}
    db.close()
    
    slots = {
        "primary": settings_dict.get("gemini_api_key") or settings_dict.get("gemini_key") or os.getenv("GEMINI_API_KEY") or "",
        "secondary": settings_dict.get("gemini_api_key_1") or os.getenv("GEMINI_API_KEY_1") or "",
        "tertiary": settings_dict.get("gemini_api_key_2") or os.getenv("GEMINI_API_KEY_2") or ""
    }
    
    results = {}
    for slot_name, key in slots.items():
        key = (key or "").strip()
        if not key:
            results[slot_name] = {"status": "not_configured", "message": "Key slot is empty"}
            continue
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models?key={key}"
            resp = requests.get(url, headers={"User-Agent": "PostAll/4.0"}, timeout=8)
            if resp.status_code == 200:
                results[slot_name] = {"status": "active", "message": "Key is active and operational"}
            elif resp.status_code == 429:
                results[slot_name] = {"status": "exhausted", "message": "Quota limit reached (HTTP 429)"}
            elif resp.status_code in (400, 403):
                results[slot_name] = {"status": "invalid", "message": f"Invalid key or permission denied ({resp.status_code})"}
            else:
                results[slot_name] = {"status": "warning", "message": f"HTTP {resp.status_code}: {resp.text[:100]}"}
        except Exception as exc:
            results[slot_name] = {"status": "error", "message": f"Connection error: {str(exc)}"}
            
    return {"status": "success", "results": results}

@app.get("/api/personas")
def api_get_personas(user=Depends(current_user)):
    """Returns available workspace personas and the currently active profile."""
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key='workspace_persona'").fetchone()
    db.close()
    active_id = row["value"] if row and row["value"] else "tech_academy"
    return {
        "active_persona": active_id,
        "personas": get_all_personas(),
        "active_profile": get_persona_profile(active_id)
    }

@app.post("/api/ai/test-provider")
async def api_test_provider(req: TestProviderIn, user=Depends(require_admin)):
    """Tests connection, latency, and model responsiveness for any supported AI provider."""
    key = req.api_key
    base_url = req.base_url
    model = req.model
    if not key:
        db = get_db()
        p = req.provider.lower().strip()
        if p == "gemini":
            r = db.execute("SELECT value FROM settings WHERE key='gemini_api_key'").fetchone()
            key = r["value"] if r else ""
        else:
            r = db.execute("SELECT value FROM settings WHERE key=?", (f"{p}_api_key",)).fetchone()
            key = r["value"] if r else ""
            if not base_url:
                rb = db.execute("SELECT value FROM settings WHERE key=?", (f"{p}_base_url",)).fetchone()
                if rb and rb["value"]: base_url = rb["value"]
            if not model:
                rm = db.execute("SELECT value FROM settings WHERE key=?", (f"{p}_model",)).fetchone()
                if rm and rm["value"]: model = rm["value"]
        db.close()
    result = await test_provider_connection(req.provider, key or "", base_url, model)
    return result

@app.post("/api/settings/test-webhooks")
async def test_webhooks_endpoint(req: Optional[TestWebhooksIn] = None, user=Depends(require_admin)):
    db = get_db()
    settings_dict = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings")}
    db.close()

    slack_url = (req.slack_webhook_url if req and req.slack_webhook_url is not None else settings_dict.get("slack_webhook_url", "")).strip()
    teams_url = (req.teams_webhook_url if req and req.teams_webhook_url is not None else settings_dict.get("teams_webhook_url", "")).strip()
    server_base_url = (settings_dict.get("server_base_url") or "http://172.19.74.165:8000").rstrip("/")

    if not slack_url and not teams_url:
        raise HTTPException(400, "Neither Slack nor Teams webhook URL is configured. Please provide or save a webhook URL first.")

    results = {}
    time_str = datetime.now(configured_timezone()).strftime("%Y-%m-%d %H:%M:%S %Z")

    async with httpx.AsyncClient() as client:
        if slack_url:
            slack_payload = {
                "text": "🧪 Postall_V4 Webhook Test Alert",
                "blocks": [
                    {
                        "type": "header",
                        "text": {"type": "plain_text", "text": "🧪 Postall_V4 Webhook Test Alert"}
                    },
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"This is an automated test notification dispatched from *Postall_V4* at `{time_str}`.\n\nYour Slack incoming webhook is active and ready to receive review alerts!"
                        }
                    },
                    {
                        "type": "actions",
                        "elements": [
                            {
                                "type": "button",
                                "text": {"type": "plain_text", "text": "Open Dashboard"},
                                "style": "primary",
                                "url": server_base_url
                            }
                        ]
                    }
                ]
            }
            try:
                resp = await client.post(slack_url, json=slack_payload, timeout=10.0)
                if resp.status_code < 400:
                    results["slack"] = {"status": "success", "message": f"Slack test delivered successfully (HTTP {resp.status_code})."}
                else:
                    results["slack"] = {"status": "error", "message": f"Slack rejected webhook (HTTP {resp.status_code}): {resp.text[:120]}"}
            except Exception as exc:
                results["slack"] = {"status": "error", "message": f"Slack request error: {str(exc)[:120]}"}
        else:
            results["slack"] = {"status": "not_configured", "message": "Slack webhook URL is empty."}

        if teams_url:
            teams_payload = {
                "@type": "MessageCard",
                "@context": "http://schema.org/extensions",
                "themeColor": "0076D7",
                "summary": "Postall_V4 Webhook Test Alert",
                "title": "🧪 Postall_V4 Webhook Test Alert",
                "text": f"This is an automated test notification dispatched from **Postall_V4** at `{time_str}`.\n\nYour Microsoft Teams webhook is active and ready to receive review alerts!",
                "potentialAction": [
                    {
                        "@type": "OpenUri",
                        "name": "Open Dashboard",
                        "targets": [{"os": "default", "uri": server_base_url}]
                    }
                ]
            }
            try:
                resp = await client.post(teams_url, json=teams_payload, timeout=10.0)
                if resp.status_code < 400:
                    results["teams"] = {"status": "success", "message": f"Microsoft Teams test delivered successfully (HTTP {resp.status_code})."}
                else:
                    results["teams"] = {"status": "error", "message": f"Teams rejected webhook (HTTP {resp.status_code}): {resp.text[:120]}"}
            except Exception as exc:
                results["teams"] = {"status": "error", "message": f"Teams request error: {str(exc)[:120]}"}
        else:
            results["teams"] = {"status": "not_configured", "message": "Teams webhook URL is empty."}

    return {"status": "success", "results": results}

@app.post("/api/social/test-connection")
def test_social_connection(req: SocialTestIn, user=Depends(current_user)):
    platform = req.platform.lower().strip()
    if platform == "linkedin":
        try:
            res = verify_linkedin_connection(token=req.token)
            return {"status": "success", "platform": "linkedin", "profile": res}
        except Exception as exc:
            raise HTTPException(400, f"LinkedIn verification failed: {exc}")
    elif platform in ("x", "twitter"):
        try:
            res = verify_x_connection(
                api_key=req.api_key,
                api_secret=req.api_secret,
                access_token=req.access_token,
                access_token_secret=req.access_token_secret,
                user_access_token=req.user_access_token or req.token,
            )
            return {"status": "success", "platform": "x", "profile": res}
        except Exception as exc:
            raise HTTPException(400, f"X (Twitter) verification failed: {exc}")
    else:
        raise HTTPException(400, f"Unknown social platform: {platform}")
@app.get("/api/logs")
def logs(user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db()
    out=[row(x) for x in db.execute("SELECT * FROM system_logs WHERE workspace_id=? OR workspace_id IS NULL ORDER BY id DESC LIMIT 200", (ws_id,)).fetchall()]
    db.close()
    return out
@app.get("/api/analytics")
def analytics(user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db()
    counts={r["status"]:r["n"] for r in db.execute("SELECT status,COUNT(*) n FROM drafts WHERE workspace_id=? GROUP BY status", (ws_id,))}
    events=[row(x) for x in db.execute("SELECT * FROM publish_events ORDER BY id DESC LIMIT 100").fetchall()]
    db.close()
    return {"drafts":counts,"publish_events":events}
@app.get("/api/ondemand/history")
def history(user=Depends(current_user), ws_id: int = Depends(active_workspace_id)):
    db=get_db()
    items=[row(x) for x in db.execute("SELECT d.*,t.title topic_name,c.name course_name FROM drafts d LEFT JOIN topics t ON t.id=d.topic_id LEFT JOIN courses c ON c.id=d.course_id WHERE d.workspace_id=? ORDER BY d.created_at DESC", (ws_id,)).fetchall()]
    for item in items:
        item["social_publications"]=[row(x) for x in db.execute("SELECT platform,status,post_url,error FROM social_publications WHERE draft_id=?",(item["id"],)).fetchall()]
    db.close()
    return items
@app.get("/api/models/usage")
def model_usage(user=Depends(current_user)):
    db=get_db(); out=[row(x) for x in db.execute("SELECT model,request_count,prompt_tokens,output_tokens,total_tokens FROM api_usage ORDER BY request_count DESC").fetchall()]; db.close(); return out
@app.post("/api/notifications/test")
def test_email(req: EmailIn,user=Depends(current_user)):
    db=get_db()
    d=db.execute("SELECT * FROM drafts WHERE id=?",(req.draft_id,)).fetchone() if req.draft_id else None
    s={r["key"]:r["value"] for r in db.execute("SELECT key,value FROM settings")}
    db.close()
    host=s.get("smtp_host") or os.getenv("SMTP_HOST") or "smtp.gmail.com"
    sender=s.get("smtp_sender") or os.getenv("EMAIL_SENDER")
    receiver=s.get("smtp_receiver") or os.getenv("EMAIL_RECEIVER")
    if not host or not sender or not receiver: raise HTTPException(400,"SMTP is not configured")
    if d:
        subject, content, asset = draft_email_content(d)
    else:
        subject = "Postall_V4 SMTP test"
        content = "This is a test email from Postall_V4. SMTP configuration and delivery are working."
        asset = None
    msg=EmailMessage(); msg["Subject"]=subject; msg["From"]=sender; msg["To"]=receiver
    msg.set_content(content)
    attach_asset(msg, asset)
    try:
        password=s.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD","")
        with smtplib.SMTP(host,int(s.get("smtp_port") or os.getenv("SMTP_PORT","587")),timeout=15) as smtp:
            smtp.starttls(); smtp.login(sender,password); smtp.send_message(msg)
    except Exception as exc:
        log("ERROR","EMAIL",f"SMTP test failed: {type(exc).__name__}: {str(exc)[:240]}")
        raise HTTPException(502,f"Email delivery failed: {type(exc).__name__}") from exc
    log("INFO","EMAIL","SMTP test email sent"); return {"status":"sent"}
@app.get("/api/system/metrics")
def metrics(user=Depends(current_user)):
    disk=psutil.disk_usage(str(ROOT))
    memory=psutil.virtual_memory()
    return {"database":"data/postall.db","runtime":"FastAPI","cpu_percent":psutil.cpu_percent(interval=0.05),
            "memory_percent":memory.percent,"memory_used_gb":memory.used/(1024**3),
            "memory_total_gb":memory.total/(1024**3),"disk_percent":disk.percent,
            "disk_used_gb":disk.used/(1024**3),"disk_total_gb":disk.total/(1024**3),
            "uptime_seconds":int(time.time()-psutil.boot_time())}

@app.get("/api/health")
def health():
    fastapi_status = "Online"
    db_status = "Online"
    active_feeds = 0
    cat_count = 5
    queued_count = 0
    settings = {}
    try:
        db = get_db()
        wal_row = db.execute("PRAGMA journal_mode;").fetchone()
        journal_mode = wal_row[0] if wal_row else "wal"
        db_status = f"Online ({journal_mode.upper()} mode active)"
        
        feed_cnt_row = db.execute("SELECT COUNT(*) as cnt FROM trending_sources WHERE is_active=1").fetchone()
        active_feeds = feed_cnt_row["cnt"] if feed_cnt_row else 0

        cat_cnt_row = db.execute("SELECT COUNT(DISTINCT category_id) as cnt FROM trending_sources").fetchone()
        if cat_cnt_row and cat_cnt_row["cnt"]:
            cat_count = cat_cnt_row["cnt"]

        draft_cnt_row = db.execute("SELECT COUNT(*) as cnt FROM drafts WHERE status IN ('DRAFT', 'SCHEDULED')").fetchone()
        queued_count = draft_cnt_row["cnt"] if draft_cnt_row else 0

        settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings").fetchall()}
        db.close()
    except Exception as exc:
        logger.exception("Health check error reading database")
        db_status = "Degraded"

    autopilot_enabled = str(settings.get("autopilot_enabled", "0")).strip().lower() in {"1", "true", "on", "yes"}
    autopilot_daemon = "Active" if autopilot_enabled else "Paused"
    trending_engine_str = f"Operational ({active_feeds} Active Feeds)"

    slack_url = settings.get("slack_webhook_url") or settings.get("webhook_url") or ""
    teams_url = settings.get("teams_webhook_url") or ""
    slack_status = "Active" if slack_url else "Standby"
    teams_status = "Active" if teams_url else "Standby"
    if slack_url and teams_url:
        webhook_alerts = "Configured (Slack & Teams)"
    elif slack_url:
        webhook_alerts = "Configured (Slack Active)"
    elif teams_url:
        webhook_alerts = "Configured (Teams Active)"
    else:
        webhook_alerts = "Disabled"

    smtp_host = settings.get("smtp_host") or os.getenv("SMTP_HOST") or ""
    smtp_status = "Configured" if smtp_host else "Disabled"

    try:
        _, local_enabled = ai_engine_settings()
    except Exception:
        local_enabled = False

    local_status = "Disabled" if not local_enabled else ("Online" if local_llm is not None else "Standby")
    try:
        mem_mb = round(psutil.Process().memory_info().rss / (1024 * 1024), 1)
    except Exception:
        mem_mb = 450.0

    if local_status == "Online":
        local_llm_str = f"Online ({int(mem_mb)} MB allocated)"
    elif local_status == "Standby":
        local_llm_str = "Standby (Ready on demand)"
    else:
        local_llm_str = "Disabled"

    gemini_key = settings.get("gemini_api_key") or os.getenv("GEMINI_API_KEY") or ""
    gemini_status = "Configured" if gemini_key else "Quota Exhausted"

    ai_key = settings.get("openai_api_key") or settings.get("ai_api_key") or settings.get("deepseek_api_key") or ""
    openai_status = "Configured" if ai_key else "Standby"

    li_tok = settings.get("linkedin_token") or settings.get("linkedin_access_token") or os.getenv("LINKEDIN_TOKEN") or ""
    linkedin_api = "Connected (OAuth 2.0)" if li_tok else "Token Required"

    tw_key = settings.get("twitter_api_key") or os.getenv("X_API_KEY") or ""
    twitter_api = "Configured" if tw_key else "Credentials Required"

    if LICENSE_VALID:
        days_left = LICENSE_PAYLOAD.get("days_remaining", 30)
        client_org = LICENSE_PAYLOAD.get("client_name") or LICENSE_PAYLOAD.get("issued_to") or "Enterprise Client"
        license_status_str = f"Active & Licensed ({days_left}d remaining)"
        lic_gate_status = "Active & Licensed"
    else:
        days_left = 0
        client_org = "Unlicensed Node"
        license_status_str = "Unlicensed"
        lic_gate_status = "Unlicensed"

    try:
        from backend.audit_streamer import get_siem_status
        siem_telemetry = get_siem_status()
    except Exception:
        siem_telemetry = {"siem_enabled": False, "status": "Standby"}

    try:
        from backend.vault import get_vault_status
        vault_telemetry = get_vault_status()
    except Exception:
        vault_telemetry = {"active_provider": "Local Encrypted Fernet Vault"}

    try:
        from backend.social_analytics import get_engagement_summary
        analytics_summary = get_engagement_summary().get("totals", {})
    except Exception:
        analytics_summary = {"posts_tracked": 0, "avg_engagement_rate": 0.0}

    try:
        from backend.storage import get_storage_provider
        sp = get_storage_provider()
        storage_telemetry = {
            "provider": sp.provider_name,
            "status": "Operational",
            "health": sp.health_check()
        }
    except Exception as exc:
        storage_telemetry = {"provider": "local", "status": "Degraded", "error": str(exc)}

    try:
        from backend.task_queue import get_task_queue
        task_telemetry = get_task_queue().get_metrics()
    except Exception as exc:
        task_telemetry = {"counts": {}, "error": str(exc)}

    return {
        "status": "Online" if db_status != "Degraded" else "Degraded",
        "fastapi": "Online",
        "fastapi_status": fastapi_status,
        "database": "Online" if db_status != "Degraded" else "Unavailable",
        "database_status": db_status,
        "autopilot_daemon": {
            "status": autopilot_daemon,
            "buffer_depth": f"{queued_count}/3 Days Queued",
            "interval": "60s"
        },
        "autopilot_daemon_status": autopilot_daemon,
        "autopilot_last_tick": AUTOPILOT_LAST_TICK,
        "trending_engine": {
            "status": "Operational",
            "active_sources": active_feeds,
            "cached_categories": cat_count
        },
        "trending_engine_status": trending_engine_str,
        "local_ai": {
            "status": local_status,
            "model": "Qwen2.5-1.5B-Instruct-GGUF",
            "allocated_ram": f"{mem_mb} MB"
        },
        "local_llm": local_llm_str,
        "local_llm_status": local_status,
        "local_llm_model": "Qwen2.5-1.5B-Instruct",
        "ai_cloud": {
            "gemini": gemini_status,
            "openai_compatible": openai_status
        },
        "gemini_api": gemini_status,
        "social_routing": {
            "linkedin": linkedin_api,
            "twitter": twitter_api
        },
        "linkedin_api": linkedin_api,
        "twitter_api": twitter_api,
        "notifications": {
            "smtp": smtp_status,
            "slack_webhook": slack_status,
            "teams_webhook": teams_status
        },
        "webhook_alerts": webhook_alerts,
        "license_gate": {
            "status": lic_gate_status,
            "valid_days": days_left,
            "client": client_org
        },
        "license_status": license_status_str,
        "siem_audit": siem_telemetry,
        "secrets_vault": vault_telemetry,
        "social_analytics": analytics_summary,
        "storage": storage_telemetry,
        "task_queue": task_telemetry,
    }

@app.get("/api/deployment/status")
def deployment_status(user=Depends(current_user)):
    warnings_path=ROOT/"data"/"deployment_warnings.txt"
    try:
        warnings=[line.strip() for line in warnings_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    except FileNotFoundError:
        warnings=[]
    except OSError as exc:
        logger.exception("Could not read deployment warnings")
        raise HTTPException(500,"Deployment status could not be read") from exc
    return {"status":"completed_with_warnings" if warnings else "completed","warnings":warnings}

@app.get("/api/status")
def status(user=Depends(current_user)):
    status=local_llm_status()
    gemini_enabled,_=ai_engine_settings()
    return {
        "status":"Online",
        "enable_gemini_api":gemini_enabled,
        "enable_local_llm":status!="Disabled",
        "local_llm_status":status,
        "local_llm_model":"Qwen2.5-1.5B-Instruct",
    }

# =====================================================================
# PROMO & ADS GENERATOR (Local LLM Powered, Token-Conserving)
# =====================================================================

@app.post("/api/promo/generate")
async def generate_promo_ad(
    objective: str = Form(...),
    brand_name: Optional[str] = Form(None),
    brand: Optional[str] = Form(None),
    key_dates: Optional[str] = Form(None),
    dates: Optional[str] = Form(None),
    context_hook: Optional[str] = Form(None),
    context: Optional[str] = Form(None),
    logo: Optional[UploadFile] = File(None),
    user=Depends(current_user),
    ws_id: int = Depends(active_workspace_id)
):
    objective = objective.strip()
    brand_name = (brand_name or brand or "").strip()
    key_dates = (key_dates or dates or "").strip()
    context_hook = (context_hook or context or "").strip()
    if not brand_name:
        raise HTTPException(422, "Brand / Company Name is required")
    if not key_dates:
        raise HTTPException(422, "Key Dates / Deadlines are required")
    if not context_hook:
        raise HTTPException(422, "Promotional Context / Core Hook is required")
    
    # Save optional logo upload to data/assets/
    logo_filename = None
    if logo and logo.filename:
        safe_name = re.sub(r"[^a-zA-Z0-9_.-]", "_", logo.filename)
        logo_path = ROOT / "data" / "assets" / f"logo_{int(time.time())}_{safe_name}"
        logo_path.parent.mkdir(parents=True, exist_ok=True)
        logo_bytes = await logo.read()
        if len(logo_bytes) > 0:
            logo_path.write_bytes(logo_bytes)
            logo_filename = str(logo_path.relative_to(ROOT))

    # Local LLM writes Hook, Value, CTA, Hashtags (0 Gemini tokens burned)
    prompt = (
        f"You are an expert technical marketing copywriter. Write a high-converting promotional LinkedIn post.\n"
        f"Campaign Objective: {objective}\n"
        f"Brand / Company: {brand_name}\n"
        f"Key Dates / Deadlines: {key_dates}\n"
        f"Hook / Promotional Context: {context_hook}\n\n"
        f"Structure the LinkedIn post exactly:\n"
        f"1. Compelling 2-line HOOK that stops the feed scroll.\n"
        f"2. Three high-impact VALUE bullet points explaining why to join/attend.\n"
        f"3. Direct CALL TO ACTION (CTA) highlighting the deadline ({key_dates}).\n"
        f"4. 4-5 relevant industry hashtags.\n"
        f"Return ONLY the post text without markdown fences or meta explanation."
    )

    try:
        post_body = await generate_with_local_llm(prompt, max_tokens=350)
    except Exception as exc:
        log("WARNING", "PROMO", f"Local LLM promo copy generation failed ({exc}); routing to light task fallback.")
        try:
            post_body = await execute_task("light", prompt)
        except Exception as exc_fallback:
            log("WARNING", "PROMO", f"Cloud fallback also unavailable ({exc_fallback}); using dynamic high-conversion template.")
            post_body = (
                f"🚀 Announcement: {objective} · {brand_name}\n\n"
                f"{context_hook}\n\n"
                f"Key Takeaways:\n"
                f"• Comprehensive hands-on coverage tailored for engineering & tech leaders\n"
                f"• Production-ready blueprints, best practices, and enterprise architectures\n"
                f"• Live Q&A and interactive deep dive sessions\n\n"
                f"🗓️ Important Timeline / Deadline: {key_dates}\n\n"
                f"Register and secure your access today!\n\n"
                f"#{re.sub(r'[^a-zA-Z0-9]', '', brand_name)} #EnterpriseTech #Innovation #Leadership"
            )

    topic_title = f"{objective} - {brand_name}"
    slug = re.sub(r"[^a-z0-9]+", "-", f"promo-{objective}-{brand_name}".lower()).strip("-")[:40] or "promo-ad"
    created_at = datetime.now(configured_timezone())

    promo_data = {
        "brand_name": brand_name,
        "objective": objective,
        "key_dates": key_dates,
        "headline": f"{objective} · {brand_name}",
        "context_hook": context_hook,
        "logo_path": logo_filename
    }

    # Check Brand Safety guardrails
    post_body, draft_status, violations = check_and_apply_brand_safety(post_body, "DRAFT")
    if violations:
        log("WARNING", "GUARDRAILS", f"Promo draft flagged for brand safety violations: {violations}")

    # Save as standard draft
    db = get_db()
    cur = db.execute(
        "INSERT INTO drafts(course_id, topic_id, prompt, body, status, created_at, workspace_id) VALUES(NULL, NULL, ?, ?, ?, ?, ?)",
        (f"[PROMO] {objective} - {brand_name}", post_body, draft_status, created_at.isoformat(timespec="seconds"), ws_id)
    )
    did = cur.lastrowid
    db.commit()
    db.close()

    # Generate Hero Banner SVG (1080x1350)
    svg_document = render_hero_banner_svg(promo_data, created_at)
    folder = post_artifact_dir(topic_title, created_at, slug)
    folder.mkdir(parents=True, exist_ok=True)
    asset_root = ROOT / "data" / "assets"
    asset_root.mkdir(parents=True, exist_ok=True)

    (folder / "infographic.svg").write_text(svg_document, encoding="utf-8")
    (asset_root / f"draft-{did}.svg").write_text(svg_document, encoding="utf-8")
    (folder / "README.md").write_text(post_body + f"\n\n---\nCampaign: {objective} · {brand_name}\nKey Dates: {key_dates}\n", encoding="utf-8")

    image_path = asset_root / f"draft-{did}.png"
    try:
        import cairosvg
        cairosvg.svg2png(bytestring=svg_document.encode("utf-8"), write_to=str(image_path), output_width=1080, output_height=1350)
    except Exception as exc:
        log("ERROR", "ASSETS", f"CairoSVG promo banner render failed ({exc})")
        if not image_path.exists():
            image_path = asset_root / f"draft-{did}.svg"

    if image_path.exists():
        (folder / "infographic.png").write_bytes(image_path.read_bytes())
        try:
            from backend.storage import get_storage_provider
            sp = get_storage_provider()
            rel_asset = str(image_path.relative_to(ROOT))
            sp.save_file(rel_asset, image_path.read_bytes(), content_type="image/png")
        except Exception as exc:
            logger.debug(f"[STORAGE] Promo storage sync error: {exc}")

    rel_image_path = str(image_path.relative_to(ROOT))
    rel_artifact_path = str(folder.relative_to(ROOT))

    db = get_db()
    db.execute("UPDATE drafts SET asset_path=?, asset_type='infographic', artifact_path=? WHERE id=?", (rel_image_path, rel_artifact_path, did))
    db.commit()
    db.close()

    log("INFO", "PROMO", f"Promotional draft #{did} generated for '{topic_title}' using Postall_V4 AI (0 cloud tokens)")
    d_obj = draft(did, user)
    asyncio.create_task(dispatch_platform_alerts("draft_ready", d_obj))
    return {
        "status": "success",
        "draft_id": did,
        "id": did,
        "title": topic_title,
        "post_body": post_body,
        "body": post_body,
        "post_content": post_body,
        "graphic_url": f"/api/drafts/{did}/asset",
        "image_path": rel_image_path,
        "asset_path": rel_image_path,
        "draft": d_obj
    }


# =====================================================================
# DATABASE MAINTENANCE, FULL BACKUP, RESTORE & OTP FACTORY RESET
# =====================================================================

PURGE_OTP_STORE: Dict[str, Any] = {"otp": None, "expires_at": 0.0, "email": ""}

class PurgeExecuteIn(BaseModel):
    password: Optional[str] = ""
    otp: Optional[str] = ""
    confirm_text: Optional[str] = ""

@app.get("/api/maintenance/backup")
def full_backup(user=Depends(require_admin)):
    """Creates a ZIP archive containing data/postall.db and the data/posts/ directory."""
    checkpoint_db()
    db_file = ROOT / "data" / "postall.db"
    posts_dir = ROOT / "data" / "posts"

    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        if db_file.exists():
            zf.write(db_file, arcname="postall.db")
        if posts_dir.exists():
            for p in posts_dir.rglob("*"):
                if p.is_file():
                    arc_name = str(Path("posts") / p.relative_to(posts_dir))
                    zf.write(p, arcname=arc_name)

    zip_buffer.seek(0)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"postall_backup_{timestamp}.zip"
    log("INFO", "MAINTENANCE", f"Full backup archive generated ({filename})")
    return Response(
        content=zip_buffer.getvalue(),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@app.post("/api/maintenance/restore")
async def full_restore(file: UploadFile = File(...), user=Depends(require_admin)):
    """Restores data/postall.db and data/posts/ from an uploaded ZIP archive."""
    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(400, "Uploaded file must be a ZIP archive (.zip)")
    content = await file.read()
    if len(content) < 100:
        raise HTTPException(400, "Uploaded file is too small or empty")

    try:
        zf = zipfile.ZipFile(BytesIO(content))
    except zipfile.BadZipFile:
        raise HTTPException(400, "Corrupt or invalid ZIP archive")

    names = zf.namelist()
    has_db = any(name in ("postall.db", "data/postall.db") for name in names)
    if not has_db:
        raise HTTPException(400, "ZIP archive must contain postall.db")

    checkpoint_db()
    db_file = ROOT / "data" / "postall.db"
    posts_dir = ROOT / "data" / "posts"
    posts_dir.mkdir(parents=True, exist_ok=True)

    # Safely extract files without directory traversal
    for item in zf.infolist():
        if ".." in item.filename or item.filename.startswith("/"):
            continue
        if item.filename in ("postall.db", "data/postall.db"):
            db_file.write_bytes(zf.read(item))
        elif item.filename.startswith("posts/") or item.filename.startswith("data/posts/"):
            rel_name = item.filename
            if rel_name.startswith("data/"):
                rel_name = rel_name[5:]
            if rel_name.startswith("posts/"):
                target = posts_dir / rel_name[6:]
                if item.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(zf.read(item))

    # Re-initialize schema and connection
    init_db()
    log("INFO", "MAINTENANCE", "Full database and post assets restored successfully from ZIP archive.")
    return {"status": "ok", "message": "Database and posts successfully restored. Please reload the dashboard."}

@app.post("/api/maintenance/request-purge")
def request_purge_otp(user=Depends(require_admin)):
    """Step 1: Generates a 6-digit OTP (5-min expiration) and emails it to the configured admin via SMTP."""
    db = get_db()
    s = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings")}
    db.close()

    otp = f"{secrets.randbelow(1000000):06d}"
    PURGE_OTP_STORE["otp"] = otp
    PURGE_OTP_STORE["expires_at"] = time.time() + 300

    host = s.get("smtp_host") or os.getenv("SMTP_HOST") or "smtp.gmail.com"
    sender = s.get("smtp_sender") or os.getenv("EMAIL_SENDER")
    receiver = s.get("smtp_receiver") or os.getenv("EMAIL_RECEIVER") or sender
    password = s.get("smtp_app_password") or os.getenv("EMAIL_APP_PASSWORD", "")
    PURGE_OTP_STORE["email"] = receiver or "admin"

    smtp_sent = False
    if host and sender and receiver:
        msg = EmailMessage()
        msg["Subject"] = "Postall_V4 · Factory Reset Security OTP"
        msg["From"] = sender
        msg["To"] = receiver
        msg.set_content(
            f"SECURITY NOTICE: Postall_V4 Database Factory Reset & Purge\n\n"
            f"Your One-Time Passcode (OTP) is:\n\n"
            f"    {otp}\n\n"
            f"This code will expire in 5 minutes.\n"
            f"If you did not initiate this action, someone may be attempting to reset your installation. "
            f"Please change your admin password immediately."
        )
        try:
            port = int(s.get("smtp_port") or os.getenv("SMTP_PORT", "587"))
            with smtplib.SMTP(host, port, timeout=15) as smtp:
                smtp.starttls()
                if password:
                    smtp.login(sender, password)
                smtp.send_message(msg)
            smtp_sent = True
            log("INFO", "MAINTENANCE", f"Factory reset OTP sent via SMTP to {receiver}")
        except Exception as exc:
            log("WARNING", "MAINTENANCE", f"Failed sending OTP via SMTP ({exc}); OTP stored in memory for verification.")
    else:
        log("INFO", "MAINTENANCE", f"SMTP not configured; OTP {otp} generated and stored in memory with 5-min expiry.")

    target_email = receiver or "the configured administrator email"
    return {
        "status": "sent",
        "expires_in": 300,
        "smtp_delivered": smtp_sent,
        "dev_otp": otp if not smtp_sent else None,
        "message": f"6-digit security OTP generated and dispatched to {target_email}. Valid for 5 minutes."
    }

@app.post("/api/maintenance/execute-purge")
def execute_purge(req: PurgeExecuteIn, user=Depends(require_admin)):
    """Step 2: Verifies authorization via Admin Password, OTP, or confirmation phrase, then executes factory reset."""
    confirm_text = (req.confirm_text or "").strip().upper()
    if confirm_text in ("CONFIRM-RESET", "FACTORY-RESET", "RESET"):
        auth_reason = f"Confirmed by authenticated operator ({user}) with reset phrase"
    else:
        # 1. Verify OTP if provided or active
        stored_otp = PURGE_OTP_STORE.get("otp")
        if req.otp or stored_otp:
            if not req.otp:
                raise HTTPException(400, "6-digit OTP passcode is required.")
            if not stored_otp:
                raise HTTPException(400, "No active OTP request found. Please request a new OTP first.")
            if time.time() > PURGE_OTP_STORE.get("expires_at", 0):
                PURGE_OTP_STORE["otp"] = None
                raise HTTPException(400, "OTP has expired. Please request a new code.")
            if not hmac.compare_digest(str(req.otp).strip(), str(stored_otp).strip()):
                raise HTTPException(400, "Invalid OTP passcode. Security verification failed.")

        # 2. Verify admin password if provided or if no OTP
        if req.password or not req.otp:
            if not req.password:
                raise HTTPException(400, "Administrator password is required.")
            db = get_db()
            admin_row = db.execute("SELECT password_hash, must_reset FROM users WHERE username='admin'").fetchone()
            db.close()
            pw_valid = False
            if admin_row:
                if verify_password(req.password, admin_row["password_hash"]):
                    pw_valid = True
                elif admin_row["must_reset"] and req.password in ("admin", "password"):
                    pw_valid = True
            if not pw_valid:
                raise HTTPException(401, "Invalid administrator password. Access denied.")
            auth_reason = "Verified via administrator credentials and security code"
        else:
            auth_reason = "Verified via one-time passcode"

    # Invalidate OTP immediately
    PURGE_OTP_STORE["otp"] = None
    PURGE_OTP_STORE["expires_at"] = 0.0

    # 3. Wipe database tables cleanly (leaving courses empty for pure factory reset)
    purge_all_tables(seed_courses=False)

    # 4. Remove physical artifact folders
    posts_dir = ROOT / "data" / "posts"
    if posts_dir.exists():
        for item in posts_dir.iterdir():
            try:
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                elif item.is_file():
                    item.unlink(missing_ok=True)
            except Exception:
                pass

    assets_dir = ROOT / "data" / "assets"
    if assets_dir.exists():
        for item in assets_dir.iterdir():
            try:
                if item.is_file() and not item.name.startswith("."):
                    item.unlink(missing_ok=True)
            except Exception:
                pass

    log("WARNING", "MAINTENANCE", f"Full factory reset executed ({auth_reason}): all database tables cleared, default admin restored, artifact folders purged.")
    return {
        "status": "purged",
        "message": "Factory reset complete. Database and post files purged. Default credentials restored: admin / admin (or admin / password)."
    }


# =====================================================================
# DYNAMIC TRENDING RADAR & RSS SOURCES MANAGEMENT
# =====================================================================

class TrendingSourceIn(BaseModel):
    category_id: Optional[str] = None
    category_label: str = Field(..., min_length=2)
    feed_name: str = Field(..., min_length=2)
    feed_url: str = Field(..., min_length=5)

class ToggleSourceIn(BaseModel):
    is_active: bool

@app.get("/api/trending/categories")
def get_trending_categories_api(user=Depends(current_user)):
    """Returns dynamic RSS categories and active source counts from trending_sources."""
    return {"categories": get_available_categories()}

@app.get("/api/trending/sources")
def get_trending_sources_api(category: Optional[str] = None, user=Depends(current_user)):
    """Lists all configured RSS feeds with active toggles."""
    return {"sources": get_trending_sources(category)}

@app.post("/api/trending/sources")
def create_trending_source_api(req: TrendingSourceIn, user=Depends(current_user)):
    """Registers a new RSS feed under a category."""
    cat_id = (req.category_id or "").strip()
    if not cat_id:
        import re
        cat_id = re.sub(r'[^a-z0-9]+', '_', req.category_label.lower()).strip('_') or "general"
    sid = add_trending_source(cat_id, req.category_label, req.feed_name, req.feed_url)
    log("INFO", "TRENDING", f"Added RSS feed source #{sid} ('{req.feed_name}') for category '{req.category_label}'")
    return {"status": "created", "id": sid, "message": f"Feed '{req.feed_name}' added to '{req.category_label}'"}

@app.delete("/api/trending/sources/{source_id}")
def delete_trending_source_api(source_id: int, user=Depends(current_user)):
    """Deletes a custom RSS feed source by ID."""
    delete_trending_source(source_id)
    log("INFO", "TRENDING", f"Deleted RSS feed source #{source_id}")
    return {"status": "deleted", "id": source_id}

@app.put("/api/trending/sources/{source_id}/toggle")
def toggle_trending_source_api(source_id: int, req: ToggleSourceIn, user=Depends(current_user)):
    """Toggles active state of an RSS feed source."""
    toggle_trending_source(source_id, req.is_active)
    state_str = "activated" if req.is_active else "deactivated"
    log("INFO", "TRENDING", f"RSS feed source #{source_id} {state_str}")
    return {"status": "updated", "id": source_id, "is_active": req.is_active}

@app.get("/api/trending/articles")
async def get_trending_articles_api(category: str = "cybersecurity", limit: int = 15, user=Depends(current_user)):
    """Fetches trending articles for a category with 30-min SQLite caching."""
    articles = await fetch_trending_articles(category=category, limit=limit)
    return {"category": category, "count": len(articles), "articles": articles}


# =====================================================================
# UNIVERSAL DOCUMENT INGESTION & CONTENT PIPELINES
# =====================================================================

@app.post("/api/pipelines/import-document")
async def import_pipeline_document(
    file: UploadFile = File(...),
    track_name: Optional[str] = Form(None),
    user=Depends(current_user)
):
    """
    Ingests and parses campaign documents (PDF, DOCX, XLSX, CSV, TXT)
    into structured content pipeline modules/topics using persona-tailored AI prompts.
    """
    if not file or not file.filename:
        raise HTTPException(400, "No document file provided for ingestion.")
    
    file_bytes = await file.read()
    if len(file_bytes) < 10:
        raise HTTPException(400, "Uploaded document is empty.")
    
    # 1. Universal Document Ingestion
    doc_text = extract_text_from_file(file_bytes, file.filename)
    if not doc_text or len(doc_text.strip()) < 20:
        raise HTTPException(422, f"Could not extract readable text from '{file.filename}'. Please verify file integrity.")
    
    # 2. Determine / create track (course)
    name = (track_name or "").strip()
    if not name:
        base_stem = Path(file.filename).stem.replace("_", " ").replace("-", " ").strip()
        name = base_stem.title() or "Imported Campaign Track"
    
    db = get_db()
    course_row = db.execute("SELECT id, name FROM courses WHERE name = ?", (name,)).fetchone()
    if course_row:
        course_id = course_row["id"]
    else:
        cursor = db.execute(
            "INSERT INTO courses (name, description, status, syllabus_url) VALUES (?, ?, 'ACTIVE', ?)",
            (name, f"Imported from {file.filename}", f"file://{file.filename}")
        )
        course_id = cursor.lastrowid
        db.commit()
    
    # 3. Read workspace persona
    settings_dict = {r["key"]: r["value"] for r in db.execute("SELECT key, value FROM settings").fetchall()}
    db.close()
    
    persona_id = settings_dict.get("workspace_persona", "tech_academy")
    
    # 4. Tailor LLM extraction prompt by persona
    if persona_id == "tech_academy":
        instruction = "Analyze this course syllabus. Extract 10-15 structured technical modules and objectives. Output as a JSON array of objects with keys: topic, summary."
    elif persona_id == "media_agency":
        instruction = "Analyze this content calendar / editorial outline. Extract scheduled campaign dates, post themes, and core hooks. Output as a JSON array of objects with keys: topic, summary."
    elif persona_id == "b2b_enterprise":
        instruction = "Analyze this strategic document / whitepaper. Extract executive thought-leadership pillars and operational takeaways. Output as a JSON array of objects with keys: topic, summary."
    else:
        instruction = "Analyze this campaign document. Extract 10-15 structured strategic content topics and actionable summaries. Output as a JSON array of objects with keys: topic, summary."
    
    system_prompt = (
        "You are an expert curriculum and campaign director. "
        "Your task is to parse unstructured enterprise documents and convert them into structured content topics. "
        "You MUST respond ONLY with a valid JSON array of objects. Each object MUST have exactly two keys: "
        "'topic' (string, concise title) and 'summary' (string, 1-2 sentence detailed overview). "
        "Do NOT return markdown fences (no ```json or ```). Return ONLY the raw JSON array."
    )
    
    user_prompt = f"{instruction}\n\nDOCUMENT CONTENT:\n{doc_text[:35000]}"
    
    items = []
    try:
        raw_ai_output = await execute_task(
            task_type="document_ingestion",
            prompt=user_prompt,
            system_prompt=system_prompt
        )
        
        clean_text = raw_ai_output.strip()
        if clean_text.startswith("```"):
            clean_text = re.sub(r"^```(?:json)?\s*", "", clean_text)
            clean_text = re.sub(r"\s*```$", "", clean_text)
        clean_text = clean_text.strip()
        
        parsed = json.loads(clean_text)
        if isinstance(parsed, list):
            for obj in parsed:
                if isinstance(obj, dict):
                    t = str(obj.get("topic") or obj.get("title") or "").strip()
                    s = str(obj.get("summary") or obj.get("details") or "").strip()
                    if t:
                        items.append({"topic": t, "summary": s})
    except Exception as exc:
        log("WARNING", "PIPELINES", f"AI extraction encountered error ({exc}); using fallback line extraction.")
    
    # Fallback if AI produced no items
    if not items:
        lines = [l.strip().lstrip("*-#0123456789. ") for l in doc_text.splitlines() if len(l.strip()) > 8]
        seen = set()
        for line in lines[:15]:
            if line not in seen:
                seen.add(line)
                items.append({
                    "topic": line[:100],
                    "summary": f"Key learning objective and core module: {line}"
                })
    
    if not items:
        items = [
            {"topic": f"{name} - Module 1: Foundational Principles", "summary": "Core architectural concepts and preliminary operational context."},
            {"topic": f"{name} - Module 2: Enterprise Implementation", "summary": "Deployment workflows, integration mechanics, and best practices."},
            {"topic": f"{name} - Module 3: Security & Governance", "summary": "Access controls, telemetry verification, and regulatory compliance."},
        ]
    
    # 5. Insert into topics table under course_id
    db = get_db()
    inserted_count = 0
    for it in items:
        existing = db.execute(
            "SELECT id FROM topics WHERE course_id = ? AND title = ?",
            (course_id, it["topic"])
        ).fetchone()
        if not existing:
            db.execute(
                "INSERT INTO topics (course_id, title, details, status) VALUES (?, ?, ?, 'PENDING')",
                (course_id, it["topic"], it["summary"])
            )
            inserted_count += 1
    db.commit()
    db.close()
    
    log("INFO", "PIPELINES", f"Imported document '{file.filename}' into pipeline '{name}': {inserted_count} new topics created.")
    
    return {
        "status": "success",
        "track_id": course_id,
        "track_name": name,
        "filename": file.filename,
        "persona_used": persona_id,
        "topics_created": inserted_count,
        "total_extracted": len(items),
        "topics": items
    }


# =====================================================================
# ENTERPRISE OVER-THE-AIR (OTA) UPDATE & MAINTENANCE ENGINE
# =====================================================================

@app.get("/api/system/update/status")
async def get_update_status(user=Depends(current_user)):
    """
    Returns current version, git commit hash, build timestamp, configured public GitHub releases repo,
    update channel, last check timestamp, and recent entries from update_history.
    """
    db = get_db()
    settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings").fetchall()}
    db.close()

    repo = settings.get("github_releases_repo") or settings.get("github_repo") or settings.get("github_repo_url") or "randumduck/Postall_V4-Releases"
    pat = settings.get("github_pat", "")
    ver_info = get_current_version()
    current_ver = str(ver_info)
    git_commit = ver_info.get("git_commit", "dev") if isinstance(ver_info, dict) else "dev"
    build_date = ver_info.get("build_date", "") if isinstance(ver_info, dict) else ""
    target_arch = ver_info.get("target_arch", "linux-x86_64") if isinstance(ver_info, dict) else "linux-x86_64"
    history = get_update_history(limit=10)
    oracle_status = get_cached_ota_status()

    return {
        "status": "operational",
        "current_version": oracle_status.get("current_version") or CURRENT_VERSION,
        "offline": oracle_status.get("oracle_reachable") is False,
        "version": current_ver,
        "git_commit": git_commit,
        "build_date": build_date,
        "target_arch": target_arch,
        "github_releases_repo": repo,
        "github_repo": repo,
        "update_channel": settings.get("update_channel", "stable"),
        "auto_check_updates": settings.get("auto_check_updates", "1") not in ("0", "false", "off"),
        "last_update_check": settings.get("last_update_check") or None,
        "has_pat": bool(pat and pat.strip()),
        "pat_masked": (pat[:4] + "..." + pat[-4:]) if (pat and len(pat) > 8) else ("Configured" if pat else "Not Configured"),
        "update_history": history,
        "history": history,
        **oracle_status
    }


@app.api_route("/api/system/update/check", methods=["GET", "POST"])
async def check_update_api(request: Request, user=Depends(current_user)):
    """
    Queries public GitHub releases repository for updates.
    Updates last_update_check timestamp in SQLite and returns update status, changelog, and sha256 checksum URL.
    """
    if request.method == "POST":
        ota_status = await check_ota_update()
        changelog_entries = ota_status.get("changelog", [])
        return {
            **ota_status,
            "current": ota_status.get("current_version"),
            "latest": ota_status.get("latest_version"),
            "notes": "\n".join(changelog_entries) if isinstance(changelog_entries, list) else "",
            "download_url": ota_status.get("patch_url") or "",
            "sha256_url": "",
            "sha256": ota_status.get("patch_sha256") or "",
            "asset_name": Path(ota_status.get("patch_url") or "").name,
            "repo": "randumduck/Postall_V4-Releases",
            "last_update_check": ota_status.get("last_checked_at"),
        }

    db = get_db()
    settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings").fetchall()}
    
    repo = settings.get("github_releases_repo") or settings.get("github_repo") or settings.get("github_repo_url") or "randumduck/Postall_V4-Releases"
    pat = settings.get("github_pat", "")
    ver_info = get_current_version()
    current_ver = str(ver_info)

    now_iso = datetime.now().isoformat()
    try:
        db.execute("INSERT INTO settings(key,value) VALUES('last_update_check',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (now_iso,))
        db.commit()
    except Exception as exc:
        logger.warning(f"Could not update last_update_check in settings: {exc}")
    finally:
        db.close()

    try:
        rel = await check_github_releases(repo, pat=pat)
    except Exception as exc:
        log("WARNING", "UPDATE", f"GitHub release check failed for '{repo}': {exc}")
        return {
            "update_available": False,
            "current_version": ver_info,
            "latest_version": current_ver,
            "current": current_ver,
            "latest": current_ver,
            "git_commit": ver_info.get("git_commit", "dev") if isinstance(ver_info, dict) else "dev",
            "changelog": f"Could not check GitHub releases: {exc}",
            "notes": f"Could not check GitHub releases: {exc}",
            "download_url": "",
            "sha256_url": "",
            "sha256": "",
            "asset_name": "",
            "repo": repo,
            "last_update_check": now_iso,
            "error": str(exc)
        }

    rel["current"] = current_ver
    rel["current_version"] = ver_info
    rel["latest"] = rel.get("latest") or rel.get("latest_version") or current_ver
    rel["notes"] = rel.get("notes") or rel.get("changelog", "")
    rel["repo"] = repo
    rel["last_update_check"] = now_iso
    return rel


@app.post("/api/system/update/apply")
@app.post("/api/system/update/apply-ota")
async def apply_ota_update_api(
    background_tasks: BackgroundTasks,
    req: Optional[ApplyOtaIn] = None,
    user=Depends(require_admin)
):
    """
    Admin-only route. Downloads the compiled release asset from public GitHub repository,
    creates pre-flight snapshot, verifies SHA-256 hash, extracts .so binaries,
    inserts audit record into update_history, and schedules container restart.
    """
    if req is None or not req.download_url:
        status = await check_ota_update()
        if not status.get("oracle_reachable"):
            raise HTTPException(502, status.get("error", "Version Oracle is unreachable."))
        if not status.get("patch_available"):
            if status.get("update_available"):
                raise HTTPException(409, "A newer release is listed, but no verified OTA patch archive is available.")
            raise HTTPException(409, "No newer OTA patch is available.")
        background_tasks.add_task(apply_latest_patch, status)
        return {
            "status": "accepted",
            "message": "The verified Version Oracle patch is being applied in the background."
        }

    operator_username = user.get("username", "admin") if isinstance(user, dict) else str(user)
    url = req.download_url if req and req.download_url else ""
    expected_sha256 = (req.expected_sha256 or req.sha256) if req else None

    db = get_db()
    settings = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings").fetchall()}
    db.close()

    pat = settings.get("github_pat", "")
    repo = settings.get("github_releases_repo") or settings.get("github_repo") or settings.get("github_repo_url") or "randumduck/Postall_V4-Releases"

    if not url:
        rel = await check_github_releases(repo, pat)
        url = rel.get("download_url")
        if not expected_sha256 and rel.get("sha256"):
            expected_sha256 = rel.get("sha256")

    if not url:
        raise HTTPException(400, "No download URL available for update payload.")

    try:
        res = await apply_update(download_url=url, expected_sha256=expected_sha256, user=operator_username, pat=pat)
    except Exception as exc:
        log("ERROR", "UPDATE", f"OTA update failed: {exc}")
        raise HTTPException(500, f"OTA update failed: {exc}")

    trigger_restart(delay_seconds=1.5)
    log("INFO", "UPDATE", f"OTA update applied ({res.get('extracted_count', 0)} files) by '{operator_username}'. Restarting container...")
    return {
        "status": "success",
        "message": "Update extracted successfully. Container reboot initiated.",
        "snapshot_path": res.get("snapshot_path"),
        "extracted_count": res.get("extracted_count", 0),
        "skipped_count": res.get("skipped_count", 0),
        "to_version": res.get("to_version"),
        "git_commit": res.get("git_commit")
    }


@app.get("/api/system/update/ledger")
async def get_update_audit_ledger(user=Depends(current_user)):
    try:
        return list_update_audit_ledger()
    except sqlite3.Error as exc:
        logger.exception("Could not read the OTA update audit ledger.")
        raise HTTPException(500, "Could not read the update audit ledger.") from exc


@app.post("/api/system/update/manual-upload")
@app.post("/api/system/update/manual")
async def manual_update_api(
    patch_archive: Optional[UploadFile] = File(None),
    file: Optional[UploadFile] = File(None),
    user=Depends(require_admin)
):
    """
    Admin-only route. Accepts an uploaded update .zip for air-gapped systems, creates a pre-update snapshot,
    extracts the update payload preserving persistent volumes, records audit entry in update_history,
    and triggers container reboot.
    """
    operator_username = user.get("username", "admin") if isinstance(user, dict) else str(user)
    uploaded = patch_archive or file
    if not uploaded:
        raise HTTPException(400, "No update file uploaded.")

    if not uploaded.filename.lower().endswith(".zip"):
        raise HTTPException(400, "Update package must be a .zip archive.")

    content = await uploaded.read()
    if len(content) < 100:
        raise HTTPException(400, "Uploaded update package is empty or corrupted.")

    import tempfile
    try:
        tmp_dir = Path("/tmp")
        tmp_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        tmp_dir = Path(tempfile.gettempdir())

    target_zip = tmp_dir / f"manual_{int(time.time())}.zip"
    target_zip.write_bytes(content)

    # 1. Create pre-update snapshot
    from_ver_info = get_current_version()
    from_ver = str(from_ver_info)
    snapshot_path = create_snapshot()

    # 2. Extract payload safely
    try:
        res = extract_update_payload(str(target_zip))
    except Exception as exc:
        log("ERROR", "UPDATE", f"Extraction of manual update payload failed: {exc}")
        raise HTTPException(500, f"Failed to extract manual update package: {exc}")
    finally:
        if target_zip.exists():
            try:
                target_zip.unlink()
            except Exception:
                pass

    # Read updated version manifest
    to_ver_info = get_current_version()
    to_ver = str(to_ver_info)
    git_commit = to_ver_info.get("git_commit", "") if isinstance(to_ver_info, dict) else ""

    log_update_history(
        from_version=from_ver,
        to_version=to_ver,
        git_commit=git_commit,
        status="SUCCESS",
        applied_by=operator_username,
        details=f"Manual zip upload: '{uploaded.filename}'. {res['extracted_count']} files updated."
    )

    trigger_restart(delay_seconds=1.5)
    log("INFO", "UPDATE", f"Manual update applied from '{uploaded.filename}' ({res['extracted_count']} files) by '{operator_username}'. Restarting container...")
    return {
        "status": "success",
        "message": f"Manual update '{uploaded.filename}' extracted successfully. Container reboot initiated.",
        "snapshot_path": snapshot_path,
        "extracted_count": res.get("extracted_count", 0),
        "skipped_count": res.get("skipped_count", 0),
        "from_version": from_ver,
        "to_version": to_ver,
        "git_commit": git_commit
    }


@app.get("/api/system/update/history")
def get_update_history_api(limit: int = 50, user=Depends(current_user)):
    """Returns the immutable update history audit ledger from postall.db."""
    return {"history": get_update_history(limit=limit)}


@app.post("/api/system/update/rollback")
def rollback_update_api(req: RollbackIn, user=Depends(require_admin)):
    """
    Admin-only route. Restores application code from a selected snapshot in data/backups/
    and triggers a graceful container restart.
    """
    operator_username = user.get("username", "admin") if isinstance(user, dict) else str(user)
    if not req.snapshot_filename:
        raise HTTPException(400, "Snapshot filename is required.")

    try:
        res = rollback_snapshot(req.snapshot_filename, user=operator_username)
    except FileNotFoundError as exc:
        raise HTTPException(404, str(exc))
    except PermissionError as exc:
        raise HTTPException(403, str(exc))
    except Exception as exc:
        log("ERROR", "UPDATE", f"Rollback failed: {exc}")
        raise HTTPException(500, f"Rollback failed: {exc}")

    trigger_restart(delay_seconds=1.5)
    log("INFO", "UPDATE", f"Rollback to snapshot '{req.snapshot_filename}' executed. Restarting container...")
    return {
        "status": "success",
        "message": f"Rollback to snapshot '{req.snapshot_filename}' executed. Container rebooting...",
        "restored_count": res.get("restored_count", 0)
    }


@app.get("/api/system/update/snapshots")
def get_update_snapshots(user=Depends(current_user)):
    """Returns the list of available pre-update snapshots in data/backups/."""
    return {"snapshots": list_snapshots()}


@app.post("/api/system/update/config")
def update_system_config(req: UpdateConfigIn, user=Depends(require_admin)):
    """Allows administrators to configure GitHub releases repo, PAT, and update channel."""
    db = get_db()
    if req.github_releases_repo is not None:
        db.execute("INSERT INTO settings(key,value) VALUES('github_releases_repo',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (req.github_releases_repo.strip(),))
    if req.github_repo is not None:
        db.execute("INSERT INTO settings(key,value) VALUES('github_repo',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (req.github_repo.strip(),))
        db.execute("INSERT INTO settings(key,value) VALUES('github_releases_repo',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (req.github_repo.strip(),))
        db.execute("INSERT INTO settings(key,value) VALUES('github_repo_url',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (req.github_repo.strip(),))
    if req.github_pat is not None and req.github_pat.strip():
        db.execute("INSERT INTO settings(key,value) VALUES('github_pat',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (req.github_pat.strip(),))
    if req.update_channel is not None:
        db.execute("INSERT INTO settings(key,value) VALUES('update_channel',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (req.update_channel.strip(),))
    if req.auto_check_updates is not None:
        val = "1" if req.auto_check_updates in (True, 1, "1", "true") else "0"
        db.execute("INSERT INTO settings(key,value) VALUES('auto_check_updates',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (val,))
    db.commit()
    db.close()
    return {"status": "success", "message": "Update configuration saved."}


# ==============================================================================
# ENTERPRISE P2 MODULE 1: SIEM AUDIT STREAMING ENDPOINTS
# ==============================================================================

class SiemTestIn(BaseModel):
    host: Optional[str] = None
    port: Optional[int] = None
    protocol: Optional[str] = None

@app.get("/api/audit/events")
def get_audit_events_api(limit: int = 50, offset: int = 0, action: Optional[str] = None, actor: Optional[str] = None, user=Depends(current_user)):
    """Returns structured audit event logs from the local persistent audit store."""
    from backend.audit_streamer import get_audit_events
    events = get_audit_events(limit=limit, offset=offset, action_filter=action, actor_filter=actor)
    return {"events": events, "count": len(events)}

@app.get("/api/audit/status")
def get_audit_status_api(user=Depends(current_user)):
    """Returns telemetry on SIEM streaming health, active protocol, and event counters."""
    from backend.audit_streamer import get_siem_status
    return get_siem_status()

@app.post("/api/audit/test-siem")
def test_siem_api(req: SiemTestIn, user=Depends(require_admin)):
    """Tests connection to remote SIEM collector port via UDP/TCP/HTTP with CEF formatted ping."""
    from backend.audit_streamer import test_siem_connection
    return test_siem_connection(host=req.host, port=req.port, protocol=req.protocol)


# ==============================================================================
# ENTERPRISE P2 MODULE 2: PLUGGABLE SECRETS VAULT ENDPOINTS
# ==============================================================================

class VaultSecretIn(BaseModel):
    key: str
    value: str

@app.get("/api/vault/status")
def get_vault_status_api(user=Depends(current_user)):
    """Returns status of pluggable secrets provider (Fernet AES-256 / HashiCorp Vault)."""
    from backend.vault import get_vault_status
    return get_vault_status()

@app.post("/api/vault/migrate")
def migrate_vault_api(user=Depends(require_admin)):
    """Admin-only. Migrates existing plaintext credentials to AES-256 Fernet encrypted tokens."""
    from backend.vault import migrate_plaintext_to_vault
    return migrate_plaintext_to_vault()

@app.post("/api/vault/secret")
def set_vault_secret_api(req: VaultSecretIn, user=Depends(require_admin)):
    """Admin-only. Stores secret encrypted at rest and synchronizes with Vault if active."""
    from backend.vault import set_secret
    success = set_secret(req.key, req.value)
    return {"status": "success" if success else "error", "key": req.key}


# ==============================================================================
# ENTERPRISE P2 MODULE 3: CLOSED-LOOP SOCIAL TELEMETRY & BI ENDPOINTS
# ==============================================================================

@app.get("/api/analytics/engagement")
def get_social_engagement_api(user=Depends(current_user)):
    """Returns engagement telemetry: impressions, clicks, reactions, CTR, and layout breakdown."""
    from backend.social_analytics import get_engagement_summary
    return get_engagement_summary()

@app.post("/api/analytics/harvest")
def harvest_social_analytics_api(user=Depends(current_user)):
    """Triggers telemetry collection across all published LinkedIn posts."""
    from backend.social_analytics import harvest_social_analytics
    return harvest_social_analytics()


# ==============================================================================
# ENTERPRISE P0 MODULE 1: PLUGGABLE OBJECT STORAGE (S3/MINIO) ENDPOINTS
# ==============================================================================

class StorageTestIn(BaseModel):
    storage_backend: Optional[str] = "local"
    s3_endpoint_url: Optional[str] = None
    s3_bucket_name: Optional[str] = None
    s3_region: Optional[str] = "us-east-1"
    s3_access_key: Optional[str] = None
    s3_secret_key: Optional[str] = None

@app.get("/api/storage/status")
def get_storage_status_api(user=Depends(current_user)):
    """Returns current storage provider health and operational telemetry."""
    from backend.storage import get_storage_provider
    sp = get_storage_provider()
    return {
        "provider": sp.provider_name,
        "health": sp.health_check()
    }

@app.post("/api/storage/test")
def test_storage_api(req: StorageTestIn, user=Depends(require_admin)):
    """Tests connectivity and round-trip read/write probe to local or S3/MinIO bucket."""
    from backend.storage import S3StorageProvider, LocalStorageProvider
    backend_choice = (req.storage_backend or "local").lower().strip()
    if backend_choice == "s3":
        if not req.s3_bucket_name:
            raise HTTPException(400, "S3 bucket name is required for testing S3 storage.")
        
        secret_key = req.s3_secret_key
        if not secret_key or secret_key == "••••••••":
            db = get_db()
            row = db.execute("SELECT value FROM settings WHERE key='s3_secret_key'").fetchone()
            db.close()
            secret_key = row["value"] if row else ""
            if not secret_key:
                try:
                    from backend.vault import get_secret_vault
                    secret_key = get_secret_vault().get_secret("s3_secret_key")
                except Exception:
                    pass

        provider = S3StorageProvider(
            bucket_name=req.s3_bucket_name,
            endpoint_url=req.s3_endpoint_url,
            region_name=req.s3_region or "us-east-1",
            access_key_id=req.s3_access_key,
            secret_access_key=secret_key
        )
    else:
        provider = LocalStorageProvider()

    return provider.health_check()


# ==============================================================================
# ENTERPRISE P0 MODULE 2: DISTRIBUTED TASK QUEUE & ACTIVITY MONITOR
# ==============================================================================

@app.get("/api/tasks/metrics")
def get_task_metrics_api(user=Depends(current_user)):
    """Returns telemetry on persistent background tasks, retry states, and dead letters."""
    from backend.task_queue import get_task_queue
    return get_task_queue().get_metrics()

@app.get("/api/tasks")
def list_tasks_api(
    status: Optional[str] = None,
    limit: int = 50,
    user=Depends(current_user)
):
    """Lists background tasks with their state, retry count, and error info.
    Optional ?status=FAILED|DEAD_LETTER|PENDING|RUNNING|COMPLETED filter.
    """
    db = get_db()
    if status:
        rows = db.execute(
            "SELECT id, name, status, priority, retry_count, max_retries, error, "
            "scheduled_for, started_at, completed_at, locked_by, created_at, updated_at "
            "FROM tasks WHERE status=? ORDER BY updated_at DESC LIMIT ?",
            (status.upper(), limit)
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT id, name, status, priority, retry_count, max_retries, error, "
            "scheduled_for, started_at, completed_at, locked_by, created_at, updated_at "
            "FROM tasks ORDER BY updated_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
    # Also grab active distributed locks
    locks = db.execute(
        "SELECT lock_name, locked_by, acquired_at, expires_at FROM distributed_locks "
        "WHERE expires_at > datetime('now')"
    ).fetchall()
    db.close()
    return {
        "tasks": [dict(r) for r in rows],
        "active_locks": [dict(lk) for lk in locks]
    }

@app.post("/api/tasks/purge-stale-locks")
def purge_stale_locks_api(user=Depends(require_admin)):
    """Removes expired distributed locks that were not released due to worker crash."""
    db = get_db()
    result = db.execute(
        "DELETE FROM distributed_locks WHERE expires_at <= datetime('now')"
    )
    count = result.rowcount
    db.commit()
    db.close()
    log("INFO", "TASK_QUEUE", f"Purged {count} stale distributed lock(s) by {user if isinstance(user, str) else user.get('username','admin')}")
    return {"status": "success", "purged_locks": count}

@app.post("/api/tasks/retry/{task_id}")
def retry_task_api(task_id: str, user=Depends(require_admin)):
    """Re-queues a failed or dead-letter task for immediate execution."""
    db = get_db()
    row = db.execute("SELECT id, status, retry_count, max_retries FROM tasks WHERE id=?", (task_id,)).fetchone()
    if not row:
        db.close()
        raise HTTPException(404, "Task not found")
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        "UPDATE tasks SET status='PENDING', scheduled_for=?, locked_by=NULL, lock_expires_at=NULL, updated_at=? WHERE id=?",
        (now_str, now_str, task_id)
    )
    db.commit()
    db.close()
    log("INFO", "TASK_QUEUE", f"Task {task_id} manually re-queued by {user if isinstance(user, str) else user.get('username','admin')}")
    return {"status": "success", "message": f"Task {task_id} re-queued for execution."}


# ==============================================================================
# ENTERPRISE P0 MODULE 3: KUBERNETES PROBES & PROMETHEUS APM METRICS
# ==============================================================================

APP_START_TIME = time.time()

@app.get("/healthz/liveness")
def k8s_liveness_probe():
    """Kubernetes liveness probe: returns 200 OK if Uvicorn process is responsive."""
    return {
        "status": "alive",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "uptime_seconds": round(time.time() - APP_START_TIME, 1)
    }

@app.get("/healthz/readiness")
def k8s_readiness_probe():
    """Kubernetes readiness probe: verifies database, storage, and engine health."""
    errors = []
    
    # 1. Verify the persistent database is writable and running in WAL mode.
    db = None
    try:
        db = get_db()
        journal_mode = db.execute("PRAGMA journal_mode").fetchone()
        if not journal_mode or str(journal_mode[0]).lower() != "wal":
            errors.append("Database journal mode is not WAL.")
        db.execute("BEGIN IMMEDIATE")
        probe = db.execute("UPDATE settings SET value=value WHERE key='dry_run_mode'")
        if probe.rowcount != 1:
            errors.append("Database write probe could not find the dry_run_mode setting.")
        db.rollback()
    except Exception as exc:
        errors.append(f"Database unavailable: {exc}")
    finally:
        if db is not None:
            db.close()

    # 2. Storage health probe
    try:
        from backend.storage import get_storage_provider
        sh = get_storage_provider().health_check()
        if sh.get("status") not in ("healthy", "operational"):
            errors.append(f"Storage volume degraded: {sh.get('error', 'unknown')}")
    except Exception as exc:
        errors.append(f"Storage probe error: {exc}")

    if errors:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "errors": errors,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        )

    return {
        "status": "ready",
        "database": "connected",
        "journal_mode": "wal",
        "storage": "operational",
        "licensed": LICENSE_VALID,
        "uptime_seconds": round(time.time() - APP_START_TIME, 1)
    }

@app.get("/metrics")
def prometheus_metrics():
    """Prometheus APM metrics exporter exposition format."""
    from backend.task_queue import get_task_queue
    q_metrics = get_task_queue().get_metrics()
    counts = q_metrics.get("counts", {})

    db = get_db()
    try:
        draft_counts = {
            r["status"]: r["cnt"]
            for r in db.execute("SELECT status, count(*) cnt FROM drafts GROUP BY status").fetchall()
        }
        courses_count = db.execute("SELECT count(*) FROM courses").fetchone()[0]
        topics_count = db.execute("SELECT count(*) FROM topics").fetchone()[0]
    except Exception:
        draft_counts = {}
        courses_count = 0
        topics_count = 0
    finally:
        db.close()

    uptime = time.time() - APP_START_TIME
    lines = [
        "# HELP postall_service_up Whether Postall_V4 service is running (1 = up)",
        "# TYPE postall_service_up gauge",
        "postall_service_up 1",
        f"postall_uptime_seconds {uptime:.1f}",
        "# HELP postall_queue_tasks Task count in persistent queue by status",
        "# TYPE postall_queue_tasks gauge",
        f'postall_queue_tasks{{status="pending"}} {counts.get("pending", 0)}',
        f'postall_queue_tasks{{status="running"}} {counts.get("running", 0)}',
        f'postall_queue_tasks{{status="retrying"}} {counts.get("retrying", 0)}',
        f'postall_queue_tasks{{status="completed"}} {counts.get("completed", 0)}',
        f'postall_queue_tasks{{status="failed"}} {counts.get("failed", 0)}',
        "# HELP postall_drafts Total drafts by editorial state",
        "# TYPE postall_drafts gauge",
        f'postall_drafts{{status="draft"}} {draft_counts.get("DRAFT", 0)}',
        f'postall_drafts{{status="scheduled"}} {draft_counts.get("SCHEDULED", 0)}',
        f'postall_drafts{{status="approved"}} {draft_counts.get("APPROVED", 0)}',
        f'postall_drafts{{status="published"}} {draft_counts.get("PUBLISHED", 0)}',
        f'postall_drafts{{status="flagged_violation"}} {draft_counts.get("FLAGGED_VIOLATION", 0)}',
        f'postall_courses_total {courses_count}',
        f'postall_topics_total {topics_count}',
    ]
    return Response(content="\n".join(lines) + "\n", media_type="text/plain; version=0.0.4; charset=utf-8")
