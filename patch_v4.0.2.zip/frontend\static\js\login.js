/**
 * Postall_V4 - Enterprise Interactive Login Engine
 * Features:
 * - Native HTML5 Canvas "Golden Sand" Particle Mesh with Distance Interconnection
 * - Magnetic Mouse Gravitational Vectoring
 * - Local & LDAP Multi-Auth Switching
 * - Secure Forgot Password Dispatch & Force Reset Workflow
 */

(function () {
    'use strict';

    /* ==========================================================================
       GOLDEN SAND PARTICLE MESH CANVAS ENGINE
       ========================================================================== */
    const canvas = document.getElementById('meshCanvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        let width = 0;
        let height = 0;
        let dpr = window.devicePixelRatio || 1;

        // Particle configuration
        const PARTICLE_COUNT = 125;
        const CONNECT_DISTANCE = 115;
        const CONNECT_DIST_SQ = CONNECT_DISTANCE * CONNECT_DISTANCE;
        const MOUSE_RADIUS = 150;
        const MOUSE_RADIUS_SQ = MOUSE_RADIUS * MOUSE_RADIUS;

        const particles = [];
        const mouse = { x: null, y: null, active: false };

        // Golden Sand Color Palette: #D4AF37, #F5D061, #B8860B
        const COLOR_GOLD_PRIMARY = { r: 212, g: 175, b: 55 };   // #D4AF37 (Classic Gold)
        const COLOR_GOLD_LIGHT   = { r: 245, g: 208, b: 97 };   // #F5D061 (Light Sand)
        const COLOR_GOLD_AMBER   = { r: 184, g: 134, b: 11 };   // #B8860B (Deep Amber)
        const GOLD_PALETTE = [COLOR_GOLD_PRIMARY, COLOR_GOLD_LIGHT, COLOR_GOLD_AMBER];

        function resize() {
            width = window.innerWidth;
            height = window.innerHeight;
            canvas.width = width * dpr;
            canvas.height = height * dpr;
            ctx.scale(dpr, dpr);
        }

        window.addEventListener('resize', resize);
        resize();

        // Mouse listeners for magnetic attraction
        window.addEventListener('mousemove', function (e) {
            mouse.x = e.clientX;
            mouse.y = e.clientY;
            mouse.active = true;
        });

        window.addEventListener('mouseleave', function () {
            mouse.x = null;
            mouse.y = null;
            mouse.active = false;
        });

        // Initialize particles with Golden Sand palette
        for (let i = 0; i < PARTICLE_COUNT; i++) {
            const color = GOLD_PALETTE[Math.floor(Math.random() * GOLD_PALETTE.length)];
            
            particles.push({
                x: Math.random() * width,
                y: Math.random() * height,
                vx: (Math.random() - 0.5) * 0.7,
                vy: (Math.random() - 0.5) * 0.7,
                radius: Math.random() * 1.5 + 1.1,
                color: color,
                alpha: Math.random() * 0.45 + 0.55
            });
        }

        // Animation frame loop
        function renderMesh() {
            ctx.clearRect(0, 0, width, height);

            const pCount = particles.length;

            // 1. Update and apply magnetic gravity physics
            for (let i = 0; i < pCount; i++) {
                const p = particles[i];

                // Mouse magnetic pull: sand clusters gently toward cursor
                if (mouse.active && mouse.x !== null) {
                    const dx = mouse.x - p.x;
                    const dy = mouse.y - p.y;
                    const distSq = dx * dx + dy * dy;

                    if (distSq < MOUSE_RADIUS_SQ && distSq > 1) {
                        const dist = Math.sqrt(distSq);
                        const force = (1 - dist / MOUSE_RADIUS) * 0.9;
                        p.x += (dx / dist) * force;
                        p.y += (dy / dist) * force;

                        // Connector ray between golden sand grain and cursor
                        const mouseAlpha = (1 - dist / MOUSE_RADIUS) * 0.45;
                        ctx.beginPath();
                        ctx.moveTo(p.x, p.y);
                        ctx.lineTo(mouse.x, mouse.y);
                        ctx.strokeStyle = `rgba(${p.color.r}, ${p.color.g}, ${p.color.b}, ${mouseAlpha})`;
                        ctx.lineWidth = 0.75;
                        ctx.stroke();
                    }
                }

                // Normal drift
                p.x += p.vx;
                p.y += p.vy;

                // Screen boundaries bounce
                if (p.x < 0) { p.x = 0; p.vx *= -1; }
                else if (p.x > width) { p.x = width; p.vx *= -1; }
                if (p.y < 0) { p.y = 0; p.vy *= -1; }
                else if (p.y > height) { p.y = height; p.vy *= -1; }

                // Draw golden sand node
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${p.color.r}, ${p.color.g}, ${p.color.b}, ${p.alpha})`;
                ctx.shadowBlur = 5;
                ctx.shadowColor = `rgba(${p.color.r}, ${p.color.g}, ${p.color.b}, 0.8)`;
                ctx.fill();
                ctx.shadowBlur = 0;
            }

            // 2. Interconnection mesh lines in Golden Sand palette
            for (let i = 0; i < pCount; i++) {
                const p1 = particles[i];
                for (let j = i + 1; j < pCount; j++) {
                    const p2 = particles[j];
                    const dx = p1.x - p2.x;
                    const dy = p1.y - p2.y;
                    const distSq = dx * dx + dy * dy;

                    if (distSq < CONNECT_DIST_SQ) {
                        const dist = Math.sqrt(distSq);
                        const alpha = (1 - dist / CONNECT_DISTANCE) * 0.32;
                        
                        ctx.beginPath();
                        ctx.moveTo(p1.x, p1.y);
                        ctx.lineTo(p2.x, p2.y);
                        
                        // Golden Sand gradient or solid stroke
                        if (p1.color !== p2.color) {
                            const grad = ctx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
                            grad.addColorStop(0, `rgba(${p1.color.r}, ${p1.color.g}, ${p1.color.b}, ${alpha})`);
                            grad.addColorStop(1, `rgba(${p2.color.r}, ${p2.color.g}, ${p2.color.b}, ${alpha})`);
                            ctx.strokeStyle = grad;
                        } else {
                            ctx.strokeStyle = `rgba(${p1.color.r}, ${p1.color.g}, ${p1.color.b}, ${alpha})`;
                        }
                        
                        ctx.lineWidth = 0.65;
                        ctx.stroke();
                    }
                }
            }

            requestAnimationFrame(renderMesh);
        }

        requestAnimationFrame(renderMesh);
    }


    /* ==========================================================================
       AUTHENTICATION LOGIC & FORM WORKFLOWS
       ========================================================================== */

    // Check if user is already authenticated
    const existingToken = localStorage.getItem('token');
    if (existingToken) {
        window.location.replace('/dashboard');
        return;
    }

    // DOM Elements
    const tabLocal = document.getElementById('tabLocal');
    const tabLdap = document.getElementById('tabLdap');

    const viewLogin = document.getElementById('viewLogin');
    const viewForgotPassword = document.getElementById('viewForgotPassword');
    const viewForceReset = document.getElementById('viewForceReset');
    const viewMfaChallenge = document.getElementById('viewMfaChallenge');

    const loginForm = document.getElementById('loginForm');
    const forgotForm = document.getElementById('forgotForm');
    const resetForm = document.getElementById('resetForm');
    const mfaForm = document.getElementById('mfaForm');
    const mfaCodeInput = document.getElementById('mfaCodeInput');
    const mfaTempToken = document.getElementById('mfaTempToken');
    const mfaSubmitBtn = document.getElementById('mfaSubmitBtn');
    const cancelMfaBtn = document.getElementById('cancelMfaBtn');
    const btnSsoLogin = document.getElementById('btnSsoLogin');

    const usernameInput = document.getElementById('usernameInput');
    const passwordInput = document.getElementById('passwordInput');
    const usernameLabel = document.getElementById('usernameLabel');
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    const ldapHint = document.getElementById('ldapHint');
    const loginTitle = document.getElementById('loginTitle');
    const loginSubtitle = document.getElementById('loginSubtitle');
    const loginSubmitBtn = document.getElementById('loginSubmitBtn');
    const loginSubmitText = document.getElementById('loginSubmitText');
    const togglePwBtn = document.getElementById('togglePwBtn');

    const forgotInput = document.getElementById('forgotInput');
    const forgotSubmitBtn = document.getElementById('forgotSubmitBtn');
    const backToLoginBtn = document.getElementById('backToLoginBtn');

    const newPasswordInput = document.getElementById('newPasswordInput');
    const confirmPasswordInput = document.getElementById('confirmPasswordInput');
    const resetSubmitBtn = document.getElementById('resetSubmitBtn');

    const authAlert = document.getElementById('authAlert');
    const authAlertText = document.getElementById('authAlertText');
    const toastContainer = document.getElementById('toast-container');

    let currentAuthType = 'local'; // 'local' | 'ldap'
    let forceResetToken = null;

    // Switch between Views
    function switchView(targetView) {
        hideAlert();
        [viewLogin, viewForgotPassword, viewForceReset, viewMfaChallenge].forEach(v => {
            if (v) v.classList.remove('active-view');
        });
        if (targetView) {
            targetView.classList.add('active-view');
        }
    }

    // Alert Messages inside Auth Card
    function showAlert(type, message) {
        if (!authAlert || !authAlertText) return;
        authAlert.className = `auth-alert auth-alert-${type} visible`;
        authAlertText.textContent = message;
    }

    function hideAlert() {
        if (!authAlert) return;
        authAlert.className = 'auth-alert';
    }

    // Floating Toasts
    function showToast(type, message, duration = 4000) {
        if (!toastContainer) return;
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        let iconSvg = '';
        if (type === 'success') {
            iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
        } else if (type === 'error') {
            iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
        } else {
            iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#F5D061" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
        }

        toast.innerHTML = `${iconSvg}<span>${message}</span>`;
        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'toastFadeOut 0.3s forwards';
            setTimeout(() => {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 300);
        }, duration);
    }

    // Toggle Password Visibility
    if (togglePwBtn && passwordInput) {
        togglePwBtn.addEventListener('click', function () {
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            togglePwBtn.innerHTML = isPassword
                ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`
                : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`;
        });
    }

    // Tab Switching: Local vs LDAP
    if (tabLocal && tabLdap) {
        tabLocal.addEventListener('click', function () {
            if (currentAuthType === 'local') return;
            currentAuthType = 'local';
            tabLocal.classList.add('active');
            tabLocal.setAttribute('aria-selected', 'true');
            tabLdap.classList.remove('active');
            tabLdap.setAttribute('aria-selected', 'false');

            // UI Adjustments for Local
            usernameLabel.textContent = 'Operator ID';
            usernameInput.placeholder = 'admin';
            forgotPasswordLink.style.display = 'inline-block';
            ldapHint.style.display = 'none';
            loginTitle.textContent = 'Operator Verification';
            loginSubtitle.textContent = 'Authenticate to initialize secure orchestration console.';
            loginSubmitText.textContent = 'Initialize Session';
            hideAlert();
        });

        tabLdap.addEventListener('click', function () {
            if (currentAuthType === 'ldap') return;
            currentAuthType = 'ldap';
            tabLdap.classList.add('active');
            tabLdap.setAttribute('aria-selected', 'true');
            tabLocal.classList.remove('active');
            tabLocal.setAttribute('aria-selected', 'false');

            // UI Adjustments for LDAP (hide Forgot Password)
            usernameLabel.textContent = 'Directory Username';
            usernameInput.placeholder = 'username@domain.com or sAMAccountName';
            forgotPasswordLink.style.display = 'none';
            ldapHint.style.display = 'flex';
            loginTitle.textContent = 'Directory Sign-In';
            loginSubtitle.textContent = 'Authenticate via corporate LDAP or Active Directory credentials.';
            loginSubmitText.textContent = 'Authenticate via LDAP';
            hideAlert();
        });
    }

    // Forgot Password link click
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', function (e) {
            e.preventDefault();
            switchView(viewForgotPassword);
            if (forgotInput) {
                forgotInput.value = usernameInput.value.trim();
                forgotInput.focus();
            }
        });
    }

    // Back to Login button
    if (backToLoginBtn) {
        backToLoginBtn.addEventListener('click', function () {
            switchView(viewLogin);
        });
    }

    /* ==========================================================================
       1. LOGIN SUBMISSION HANDLER
       ========================================================================== */
    if (loginForm) {
        loginForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();

            if (!username || !password) {
                showAlert('error', 'Please provide both username and password.');
                return;
            }

            loginSubmitBtn.disabled = true;
            const originalText = loginSubmitText.textContent;
            loginSubmitText.textContent = 'Authenticating...';

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        username: username,
                        password: password,
                        auth_type: currentAuthType
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    // Check for Mandatory Password Reset
                    if (data.status === 'force_reset' || data.must_reset) {
                        forceResetToken = data.token || data.access_token;
                        sessionStorage.setItem('reset_token', forceResetToken);
                        switchView(viewForceReset);
                        showAlert('info', 'Temporary or default passkey detected. Please define a permanent password.');
                        showToast('info', 'Password update required to proceed.');
                        if (newPasswordInput) newPasswordInput.focus();
                        return;
                    }

                    // Successful Direct Login
                    const token = data.access_token || data.token;
                    if (token) {
                        localStorage.setItem('token', token);
                        showToast('success', 'Authentication verified. Launching console...');
                        setTimeout(() => {
                            window.location.replace('/dashboard');
                        }, 400);
                    } else {
                        throw new Error('Authentication token missing from response payload.');
                    }
                } else if (response.status === 403 && (data.detail === 'MFA_REQUIRED' || data.status === 'mfa_required')) {
                    // Two-Factor Authentication Challenge
                    if (mfaTempToken) mfaTempToken.value = data.temp_token || '';
                    switchView(viewMfaChallenge);
                    showAlert('info', 'Two-Factor Authentication required. Enter the 6-digit code from your authenticator app.');
                    if (mfaCodeInput) {
                        mfaCodeInput.value = '';
                        mfaCodeInput.focus();
                    }
                    return;
                } else {
                    const errorMsg = data.detail || (currentAuthType === 'ldap' 
                        ? 'LDAP authentication failed. Verify directory credentials.' 
                        : 'Invalid operator ID or passkey.');
                    showAlert('error', errorMsg);
                }
            } catch (err) {
                showAlert('error', err.message || 'Network failure connecting to core authentication service.');
            } finally {
                loginSubmitBtn.disabled = false;
                loginSubmitText.textContent = originalText;
            }
        });
    }

    /* ==========================================================================
       2. FORGOT PASSWORD HANDLER
       ========================================================================== */
    if (forgotForm) {
        forgotForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const target = forgotInput.value.trim();
            if (!target) {
                showAlert('error', 'Please enter your Operator ID or registered email.');
                return;
            }

            forgotSubmitBtn.disabled = true;
            forgotSubmitBtn.querySelector('span').textContent = 'Dispatching Passkey...';

            try {
                const response = await fetch('/api/auth/forgot-password', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username_or_email: target })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    showToast('success', 'Temporary password sent to email.');
                    if (data.dev_temp_pw) {
                        showAlert('success', `Temporary Passkey: ${data.dev_temp_pw}`);
                    } else {
                        showAlert('success', 'A temporary passkey has been dispatched to your email address.');
                    }

                    setTimeout(() => {
                        usernameInput.value = target;
                        passwordInput.value = data.dev_temp_pw || '';
                        switchView(viewLogin);
                        showAlert('info', 'Log in using your temporary passkey. You will then set a new password.');
                        passwordInput.focus();
                    }, data.dev_temp_pw ? 3500 : 2000);
                } else {
                    showAlert('error', data.detail || 'Unable to locate user account matching provided identifier.');
                }
            } catch (err) {
                showAlert('error', 'Network failure while dispatching password recovery request.');
            } finally {
                forgotSubmitBtn.disabled = false;
                forgotSubmitBtn.querySelector('span').textContent = 'Send Temporary Passkey';
            }
        });
    }

    /* ==========================================================================
       3. FORCE RESET PASSWORD HANDLER
       ========================================================================== */
    if (resetForm) {
        resetForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const newPw = newPasswordInput.value.trim();
            const confirmPw = confirmPasswordInput.value.trim();

            if (newPw.length < 8) {
                showAlert('error', 'New password must be at least 8 characters in length.');
                return;
            }

            if (newPw !== confirmPw) {
                showAlert('error', 'New password and confirmation do not match.');
                return;
            }

            const token = forceResetToken || sessionStorage.getItem('reset_token');
            if (!token) {
                showAlert('error', 'Session verification token lost. Please log in again.');
                setTimeout(() => switchView(viewLogin), 1500);
                return;
            }

            resetSubmitBtn.disabled = true;
            resetSubmitBtn.querySelector('span').textContent = 'Updating Passkey...';

            try {
                const response = await fetch('/api/auth/reset-password', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        new_password: newPw,
                        confirm_password: confirmPw
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    const freshToken = data.access_token || data.token || token;
                    localStorage.setItem('token', freshToken);
                    sessionStorage.removeItem('reset_token');

                    showToast('success', 'Passkey successfully updated! Launching console...');
                    showAlert('success', 'Credentials updated. Redirecting to Enterprise Dashboard...');
                    setTimeout(() => {
                        window.location.replace('/dashboard');
                    }, 600);
                } else {
                    showAlert('error', data.detail || 'Failed to update passkey. Please check password criteria.');
                }
            } catch (err) {
                showAlert('error', 'Network failure updating password credentials.');
            } finally {
                resetSubmitBtn.disabled = false;
                resetSubmitBtn.querySelector('span').textContent = 'Update Password & Launch';
            }
        });
    }

    /* ==========================================================================
       4. CORPORATE SSO (OIDC) HANDLER
       ========================================================================== */
    if (btnSsoLogin) {
        btnSsoLogin.addEventListener('click', function () {
            window.location.href = '/api/auth/sso/login';
        });
    }

    async function checkSsoReadiness() {
        try {
            const res = await fetch('/api/auth/sso/status');
            const data = await res.json();
            const ssoBox = document.getElementById('ssoContainer');
            if (ssoBox) {
                if (data.sso_enabled && data.client_configured) {
                    ssoBox.style.display = 'block';
                } else {
                    ssoBox.style.display = 'none';
                }
            }
        } catch (e) {
            // Keep container default state if network check fails
        }
    }
    checkSsoReadiness();

    /* ==========================================================================
       5. TWO-FACTOR AUTHENTICATION (TOTP MFA) HANDLER
       ========================================================================== */
    if (mfaForm) {
        mfaForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            hideAlert();

            const code = mfaCodeInput ? mfaCodeInput.value.trim() : '';
            const tempToken = mfaTempToken ? mfaTempToken.value.trim() : '';

            if (!code || code.length !== 6) {
                showAlert('error', 'Please enter a valid 6-digit verification code.');
                return;
            }

            if (mfaSubmitBtn) {
                mfaSubmitBtn.disabled = true;
                const txtSpan = mfaSubmitBtn.querySelector('span');
                if (txtSpan) txtSpan.textContent = 'Verifying Code...';
            }

            try {
                const response = await fetch('/api/auth/mfa/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        code: code,
                        temp_token: tempToken
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (response.ok) {
                    const token = data.access_token || data.token;
                    if (token) {
                        localStorage.setItem('token', token);
                        showToast('success', 'Two-Factor Authentication verified! Launching console...');
                        showAlert('success', 'Identity confirmed. Launching Command Center...');
                        setTimeout(() => {
                            window.location.replace('/dashboard');
                        }, 500);
                    } else {
                        throw new Error('Access token missing from MFA verification payload.');
                    }
                } else {
                    showAlert('error', data.detail || 'Invalid verification code. Please check your authenticator app.');
                }
            } catch (err) {
                showAlert('error', err.message || 'Verification failure connecting to authentication service.');
            } finally {
                if (mfaSubmitBtn) {
                    mfaSubmitBtn.disabled = false;
                    const txtSpan = mfaSubmitBtn.querySelector('span');
                    if (txtSpan) txtSpan.textContent = 'Verify Identity';
                }
            }
        });
    }

    if (cancelMfaBtn) {
        cancelMfaBtn.addEventListener('click', function () {
            if (mfaCodeInput) mfaCodeInput.value = '';
            if (mfaTempToken) mfaTempToken.value = '';
            switchView(viewLogin);
        });
    }

})();
